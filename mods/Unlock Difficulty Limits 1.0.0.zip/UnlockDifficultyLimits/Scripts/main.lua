-- ue4ss/Mods/UnlockDifficultyLimits/Scripts/main.lua
-- 解除世界難度與存檔設定之滑桿限制，支援超出3.0上限與精細數值調節

local config = {
    MaxSliderValue = 100.0,
    StepIncrements = 250,
    DecimalPlaces = 2,
    UnlockPostCreationEdit = true,
    VerboseLogging = false
}

local function logMessage(msg)
    print("[UnlockDifficultyLimits] " .. msg .. "\n")
end

local function loadConfig()
    local configPath = "ue4ss/Mods/UnlockDifficultyLimits/config.txt"
    -- 嘗試讀取 config.txt
    local f = io.open(configPath, "r")
    if not f then
        f = io.open("Mods/UnlockDifficultyLimits/config.txt", "r")
    end
    if f then
        for line in f:lines() do
            local k, v = line:match("^([%w_]+)%s*=%s*(.+)$")
            if k and v then
                v = v:gsub("%s+$", "")
                if k == "MaxSliderValue" then
                    config.MaxSliderValue = tonumber(v) or 100.0
                elseif k == "StepIncrements" then
                    config.StepIncrements = tonumber(v) or 250
                elseif k == "DecimalPlaces" then
                    config.DecimalPlaces = tonumber(v) or 2
                elseif k == "UnlockPostCreationEdit" then
                    config.UnlockPostCreationEdit = (v:lower() == "true")
                elseif k == "VerboseLogging" then
                    config.VerboseLogging = (v:lower() == "true")
                end
            end
        end
        f:close()
    end
end

loadConfig()

local excludedFlags = EObjectFlags.RF_ClassDefaultObject | EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_BeginDestroyed | EObjectFlags.RF_FinishDestroyed
local patchedCount = 0

local function patchDifficultyAsset(asset)
    if not asset or not asset:IsValid() or asset:HasAnyFlags(excludedFlags) then
        return false
    end

    local modified = false
    -- 1. 解除滑桿數據限制
    local sliderData = asset.FrontEndSliderData
    if sliderData then
        if sliderData.MaxValue < config.MaxSliderValue then
            sliderData.MaxValue = config.MaxSliderValue
            sliderData.AmountGamepadSteps = config.StepIncrements
            sliderData.AmountDecimalPlaces = config.DecimalPlaces
            modified = true
        end
    end

    -- 2. 解除建立世界後之修改限制
    if config.UnlockPostCreationEdit then
        if not asset.bCanBeChangedAfterWorldCreation then
            asset.bCanBeChangedAfterWorldCreation = true
            modified = true
        end
        -- PlayerAdjustable: 3 = AllModes, 1 = OnlyCustom
        if asset.PlayerAdjustable ~= 3 then
            asset.PlayerAdjustable = 3
            modified = true
        end
    end

    return modified
end

local function scanAllDifficultyAssets()
    local assets = FindAllOf("DifficultySettingData") or {}
    local currentPatched = 0
    for _, asset in ipairs(assets) do
        local ok, changed = pcall(patchDifficultyAsset, asset)
        if ok and changed then
            currentPatched = currentPatched + 1
        end
    end
    if currentPatched > 0 then
        patchedCount = patchedCount + currentPatched
        logMessage(string.format("已解除 %d 個難度設定資產之限制 (最大值: %.1f, 總計解除: %d)", currentPatched, config.MaxSliderValue, patchedCount))
    end
end

-- 延遲批次掃描
local scanScheduled = false
local function scheduleScan()
    if scanScheduled then return end
    scanScheduled = true
    ExecuteWithDelay(200, function()
        ExecuteInGameThread(function()
            scanScheduled = false
            scanAllDifficultyAssets()
        end)
    end)
end

local function onDifficultyConstructed()
    scheduleScan()
end

-- 註冊新物件回調
local function initMod()
    pcall(NotifyOnNewObject, "/Script/Dominion.DifficultySettingData", onDifficultyConstructed)
    -- 初始掃描已載入物件
    scheduleScan()
    logMessage(string.format("模組載入完成 (最大上限: %.1f, 小數精度: %d, 允許建立後修改: %s)", 
        config.MaxSliderValue, config.DecimalPlaces, tostring(config.UnlockPostCreationEdit)))
end

ExecuteInGameThread(initMod)
