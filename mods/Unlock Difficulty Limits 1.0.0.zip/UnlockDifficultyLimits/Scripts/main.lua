-- ue4ss/Mods/UnlockDifficultyLimits/Scripts/main.lua
-- 解除世界難度滑桿限制、提供遊戲內暫停選單 (Esc -> MODS) 即時調整與控制台輸入指令

local TAG = "[WorldSettings] "
local function logMessage(msg)
    print(TAG .. tostring(msg) .. "\n")
end

-- 映射 ModMenu 鍵值至官方 GameplayTag
local KEY_TO_TAG = {
    NoBuildingStability = "Difficulty.Player.NoBuildingStability",
    CarryCapacityScale = "Difficulty.Player.InventoryCarryCapacityScale",
    StaminaScale = "Difficulty.Player.StaminaScale",
    SpellCooldownScale = "Difficulty.Player.SpellCooldownScale",
    SpellCostScale = "Difficulty.Player.SpellCostScale",
    TeleportCostScale = "Difficulty.Player.TeleportationCostScale",
    XPGainScale = "Difficulty.Progression.XPGainScale",
    ProcessingSpeedScale = "Difficulty.Progression.ProcessingSpeedScale",
    CraftingCostScale = "Difficulty.Progression.CraftingCostScale",
    BuildingMaterialCostScale = "Difficulty.Progression.BuildingMaterialCostScale",
    EnduranceDrainScale = "Difficulty.SurvivalCore.EnduranceDrainScale",
    HydrationDrainScale = "Difficulty.SurvivalCore.HydrationDrainScale",
    SustenanceDrainScale = "Difficulty.SurvivalCore.SustenanceDrainScale",
    BossDamage = "Difficulty.AI.Boss.Damage",
}

local cfg = {
    NoBuildingStability = true,
    CarryCapacityScale = 3.0,
    StaminaScale = 2.1,
    SpellCooldownScale = 0.0,
    SpellCostScale = 0.0,
    TeleportCostScale = 0.0,
    XPGainScale = 3.0,
    ProcessingSpeedScale = 3.0,
    CraftingCostScale = 0.3,
    BuildingMaterialCostScale = 0.0,
    EnduranceDrainScale = 0.3,
    HydrationDrainScale = 0.3,
    SustenanceDrainScale = 0.3,
    BossDamage = 1.3,
    MaxSliderValue = 100.0,
    StepIncrements = 250,
    DecimalPlaces = 2,
    UnlockPostCreationEdit = true,
}

local function loadConfig()
    local paths = {
        "ue4ss/Mods/UnlockDifficultyLimits/config.txt",
        "Mods/UnlockDifficultyLimits/config.txt"
    }
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then
            for line in f:lines() do
                local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
                if k and cfg[k] ~= nil then
                    v = v:gsub("%s+[#;].*$", "")
                    if type(cfg[k]) == "boolean" then
                        cfg[k] = (v:lower() == "true")
                    elseif type(cfg[k]) == "number" then
                        cfg[k] = tonumber(v) or cfg[k]
                    else
                        cfg[k] = v
                    end
                end
            end
            f:close()
            break
        end
    end
end
loadConfig()

-- 1. 解除主選單與 DataAsset 滑桿上限限制 ----------------------------------------
local excludedFlags = EObjectFlags.RF_ClassDefaultObject | EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_BeginDestroyed | EObjectFlags.RF_FinishDestroyed

local function patchDifficultyAsset(asset)
    if not asset or not asset:IsValid() or asset:HasAnyFlags(excludedFlags) then
        return false
    end
    local modified = false
    local sliderData = asset.FrontEndSliderData
    if sliderData then
        if sliderData.MaxValue < cfg.MaxSliderValue then
            sliderData.MaxValue = cfg.MaxSliderValue
            sliderData.AmountGamepadSteps = cfg.StepIncrements
            sliderData.AmountDecimalPlaces = cfg.DecimalPlaces
            modified = true
        end
    end
    if cfg.UnlockPostCreationEdit then
        if not asset.bCanBeChangedAfterWorldCreation then
            asset.bCanBeChangedAfterWorldCreation = true
            modified = true
        end
        if asset.PlayerAdjustable ~= 3 then
            asset.PlayerAdjustable = 3
            modified = true
        end
    end
    return modified
end

local function scanAllDifficultyAssets()
    local assets = FindAllOf("DifficultySettingData") or {}
    for _, asset in ipairs(assets) do
        pcall(patchDifficultyAsset, asset)
    end
end

-- 2. 遊戲執行期即時修改難度 (Runtime In-Game Difficulty Apply) ----------------------
local function applySettingToRuntime(tagName, val)
    local numVal = tonumber(val)
    if not numVal then return false end

    local successCount = 0

    -- A. 更新 SurvivalDifficultyComponent
    local comps = FindAllOf("SurvivalDifficultyComponent") or {}
    for _, comp in ipairs(comps) do
        if comp:IsValid() then
            local repl = comp.ReplicatedDifficultySettings
            if repl and repl.CustomDifficultySettings then
                local found = false
                for _, entry in ipairs(repl.CustomDifficultySettings) do
                    local tname = entry.SettingTag and entry.SettingTag.TagName
                    if tname and tostring(tname) == tagName then
                        entry.SettingValue = numVal
                        found = true
                        break
                    end
                end
                -- 呼叫屬性同步重算
                pcall(function() comp:OnRep_DifficultySettings() end)
                successCount = successCount + 1
            end
        end
    end

    -- B. 更新 PersistenceSubsystem (若在世界中)
    local persists = FindAllOf("PersistenceSubsystem") or {}
    for _, persist in ipairs(persists) do
        if persist:IsValid() and persist.WorldSaveSettings then
            local custom = persist.WorldSaveSettings.CustomDifficultySettings
            if custom then
                pcall(function()
                    custom[tagName] = numVal
                end)
                successCount = successCount + 1
            end
        end
    end

    return successCount > 0
end

local function applyAllConfigSettings()
    for key, tag in pairs(KEY_TO_TAG) do
        local val = cfg[key]
        if type(val) == "boolean" then
            val = val and 1.0 or 0.0
        end
        applySettingToRuntime(tag, val)
    end
end

-- 3. 遊戲內 Mod Menu 支援 (暫停選單 Esc -> MODS 即時同步) -----------------------
local MODMENU_ID = "UnlockDifficultyLimits"
local mmRev = nil

local function syncFromModMenu()
    local ok, rev = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".rev") end)
    if not ok or type(rev) ~= "number" or rev == mmRev then return end
    mmRev = rev

    local changed = false
    for key, oldVal in pairs(cfg) do
        local okV, newVal = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. "." .. key) end)
        if okV and newVal ~= nil and newVal ~= oldVal then
            cfg[key] = newVal
            changed = true
            local tag = KEY_TO_TAG[key]
            if tag then
                local fval = newVal
                if type(newVal) == "boolean" then fval = newVal and 1.0 or 0.0 end
                applySettingToRuntime(tag, fval)
                logMessage(string.format("Mod Menu 變更: %s (%s) = %s", key, tag, tostring(newVal)))
            end
        end
    end
end

-- 4. 註冊遊戲內控制台指令 (Console Commands) 支援手動輸入精準數值 ------------------
local function registerConsoleCommands()
    -- SetXP <數值>
    pcall(RegisterConsoleCommandHandler, "setxp", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.XPGainScale = val
            applySettingToRuntime(KEY_TO_TAG.XPGainScale, val)
            local msg = string.format("[世界設定] 經驗值獲得倍率已設定為: %.2fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("用法: setxp <數值> (例如: setxp 10)") end) end
        end
        return true
    end)

    -- SetCarry <數值>
    pcall(RegisterConsoleCommandHandler, "setcarry", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.CarryCapacityScale = val
            applySettingToRuntime(KEY_TO_TAG.CarryCapacityScale, val)
            local msg = string.format("[世界設定] 背包負重容量倍率已設定為: %.1fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("用法: setcarry <數值> (例如: setcarry 50)") end) end
        end
        return true
    end)

    -- SetStamina <數值>
    pcall(RegisterConsoleCommandHandler, "setstamina", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.StaminaScale = val
            applySettingToRuntime(KEY_TO_TAG.StaminaScale, val)
            local msg = string.format("[世界設定] 耐力上限倍率已設定為: %.2fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- SetCooldown <數值>
    pcall(RegisterConsoleCommandHandler, "setcooldown", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.SpellCooldownScale = val
            applySettingToRuntime(KEY_TO_TAG.SpellCooldownScale, val)
            local msg = string.format("[世界設定] 法術冷卻時間倍率已設定為: %.2fx (0=無冷卻)", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- SetCost <數值>
    pcall(RegisterConsoleCommandHandler, "setcost", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.SpellCostScale = val
            applySettingToRuntime(KEY_TO_TAG.SpellCostScale, val)
            local msg = string.format("[世界設定] 法術魔力消耗倍率已設定為: %.2fx (0=無消耗)", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- NoStability <1 或 0>
    pcall(RegisterConsoleCommandHandler, "nostability", function(_, params, ar)
        local raw = params and params[1]
        local enable = (raw == "1" or raw == "true" or raw == "on")
        cfg.NoBuildingStability = enable
        applySettingToRuntime(KEY_TO_TAG.NoBuildingStability, enable and 1.0 or 0.0)
        local msg = string.format("[世界設定] 無建築穩定性 (免支撐搭建): %s", enable and "開啟 (已啟用)" or "關閉 (依賴支撐)")
        logMessage(msg)
        if ar then pcall(function() ar:Log(msg) end) end
        return true
    end)

    -- SetDiff <關鍵字> <數值>
    pcall(RegisterConsoleCommandHandler, "setdiff", function(_, params, ar)
        if not params or #params < 2 then
            if ar then pcall(function() ar:Log("用法: setdiff <名稱> <數值> (例如: setdiff xp 10 或 setdiff carry 50)") end) end
            return true
        end
        local k = tostring(params[1]):lower()
        local v = tonumber(params[2])
        if not v then
            if ar then pcall(function() ar:Log("請提供有效數值！") end) end
            return true
        end

        local targetTag = nil
        if k:find("xp") then targetTag = KEY_TO_TAG.XPGainScale
        elseif k:find("carry") or k:find("weight") then targetTag = KEY_TO_TAG.CarryCapacityScale
        elseif k:find("stam") then targetTag = KEY_TO_TAG.StaminaScale
        elseif k:find("cool") then targetTag = KEY_TO_TAG.SpellCooldownScale
        elseif k:find("cost") then targetTag = KEY_TO_TAG.SpellCostScale
        elseif k:find("speed") or k:find("process") then targetTag = KEY_TO_TAG.ProcessingSpeedScale
        elseif k:find("stab") then targetTag = KEY_TO_TAG.NoBuildingStability
        elseif k:find("boss") then targetTag = KEY_TO_TAG.BossDamage
        end

        if targetTag then
            applySettingToRuntime(targetTag, v)
            local msg = string.format("[世界設定] %s 已即時套用數值: %.2f", targetTag, v)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("未識別之設定名稱，支援: xp, carry, stam, cool, cost, speed, stab, boss") end) end
        end
        return true
    end)

    -- DiffStatus 查看當前狀態
    pcall(RegisterConsoleCommandHandler, "diffstatus", function(_, _, ar)
        local lines = {
            "=== 當前世界難度自訂設定 ===",
            string.format("無建築穩定性: %s", cfg.NoBuildingStability and "開啟" or "關閉"),
            string.format("經驗值獲得倍率: %.2fx", cfg.XPGainScale),
            string.format("背包負重容量倍率: %.1fx", cfg.CarryCapacityScale),
            string.format("耐力上限倍率: %.2fx", cfg.StaminaScale),
            string.format("法術冷卻倍率: %.2fx", cfg.SpellCooldownScale),
            string.format("法術消耗倍率: %.2fx", cfg.SpellCostScale),
            string.format("加工精煉速度: %.2fx", cfg.ProcessingSpeedScale),
            "提示: 可使用 'setxp <數值>'、'setcarry <數值>' 等隨時修改！"
        }
        for _, l in ipairs(lines) do
            logMessage(l)
            if ar then pcall(function() ar:Log(l) end) end
        end
        return true
    end)
end

-- 5. 主循環與初始化 -------------------------------------------------------------
local function loop()
    syncFromModMenu()
end

local function initMod()
    -- 解除 DataAsset 滑桿上限
    scanAllDifficultyAssets()
    pcall(NotifyOnNewObject, "/Script/Dominion.DifficultySettingData", scanAllDifficultyAssets)

    -- 當進入世界時自動套用設定
    pcall(NotifyOnNewObject, "/Script/Dominion.SurvivalDifficultyComponent", function()
        ExecuteWithDelay(1000, function()
            ExecuteInGameThread(applyAllConfigSettings)
        end)
    end)

    -- 註冊控制台指令
    registerConsoleCommands()

    -- 啟動遊戲線程定時同步 Mod Menu
    if not pcall(LoopInGameThreadWithDelay, 600, function() pcall(loop) end) then
        LoopAsync(600, function() pcall(loop); return false end)
    end

    logMessage("遊戲內世界設定模組已就緒！支援 Mod Menu (Esc -> MODS) 與控制台指令 (setxp, setcarry...)")
end

ExecuteInGameThread(initMod)
