-- ue4ss/Mods/UnlockDifficultyLimits/Scripts/main.lua
-- 解除世界難度滑桿限制 (突破 3.0 上限至 300.0)
-- 解決級距粗暴跳躍 (修正滑桿步長為 0.05，解除滑鼠強制吸附，實現絲滑微調)
-- 提供遊戲內暫停選單 (Esc -> MODS) 即時調整與控制台輸入指令 (setxp, setcarry, setdiff 等)

local TAG = "[WorldSettings] "
local function logMessage(msg)
    print(TAG .. tostring(msg) .. "\n")
end

-- 映射 ModMenu 鍵值至官方 GameplayTag
local KEY_TO_TAG = {
    NoBuildingStability = "Difficulty.Player.NoBuildingStability",
    CarryCapacityScale = "Difficulty.Player.InventoryCarryCapacityScale",
    StaminaScale = "Difficulty.Player.StaminaScale",
    SpellCooldownScale = "Difficulty.Player.SpellCooldownScale",
    SpellCostScale = "Difficulty.Player.SpellCostScale",
    TeleportCostScale = "Difficulty.Player.TeleportationCostScale",
    XPGainScale = "Difficulty.Progression.XPGainScale",
    ProcessingSpeedScale = "Difficulty.Progression.ProcessingSpeedScale",
    CraftingCostScale = "Difficulty.Progression.CraftingCostScale",
    BuildingMaterialCostScale = "Difficulty.Progression.BuildingMaterialCostScale",
    EnduranceDrainScale = "Difficulty.SurvivalCore.EnduranceDrainScale",
    HydrationDrainScale = "Difficulty.SurvivalCore.HydrationDrainScale",
    SustenanceDrainScale = "Difficulty.SurvivalCore.SustenanceDrainScale",
    BossDamage = "Difficulty.AI.Boss.Damage",
}

local cfg = {
    NoBuildingStability = true,
    CarryCapacityScale = 3.0,
    StaminaScale = 2.1,
    SpellCooldownScale = 0.0,
    SpellCostScale = 0.0,
    TeleportCostScale = 0.0,
    XPGainScale = 3.0,
    ProcessingSpeedScale = 3.0,
    CraftingCostScale = 0.3,
    BuildingMaterialCostScale = 0.0,
    EnduranceDrainScale = 0.3,
    HydrationDrainScale = 0.3,
    SustenanceDrainScale = 0.3,
    BossDamage = 1.3,
    MaxSliderValue = 300.0,
    StepSize = 0.05,
    NumGamepadSliderIncrements = 3000,
    DecimalPlaces = 2,
    UnlockPostCreationEdit = true,
}

local function loadConfig()
    local paths = {
        "ue4ss/Mods/UnlockDifficultyLimits/config.txt",
        "Mods/UnlockDifficultyLimits/config.txt"
    }
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then
            for line in f:lines() do
                local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
                if k and cfg[k] ~= nil then
                    v = v:gsub("%s+[#;].*$", "")
                    if type(cfg[k]) == "boolean" then
                        cfg[k] = (v:lower() == "true")
                    elseif type(cfg[k]) == "number" then
                        cfg[k] = tonumber(v) or cfg[k]
                    else
                        cfg[k] = v
                    end
                end
            end
            f:close()
            break
        end
    end
end
loadConfig()

-- 1. 解除 DataAsset 上限限制 ----------------------------------------------------
local excludedFlags = EObjectFlags.RF_ClassDefaultObject | EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_BeginDestroyed | EObjectFlags.RF_FinishDestroyed

local function patchDifficultyAsset(asset)
    if not asset or not asset:IsValid() or asset:HasAnyFlags(excludedFlags) then
        return false
    end
    local modified = false
    local sliderData = asset.FrontEndSliderData
    if sliderData then
        if sliderData.MaxValue < cfg.MaxSliderValue then
            sliderData.MaxValue = cfg.MaxSliderValue
            sliderData.AmountGamepadSteps = 250
            sliderData.AmountDecimalPlaces = cfg.DecimalPlaces
            modified = true
        end
    end
    if cfg.UnlockPostCreationEdit then
        if not asset.bCanBeChangedAfterWorldCreation then
            asset.bCanBeChangedAfterWorldCreation = true
            modified = true
        end
        if asset.PlayerAdjustable ~= 3 then
            asset.PlayerAdjustable = 3
            modified = true
        end
    end
    return modified
end

local function scanAllDifficultyAssets()
    local assets = FindAllOf("DifficultySettingData") or {}
    for _, asset in ipairs(assets) do
        pcall(patchDifficultyAsset, asset)
    end
end

-- 2. 核心修正：動態優化遊戲內滑桿元件 (SliderUIInput / WBP_Settings_Slider_C) -------
-- 徹底解決「拉一格跳 10.00x」的問題：
--   1) 提高 NumGamepadSliderIncrements 至 3000，使控制器/方向鍵每步僅 0.05~0.1
--   2) 設定 USlider.StepSize = 0.05
--   3) 關閉 USlider.MouseUsesStep (設為 false)，滑鼠拖曳完全平滑無卡頓吸附，精準停留於任意小數
--   4) 保持 AmountDecimalPlacesToShow = 2，顯示為 1.25x、3.50x 等乾淨數值
local function patchSliderWidget(sliderWidget)
    if not sliderWidget or not sliderWidget:IsValid() or sliderWidget:HasAnyFlags(excludedFlags) then
        return false
    end
    local modified = false
    pcall(function()
        -- 設定顯示小數位數
        if sliderWidget.AmountDecimalPlacesToShow ~= cfg.DecimalPlaces then
            sliderWidget.AmountDecimalPlacesToShow = cfg.DecimalPlaces
            modified = true
        end

        -- 大幅提升級距分割數，防止計算步長時除以 10 導致一次跳 10.00
        if sliderWidget.NumGamepadSliderIncrements and sliderWidget.NumGamepadSliderIncrements < cfg.NumGamepadSliderIncrements then
            sliderWidget.NumGamepadSliderIncrements = cfg.NumGamepadSliderIncrements
            modified = true
        end

        -- 更新初始最大值
        if sliderWidget.InitialMaxSliderValue and sliderWidget.InitialMaxSliderValue < cfg.MaxSliderValue then
            sliderWidget.InitialMaxSliderValue = cfg.MaxSliderValue
            modified = true
        end

        -- 調整內層 USlider 控制元件
        local innerSlider = sliderWidget.InputSlider
        if innerSlider and innerSlider:IsValid() then
            -- 關閉滑鼠粗暴吸附 (關鍵修正)
            if innerSlider.MouseUsesStep ~= false then
                innerSlider.MouseUsesStep = false
                modified = true
            end

            -- 設定極細步長 (0.05)
            if innerSlider.StepSize ~= cfg.StepSize then
                pcall(function() innerSlider:SetStepSize(cfg.StepSize) end)
                innerSlider.StepSize = cfg.StepSize
                modified = true
            end

            -- 同步最大值
            if innerSlider.MaxValue < cfg.MaxSliderValue then
                pcall(function() innerSlider:SetMaxValue(cfg.MaxSliderValue) end)
                innerSlider.MaxValue = cfg.MaxSliderValue
                modified = true
            end
        end
    end)
    return modified
end

local function scanAndPatchAllSliders()
    local count = 0
    local widgets = FindAllOf("SliderUIInput") or {}
    for _, w in ipairs(widgets) do
        if patchSliderWidget(w) then count = count + 1 end
    end
    local wbpWidgets = FindAllOf("WBP_Settings_Slider_C") or {}
    for _, w in ipairs(wbpWidgets) do
        if patchSliderWidget(w) then count = count + 1 end
    end
    return count
end

-- 3. 遊戲執行期即時修改難度 (Runtime In-Game Difficulty Apply) ----------------------
local function applySettingToRuntime(tagName, val)
    local numVal = tonumber(val)
    if not numVal then return false end

    local successCount = 0

    -- A. 更新 SurvivalDifficultyComponent
    local comps = FindAllOf("SurvivalDifficultyComponent") or {}
    for _, comp in ipairs(comps) do
        if comp:IsValid() then
            local repl = comp.ReplicatedDifficultySettings
            if repl and repl.CustomDifficultySettings then
                local found = false
                for _, entry in ipairs(repl.CustomDifficultySettings) do
                    local tname = entry.SettingTag and entry.SettingTag.TagName
                    if tname and tostring(tname) == tagName then
                        entry.SettingValue = numVal
                        found = true
                        break
                    end
                end
                -- 呼叫屬性同步重算
                pcall(function() comp:OnRep_DifficultySettings() end)
                successCount = successCount + 1
            end
        end
    end

    -- B. 更新 PersistenceSubsystem (若在世界中)
    local persists = FindAllOf("PersistenceSubsystem") or {}
    for _, persist in ipairs(persists) do
        if persist:IsValid() and persist.WorldSaveSettings then
            local custom = persist.WorldSaveSettings.CustomDifficultySettings
            if custom then
                pcall(function()
                    custom[tagName] = numVal
                end)
                successCount = successCount + 1
            end
        end
    end

    return successCount > 0
end

local function applyAllConfigSettings()
    for key, tag in pairs(KEY_TO_TAG) do
        local val = cfg[key]
        if type(val) == "boolean" then
            val = val and 1.0 or 0.0
        end
        applySettingToRuntime(tag, val)
    end
end

-- 4. 遊戲內 Mod Menu 支援 (暫停選單 Esc -> MODS 即時同步) -----------------------
local MODMENU_ID = "UnlockDifficultyLimits"
local mmRev = nil

local function syncFromModMenu()
    local ok, rev = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".rev") end)
    if not ok or type(rev) ~= "number" or rev == mmRev then return end
    mmRev = rev

    local changed = false
    for key, oldVal in pairs(cfg) do
        local okV, newVal = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. "." .. key) end)
        if okV and newVal ~= nil and newVal ~= oldVal then
            cfg[key] = newVal
            changed = true
            local tag = KEY_TO_TAG[key]
            if tag then
                local fval = newVal
                if type(newVal) == "boolean" then fval = newVal and 1.0 or 0.0 end
                applySettingToRuntime(tag, fval)
                logMessage(string.format("Mod Menu 變更: %s (%s) = %s", key, tag, tostring(newVal)))
            end
        end
    end
end

-- 5. 註冊遊戲內控制台指令 (Console Commands) 支援鍵盤直接輸入精準數字 ------------------
local function registerConsoleCommands()
    -- SetXP <數值>
    pcall(RegisterConsoleCommandHandler, "setxp", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.XPGainScale = val
            applySettingToRuntime(KEY_TO_TAG.XPGainScale, val)
            local msg = string.format("[世界設定] 經驗值獲得倍率已設定為: %.2fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("用法: setxp <數值> (例如: setxp 10 或 setxp 100)") end) end
        end
        return true
    end)

    -- SetCarry <數值>
    pcall(RegisterConsoleCommandHandler, "setcarry", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.CarryCapacityScale = val
            applySettingToRuntime(KEY_TO_TAG.CarryCapacityScale, val)
            local msg = string.format("[世界設定] 背包負重容量倍率已設定為: %.1fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("用法: setcarry <數值> (例如: setcarry 50 或 setcarry 200)") end) end
        end
        return true
    end)

    -- SetStamina <數值>
    pcall(RegisterConsoleCommandHandler, "setstamina", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.StaminaScale = val
            applySettingToRuntime(KEY_TO_TAG.StaminaScale, val)
            local msg = string.format("[世界設定] 耐力上限倍率已設定為: %.2fx", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- SetCooldown <數值>
    pcall(RegisterConsoleCommandHandler, "setcooldown", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.SpellCooldownScale = val
            applySettingToRuntime(KEY_TO_TAG.SpellCooldownScale, val)
            local msg = string.format("[世界設定] 法術冷卻時間倍率已設定為: %.2fx (0=無冷卻)", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- SetCost <數值>
    pcall(RegisterConsoleCommandHandler, "setcost", function(_, params, ar)
        local val = params and tonumber(params[1])
        if val then
            cfg.SpellCostScale = val
            applySettingToRuntime(KEY_TO_TAG.SpellCostScale, val)
            local msg = string.format("[世界設定] 法術魔力消耗倍率已設定為: %.2fx (0=無消耗)", val)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        end
        return true
    end)

    -- NoStability <1 或 0>
    pcall(RegisterConsoleCommandHandler, "nostability", function(_, params, ar)
        local raw = params and params[1]
        local enable = (raw == "1" or raw == "true" or raw == "on")
        cfg.NoBuildingStability = enable
        applySettingToRuntime(KEY_TO_TAG.NoBuildingStability, enable and 1.0 or 0.0)
        local msg = string.format("[世界設定] 無建築穩定性 (免支撐搭建): %s", enable and "開啟 (已啟用)" or "關閉 (依賴支撐)")
        logMessage(msg)
        if ar then pcall(function() ar:Log(msg) end) end
        return true
    end)

    -- SetDiff <關鍵字> <數值>
    pcall(RegisterConsoleCommandHandler, "setdiff", function(_, params, ar)
        if not params or #params < 2 then
            if ar then pcall(function() ar:Log("用法: setdiff <名稱> <數值> (例如: setdiff xp 10 或 setdiff carry 50)") end) end
            return true
        end
        local k = tostring(params[1]):lower()
        local v = tonumber(params[2])
        if not v then
            if ar then pcall(function() ar:Log("請提供有效數值！") end) end
            return true
        end

        local targetTag = nil
        if k:find("xp") then targetTag = KEY_TO_TAG.XPGainScale
        elseif k:find("carry") or k:find("weight") then targetTag = KEY_TO_TAG.CarryCapacityScale
        elseif k:find("stam") then targetTag = KEY_TO_TAG.StaminaScale
        elseif k:find("cool") then targetTag = KEY_TO_TAG.SpellCooldownScale
        elseif k:find("cost") then targetTag = KEY_TO_TAG.SpellCostScale
        elseif k:find("speed") or k:find("process") then targetTag = KEY_TO_TAG.ProcessingSpeedScale
        elseif k:find("craft") then targetTag = KEY_TO_TAG.CraftingCostScale
        elseif k:find("build") then targetTag = KEY_TO_TAG.BuildingMaterialCostScale
        elseif k:find("endur") then targetTag = KEY_TO_TAG.EnduranceDrainScale
        elseif k:find("hydra") or k:find("thirst") then targetTag = KEY_TO_TAG.HydrationDrainScale
        elseif k:find("sust") or k:find("hunger") then targetTag = KEY_TO_TAG.SustenanceDrainScale
        elseif k:find("stab") then targetTag = KEY_TO_TAG.NoBuildingStability
        elseif k:find("boss") then targetTag = KEY_TO_TAG.BossDamage
        end

        if targetTag then
            applySettingToRuntime(targetTag, v)
            local msg = string.format("[世界設定] %s 已即時套用數值: %.2f", targetTag, v)
            logMessage(msg)
            if ar then pcall(function() ar:Log(msg) end) end
        else
            if ar then pcall(function() ar:Log("未識別之設定名稱，支援: xp, carry, stam, cool, cost, speed, craft, build, endur, thirst, hunger, stab, boss") end) end
        end
        return true
    end)

    -- DiffStatus 查看當前狀態
    pcall(RegisterConsoleCommandHandler, "diffstatus", function(_, _, ar)
        local lines = {
            "=== 當前世界難度自訂設定 ===",
            string.format("無建築穩定性: %s", cfg.NoBuildingStability and "開啟" or "關閉"),
            string.format("經驗值獲得倍率: %.2fx", cfg.XPGainScale),
            string.format("背包負重容量倍率: %.1fx", cfg.CarryCapacityScale),
            string.format("耐力上限倍率: %.2fx", cfg.StaminaScale),
            string.format("法術冷卻倍率: %.2fx", cfg.SpellCooldownScale),
            string.format("法術消耗倍率: %.2fx", cfg.SpellCostScale),
            string.format("加工精煉速度: %.2fx", cfg.ProcessingSpeedScale),
            "提示: 可使用 'setxp <數值>'、'setcarry <數值>' 或 'setdiff <名稱> <數值>' 隨時鍵盤精準修改！"
        }
        for _, l in ipairs(lines) do
            logMessage(l)
            if ar then pcall(function() ar:Log(l) end) end
        end
        return true
    end)
end

-- 6. 主循環與初始化 -------------------------------------------------------------
local function loop()
    syncFromModMenu()
    scanAndPatchAllSliders()
end

local function initMod()
    -- 解除 DataAsset 滑桿上限
    scanAllDifficultyAssets()
    pcall(NotifyOnNewObject, "/Script/Dominion.DifficultySettingData", scanAllDifficultyAssets)

    -- 註冊滑桿元件與世界設定選單監聽
    pcall(NotifyOnNewObject, "/Script/Dominion.SliderUIInput", patchSliderWidget)
    pcall(NotifyOnNewObject, "/Game/UI/Settings/WBP_Settings_Slider.WBP_Settings_Slider_C", patchSliderWidget)
    pcall(NotifyOnNewObject, "/Script/Dominion.MainMenuWorldAdvancedSettingsSubWidget", function()
        ExecuteWithDelay(200, function() ExecuteInGameThread(scanAndPatchAllSliders) end)
    end)
    pcall(NotifyOnNewObject, "/Game/UI/MainMenu/CreateWorld/WBP_MainMenu_CreateWorld_AdvancedSettings.WBP_MainMenu_CreateWorld_AdvancedSettings_C", function()
        ExecuteWithDelay(200, function() ExecuteInGameThread(scanAndPatchAllSliders) end)
    end)

    -- 當進入世界時自動套用設定
    pcall(NotifyOnNewObject, "/Script/Dominion.SurvivalDifficultyComponent", function()
        ExecuteWithDelay(1000, function()
            ExecuteInGameThread(applyAllConfigSettings)
        end)
    end)

    -- 註冊控制台指令
    registerConsoleCommands()

    -- 啟動遊戲線程定時同步 (每 300ms 維持滑桿極致平滑與 ModMenu 同步)
    if not pcall(LoopInGameThreadWithDelay, 300, function() pcall(loop) end) then
        LoopAsync(300, function() pcall(loop); return false end)
    end

    logMessage("世界難度解鎖與滑桿平滑模組已就緒！上限 300.0，步長 0.05 絲滑拖曳，支援控制台與 Mod Menu！")
end

ExecuteInGameThread(initMod)
