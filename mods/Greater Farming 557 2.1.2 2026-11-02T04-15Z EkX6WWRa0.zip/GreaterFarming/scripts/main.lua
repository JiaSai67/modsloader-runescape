-- ============================================================
-- Come Correct Gaming (CCG) | KPNC
-- Free community mod for RuneScape: Dragonwilds
-- ============================================================


local CFG_ENTRIES = {
    { "Mucksplosion",          "true",   "Turn the larger Mucksplosion range on or off" },
    { "MucksplosionRadius",    "4000", "Mucksplosion range (default game value is 100)" },
    { "Humidify",              "true",   "Turn the larger Humidify range on or off" },
    { "HumidifyRadius",        "4000", "Humidify range (default game value is 150)" },
    { "Cooldowns",             "false",  "Turn shorter spell cooldowns on or off" },
    { "CooldownMultiplier",    "0.5",  "0.5 = half the normal cooldown; 1.0 = normal cooldown" },
    { "AxtralProjection",      "true",   "Turn the Axtral Projection changes on or off" },
    { "AxtralDistance",        "4000", "How far the axe travels (default is 2000)" },
    { "AxtralSpeed",           "2000", "How fast the axe travels (default is 1000)" },
    { "AxtralWidth",           "3",    "How wide the axe hits to the sides (1 = normal, 0 = unchanged). Very high values shorten the forward range" },
    { "Splinter",              "true",   "Turn the larger Splinter range on or off" },
    { "SplinterRadiusMultiplier","3",  "Size of the Splinter area (1 = normal)" },
    { "SplinterPlacementDistance","3000","How far away Splinter can be placed (1500 = normal; 0 = unchanged)" },
    { "AgilityOrbs",           "true",   "Turn the larger agility orb pickup range on or off" },
    { "AgilityOrbRadius",      "3",    "Agility orb pickup size (1 = normal, 3 = three times bigger, max 5; 0 = unchanged)" },
    { "Runecrafting",          "true",   "Turn the higher runecrafting limit on or off" },
    { "RuneLimit",             "1000", "Maximum runes per craft" },
    { "AutocraftBonus",        "true",   "Give autocraft the full +100% bonus runes (experimental)" },
    { "AutocraftXP",           "1.0",  "Autocraft XP (0.25 = normal; 1.0 = full XP; 0 = unchanged)" },
    { "CarryWeightPercent",    "100",  "How much your items weigh, in percent (100 = normal, 50 = half, 0 = weightless)" },
    { "CarryWeightBase",       "550",  "Your normal carry limit (shown in the inventory). Only change if the numbers look off" },
    { "DebugDump",             "false",  "Extra UE4SS logging for troubleshooting (leave off unless needed)" },
}

local MOD_DIR = "."
do
    local src = ""
    pcall(function() src = debug.getinfo(1, "S").source or "" end)
    MOD_DIR = src:match("^@?(.*)[\\/][Ss]cripts[\\/][^\\/]*$") or src:match("^@?(.*)[\\/][^\\/]*$") or "."
end

local CFG = {}
do
    local path = MOD_DIR .. "\\config.txt"

    local f = io.open(path, "r")
    if f then
        for line in f:lines() do
            line = line:gsub("#.*$", "")
            local k, v = line:match("^%s*([%w_]+)%s*[=:]%s*(.-)%s*$")
            if k and v and v ~= "" then CFG[k:lower()] = v:lower() end
        end
        f:close()
    else
        local out = io.open(path, "w")
        if out then
            out:write("# Greater Farming settings | CCG - KPNC\n")
            out:write("# Change what you want below and save the file. Then restart the game to apply the changes.\n")
            out:write("# true = enabled, false = disabled. If a setting is missing, the mod uses its default.\n# With the Mod Menu mod installed you can also change these in game: Esc > MODS > Greater Farming.\n\n")
            for _, e in ipairs(CFG_ENTRIES) do
                out:write(string.format("%-24s = %-6s  # %s\n", e[1], e[2], e[3]))
            end
            out:close()
        end
    end
end

-- ---------------------------------------------------------------------
-- originals.txt prevents stacked changes; reuse vanilla values only when applied values match.
-- ---------------------------------------------------------------------
local ORIG_PATH = MOD_DIR .. "\\originals.txt"
local ORIG = {}
local origDirty = false
do
    local f = io.open(ORIG_PATH, "r")
    if f then
        for line in f:lines() do
            local k, o, ap = line:match("^(.-)\t(%S+)\t(%S+)%s*$")
            if k and tonumber(o) and tonumber(ap) then ORIG[k] = { orig = tonumber(o), applied = tonumber(ap) } end
        end
        f:close()
    end
end

local function orig_flush()
    if not origDirty then return end
    local f = io.open(ORIG_PATH, "w")
    if f then
        for k, e in pairs(ORIG) do
            f:write(string.format("%s\t%.9g\t%.9g\n", k, e.orig, e.applied))
        end
        f:close()
        origDirty = false
    end
end

local function resolve_original(key, current)
    local e = ORIG[key]
    if e and math.abs(current - e.applied) < 0.01 then return e.orig end
    return current
end

local function record_applied(key, orig, applied)
    local e = ORIG[key]
    if e and math.abs(e.orig - orig) < 0.0001 and math.abs(e.applied - applied) < 0.0001 then return end
    ORIG[key] = { orig = orig, applied = applied }
    origDirty = true
end

local function cfg_default(key)
    for _, e in ipairs(CFG_ENTRIES) do
        if e[1]:lower() == key:lower() then return e[2] end
    end
end

local function cfg_bool(key)
    local v = CFG[key:lower()] or cfg_default(key)
    return v == "on" or v == "true" or v == "yes" or v == "1"
end

local function cfg_num(key)
    local v = tonumber(CFG[key:lower()])
    if v == nil then v = tonumber(cfg_default(key)) end
    return v
end

-- Mod Menu refresh handlers.
local REFRESH = {}

local TARGETS = {
    {
        name = "Mucksplosion (Compost)",
        path = "/Agility/Gameplay/UtilityMagic/PerkSpells/Farming/USD_Farming_Compost.USD_Farming_Compost",
        radius_key = "MucksplosionRadius", enabled_key = "Mucksplosion",
        new_radius = cfg_num("MucksplosionRadius"),
        enabled = cfg_bool("Mucksplosion"),
    },
    {
        name = "Humidify",
        path = "/Game/Gameplay/UtilityMagic/PerkSpells/Farming/Humidify/USD_Humidify.USD_Humidify",
        radius_key = "HumidifyRadius", enabled_key = "Humidify",
        new_radius = cfg_num("HumidifyRadius"),
        enabled = cfg_bool("Humidify"),
    },
}

local KEYWORD_TARGETS = {
    {
        name = "Rocksplosion",
        keyword = "rocksplosion",
        new_radius = 1500.0,
    },
    {
        name = "Trunk Totem",
        keyword = "pileemup",
        keyword2 = "totem",
        new_radius = 600.0,
    },
}

local COOLDOWN_MULTIPLIER = cfg_num("CooldownMultiplier")
local COOLDOWNS_ENABLED = cfg_bool("Cooldowns")

local function log(fmt, ...)
    print(string.format("[GreaterFarming] " .. fmt, ...))
end
-- ---------------------------------------------------------------------
-- Single game-thread scheduler avoids concurrent Lua calls. Tasks sleep when finished.
-- PerfLog = true enables task and search timing.
-- ---------------------------------------------------------------------
local PERF = ({ ["true"] = true, ["1"] = true, ["on"] = true, ["yes"] = true })[CFG["perflog"] or ""] == true

local TICK_MS = 250
local tickCount = 0
local tasks, delayed = {}, {}
local perfStats, perfEvents = {}, {}

local function perf_add(label, seconds, objs)
    local s = perfStats[label]
    if not s then s = { calls = 0, total = 0, max = 0 }; perfStats[label] = s end
    s.calls = s.calls + 1
    s.total = s.total + seconds
    if seconds > s.max then s.max = seconds end
    s.objs = objs
end

local function bump(label)   -- PerfLog event counter.
    if PERF then perfEvents[label] = (perfEvents[label] or 0) + 1 end
end

-- A task sleeps on true; wake() restarts it.
local function add_task(name, ms, fn)
    local t = { name = name, n = math.max(1, math.floor(ms / TICK_MS + 0.5)), fn = fn, on = true, nextTick = 0, fails = 0 }
    tasks[#tasks + 1] = t
    return t
end

local function wake(t)
    t.on = true
    t.fails = 0
    t.nextTick = 0
end

local function later(ms, fn)   -- Deferred game-thread callback.
    delayed[#delayed + 1] = { due = tickCount + math.max(1, math.ceil(ms / TICK_MS)), fn = fn }
end

-- Global object search with optional timing.
local function find_all(name)
    local t0 = PERF and os.clock() or 0
    local ok, list = pcall(FindAllOf, name)
    if PERF then perf_add("FindAllOf " .. name, os.clock() - t0, (ok and type(list) == "table") and #list or 0) end
    if ok and list ~= nil then return list end
    return nil
end

local function run_tick()
    tickCount = tickCount + 1

    if #delayed > 0 then
        local pending = delayed
        delayed = {}
        for _, d in ipairs(pending) do
            if tickCount >= d.due then
                pcall(d.fn)
            else
                delayed[#delayed + 1] = d
            end
        end
    end

    for _, t in ipairs(tasks) do
        if t.on and tickCount >= t.nextTick then
            t.nextTick = tickCount + t.n
            local t0 = PERF and os.clock() or 0
            local ok, done = pcall(t.fn)
            if PERF then perf_add("task " .. t.name, os.clock() - t0) end
            if not ok and not t.errLogged then
                t.errLogged = true
                log("%s task error: %s", t.name, tostring(done))
            end
            if ok and done == true then
                t.on = false
            else
                t.fails = t.fails + 1
                -- Back off while assets are unavailable.
                if t.slow and t.fails >= 40 then t.nextTick = tickCount + t.n * 10 end
            end
        end
    end
end

local function start_scheduler()
    if type(LoopInGameThreadWithDelay) == "function"
        and pcall(LoopInGameThreadWithDelay, TICK_MS, function() pcall(run_tick) end) then
        if PERF then log("[perf] timer runs on the game thread.") end
        return
    end
    LoopAsync(TICK_MS, function() pcall(run_tick); return false end)   -- Older UE4SS.
    if PERF then log("[perf] timer runs on a background thread (LoopInGameThreadWithDelay not available).") end
end

-- Apply relative to vanilla; avoid stacked modifiers.
local function managed_number(obj, field, key, target_fn, label)
    local okB, cur = pcall(function() return obj[field] end)
    if not (okB and type(cur) == "number") then return false end
    local orig = resolve_original(key, cur)
    local target = target_fn(orig)
    if target == nil then target = orig end
    if math.abs(cur - target) >= 0.01 then
        pcall(function() obj[field] = target end)
        local okA, after = pcall(function() return obj[field] end)
        if not (okA and type(after) == "number" and math.abs(after - target) < 0.01) then
            log("%s: write did NOT stick (wanted %.1f, reads back %s).", label, target, tostring(after))
            return false
        end
        log("%s: %.1f -> %.1f (vanilla %.1f)", label, cur, after, orig)
    end
    record_applied(key, orig, target)
    return true
end

local function find_numeric_shape_modules(obj)
    local okMod, modulesContainer = pcall(function() return obj.Modules end)
    local okArr, arr = pcall(function() return modulesContainer.Modules end)
    if not okMod or not okArr or arr == nil then return {} end

    local shapes = {}
    pcall(function()
        arr:ForEach(function(index, elem)
            local okGet, wrapper = pcall(function() return elem:get() end)
            if not okGet or wrapper == nil then return end
            local okInner, inner = pcall(function() return wrapper.Module end)
            if not okInner or inner == nil then return end
            local okFull, full = pcall(function() return inner:GetFullName() end)
            if not (okFull and tostring(full):find("SpellModule_Shape")) then return end

            local okShape, shape = pcall(function() return inner.Shape end)
            if not okShape or shape == nil then return end

            local okCur, current = pcall(function() return shape.Radius end)
            if okCur and type(current) == "number" then
                table.insert(shapes, { shape = shape, name = tostring(full), current = current })
            end
        end)
    end)
    return shapes
end

local function apply_target(target)
    local ok, obj = pcall(function() return StaticFindObject(target.path) end)
    if not ok or obj == nil then return false end

    local okValid, isValid = pcall(function() return obj:IsValid() end)
    if not okValid or isValid ~= true then return false end

    local shapes = find_numeric_shape_modules(obj)
    if #shapes == 0 then return false end

    local appliedAny = false
    for _, entry in ipairs(shapes) do
        local key = "radius|" .. target.name .. "|" .. entry.name
        local good = managed_number(entry.shape, "Radius", key, function(orig)
            if target.enabled then return target.new_radius end
            return orig
        end, target.name .. " radius")
        if good then appliedAny = true end
    end
    orig_flush()
    return appliedAny
end

local state = {}
for i, target in ipairs(TARGETS) do
    state[i] = { applied = false }
end

log("Loaded. Settings are applied once the world is ready. With Mod Menu installed they can also be changed live (Esc > MODS).")

local t_targets
REFRESH[#REFRESH + 1] = function()
    for i, target in ipairs(TARGETS) do
        target.new_radius = cfg_num(target.radius_key)
        target.enabled = cfg_bool(target.enabled_key)
        state[i].applied = false
    end
    if t_targets then wake(t_targets) end
end

-- Apply once; wake on settings changes.
local function targets_step()
    local allDone = true
    for i, target in ipairs(TARGETS) do
        if not state[i].applied then
            if apply_target(target) then
                state[i].applied = true
            else
                allDone = false
            end
        end
    end
    return allDone
end
t_targets = add_task("spell radius", 1000, targets_step)
t_targets.slow = true


local SPELLCASTING_ALIASES = { "SpellcastingComponent", "BP_Components_SpellcastingComponent", "BP_Components_Spellcasting" }

local function is_valid_obj(obj)
    if obj == nil then return false end
    local ok, v = pcall(function() return obj:IsValid() end)
    return ok and v == true
end

-- Cache local controller to avoid repeated global searches.
local cachedPC, lastPCScan = nil, 0

local function forget_player()   -- Reset after world change or respawn.
    cachedPC, lastPCScan = nil, 0
end

local function get_local_player_controller()
    if cachedPC ~= nil then
        if is_valid_obj(cachedPC) then return cachedPC end
        cachedPC = nil
    end

    -- Limit controller searches to once per 3s.
    local now = os.time()
    if now - lastPCScan < 3 then return nil end
    lastPCScan = now

    local list = find_all("PlayerController")
    if list == nil then return nil end
    local found, firstValid = nil, nil
    pcall(function()
        for _, pc in ipairs(list) do
            if is_valid_obj(pc) then
                if firstValid == nil then firstValid = pc end
                local okLocal, isLocal = pcall(function() return pc:IsLocalController() end)
                if okLocal and isLocal then found = pc end
            end
        end
    end)
    cachedPC = found or firstValid
    return cachedPC
end

local function get_spellcasting_component(pc)
    for _, alias in ipairs(SPELLCASTING_ALIASES) do
        local ok, comp = pcall(function() return pc[alias] end)
        if ok and is_valid_obj(comp) then return comp end
    end
    return nil
end

local function get_selected_spells()
    local pc = get_local_player_controller()
    if pc == nil then return nil end
    local sc = get_spellcasting_component(pc)
    if sc == nil then return nil end
    local ok, selected = pcall(function() return sc.SelectedSpells end)
    if not ok or selected == nil then return nil end
    return selected, pc
end

local matchedKeywordTargets = {} -- [index into KEYWORD_TARGETS] = true once handled
local reducedCooldowns = {} -- [full name string] = true once handled
local keywordScanAttempts = 0
local dumpedAllSpellNames = false

local cdState = { count = -1, lastPass = 0, dirty = true, pc = nil }
local t_cooldown

REFRESH[#REFRESH + 1] = function()
    COOLDOWN_MULTIPLIER = cfg_num("CooldownMultiplier")
    COOLDOWNS_ENABLED = cfg_bool("Cooldowns")
    reducedCooldowns = {}
    cdState.dirty = true
    if t_cooldown then wake(t_cooldown) end
end

local function cooldown_pass(selected, n)
    keywordScanAttempts = keywordScanAttempts + 1

    local anyKeywordUnmatched = false
    for ki in ipairs(KEYWORD_TARGETS) do
        if not matchedKeywordTargets[ki] then anyKeywordUnmatched = true end
    end

    for i = 1, n do
        local okEntry, entry = pcall(function() return selected[i] end)
        if okEntry and is_valid_obj(entry) then
            local okFull, full = pcall(function() return entry:GetFullName() end)
            local fullName = (okFull and full) and tostring(full) or nil

            if fullName then
                local lowerName = fullName:lower()

                for ki, kt in ipairs(KEYWORD_TARGETS) do
                    if not matchedKeywordTargets[ki] then
                        local hit = lowerName:find(kt.keyword, 1, true) ~= nil
                        if not hit and kt.keyword2 then
                            hit = lowerName:find(kt.keyword2, 1, true) ~= nil
                        end
                        if hit then
                            local shapes = find_numeric_shape_modules(entry)
                            if #shapes > 0 then
                                for _, s in ipairs(shapes) do
                                    if math.abs(s.current - kt.new_radius) >= 0.01 then
                                        local okSet = pcall(function() s.shape.Radius = kt.new_radius end)
                                        if okSet then
                                            log("%s: Radius set to %.1f (was %.1f) [%s]", kt.name, kt.new_radius, s.current, fullName)
                                        end
                                    end
                                end
                            else
                                log("%s: matched '%s' but has no adjustable Shape module -- its range may be hardcoded in its logic and can't be changed this way.", kt.name, fullName)
                            end
                            matchedKeywordTargets[ki] = true
                        end
                    end
                end

                if not reducedCooldowns[fullName] and not lowerName:find("hometeleport", 1, true) then
                    local okCd, cd = pcall(function() return entry.CooldownDuration end)
                    if okCd and type(cd) == "number" and cd > 0 then
                        managed_number(entry, "CooldownDuration", "cd|" .. fullName, function(orig)
                            if COOLDOWNS_ENABLED then return orig * COOLDOWN_MULTIPLIER end
                            return orig
                        end, "Cooldown [" .. (fullName:match("([^/%.]+)%.[^/%.]+$") or fullName) .. "]")
                        reducedCooldowns[fullName] = true
                    end
                end
            end
        end
    end
    orig_flush()

    if anyKeywordUnmatched and not dumpedAllSpellNames and keywordScanAttempts >= 10 then
        log("Still missing a keyword match after %d tries -- dumping every equipped spell's name so the keyword(s) can be corrected:", keywordScanAttempts)
        for i = 1, n do
            local okEntry, entry = pcall(function() return selected[i] end)
            if okEntry and is_valid_obj(entry) then
                local okFull, full = pcall(function() return entry:GetFullName() end)
                if okFull and full then
                    log("  slot %d: %s", i, tostring(full))
                end
            end
        end
        dumpedAllSpellNames = true
    end
end

-- Event-driven only (woken on spell equip, ClientRestart, or Mod Menu change); sleeps once applied (zero polling).
local function cooldown_step()
    local selected, pc = get_selected_spells()
    if selected == nil then return false end   -- Player not ready yet.

    local okN, n = pcall(function() return #selected end)
    if not okN or type(n) ~= "number" then return false end

    cdState.pc = pc
    cdState.dirty, cdState.count, cdState.lastPass = false, n, os.time()
    cooldown_pass(selected, n)
    return true   -- Sleep task immediately after applying; zero periodic polling.
end
t_cooldown = add_task("cooldowns", 3000, cooldown_step)
t_cooldown.slow = true

-- Spell selection event.
do
    local ok, err = pcall(RegisterHook, "/Script/Dominion.SpellcastingComponent:Client_NotifyAllSelectedSpells", function() end, function()
        bump("spell list event")
        cdState.dirty = true
        wake(t_cooldown)
    end)
    if not ok and PERF then log("[perf] spell list hook unavailable: %s", tostring(err)) end
end


local SAFE_SCALAR_PROPERTY_TYPES = {
    FloatProperty = true, DoubleProperty = true,
    Int8Property = true, Int16Property = true, IntProperty = true, Int64Property = true,
    UInt16Property = true, UInt32Property = true, UInt64Property = true, ByteProperty = true,
    BoolProperty = true, NameProperty = true, StrProperty = true, TextProperty = true,
}

local function get_prop_type_name(prop)
    local propTypeName = nil
    pcall(function()
        local propClass = prop:GetClass()
        if propClass then
            local fn2 = nil
            pcall(function() fn2 = propClass:GetFName() end)
            if fn2 then pcall(function() propTypeName = fn2:ToString() end) end
            if not propTypeName then pcall(function() propTypeName = propClass:GetName() end) end
        end
    end)
    return propTypeName
end

local function dump_safe_properties(obj, indent)
    local okCls, cls = pcall(function() return obj:GetClass() end)
    if not okCls or cls == nil then return end

    local seen = {}
    pcall(function()
        cls:ForEachProperty(function(prop)
            local pname = nil
            pcall(function()
                local fn = prop:GetFName()
                if fn then pname = fn:ToString() end
            end)
            if not pname then pcall(function() pname = prop:GetName() end) end
            if pname and not seen[pname] then
                seen[pname] = true
                local propTypeName = get_prop_type_name(prop)
                if propTypeName and SAFE_SCALAR_PROPERTY_TYPES[propTypeName] then
                    local okv, v = pcall(function() return obj[pname] end)
                    if okv then
                        log("%s%s (%s) = %s", indent, pname, propTypeName, tostring(v))
                    end
                elseif propTypeName == "ObjectProperty" then
                    log("%s%s (ObjectProperty -- not dereferenced)", indent, pname)
                elseif propTypeName then
                    log("%s%s (%s -- skipped)", indent, pname, propTypeName)
                end
            end
        end)
    end)
end

local function dump_modules(obj, indent)
    local okMod, modulesContainer = pcall(function() return obj.Modules end)
    local okArr, arr = pcall(function() return modulesContainer.Modules end)
    if not okMod or not okArr or arr == nil then
        log("%s(no .Modules.Modules array)", indent)
        return
    end
    pcall(function()
        arr:ForEach(function(index, elem)
            local okGet, wrapper = pcall(function() return elem:get() end)
            if not okGet or wrapper == nil then return end
            local okInner, inner = pcall(function() return wrapper.Module end)
            if not okInner or inner == nil then return end
            local okFull, full = pcall(function() return inner:GetFullName() end)
            log("%smodule[%s]: %s", indent, tostring(index), (okFull and full) and tostring(full) or "?")
            dump_safe_properties(inner, indent .. "    ")
        end)
    end)
end

local INVESTIGATE_TARGETS = {
    { name = "Splinter", path = "/Game/Gameplay/UtilityMagic/PerkSpells/Splinter/USD_Splinter.USD_Splinter" },
    { name = "Axtral Projection", path = "/Game/Gameplay/UtilityMagic/PerkSpells/AxtralProjection/USD_AxtralProjection.USD_AxtralProjection" },
}

local investigateDone = {}
if cfg_bool("DebugDump") then LoopAsync(1000, function()
    local allDone = true
    for i, t in ipairs(INVESTIGATE_TARGETS) do
        if not investigateDone[i] then
            local ok, obj = pcall(function() return StaticFindObject(t.path) end)
            if ok and obj ~= nil then
                local okValid, isValid = pcall(function() return obj:IsValid() end)
                if okValid and isValid then
                    log("=== %s: top-level properties ===", t.name)
                    dump_safe_properties(obj, "  ")
                    log("=== %s: modules ===", t.name)
                    dump_modules(obj, "  ")
                    investigateDone[i] = true
                else
                    allDone = false
                end
            else
                allDone = false
            end
        end
    end
    return allDone
end) end

local AXTRAL_ENABLED = cfg_bool("AxtralProjection")
local AXTRAL_PATH = "/Game/Gameplay/UtilityMagic/PerkSpells/AxtralProjection/USD_AxtralProjection.USD_AxtralProjection"
local AXTRAL_DISTANCE = cfg_num("AxtralDistance")
local AXTRAL_SPEED = cfg_num("AxtralSpeed")
-- Nonpositive width falls back to 1x; zero-size collision can crash.
local AXTRAL_WIDTH_MULTIPLIER = cfg_num("AxtralWidth")
if not (AXTRAL_WIDTH_MULTIPLIER and AXTRAL_WIDTH_MULTIPLIER > 0) then AXTRAL_WIDTH_MULTIPLIER = 1 end

local axtralDone = false
local t_axtral
REFRESH[#REFRESH + 1] = function()
    AXTRAL_ENABLED = cfg_bool("AxtralProjection")
    AXTRAL_DISTANCE = cfg_num("AxtralDistance")
    AXTRAL_SPEED = cfg_num("AxtralSpeed")
    AXTRAL_WIDTH_MULTIPLIER = cfg_num("AxtralWidth")
    if not (AXTRAL_WIDTH_MULTIPLIER and AXTRAL_WIDTH_MULTIPLIER > 0) then AXTRAL_WIDTH_MULTIPLIER = 1 end
    axtralDone = false
    if t_axtral then wake(t_axtral) end
end
-- Flight duration must cover distance/speed; vanilla 6s cap can truncate travel.
local function ax_duration(inner, full, short)
    local cls = full:match("^(%S+)") or "SpellModule_ExpireAfterDuration"
    local key = "ax|" .. cls .. " " .. AXTRAL_PATH .. ":" .. short .. "|Duration"
    managed_number(inner, "Duration", key, function(orig)
        if AXTRAL_ENABLED and AXTRAL_DISTANCE and AXTRAL_DISTANCE > 0 then
            local sp = (AXTRAL_SPEED and AXTRAL_SPEED > 0) and AXTRAL_SPEED or 1000
            local need = AXTRAL_DISTANCE / sp * 1.25
            if need > orig then return need end
        end
        return orig
    end, "Axtral Projection " .. short .. " Duration")
end

-- Scale hit sphere or box width.
local axShapeLogged = {}
local function ax_apply_shape(inner, full, prop, tag)
    local okS, shape = pcall(function() return inner[prop] end)
    if not (okS and shape ~= nil) then return end
    local okV, valid = pcall(function() return shape:IsValid() end)
    if not (okV and valid) then return end
    local okN, sname = pcall(function() return shape:GetFullName() end)
    sname = okN and tostring(sname) or "?"
    if tag ~= "" then
        -- Skip duplicate shape to avoid double scaling.
        local okM, mainShape = pcall(function() return inner.Shape end)
        if okM and mainShape ~= nil then
            local okM2, mname = pcall(function() return mainShape:GetFullName() end)
            if okM2 and tostring(mname) == sname then return end
        end
    end
    if not axShapeLogged[prop] then
        axShapeLogged[prop] = true
        log("Axtral Projection: %s is %s", prop, sname)
    end
    local label = (tag ~= "" and "upgraded " or "") .. "hit "
    local okR, r = pcall(function() return shape.Radius end)
    if okR and type(r) == "number" and r > 0 then
        managed_number(shape, "Radius", "ax|" .. full .. "|" .. tag .. "Radius", function(orig)
            if AXTRAL_ENABLED then return orig * AXTRAL_WIDTH_MULTIPLIER end
            return orig
        end, "Axtral Projection " .. label .. "Radius")
        return
    end
    -- Box extents: X forward, Y lateral, Z vertical.
    local okE, ex = pcall(function() return shape.Extents end)
    if not (okE and ex ~= nil) then
        log("Axtral Projection: could not read the %sbox Extents.", label)
        return
    end
    local base = "ax|" .. full .. "|" .. tag .. "Extents"
    managed_number(ex, "Y", base .. "Y", function(orig)
        if AXTRAL_ENABLED then return orig * AXTRAL_WIDTH_MULTIPLIER end
        return orig
    end, "Axtral Projection " .. label .. "box width (Y)")
end

-- Woodcutting upgrade uses UpgradeSettings[].Distance instead of base Distance.
local axUpLogged = {}
local function ax_upgrade_distance(inner, full, short)
    local okU, arr = pcall(function() return inner.UpgradeSettings end)
    if not (okU and arr ~= nil) then return end
    pcall(function()
        arr:ForEach(function(idx, elem)
            local okG, item = pcall(function() return elem:get() end)
            if not okG or item == nil then return end
            local perk = "?"
            pcall(function()
                local pk = item.UpgradePerk
                if pk ~= nil then perk = tostring(pk:GetFullName()) end
            end)
            local key = "ax|" .. full .. "|UpDistance" .. tostring(idx)
            if not axUpLogged[key] then
                axUpLogged[key] = true
                local d = nil
                pcall(function() d = item.Distance end)
                log("Axtral Projection %s UpgradeSettings[%s]: Distance %s, perk %s", short, tostring(idx), tostring(d), perk)
            end
            managed_number(item, "Distance", key, function(orig)
                if AXTRAL_ENABLED and AXTRAL_DISTANCE and AXTRAL_DISTANCE > 0 then return math.max(orig, AXTRAL_DISTANCE) end
                return orig
            end, "Axtral Projection " .. short .. " upgraded Distance[" .. tostring(idx) .. "]")
        end)
    end)
end

local function axtral_step()
    if axtralDone then return true end
    local ok, obj = pcall(function() return StaticFindObject(AXTRAL_PATH) end)
    if not (ok and obj ~= nil) then return false end
    local okV, valid = pcall(function() return obj:IsValid() end)
    if not (okV and valid) then return false end

    local okMod, container = pcall(function() return obj.Modules end)
    local okArr, arr = pcall(function() return container.Modules end)
    if not (okMod and okArr and arr ~= nil) then return false end

    local touched = 0
    pcall(function()
        arr:ForEach(function(index, elem)
            local okGet, wrapper = pcall(function() return elem:get() end)
            if not okGet or wrapper == nil then return end
            local okInner, inner = pcall(function() return wrapper.Module end)
            if not okInner or inner == nil then return end
            local okFull, full = pcall(function() return inner:GetFullName() end)
            full = okFull and tostring(full) or ""
            local short = full:match("([^:]+)$") or full

            if full:find("SpellModule_ExpireAfterDistance") then
                managed_number(inner, "Distance", "ax|" .. full .. "|Distance", function(orig)
                    if AXTRAL_ENABLED and AXTRAL_DISTANCE and AXTRAL_DISTANCE > 0 then return AXTRAL_DISTANCE end
                    return orig
                end, "Axtral Projection " .. short .. " Distance")
                ax_upgrade_distance(inner, full, short)
                touched = touched + 1
            elseif full:find("SpellModule_Movement") then
                managed_number(inner, "Speed", "ax|" .. full .. "|Speed", function(orig)
                    if AXTRAL_ENABLED and AXTRAL_SPEED and AXTRAL_SPEED > 0 then return AXTRAL_SPEED end
                    return orig
                end, "Axtral Projection " .. short .. " Speed")
                touched = touched + 1
            elseif full:find("SpellModule_ExpireAfterDuration") then
                ax_duration(inner, full, short)
                touched = touched + 1
            elseif full:find("SpellModule_Shape") then
                ax_apply_shape(inner, full, "Shape", "")
                -- Three-axe perk uses a separate upgraded hit shape.
                ax_apply_shape(inner, full, "UpgradedShape", "Up")
                touched = touched + 1
            end
        end)
    end)
    orig_flush()
    if touched > 0 then axtralDone = true end
    return axtralDone
end
t_axtral = add_task("axtral projection", 1500, axtral_step)
t_axtral.slow = true

local SPLINTER_ENABLED = cfg_bool("Splinter")
local SPLINTER_PATH = "/Game/Gameplay/UtilityMagic/PerkSpells/Splinter/USD_Splinter.USD_Splinter"
local SPLINTER_RADIUS_MULT = cfg_num("SplinterRadiusMultiplier")
local SPLINTER_PLACEMENT = cfg_num("SplinterPlacementDistance")

local splinterDone = false
local t_splinter
REFRESH[#REFRESH + 1] = function()
    SPLINTER_ENABLED = cfg_bool("Splinter")
    SPLINTER_RADIUS_MULT = cfg_num("SplinterRadiusMultiplier")
    SPLINTER_PLACEMENT = cfg_num("SplinterPlacementDistance")
    splinterDone = false
    if t_splinter then wake(t_splinter) end
end
local function splinter_step()
    if splinterDone then return true end
    local ok, obj = pcall(function() return StaticFindObject(SPLINTER_PATH) end)
    if not (ok and obj ~= nil) then return false end
    local okV, valid = pcall(function() return obj:IsValid() end)
    if not (okV and valid) then return false end
    local okMod, container = pcall(function() return obj.Modules end)
    local okArr, arr = pcall(function() return container.Modules end)
    if not (okMod and okArr and arr ~= nil) then return false end

    local touched = 0
    local seen = {}
    pcall(function()
        arr:ForEach(function(index, elem)
            local okGet, wrapper = pcall(function() return elem:get() end)
            if not okGet or wrapper == nil then return end
            local okInner, inner = pcall(function() return wrapper.Module end)
            if not okInner or inner == nil then return end
            local okFull, full = pcall(function() return inner:GetFullName() end)
            if not (okFull and tostring(full):find("SpellModule_Shape")) then return end
            touched = touched + 1
            for _, field in ipairs({ "Shape", "UpgradedShape" }) do
                local okS, shape = pcall(function() return inner[field] end)
                if okS and is_valid_obj(shape) then
                    local okN, nm = pcall(function() return shape:GetFullName() end)
                    local key = okN and tostring(nm) or (field .. tostring(index))
                    if not seen[key] then
                        seen[key] = true
                        if cfg_bool("DebugDump") then
                            log("Splinter: %s = %s", field, key)
                            dump_safe_properties(shape, "      ")
                        end
                        local okR, r = pcall(function() return shape.Radius end)
                        if okR and type(r) == "number" and r > 0 then
                            managed_number(shape, "Radius", "sp|" .. key .. "|Radius", function(orig)
                                if SPLINTER_ENABLED then return orig * SPLINTER_RADIUS_MULT end
                                return orig
                            end, "Splinter " .. field .. " radius")
                        else
                            log("Splinter: %s has no numeric Radius to change.", field)
                        end
                    end
                end
            end
        end)
    end)

    local placeOn = SPLINTER_ENABLED and SPLINTER_PLACEMENT and SPLINTER_PLACEMENT > 0
    if managed_number(obj, "MaxPlacementDistanceFromCamera", "sp|MaxPlacementDistance", function(orig)
        if placeOn then return SPLINTER_PLACEMENT end
        return orig
    end, "Splinter placement distance") then
        pcall(function() obj.bOverrideMaxPlacementDistanceFromCamera = placeOn and true or false end)
    end

    orig_flush()
    if touched > 0 then splinterDone = true end
    return splinterDone
end
t_splinter = add_task("splinter", 1500, splinter_step)
t_splinter.slow = true

-- Spawn events resize course orbs; slow sweep catches misses. Cache vanilla radius per class.
local AGILITY_ENABLED = cfg_bool("AgilityOrbs")
local AGILITY_MULT = cfg_num("AgilityOrbRadius")
local AGILITY_MAX_MULT = 5   -- Values above 5 can break courses.
local function agility_clamp()
    if AGILITY_MULT and AGILITY_MULT > AGILITY_MAX_MULT then
        log("AgilityOrbRadius %s is too big and breaks the course -- using %s instead.", tostring(AGILITY_MULT), tostring(AGILITY_MAX_MULT))
        AGILITY_MULT = AGILITY_MAX_MULT
    end
end
agility_clamp()
do
    local ORB_CLASSES = {
        { cls = "BP_AgilityOrb_Base_C", label = "Agility orb", path = "/Agility/Gameplay/World/BP_AgilityOrb_Base.BP_AgilityOrb_Base_C" },
        { cls = "BP_StaminaOrb_C",      label = "Stamina orb", path = "/Agility/Gameplay/World/AgilityObjects/BP_StaminaOrb.BP_StaminaOrb_C" },
    }
    local loggedClass, warnedClass = {}, {}
    local classOrig = {}   -- Vanilla radius per orb type.
    local sweep_all
    local watching = {}    -- Orb classes with a spawn watcher registered.

    REFRESH[#REFRESH + 1] = function()
        local wasOn, wasMult = AGILITY_ENABLED, AGILITY_MULT
        AGILITY_ENABLED = cfg_bool("AgilityOrbs")
        AGILITY_MULT = cfg_num("AgilityOrbRadius")
        agility_clamp()
        loggedClass = {}
        if wasOn ~= AGILITY_ENABLED or wasMult ~= AGILITY_MULT then
            sweep_all("settings")   -- Resize orbs that already exist.
        end
    end

    local function find_collider(orb)
        local comp = nil
        pcall(function() comp = orb.SphereColliderComponent end)
        if is_valid_obj(comp) then return comp end
        for _, path in ipairs({ "/Script/Engine.SphereComponent" }) do
            pcall(function()
                local cls = StaticFindObject(path)
                if cls then comp = orb:GetComponentByClass(cls) end
            end)
            if is_valid_obj(comp) then return comp end
        end
        return nil
    end

    -- Status: gone/pending/ok; second return indicates radius change.
    local function widen_orb(orb, info, source)
        if not is_valid_obj(orb) then return "gone" end
        local comp = find_collider(orb)
        if not comp then return "pending" end
        local okR, cur = pcall(function() return comp.SphereRadius end)
        if not (okR and type(cur) == "number") then return "pending" end
        local key = "ag|" .. info.cls
        local orig = classOrig[info.cls]
        if orig == nil then
            orig = resolve_original(key, cur)
            classOrig[info.cls] = orig
        end
        local target = orig
        if AGILITY_ENABLED and AGILITY_MULT and AGILITY_MULT > 0 then target = orig * AGILITY_MULT end
        local changed = false
        if math.abs(cur - target) >= 0.01 then
            -- Engine setter updates overlaps; property write is fallback.
            pcall(function() comp:SetSphereRadius(target, true) end)
            local okN, now = pcall(function() return comp.SphereRadius end)
            if okN and type(now) == "number" and math.abs(now - target) > 0.01 then
                pcall(function() comp.SphereRadius = target end)
                okN, now = pcall(function() return comp.SphereRadius end)
            end
            changed = true
            if not loggedClass[info.cls] then
                loggedClass[info.cls] = true
                log("%s pickup radius: %s -> %s (vanilla %s, x%s) [%s]", info.label, tostring(cur), tostring(okN and now or "?"), tostring(orig), tostring(AGILITY_MULT), source)
            end
        end
        record_applied(key, orig, target)
        return "ok", changed
    end

    -- Spawned colliders may initialize late; retry briefly.
    local RETRY = { 250, 500, 1000, 1500, 2500 }
    local function watch_orb(orb, info, i)
        later(RETRY[i], function()
            if i == 1 then
                local okN, full = pcall(function() return orb:GetFullName() end)
                if okN and tostring(full):find("Default__", 1, true) then return end
            end
            local res = widen_orb(orb, info, "spawn event")
            if res == "pending" then
                if i < #RETRY then
                    watch_orb(orb, info, i + 1)
                elseif not warnedClass[info.cls] then
                    warnedClass[info.cls] = true
                    log("%s: no sphere collider found to widen.", info.label)
                end
            elseif res == "ok" then
                orig_flush()
            end
        end)
    end

    -- Sweep for missed orbs and live setting changes.
    local missedLogged = 0
    sweep_all = function(source)
        local fixed = 0
        for _, info in ipairs(ORB_CLASSES) do
            local orbs = find_all(info.cls)
            if orbs then
                for _, orb in ipairs(orbs) do
                    local res, changed = widen_orb(orb, info, source)
                    if changed then fixed = fixed + 1 end
                end
            end
        end
        orig_flush()
        if fixed > 0 and source == "sweep" then
            bump("orbs fixed by sweep (spawn event missed them)")
            if missedLogged < 3 then
                missedLogged = missedLogged + 1
                log("Agility: the sweep resized %d orb(s) the spawn event missed.", fixed)
            end
        end
        return fixed
    end
    add_task("agility sweep", 20000, function()
        if next(watching) ~= nil then sweep_all("sweep") end   -- No orb class watched yet.
    end)

    -- Orb classes load with the course; avoid costly unloaded-class lookups.
    add_task("agility watch", 5000, function()
        local waiting = false
        for _, info in ipairs(ORB_CLASSES) do
            if not watching[info.cls] then
                local orbs = find_all(info.cls)
                if orbs and #orbs > 0 then
                    watching[info.cls] = true
                    local okR, err = pcall(NotifyOnNewObject, info.path, function(orb)
                        bump(info.label .. " spawn event")
                        watch_orb(orb, info, 1)
                    end)
                    if okR then
                        if PERF then log("[perf] watching for new %ss.", info.label:lower()) end
                    else
                        log("%s: could not watch for new orbs (%s); the periodic sweep covers them.", info.label, tostring(err))
                    end
                    for _, orb in ipairs(orbs) do widen_orb(orb, info, "startup") end   -- Handle existing orbs.
                    orig_flush()
                else
                    waiting = true
                end
            end
        end
        return not waiting
    end)
end

do
local WANTED_MAX = cfg_num("RuneLimit")     -- Craft limit.
local APPLY_LIMIT = cfg_bool("Runecrafting")    -- Disabled retains vanilla limit (50).

local AUTOCRAFT_FULL_BONUS = cfg_bool("AutocraftBonus")     -- Experimental: +100% autocraft bonus without perk.
local AUTOCRAFT_XP_MULTIPLIER = (cfg_num("AutocraftXP") or 0) > 0 and cfg_num("AutocraftXP") or nil   -- Vanilla XP 0.25; 1.0 = attuning XP; nil = unchanged.

local function log(fmt, ...)
    print(string.format("[GreaterFarming] Runecrafting: " .. fmt, ...))
end

local SAFE = {
    FloatProperty = true, DoubleProperty = true, Int8Property = true, Int16Property = true,
    IntProperty = true, Int64Property = true, UInt16Property = true, UInt32Property = true,
    UInt64Property = true, ByteProperty = true, BoolProperty = true,
}

local function prop_type(prop)
    local name
    pcall(function()
        local c = prop:GetClass()
        name = c:GetFName():ToString()
    end)
    return name
end

local function dump_scalars(obj, indent)
    local okc, cls = pcall(function() return obj:GetClass() end)
    if not okc or cls == nil then return end
    local seen = {}
    pcall(function()
        cls:ForEachProperty(function(prop)
            local pname
            pcall(function() pname = prop:GetFName():ToString() end)
            if pname and not seen[pname] then
                seen[pname] = true
                local t = prop_type(prop)
                if t and SAFE[t] then
                    local ok, v = pcall(function() return obj[pname] end)
                    if ok then log("%s%s (%s) = %s", indent, pname, t, tostring(v)) end
                end
            end
        end)
    end)
end

local function valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

local function unwrap(v)
    if type(v) == "userdata" then
        local ok, inner = pcall(function() return v:get() end)
        if ok and inner ~= nil then return inner end
    end
    return v
end

local function dump_map(label, map, value_is_object)
    log("%s:", label)
    local ok = pcall(function()
        map:ForEach(function(k, v)
            local key = unwrap(k)
            local val = unwrap(v)
            local keyStr = tostring(key)
            pcall(function() if type(key) == "userdata" then keyStr = key:GetFullName() end end)
            if value_is_object and type(val) == "userdata" then
                log("    [%s]", keyStr)
                dump_scalars(val, "        ")
            else
                log("    [%s] = %s", keyStr, tostring(val))
            end
        end)
    end)
    if not ok then log("    (could not read this table)") end
end

local lastPanel = nil
local inspected = {}

local function inspect_panel(panel)
    log("---- Rune altar screen opened ----")

    local okS, slider = pcall(function() return panel.AmountSlider end)
    if okS and valid(slider) then
        log("AmountSlider settings:")
        dump_scalars(slider, "    ")
        local okI, inner = pcall(function() return slider.InputSlider end)
        if okI and valid(inner) then
            log("  inner slider:")
            dump_scalars(inner, "    ")
        end
    else
        log("AmountSlider not readable.")
    end

    local okC, cfg = pcall(function() return panel.ConfigData end)
    if okC and valid(cfg) then
        log("ConfigData (RunecraftingData):")
        dump_scalars(cfg, "    ")
        local okM, m = pcall(function() return cfg.RecipeDataToAutoCraftBonusMap end)
        if okM and m ~= nil then
            log("  AutoCraft bonus table (rune recipe -> bonus when the efficiency perk is owned):")
            pcall(function()
                m:ForEach(function(k, v)
                    local key = unwrap(k)
                    local name = "?"
                    pcall(function() name = key:GetFullName() end)
                    local val = unwrap(v)
                    local bonus, perkName = nil, "none"
                    pcall(function() bonus = val.BonusRewardWithPerk end)
                    pcall(function()
                        local pk = val.Perk
                        if valid(pk) then perkName = pk:GetFullName() end
                    end)
                    log("    %s  bonus=%s  perk required=%s", (tostring(name):gsub("^.- ", "")), tostring(bonus), tostring(perkName))
                end)
            end)
        end
    else
        log("ConfigData not readable.")
    end

    local okD, diff = pcall(function() return panel.DifficultyConfigData end)
    if okD and diff ~= nil then
        log("Attunement difficulty tiers (key: 0=High 1=Medium 2=Low):")
        pcall(function()
            diff:ForEach(function(k, v)
                local key = unwrap(k)
                local data = unwrap(v)
                local br
                pcall(function() br = data.BonusReward end)
                log("    tier %s: BonusReward=%s", tostring(key), tostring(br))
            end)
        end)
    end
end


local autocraftApplied = false
local function apply_autocraft(panel)
    if autocraftApplied then return end
    local okC, cfg = pcall(function() return panel.ConfigData end)
    if not (okC and valid(cfg)) then return end

    managed_number(cfg, "XPMultiplierAutoCraft", "rc|XPMultiplierAutoCraft", function(orig)
        return AUTOCRAFT_XP_MULTIPLIER or orig
    end, "Runecrafting autocraft XP multiplier")
    orig_flush()

    if AUTOCRAFT_FULL_BONUS then
        local okM, m = pcall(function() return cfg.RecipeDataToAutoCraftBonusMap end)
        if okM and m ~= nil then
            pcall(function()
                m:ForEach(function(k, v)
                    local val = unwrap(v)
                    local name = "?"
                    pcall(function() name = tostring(unwrap(k):GetFullName()):gsub("^.- ", "") end)
                    pcall(function() val.BonusRewardWithPerk = 100.0 end)
                    local hadPerk = false
                    pcall(function() hadPerk = valid(val.Perk) end)
                    if hadPerk then pcall(function() val.Perk = nil end) end
                    local stillPerk = true
                    pcall(function() stillPerk = valid(val.Perk) end)
                    local bonus
                    pcall(function() bonus = val.BonusRewardWithPerk end)
                    log("Autocraft bonus for %s: bonus=%s, perk requirement %s", name, tostring(bonus),
                        (hadPerk and not stillPerk) and "REMOVED" or (hadPerk and "still set" or "none"))
                end)
            end)
        end
    end
    autocraftApplied = true
end

local function apply_limit(panel, why)
    if not APPLY_LIMIT then return true end
    local okS, slider = pcall(function() return panel.AmountSlider end)
    if not (okS and valid(slider)) then return false end
    local okM, cur = pcall(function() return slider.MaximumCraftableItems end)
    local okI, inner = pcall(function() return slider.InputSlider end)
    local innerMax
    if okI and valid(inner) then pcall(function() innerMax = inner.MaxValue end) end
    log("[%s] slider MaximumCraftableItems=%s, inner MaxValue=%s", why, tostring(cur), tostring(innerMax))
    if okM and type(cur) == "number" and cur >= 1 and cur <= 50 and innerMax and innerMax <= 50.5 and cur >= 50 then
        pcall(function() slider.MaximumCraftableItems = WANTED_MAX end)
        pcall(function() slider:UpdateMaxValue(WANTED_MAX) end)
        local _, after = pcall(function() return slider.MaximumCraftableItems end)
        local afterInner
        pcall(function() afterInner = inner.MaxValue end)
        log("Limit raised: MaximumCraftableItems -> %s, inner MaxValue -> %s", tostring(after), tostring(afterInner))
    end
    return true
end

local panelRef, panelAddr = nil, nil

local function find_panel()
    local best
    for _, cname in ipairs({ "WBP_Runecrafting_MainPanel_C", "RunecraftingMainPanel" }) do
        local list = find_all(cname)
        if list then
            for _, p in ipairs(list) do
                local okF, full = pcall(function() return p:GetFullName() end)
                if valid(p) and okF and not tostring(full):find("Default__") then best = p end
            end
        end
        if best then return best end
    end
end

-- Wait for panel data before marking setup complete.
local function setup_panel(p, why)
    local addr = tostring(p)
    pcall(function() addr = tostring(p:GetAddress()) end)
    if addr == panelAddr then return true end
    if cfg_bool("DebugDump") then inspect_panel(p) end
    apply_autocraft(p)
    local limitOk = apply_limit(p, why)
    if autocraftApplied and limitOk then
        panelAddr = addr
        return true
    end
    return false
end

-- Panel data initializes after creation; retry briefly.
local PANEL_RETRY = { 500, 1000, 2000, 4000 }
local function watch_panel(p, i)
    later(PANEL_RETRY[i], function()
        if not valid(p) then return end
        local okF, full = pcall(function() return p:GetFullName() end)
        if okF and tostring(full):find("Default__", 1, true) then return end
        panelRef = p
        if not setup_panel(p, "screen opened") and i < #PANEL_RETRY then watch_panel(p, i + 1) end
    end)
end

REFRESH[#REFRESH + 1] = function()
    local newMax, newApply = cfg_num("RuneLimit"), cfg_bool("Runecrafting")
    local xp = cfg_num("AutocraftXP")
    local newXp = (xp or 0) > 0 and xp or nil
    local bonusOn = cfg_bool("AutocraftBonus")
    local changed = (newMax ~= WANTED_MAX) or (newApply ~= APPLY_LIMIT) or (newXp ~= AUTOCRAFT_XP_MULTIPLIER)
        or (bonusOn and not AUTOCRAFT_FULL_BONUS)
    WANTED_MAX, APPLY_LIMIT, AUTOCRAFT_XP_MULTIPLIER = newMax, newApply, newXp
    if bonusOn then AUTOCRAFT_FULL_BONUS = true end   -- Enable live; disable requires restart.
    autocraftApplied = false
    if changed and valid(panelRef) then   -- Apply to the existing panel right away.
        panelAddr = nil
        setup_panel(panelRef, "settings changed")
    end
end

-- Fallback search while panel reference is missing.
add_task("rune panel check", 30000, function()
    if valid(panelRef) then return end
    local p = find_panel()
    if p then
        bump("rune panel found by sweep")
        watch_panel(p, 1)
    end
end)

-- Initialize new rune panel after data loads.
pcall(function()
    NotifyOnNewObject("/Script/Dominion.RunecraftingMainPanel", function(p)
        bump("rune panel created")
        watch_panel(p, 1)
    end)
end)

pcall(function()
    RegisterHook("/Script/Dominion.RunecraftingMainPanel:BP_OnRuneSelected", function() end, function(self, rune)
        pcall(function()
            local p = unwrap(self)
            if valid(p) then
                local runeType = unwrap(rune)
                log("Rune selected: %s", tostring(runeType))
                apply_limit(p, "rune selected")
            end
        end)
    end)
end)

log("loaded. Limit %s, autocraft full bonus=%s, autocraft XP x%s.", tostring(WANTED_MAX), tostring(AUTOCRAFT_FULL_BONUS), tostring(AUTOCRAFT_XP_MULTIPLIER))
end

-- ------------------------------------------------------------
-- Carry weight
--
-- Legs of Lightness effect: extra capacity = base / (percent / 100) - base.
-- 100% = vanilla; 0% = 999999 total.
-- ------------------------------------------------------------
do
    local valid = is_valid_obj   
    local CW_GE_PATH   = "/Game/Gameplay/GameplayEffects/Effects/GE_ModifyMaxCarryWeight_LegsofLightness.GE_ModifyMaxCarryWeight_LegsofLightness_C"
    local CW_KEY = "cw|legsoflightness"
    local UNLIMITED = 999999
    local said = {}
    local function note(msg)   -- Log once per message.
        if not said[msg] then said[msg] = true; log("%s", msg) end
    end

    local function find_class(path)
        local okS, found = pcall(StaticFindObject, path)
        if okS and valid(found) then return found end
        if LoadAsset then
            pcall(LoadAsset, (path:gsub("%.[^%.]*$", "")))
            okS, found = pcall(StaticFindObject, path)
            if okS and valid(found) then return found end
        end
        return nil
    end

    local function full_name(o)
        local ok, n = pcall(function() return o:GetFullName() end)
        return ok and tostring(n) or ""
    end

    local lastPawnScan = 0
    local function get_pawn()
        local pc = get_local_player_controller()
        if pc then
            local okP, pawn = pcall(function() return pc.Pawn end)
            if okP and valid(pawn) then return pawn end
            okP, pawn = pcall(function() return pc:GetPawn() end)
            if okP and valid(pawn) then return pawn end
        end
        -- Fallback search, at most every 5s.
        local now = os.time()
        if now - lastPawnScan < 5 then return nil end
        lastPawnScan = now
        local okF, pawn = pcall(function() return FindFirstOf("BP_PlayerCharacter_C") end)
        if okF and valid(pawn) and not full_name(pawn):find("Default__", 1, true) then return pawn end
        return nil
    end

    local function ge_component(pawn)
        local okC, comp = pcall(function() return pawn.BP_Components_PlayerGameplayEffects end)
        if okC and valid(comp) then return comp end
        return nil
    end

    local cw = { appliedPercent = 100, pawnName = nil, wantPercent = nil, warned = false }

    local function cw_percent()
        local p = cfg_num("CarryWeightPercent")
        if p == nil then p = 100 end
        if p < 0 then p = 0 elseif p > 100 then p = 100 end
        return p
    end

    local function cw_delta(percent)
        local base = cfg_num("CarryWeightBase") or 550
        if base < 1 then base = 550 end
        if percent <= 0 then return UNLIMITED - base end   -- Inventory cap.
        return base / (percent / 100) - base
    end

    -- Apply only when pawn or weight setting changes.
    local function cw_apply()
        local percent = cw_percent()
        local pawn = get_pawn()
        if not pawn then return false end
        local pname = full_name(pawn)
        if not pname:find("PlayerCharacter", 1, true) then return false end   -- Ignore menu/loading state.
        local pawnChanged = (cw.pawnName ~= pname)
        if not pawnChanged and cw.appliedPercent == percent then return true end

        local cls = find_class(CW_GE_PATH)
        if not cls then note("Carry weight: could not find the carry weight effect class."); return false end
        local okCdo, cdo = pcall(function() return cls:GetCDO() end)
        if not okCdo or not valid(cdo) then note("Carry weight: could not get the effect's default object."); return false end
        local comp = ge_component(pawn)
        if not comp then note("Carry weight: could not find the player's effects component on " .. pname); return false end

        local okA, cur = pcall(function() return cdo.Data.AmountToModify.Value end)
        if not (okA and type(cur) == "number") then
            note("Carry weight: could not read Data.AmountToModify.Value (got " .. tostring(cur) .. ").")
            return false
        end
        local orig = resolve_original(CW_KEY, cur)

        -- Remove previously applied effect on the same pawn.
        if not pawnChanged and cw.appliedPercent < 100 then
            pcall(function() comp:BP_RemoveAllGameplayEffectsWithData(cls) end)
        end

        if percent >= 100 then
            pcall(function() cdo.Data.AmountToModify.Value = orig end)
            record_applied(CW_KEY, orig, orig)
            if cw.appliedPercent < 100 or cw.pawnName ~= nil then log("Carry weight: back to normal.") end
        else
            local delta = cw_delta(percent)
            pcall(function() cdo.Data.AmountToModify.Value = delta end)
            record_applied(CW_KEY, orig, delta)
            local okG, err = pcall(function() return pawn:AddGameplayEffect(cdo, pawn, pawn) end)
            if not okG then
                log("Carry weight: could not apply (%s)", tostring(err))
                return false
            end
            log("Carry weight: items weigh %.0f%% (extra capacity +%.0f on a base of %s).", percent, delta, tostring(cfg_num("CarryWeightBase")))
        end
        cw.appliedPercent = percent
        cw.pawnName = pname
        orig_flush()
        return true
    end

    REFRESH[#REFRESH + 1] = function()
        cw.warned = false
        local ok, e = pcall(cw_apply)
        if not ok then note('Carry weight error: ' .. tostring(e)) end
    end

    -- Pawn components initialize after respawn; retry briefly.
    local kickGen = 0
    local function cw_kick()
        kickGen = kickGen + 1
        local gen = kickGen
        for _, ms in ipairs({ 1000, 3000, 6000, 12000 }) do
            later(ms, function()
                if gen ~= kickGen then return end
                local ok, res = pcall(cw_apply)
                if not ok then note('Carry weight error: ' .. tostring(res)) end
                if ok and res then kickGen = kickGen + 1 end   -- Applied; cancel the remaining attempts.
            end)
        end
    end

    local okHook, errHook = pcall(RegisterHook, "/Script/Engine.PlayerController:ClientRestart", function() end, function()
        bump("player restart event")
        forget_player()
        cdState.dirty = true
        wake(t_cooldown)
        cw_kick()
    end)
    if not okHook and PERF then log("[perf] player restart hook unavailable: %s", tostring(errHook)) end

    -- Cached-player fallback for missed restart events.
    add_task("carry weight", 10000, function()
        local ok, e = pcall(cw_apply)
        if not ok then note('Carry weight error: ' .. tostring(e)) end
    end)
    log("Carry weight %s%%.", tostring(cfg_num("CarryWeightPercent")))
end

-- ------------------------------------------------------------
-- Optional Mod Menu live sync; config.txt remains standalone.
-- ------------------------------------------------------------
do
    local MODMENU_ID = "GreaterFarming"
    local mmRev = nil
    local function modmenu_sync()
        local ok, rev = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".rev") end)
        if not ok or type(rev) ~= "number" or rev == mmRev then return end
        local first = (mmRev == nil)
        mmRev = rev
        if first then return end   -- Initial revision reflects startup config.

        local changed = 0
        for _, e in ipairs(CFG_ENTRIES) do
            local key = e[1]
            if key ~= "DebugDump" then
                local okV, v = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. "." .. key) end)
                if okV and v ~= nil then
                    local text
                    if type(v) == "boolean" then text = v and "true" or "false"
                    elseif type(v) == "number" then text = string.format("%.10g", v)
                    else text = tostring(v):lower() end
                    if CFG[key:lower()] ~= text then
                        CFG[key:lower()] = text
                        changed = changed + 1
                    end
                end
            end
        end
        if changed > 0 then
            for _, fn in ipairs(REFRESH) do pcall(fn) end
            print(string.format("[GreaterFarming] Mod Menu: %d setting(s) changed -- applying live.\n", changed))
        end
    end
    -- Mod Menu revision polling; no change callback available.
    add_task("mod menu", 500, function() pcall(modmenu_sync) end)
end

-- ------------------------------------------------------------
-- PerfLog: minute summaries. os.clock resolution ~1ms.
-- ------------------------------------------------------------
if PERF then
    add_task("perf report", 60000, function()
        local labels = {}
        for k in pairs(perfStats) do labels[#labels + 1] = k end
        table.sort(labels)
        for _, k in ipairs(labels) do
            local s = perfStats[k]
            log("[perf] %-44s %4d run(s)  avg %.2f ms  max %.2f ms%s", k, s.calls, s.total / s.calls * 1000, s.max * 1000,
                s.objs and string.format("  (%d object(s))", s.objs) or "")
        end
        local evs = {}
        for k, v in pairs(perfEvents) do evs[#evs + 1] = string.format("%s x%d", k, v) end
        table.sort(evs)
        if #evs > 0 then log("[perf] events this minute: %s", table.concat(evs, ", ")) end
        perfStats, perfEvents = {}, {}
    end)

    -- One-time search benchmark after player initialization.
    local waited = 0
    add_task("perf benchmark", 5000, function()
        if cachedPC == nil then return end
        waited = waited + 1
        if waited < 6 then return end
        for _, name in ipairs({ "PlayerController", "BP_AgilityOrb_Base_C", "BP_StaminaOrb_C", "WBP_Runecrafting_MainPanel_C" }) do
            local runs, count, t0 = 10, 0, os.clock()
            for _ = 1, runs do
                local list = find_all(name)
                count = list and #list or 0
            end
            log("[perf] benchmark: FindAllOf %s takes %.2f ms per search (%d object(s) found)", name, (os.clock() - t0) / runs * 1000, count)
        end
        return true
    end)
end

start_scheduler()