DON'T REPLANT - RuneScape: Dragonwilds
by Luckiron

Your crops grow back after every harvest. No more replanting.

WHAT IT DOES
- Harvest your crop as usual. The same plant is replanted in the same plot right away,
  for free (no seed is taken from your inventory).
- It grows again from the start, like a seed you planted yourself. Rapid Growth still works.
- You still water after each harvest. One compost lasts 2 harvests (you can change this).
- Plants can still get sick and die: dig up a dead plant with a spade and plant a new seed.
  (You can turn diseases off with the NoDisease setting.)
- Every harvest gives the full amount of crops, the full Farming XP and the normal chance of seeds.

HOW IT WORKS
- A plot is remembered as soon as you plant a seed in it yourself while the mod is installed.
- To change the crop in a plot: dig it up with a spade, then plant the new seed.
- Crops planted BEFORE you installed the mod act like berry bushes (they stay after harvest,
  but keep their compost and give a little less each time). Dig them up and plant them again
  once to switch them to the full system.

MULTIPLAYER
Only the host (or the dedicated server) needs the mod. Friends don't need to install anything.

REQUIREMENTS
- UE4SS for RSDragonwilds (required): https://www.nexusmods.com/runescapedragonwilds/mods/4
- Mod Menu by Maxxfilth (optional, settings in game): https://www.nexusmods.com/runescapedragonwilds/mods/548

INSTALLATION
1. Install UE4SS for RSDragonwilds.
2. Put this DontReplant folder in:
   RSDragonwilds\RSDragonwilds\Binaries\Win64\ue4ss\Mods\
   (on Steam, the first RSDragonwilds folder is in steamapps\common)
3. Start the game. Keep the enabled.txt file in the folder: it tells the game to load the mod.

SETTINGS
With Mod Menu: press Esc, click MODS, then Don't Replant.
Without Mod Menu: open config.txt with Notepad, change the value after "=", save, restart the game.

  Enabled (Mod Menu: "Crops stay after harvest") - default true
    false = normal farming, as if the mod wasn't installed.

  Replant (Mod Menu: "Free replant after harvest") - default true
    true  = plots you planted yourself are replanted for free, full crops and XP every time.
    false = every crop acts like a berry bush instead.

  CompostHarvests (Mod Menu: "Harvests per compost") - default 2
    How many harvests one compost lasts. 1 = like the base game.

  NoDisease (Mod Menu: "Disable plant disease") - default false
    true  = crops never get sick (a plant that is already sick still needs a cure once).
    false = like the base game. In multiplayer, only the host's setting counts.

  Exclude (Mod Menu: "Keep vanilla for") - default empty
    Crops that work exactly like in the base game (they disappear when harvested).
    Names separated by commas, capital letters don't matter. Example: Exclude = Wheat, Flax
    Names you can use:
      Cabbage, Onion, Potato, Tomato, Pumpkin, Watermelon, Wheat, Flax,
      Harralander, Marrentill, Toadflax, Irit, Kwuarm, Snapdragon, Avantoe,
      SwampWeed, CorpseCotton, Weed_Desert (Desert Weed),
      Cactus_Barrel, Cactus_Bunny, Cactus_Pipe,
      Redberry, Dwellberry, Cadavaberry (berry bushes)
    Berry bushes already grow back in the base game: if you list them here, they keep their
    normal berry bush behavior.

  FullXp (Mod Menu: "Full XP on every harvest") - default true
    For everything that grows back like a berry bush (crops planted before the mod, and berry
    bushes listed in Exclude). true = full XP every harvest, false = base game (5% after the
    first harvest).

  Verbose (Mod Menu: "Detailed log") - default false
    Writes what the mod does in ue4ss\UE4SS.log. Only useful to report a bug.

GOOD TO KNOW
- The mod never changes your save file. Remove it and farming goes back to normal.
- Remembered plots are kept in plots.txt in this folder. Delete it to make the mod forget them.
- Tested on Steam. Not tested on Game Pass yet.

UNINSTALL
Delete the DontReplant folder.

CHANGELOG
1.1 - New option: Disable plant disease (NoDisease, off by default).
1.0 - First release.

CREDITS
Maxxfilth for Mod Menu, and the UE4SS team for UE4SS.

LICENSE
Free to use and to set up for your own game. Please don't re-upload it elsewhere (link to the
Nexus Mods page instead), and ask Luckiron before sharing a modified version or reusing part of it.
Full text in the LICENSE file.
