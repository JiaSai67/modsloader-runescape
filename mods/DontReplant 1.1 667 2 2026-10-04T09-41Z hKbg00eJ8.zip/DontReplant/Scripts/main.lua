-- Don't Replant - RuneScape: Dragonwilds - by Luckiron (all rights reserved, see LICENSE)
--
-- Crops stay in their farming plot after a harvest: there is nothing to replant. Watering,
-- compost and disease still matter, a plant that dies still has to be dug up with a spade, and a
-- harvest keeps its normal chance to give a seed back.
--
-- How it works, per plot:
--   * Known plot (planted by hand while the mod runs, remembered in plots.txt): the harvest is a
--     vanilla one (full yield, full XP, plot cleared with its water and compost), then the mod
--     plants the same crop again for free. It grows from the seed stage the vanilla way (the
--     Rapid Growth spell still works on it). After the first harvest of a compost the mod puts
--     the same compost back (CompostHarvests = 2: one compost lasts two harvests). Everything
--     goes through the game's own server functions (Server_TryPlantSeed,
--     Server_TryFertilizePlot), so guests and the save see an ordinary plot.
--   * Unknown plot (planted before the mod or while it was off): the game's berry-bush switch,
--     bIsBerryBush, is on for every crop, in memory only. The plant reverts one stage instead of
--     being cleared, keeps its compost and gives ~10% less per extra harvest, like a vanilla bush.
--     FullXp removes the 95% XP cut on those extra harvests (one global setting).
--   NoDisease (off by default) sets every crop's disease chance to 0, in memory only.
--   Nothing is written to the save. Without the mod, crops are single-harvest again.
--
-- Multiplayer: harvests, planting and compost all run on the machine that owns the world (solo,
-- co-op host or dedicated server), so only that machine needs the mod. On a guest it stays idle.
--
-- Threading: ALL of this mod's Lua runs on the game thread: one LoopInGameThreadWithDelay loop,
-- the hooks (the game calls them on its own thread) and the console command. No ExecuteWithDelay,
-- LoopAsync or ExecuteAsync: the first test version (0.1.0) started through ExecuteWithDelay (UE4SS's background thread)
-- and crashed the game at the title screen with a corrupted Lua state (2026-09-30).
-- The hooks never call the game back while it is handling a request: the replanting they ask for
-- runs on the next loop pass, a quarter of a second later.

local MOD_ID  = "DontReplant"
local VERSION = "1.1"
local TAG     = "[DontReplant] "

local cfg = {
    Enabled         = true,
    Replant         = true,  -- known plots: vanilla harvest, then free replant (full yield and XP)
    CompostHarvests = 2,     -- one compost lasts this many harvests on a known plot (1 = vanilla)
    NoDisease       = false, -- true = crops never get sick (disease chance 0), false = vanilla
    Exclude         = "",    -- comma-separated crops left vanilla, e.g. "Wheat, FPD_Flax"
    FullXp          = true,  -- unknown plots: full Farming XP on every harvest, not 5% after the first
    Verbose         = false,
}

-- Never touched. FPD_Weeds is the weeds that grow on an empty plot: clearing them must keep
-- emptying the plot. (FPD_Weed_Desert and FPD_SwampWeed are real crops and are converted.)
local NEVER = { fpd_weeds = true }

-- Crops in the 1.0 build: 24 FPD_ assets besides FPD_Weeds. Only used to know when a scan has
-- seen everything, so the mod can stop walking the object list every few seconds.
local EXPECTED_CROPS = 24

local FLAG = "bIsBerryBush"
local FARM = "/Script/Dominion.FarmCommandComponent:"

local LOOP_MS         = 250   -- loop pass: a replant waits at most a quarter of a second
local TICK_EVERY      = 8     -- everything else runs every 8 passes (2 s), a "tick"
local START_TICKS     = 5     -- do nothing for the first 5 ticks (10 s) while the game starts
local PC_RETRY_TICKS  = 2     -- look for a player controller at most every 2 ticks (4 s)
local FIND_RETRY_TICKS = 15   -- a missing subsystem is looked for at most every 15 ticks (30 s)
local FAST_SCAN_TICKS = 3     -- first rescan 6 s after a world change, then doubling...
local SLOW_SCAN_TICKS = 150   -- ...up to every 5 min (FindAllOf costs ~50 ms on the game thread)
local COMPOST_CHUNK   = 10    -- the game applies compost 10 charges at a time (seen 2026-10-01)

local tickCount = 0

local function log(fmt, ...) print(TAG .. string.format(fmt, ...) .. "\n") end
local function vlog(fmt, ...) if cfg.Verbose then log(fmt, ...) end end

-- ---------------------------------------------------------------------------
-- Defensive reflection
-- ---------------------------------------------------------------------------

local function valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

local function fullName(o)
    local ok, s = pcall(function() return o:GetFullName() end)
    return ok and tostring(s) or "?"
end

local function shortName(o)
    local ok, s = pcall(function() return o:GetFName():ToString() end)
    return ok and tostring(s) or "?"
end

local function isCDO(o) return fullName(o):find("Default__", 1, true) ~= nil end

local function address(o)
    local ok, a = pcall(function() return o:GetAddress() end)
    return ok and a or nil
end

local function readFlag(o)
    local ok, v = pcall(function() return o[FLAG] end)
    if ok and type(v) == "boolean" then return v end
    return nil
end

local function writeFlag(o, value)
    return (pcall(function() o[FLAG] = value end))
end

-- Value of a hook parameter (UE4SS hands them over wrapped). nil on any failure.
local function param(p)
    if p == nil then return nil end
    local ok, v = pcall(function() return p:get() end)
    if ok then return v end
    return nil
end

-- Calls a game function that answers true/false. false on any failure.
local function callBool(o, fnName)
    local ok, v = pcall(function() return o[fnName](o) end)
    return ok and v == true
end

-- The first live object of a class, kept for next time. FindAllOf walks every object (~50 ms),
-- so a missing one is looked for at most every FIND_RETRY_TICKS.
local finders = {}

local function cached(className)
    local c = finders[className]
    if not c then c = {}; finders[className] = c end
    if valid(c.obj) then return c.obj end
    c.obj = nil
    if (c.nextTry or 0) > tickCount then return nil end
    c.nextTry = tickCount + FIND_RETRY_TICKS
    local ok, all = pcall(FindAllOf, className)
    if ok and type(all) == "table" then
        for _, o in ipairs(all) do
            if valid(o) and not isCDO(o) then c.obj = o; break end
        end
    end
    return c.obj
end

-- ---------------------------------------------------------------------------
-- Config (config.txt next to enabled.txt, "Key = value" lines, also written by Mod Menu)
-- ---------------------------------------------------------------------------

local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    return src:match("^(.*)[/\\][Ss]cripts[/\\][^/\\]*$")
end

local function loadConfig()
    local root = modRoot()
    local f = root and io.open(root .. "\\config.txt", "r")
    if not f then log("no config.txt found, using defaults"); return end
    for line in f:lines() do
        line = line:gsub("^%s+", ""):gsub("%s+$", "")
        local first = line:sub(1, 1)
        if line ~= "" and first ~= "#" and first ~= ";" then
            local k, v = line:match("^([%w_]+)%s*=%s*(.-)$")
            if k then
                v = v:gsub("%s*[#;].*$", "")
                if type(cfg[k]) == "boolean" then
                    v = v:lower()
                    cfg[k] = (v == "true" or v == "1" or v == "yes")
                elseif type(cfg[k]) == "number" then
                    local n = tonumber(v)
                    if n then cfg[k] = n else log("bad number for %s: %s", k, v) end
                elseif type(cfg[k]) == "string" then
                    cfg[k] = v
                else
                    log("unknown config key ignored: %s", k)
                end
            end
        end
    end
    f:close()
end

-- ---------------------------------------------------------------------------
-- Crops the mod knows about
-- ---------------------------------------------------------------------------

-- [full name] = { obj, name, original = vanilla bIsBerryBush, skip = left vanilla }
local tracked = {}
local excluded = {}

local function isExcluded(name)
    local key = name:lower()
    return NEVER[key] == true or excluded[key] == true
end

local function rebuildExcluded()
    excluded = {}
    for word in (cfg.Exclude or ""):gmatch("[^,%s]+") do
        local key = word:lower()
        if key:sub(1, 4) ~= "fpd_" then key = "fpd_" .. key end
        excluded[key] = true
    end
    for _, e in pairs(tracked) do e.skip = isExcluded(e.name) end
end

local function cropCount()
    local n = 0
    for _, e in pairs(tracked) do
        if not NEVER[e.name:lower()] then n = n + 1 end
    end
    return n
end

local flagMissingWarned = false

-- Walks the object list (about 50 ms), so it only runs on the schedule in tick().
local function scan()
    local ok, all = pcall(FindAllOf, "FarmPlantDataAsset")
    if not ok or type(all) ~= "table" then return 0 end
    local added = 0
    for _, o in ipairs(all) do
        if valid(o) and not isCDO(o) then
            local full = fullName(o)
            if not tracked[full] then
                local name = shortName(o)
                local original = readFlag(o)
                if original == nil then
                    if not flagMissingWarned then
                        flagMissingWarned = true
                        log("%s has no %s property: the game changed, Don't Replant cannot work on this version", name, FLAG)
                    end
                else
                    tracked[full] = { obj = o, name = name, original = original, skip = isExcluded(name) }
                    added = added + 1
                    vlog("found %s (vanilla %s = %s)", name, FLAG, tostring(original))
                end
            end
        end
    end
    return added
end

-- on = true: every crop not excluded stays after harvest. on = false: vanilla values back.
-- Returns how many crops were switched on, switched off, and unloaded since the last call.
local function setAll(on)
    local switchedOn, switchedOff, dropped = 0, 0, 0
    for full, e in pairs(tracked) do
        if not valid(e.obj) then
            tracked[full] = nil   -- unloaded; a rescan picks up the reloaded asset with its vanilla value
            dropped = dropped + 1
        else
            local want = e.original
            if on and not e.skip then want = true end
            if readFlag(e.obj) ~= want and writeFlag(e.obj, want) then
                if want then switchedOn = switchedOn + 1 else switchedOff = switchedOff + 1 end
                vlog("%s: %s = %s", e.name, FLAG, tostring(want))
            end
        end
    end
    return switchedOn, switchedOff, dropped
end

-- The same value on every crop but the weeds, whatever the config. Only used around one harvest;
-- setAll puts the normal values back right after it.
local function forceAll(value)
    for _, e in pairs(tracked) do
        if valid(e.obj) and not NEVER[e.name:lower()] and readFlag(e.obj) ~= value then
            writeFlag(e.obj, value)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Harvest XP
-- ---------------------------------------------------------------------------

-- One global farming setting: every harvest of a bush after its first one gives
-- BerryBushXpReductionFactor times the XP (0.05 in 1.0). 1.0 means no reduction. It is global,
-- so the vanilla berry bushes get full XP too. Known plots do not need it: their harvests are
-- vanilla first harvests.
local XP_FACTOR = "BerryBushXpReductionFactor"
local settings, xpOriginal = nil, nil

local function farmingSettings()
    if not valid(settings) then
        local ok, s = pcall(StaticFindObject, "/Script/Dominion.Default__FarmingSettings")
        settings = (ok and valid(s)) and s or nil
    end
    return settings
end

-- on = true: full XP on every harvest, false: the vanilla factor. Returns true when it changed.
local function setFullXp(on)
    local s = farmingSettings()
    if not s then return false end
    local ok, current = pcall(function() return s[XP_FACTOR] end)
    if not ok or type(current) ~= "number" then return false end
    if xpOriginal == nil then xpOriginal = current end
    local want = on and 1.0 or xpOriginal
    if current == want then return false end
    return (pcall(function() s[XP_FACTOR] = want end))
end

-- ---------------------------------------------------------------------------
-- Plant disease
-- ---------------------------------------------------------------------------

-- Each crop has a disease chance (FPD_Cabbage: 0.4 = 40%, the wiki's numbers), a second one for a
-- plot of the wrong tier, and the same two fields on each of its growth stages. NoDisease puts all
-- of them to 0, in memory only; the vanilla values come back when it is turned off.
local DISEASE_PROPS = { "DiseaseChance", "DiseaseChanceNotPreferred" }

-- Vanilla value of every disease field, keyed by object and field, read before the first write.
-- Keyed by object rather than by crop, so a growth stage shared by two crops keeps its true value.
local diseaseOriginal = {}

-- The disease fields of one crop and of its growth stages, listed once per crop.
local function diseaseFields(e)
    if e.disease then return e.disease end
    local list = {}
    local function add(o)
        for _, prop in ipairs(DISEASE_PROPS) do
            local ok, v = pcall(function() return o[prop] end)
            if ok and type(v) == "number" then
                local key = fullName(o) .. "|" .. prop
                if diseaseOriginal[key] == nil then diseaseOriginal[key] = v end
                list[#list + 1] = { obj = o, prop = prop, key = key }
            end
        end
    end
    add(e.obj)
    pcall(function()
        local stages = e.obj.Stages
        for i = 1, stages:GetArrayNum() do
            local stage = stages[i]
            if valid(stage) then add(stage) end
        end
    end)
    e.disease = list
    return list
end

-- on = true: no crop can get sick, false: the vanilla chances. Returns how many fields changed.
local function setNoDisease(on)
    for _, e in pairs(tracked) do                 -- list every field before writing any
        if valid(e.obj) and not NEVER[e.name:lower()] then diseaseFields(e) end
    end
    local changed = 0
    for _, e in pairs(tracked) do
        if e.disease and valid(e.obj) then
            for _, f in ipairs(e.disease) do
                local want = on and 0.0 or diseaseOriginal[f.key]
                local ok, current = pcall(function() return f.obj[f.prop] end)
                if ok and type(current) == "number" and want ~= nil and current ~= want then
                    if pcall(function() f.obj[f.prop] = want end) then changed = changed + 1 end
                end
            end
        end
    end
    return changed
end

-- ---------------------------------------------------------------------------
-- Plant ids
-- ---------------------------------------------------------------------------

-- The game names a crop with a small number, its NetId: Server_TryPlantSeed receives one. The
-- plant data subsystem keeps the crops in id order (NetIdToData), so the mod can turn an id into
-- a crop name and back. plots.txt stores names: an id could change with a game update.
local idToName, nameToId = nil, nil
local idCount = 0

-- Returns true once the table is built (it never changes while the game runs).
local function loadPlantIds()
    if idToName then return true end
    local sub = cached("FarmPlantDataSubsystem")
    if not sub then return false end
    local list = nil
    pcall(function() list = sub.NetIdToData end)
    if not list then return false end
    local n = 0
    pcall(function() n = list:GetArrayNum() end)
    if n == 0 then return false end
    local byId, byName = {}, {}
    for i = 1, n do
        local asset = nil
        pcall(function() asset = list[i] end)
        if valid(asset) then
            local name = shortName(asset)
            byId[i - 1] = name        -- Lua arrays start at 1, the game's ids at 0
            byName[name] = i - 1
        end
    end
    idToName, nameToId, idCount = byId, byName, n
    log("%d plant ids loaded (FPD_Cabbage = %s)", n, tostring(byName.FPD_Cabbage))
    return true
end

-- ---------------------------------------------------------------------------
-- Known plots (plots.txt, next to config.txt)
-- ---------------------------------------------------------------------------

-- One line per plot planted by hand while the mod runs, for every world:
--   world|plot id|crop|preferred plot tier (0/1)|compost level|harvests since that compost
-- allPlots[world][plot id] = { crop = "FPD_Cabbage", pref = true, compost = 1, uses = 0 }
local allPlots = {}
local plots = {}               -- the current world's plots (a table inside allPlots)
local worldId = nil
local plotsDirty = false
local plotsPath = (modRoot() or ".") .. "\\plots.txt"

local function loadPlots()
    local f = io.open(plotsPath, "r")
    if not f then return end
    local count = 0
    for line in f:lines() do
        local w, id, crop, pref, compost, uses = line:match("^([^#|][^|]*)|(%d+)|([%w_]+)|([01])|(%d+)|(%d+)")
        if w then
            allPlots[w] = allPlots[w] or {}
            allPlots[w][tonumber(id)] = { crop = crop, pref = pref == "1", compost = tonumber(compost), uses = tonumber(uses) }
            count = count + 1
        end
    end
    f:close()
    log("%d known plot(s) read from plots.txt", count)
end

local function savePlots()
    plotsDirty = false
    local f = io.open(plotsPath, "w")
    if not f then log("cannot write %s", plotsPath); return end
    f:write("# Don't Replant - plots replanted after each harvest. Delete a line to forget a plot.\n")
    f:write("# world|plot|crop|preferred tier|compost level|harvests since that compost\n")
    for w, list in pairs(allPlots) do
        for id, r in pairs(list) do
            f:write(string.format("%s|%s|%s|%d|%d|%d\n", w, tostring(math.tointeger(id) or id), r.crop,
                r.pref and 1 or 0, r.compost or 0, r.uses or 0))
        end
    end
    f:close()
end

-- The loaded world's save id (worlds can have plots with the same ids), or nil at the menu.
local function currentWorldId()
    local p = cached("PersistenceSubsystem")
    if not p then return nil end
    local id = nil
    pcall(function()
        local g = p.WorldSaveSettings.WorldSaveGuid
        if g.A ~= 0 or g.B ~= 0 or g.C ~= 0 or g.D ~= 0 then
            id = string.format("%08X%08X%08X%08X", g.A & 0xFFFFFFFF, g.B & 0xFFFFFFFF, g.C & 0xFFFFFFFF, g.D & 0xFFFFFFFF)
        end
    end)
    if not id then
        pcall(function()
            local s = p.WorldSaveSettings.WorldSlotName:ToString()
            if s ~= "" then id = (s:gsub("[|%s]", "_")) end
        end)
    end
    return id
end

-- The plot component of a plot id, from the farming subsystem of the current world.
local function slotOf(plotId)
    local farming = cached("FarmingSubsystem")
    if not farming then return nil end
    local ok, slot = pcall(function() return farming:BP_GetFarmSlotActor(plotId) end)
    if ok and valid(slot) then return slot end
    return nil
end

-- ---------------------------------------------------------------------------
-- Who owns the world
-- ---------------------------------------------------------------------------

-- Any player controller tells who owns the world. On the machine that owns it (solo, co-op host,
-- dedicated server) every controller has authority; on a guest the only controller is its own,
-- without authority. FindAllOf walks every object (~50 ms), so the controller is cached and a
-- missing one is looked for at most every PC_RETRY_TICKS. A map load creates a new controller,
-- which is also how a world change is noticed.
local pc = nil
local pcRetry = 0

local function findController()
    if valid(pc) then return pc end
    pc = nil
    pcRetry = pcRetry - 1
    if pcRetry > 0 then return nil end
    pcRetry = PC_RETRY_TICKS
    local ok, all = pcall(FindAllOf, "PlayerController")
    if ok and type(all) == "table" then
        for _, c in ipairs(all) do
            if valid(c) and not isCDO(c) then pc = c; break end
        end
    end
    return pc
end

-- "authority", "client", or nil while there is no controller (loading, empty dedicated server).
local function worldRole()
    local c = findController()
    if not c then return nil, nil end
    local ok, auth = pcall(function() return c:HasAuthority() end)
    if not ok then return nil, nil end
    return (auth and "authority" or "client"), c
end

local role = nil

local function isActive() return cfg.Enabled and role == "authority" end

-- ---------------------------------------------------------------------------
-- Farming hooks: what the host receives when someone plants, composts, digs or harvests
-- ---------------------------------------------------------------------------

local busy = false        -- true while the mod itself calls the game's farming functions
local harvesting = nil    -- the harvest being handled, between its pre and post hook
local pending = {}        -- replants waiting for the next loop pass
local hooksOn = false

local function replantOn() return isActive() and cfg.Replant and not busy end

-- Server_TryPlantSeed(PlotID, NetId, bIsPreferredPlotTier, Instigator), after the game ran it.
local function onPlant(plotP, netP, prefP)
    if not replantOn() or not loadPlantIds() then return end
    local plotId, pref, netId = param(plotP), param(prefP), nil
    pcall(function() netId = param(netP).NetId end)
    local crop = netId and idToName[netId]
    if plotId == nil or not crop or NEVER[crop:lower()] then return end
    plots[plotId] = { crop = crop, pref = pref == true, compost = 0, uses = 0 }
    plotsDirty = true
    vlog("plot %s: %s planted, it will be replanted after each harvest", tostring(plotId), crop)
end

-- Server_TryFertilizePlot(PlotID, CompostLevel, Charges, Instigator): compost by hand.
local function onFertilize(plotP, levelP)
    if not replantOn() then return end
    local plotId = param(plotP)
    local r = plotId ~= nil and plots[plotId] or nil
    if not r then return end
    local level = param(levelP)
    if type(level) == "number" and level > 0 then r.compost = level end
    r.uses = 0
    plotsDirty = true
end

-- Server_TryTillPlot(PlotID, Charges, Instigator): the spade. A dug plot is forgotten.
local function onTill(plotP)
    if not replantOn() then return end
    local plotId = param(plotP)
    if plotId ~= nil and plots[plotId] then
        plots[plotId] = nil
        plotsDirty = true
        vlog("plot %s dug up: forgotten", tostring(plotId))
    end
end

-- Server_TryHarvestPlot(PlotID, YieldMultiplier, Instigator, ...), before the game runs it.
-- On a known plot this one harvest becomes a vanilla one: the game clears the plot.
local function onHarvestBefore(ctx, plotP, instP)
    harvesting = nil
    if not replantOn() then return end
    local plotId = param(plotP)
    local r = plotId ~= nil and plots[plotId] or nil
    if not r or isExcluded(r.crop) then return end
    local slot = slotOf(plotId)
    if not slot or not callBool(slot, "CanHarvest") then return end
    harvesting = { plotId = plotId, rec = r, comp = param(ctx), who = param(instP),
                   fertilized = callBool(slot, "IsFullyFertilized") }
    forceAll(false)
end

-- Same harvest, after the game ran it: berry-bush switch back, replant on the next pass.
local function onHarvestAfter()
    local h = harvesting
    harvesting = nil
    if not h then return end
    setAll(isActive())
    pending[#pending + 1] = h
end

local function watch(fnName, before, after)
    local ok, err = pcall(RegisterHook, FARM .. fnName,
        function(...)
            if before then
                local okB, e = pcall(before, ...)
                if not okB then log("%s hook: %s", fnName, tostring(e)) end
            end
        end,
        function(...)
            if after then
                local okA, e = pcall(after, ...)
                if not okA then log("%s hook: %s", fnName, tostring(e)) end
            end
        end)
    if not ok then log("cannot watch %s: %s", fnName, tostring(err)) end
    return ok
end

local function registerHooks()
    hooksOn = watch("Server_TryHarvestPlot",
        function(ctx, plotP, _, instP) onHarvestBefore(ctx, plotP, instP) end,
        function() onHarvestAfter() end)
    watch("Server_TryPlantSeed", nil, function(_, plotP, netP, prefP) onPlant(plotP, netP, prefP) end)
    watch("Server_TryFertilizePlot", nil, function(_, plotP, levelP) onFertilize(plotP, levelP) end)
    watch("Server_TryTillPlot", nil, function(_, plotP) onTill(plotP) end)
    log("farming hooks %s", hooksOn and "on" or "missing: plots will not be replanted")
end

-- ---------------------------------------------------------------------------
-- Replanting (runs on the loop pass after a harvest, never inside the hook)
-- ---------------------------------------------------------------------------

local function compostCharges()
    local n = 50
    pcall(function() n = farmingSettings().CompostNeededForFertilizing end)
    return tonumber(n) or 50
end

local function replant(h)
    local r, comp, plotId, who = h.rec, h.comp, h.plotId, h.who
    if not valid(comp) then return end
    if not loadPlantIds() then log("cannot replant plot %s: plant ids unavailable", tostring(plotId)); return end
    local netId = nameToId[r.crop]
    if netId == nil then log("cannot replant plot %s: no id for %s", tostring(plotId), r.crop); return end
    local recompost = false
    busy = true
    local ok, err = pcall(function()
        comp:Server_TryPlantSeed(plotId, { NetId = netId }, r.pref, who)
        if h.fertilized then
            r.uses = (r.uses or 0) + 1
            if r.uses < cfg.CompostHarvests and (r.compost or 0) > 0 then
                recompost = true
                local left = compostCharges()
                while left > 0 do
                    local n = math.min(COMPOST_CHUNK, left)
                    comp:Server_TryFertilizePlot(plotId, r.compost, n, who)
                    left = left - n
                end
            end
        end
    end)
    busy = false
    plotsDirty = true
    if ok then
        vlog("plot %s: %s replanted%s", tostring(plotId), r.crop, recompost and ", compost put back" or "")
    else
        log("replanting plot %s failed: %s", tostring(plotId), tostring(err))
    end
end

local function processPending()
    if #pending == 0 then return end
    local list = pending
    pending = {}
    for _, h in ipairs(list) do replant(h) end
end

-- ---------------------------------------------------------------------------
-- Mod Menu live settings (optional; without Mod Menu `rev` is nil and nothing happens)
-- ---------------------------------------------------------------------------

local mmRev = nil
local function modMenuSync()
    local ok, rev = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MOD_ID .. ".rev") end)
    if not ok or type(rev) ~= "number" or rev == mmRev then return end
    mmRev = rev
    local function get(key)
        local okV, v = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MOD_ID .. "." .. key) end)
        if okV then return v end
    end
    for _, key in ipairs({ "Enabled", "Replant", "NoDisease", "FullXp", "Verbose" }) do
        local v = get(key); if type(v) == "boolean" then cfg[key] = v end
    end
    local c = get("CompostHarvests"); if type(c) == "number" then cfg.CompostHarvests = c end
    local x = get("Exclude")
    if type(x) == "string" and x ~= cfg.Exclude then cfg.Exclude = x; rebuildExcluded() end
end

-- ---------------------------------------------------------------------------
-- Main loop
-- ---------------------------------------------------------------------------

local worldKey = nil
local scanEvery, ticksToScan = FAST_SCAN_TICKS, 0

local function tick()
    tickCount = tickCount + 1
    if tickCount <= START_TICKS then return end   -- let the game and the other mods finish starting
    if not hooksOn and tickCount == START_TICKS + 1 then registerHooks() end
    pcall(modMenuSync)

    local newRole, controller = worldRole()
    local key = controller and address(controller) or nil
    if key ~= worldKey then
        worldKey = key
        finders = {}                               -- the farming subsystem belongs to the old world
        scanEvery, ticksToScan = FAST_SCAN_TICKS, 0
    end
    if newRole == nil then return end   -- loading: keep everything as it is until a controller exists
    if newRole ~= role then
        role = newRole
        if role == "client" then
            log("joined someone else's world: the host decides how crops behave, staying idle here")
        else
            log("this machine owns the world: crops %s", cfg.Enabled and "stay in their plot after harvest" or "are vanilla (Enabled = false)")
        end
    end

    if isActive() then
        ticksToScan = ticksToScan - 1
        if ticksToScan <= 0 then
            local added = scan()
            local crops = cropCount()
            if added > 0 then log("%d crop(s) known (%d new)", crops, added) end
            scanEvery = crops >= EXPECTED_CROPS and SLOW_SCAN_TICKS or math.min(scanEvery * 2, SLOW_SCAN_TICKS)
            ticksToScan = scanEvery
        end
        local wid = currentWorldId() or "default"
        if wid ~= worldId then
            worldId = wid
            allPlots[wid] = allPlots[wid] or {}
            plots = allPlots[wid]
            local n = 0
            for _ in pairs(plots) do n = n + 1 end
            log("world %s: %d known plot(s)", wid, n)
        end
        if cfg.Replant then
            loadPlantIds()
            cached("FarmingSubsystem")             -- ready before the first harvest
        end
    end

    local on, off, dropped = setAll(isActive())
    if on > 0 then log("%d crop(s) now stay in the plot after harvest", on) end
    if off > 0 then log("%d crop(s) back to vanilla", off) end
    if dropped > 0 then
        vlog("%d crop(s) unloaded, rescanning", dropped)
        scanEvery, ticksToScan = FAST_SCAN_TICKS, 1
    end

    local fullXp = isActive() and cfg.FullXp
    if setFullXp(fullXp) then
        log(fullXp and "every harvest now gives full Farming XP" or "harvest XP back to vanilla (%g after the first harvest)", xpOriginal)
    end

    local noDisease = isActive() and cfg.NoDisease
    local diseaseChanged = setNoDisease(noDisease)
    if diseaseChanged > 0 then
        log(noDisease and "plant disease off (%d disease chance(s) set to 0)" or "plant disease back to vanilla (%d disease chance(s) restored)", diseaseChanged)
    end

    if plotsDirty then savePlots() end
end

local passes = 0
local function loopPass()
    passes = passes + 1
    local ok, err = pcall(processPending)
    if not ok then log("replant error: %s", tostring(err)) end
    if passes % TICK_EVERY == 0 then
        local okT, errT = pcall(tick)
        if not okT then log("tick error: %s", tostring(errT)) end
    end
end

-- ---------------------------------------------------------------------------
-- Console: dontreplant [status|on|off|scan]
-- ---------------------------------------------------------------------------

local function say(ar, fmt, ...)
    local msg = TAG .. string.format(fmt, ...)
    print(msg .. "\n")
    if ar then pcall(function() ar:Log(msg) end) end
end

local function num(o, prop)
    local ok, v = pcall(function() return o[prop] end)
    if ok and type(v) == "number" then return string.format("%g", v) end
    return "?"
end

local function status(ar)
    say(ar, "v%s  enabled=%s  role=%s  replant=%s  hooks=%s  disease=%s", VERSION, tostring(cfg.Enabled), tostring(role),
        tostring(cfg.Replant), hooksOn and "on" or "off", (isActive() and cfg.NoDisease) and "off" or "vanilla")
    local s = farmingSettings()
    if s then
        say(ar, "FarmingSettings: BerryBushXpReductionFactor=%s CompostNeededForFertilizing=%s",
            num(s, XP_FACTOR), num(s, "CompostNeededForFertilizing"))
    end
    say(ar, "plant ids: %s", idToName and string.format("%d (FPD_Cabbage = %s)", idCount, tostring(nameToId.FPD_Cabbage)) or "not loaded")
    local ids = {}
    for id in pairs(plots) do ids[#ids + 1] = id end
    table.sort(ids)
    say(ar, "world %s: %d known plot(s)", tostring(worldId), #ids)
    for i, id in ipairs(ids) do
        if i > 20 then say(ar, "  ... %d more", #ids - 20); break end
        local r = plots[id]
        say(ar, "  plot %s: %s, compost level %d, %d harvest(s) on it", tostring(id), r.crop, r.compost or 0, r.uses or 0)
    end
    local names = {}
    for full in pairs(tracked) do names[#names + 1] = full end
    table.sort(names)
    for _, full in ipairs(names) do
        local e = tracked[full]
        say(ar, "  %-20s %s=%s (vanilla %s)%s", e.name, FLAG, tostring(readFlag(e.obj)), tostring(e.original),
            e.skip and " [left vanilla]" or "")
    end
    say(ar, "%d crop(s) known", cropCount())
end

pcall(RegisterConsoleCommandHandler, "dontreplant", function(_, params, ar)
    local ok, err = pcall(function()
        local sub = ((params and params[1]) or "status"):lower()
        if sub == "on" or sub == "off" then
            cfg.Enabled = (sub == "on")
            say(ar, "%s for this session (config.txt unchanged)", cfg.Enabled and "enabled" or "disabled")
            if isActive() then scan() end
            local on, off = setAll(isActive())
            setFullXp(isActive() and cfg.FullXp)
            setNoDisease(isActive() and cfg.NoDisease)
            say(ar, "%d crop(s) changed", on + off)
        elseif sub == "scan" then
            local added = scan()
            setAll(isActive())
            say(ar, "scan: %d new, %d crop(s) known", added, cropCount())
        else
            status(ar)
        end
    end)
    if not ok then say(ar, "command failed: %s", tostring(err)) end
    return true
end)

-- ---------------------------------------------------------------------------
-- Start
-- ---------------------------------------------------------------------------

loadConfig()
rebuildExcluded()
loadPlots()

if type(LoopInGameThreadWithDelay) ~= "function" then
    log("v%s: this UE4SS build has no LoopInGameThreadWithDelay, the mod stays idle (needs UE4SS 3.0.1 f6d5f942 or newer)", VERSION)
else
    local okLoop, err = pcall(LoopInGameThreadWithDelay, LOOP_MS, loopPass)
    if okLoop then
        log("v%s loaded (Enabled = %s, Replant = %s%s), main loop on the game thread", VERSION, tostring(cfg.Enabled),
            tostring(cfg.Replant), cfg.Exclude ~= "" and (", Exclude = " .. cfg.Exclude) or "")
    else
        log("v%s: could not start the main loop (%s), the mod stays idle", VERSION, tostring(err))
    end
end
