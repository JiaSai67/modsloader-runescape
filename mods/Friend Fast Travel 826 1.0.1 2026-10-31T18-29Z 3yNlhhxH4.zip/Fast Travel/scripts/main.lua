-- FriendTravel for RuneScape: Dragonwilds (UE4SS)
-- From a lodestone map, click a friend's marker to teleport to them for law runes.
local P = "/Script/Dominion."

-- ===== settings =====
local MOVE_DELAY_MS = 200       -- black screen starts -> you are moved
local ARRIVE_DELAY_MS = 2900    -- black screen starts -> arrival finished
local MAX_LODESTONE_DIST = 800  -- you must be this close to a lodestone you used
local MAGIC = 1179866673        -- marks a friend-travel request sent to the host
local ARRIVE_CHECK_DIST = 2000  -- landed farther than this from the friend -> move again

local function log(msg) print("[FriendTravel] " .. msg) end
log("loaded v2 (long-range fix)")

-- ===== helpers =====
local function each_live(class, fn)
  for _, c in ipairs(FindAllOf(class) or {}) do
    local ok, name = pcall(function() return c:GetFullName() end)
    if ok and not name:find("Default__", 1, true) and not name:find("GEN_VARIABLE", 1, true) then
      fn(c, name)
    end
  end
end

local function owned_by_local_controller(c)
  local ok, outer = pcall(function() return c:GetOuter() end)
  if not ok or not outer then return false end
  local okl, isl = pcall(function() return outer:IsLocalController() end)
  return okl and isl == true
end

local function local_component(class)
  local found, first
  each_live(class, function(c)
    first = first or c
    if not found and owned_by_local_controller(c) then found = c end
  end)
  return found or first
end

local function get_me_and_others()
  local me, others = nil, {}
  for _, c in ipairs(FindAllOf("DominionPlayerCharacter") or {}) do
    local ok, isme = pcall(function() return c:IsLocallyControlled() end)
    if ok and isme then me = c else others[#others + 1] = c end
  end
  return me, others
end

local function is_host(me)
  local ok, a = pcall(function() return me:HasAuthority() end)
  return ok and a == true
end

local function icon_visible(w)
  local okf, full = pcall(function() return w:GetFullName() end)
  if not okf or not full or full:find("Default__", 1, true) then return false end
  local okv, vis = pcall(function() return w:IsVisible() end)
  return okv and vis == true
end

local function dist3(a, b)
  return math.sqrt((a.X - b.X) ^ 2 + (a.Y - b.Y) ^ 2 + (a.Z - b.Z) ^ 2)
end

local function after(ms, fn)
  if ExecuteWithDelay then
    ExecuteWithDelay(ms, function() ExecuteInGameThread(fn) end)
  else
    LoopAsync(ms, function() ExecuteInGameThread(fn) return true end)
  end
end

-- ===== "must be standing at a lodestone" =====
local anchor = nil
local last_guid = nil

local function set_anchor()
  ExecuteInGameThread(function()
    local me = get_me_and_others()
    if not me then return end
    local ok, l = pcall(function() return me:K2_GetActorLocation() end)
    if ok and l then anchor = { X = l.X, Y = l.Y, Z = l.Z } end
  end)
end

local function at_lodestone(me)
  local a = me:K2_GetActorLocation()
  local best = nil
  local function consider(d) if d and (not best or d < best) then best = d end end
  if anchor then consider(dist3(a, anchor)) end
  for _, l in ipairs(FindAllOf("WorldLodestone") or {}) do
    local ok, full = pcall(function() return l:GetFullName() end)
    if ok and full and not full:find("Default__", 1, true) then
      local okl, b = pcall(function() return l:K2_GetActorLocation() end)
      if okl and b then consider(dist3(a, b)) end
    end
  end
  for _, c in ipairs(FindAllOf("LodestoneComponent") or {}) do
    local ok, full = pcall(function() return c:GetFullName() end)
    if ok and full and not full:find("Default__", 1, true) then
      local oko, owner = pcall(function() return c:GetOwner() end)
      if oko and owner then
        local okl, b = pcall(function() return owner:K2_GetActorLocation() end)
        if okl and b then consider(dist3(a, b)) end
      end
    end
  end
  return best ~= nil and best <= MAX_LODESTONE_DIST, best
end

-- ===== friend markers on the map =====
local function friend_icons()
  local list = {}
  for _, w in ipairs(FindAllOf("WBP_Dominion_MinimapInternal_Icon_C") or {}) do
    if icon_visible(w) then
      local okm, mc = pcall(function() return w.MapIconComp end)
      if okm and mc then
        local tex = ""
        pcall(function() tex = mc.IconTexture:GetFullName() end)
        if tex:find("FriendArrow", 1, true) then
          local label = ""
          pcall(function() label = mc.IconLabel:ToString() end)
          list[#list + 1] = { w = w, mc = mc, label = label }
        end
      end
    end
  end
  return list
end

local function set_clickable(f, on)
  pcall(function() f.mc:SetIconInteractable(on) end)
  local want = on and 0 or 1
  local cv = nil
  pcall(function() cv = f.w.Widget_MouseCapture:GetVisibility() end)
  if cv ~= want then
    pcall(function() f.w.Widget_MouseCapture:SetVisibility(want) end)
  end
end

-- markers are only clickable while you are at a lodestone
local function refresh_markers()
  local fl = friend_icons()
  if #fl == 0 then return end
  local me = get_me_and_others()
  if not me then return end
  local ok = at_lodestone(me)
  for _, f in ipairs(fl) do
    local cur = false
    pcall(function() cur = f.mc.bIconInteractable == true end)
    if ok and not cur then
      set_clickable(f, true)
    elseif (not ok) and cur then
      set_clickable(f, false)
    end
  end
end

-- ===== players and pricing =====
local function ps_for_pawn(pawn)
  local pn = nil
  pcall(function() pn = pawn:GetFullName() end)
  for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
    local okp, pp = pcall(function() return ps:GetPawn() end)
    if okp and pp then
      local okn, nm = pcall(function() return pp:GetFullName() end)
      if okn and nm == pn then return ps end
    end
  end
  return nil
end

-- Match a map marker to a player by name. Player states always replicate, but a
-- joined player only has another player's pawn while that player is nearby, so
-- the pawn may be nil for a far-away friend.
local function find_friend(label, others)
  for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
    local ok, full = pcall(function() return ps:GetFullName() end)
    if ok and full and not full:find("Default__", 1, true) then
      local name = nil
      local okn, v = pcall(function() return ps:GetPlayerName():ToString() end)
      if okn and v then
        name = v
      else
        pcall(function() name = ps.PlayerNamePrivate:ToString() end)
      end
      if name ~= nil and name == label then
        local pawn = nil
        pcall(function()
          local p = ps:GetPawn()
          if p and p:IsValid() then pawn = p end
        end)
        return pawn, ps
      end
    end
  end
  if #others == 1 then return others[1], nil end
  return nil, nil
end

local function actor_loc(actor)
  local loc = nil
  pcall(function()
    local l = actor:K2_GetActorLocation()
    loc = { X = l.X, Y = l.Y, Z = l.Z }
  end)
  return loc
end

-- where a friend's marker sits in the world, for when their pawn isn't loaded here
local function marker_location(label, me)
  local mine = actor_loc(me)
  for _, f in ipairs(friend_icons()) do
    if f.label == label then
      local tries = {
        function() return f.mc:K2_GetComponentLocation() end,
        function() return f.mc:GetOwner():K2_GetActorLocation() end,
      }
      for _, try in ipairs(tries) do
        local ok, l = pcall(try)
        if ok and l and (l.X ~= 0 or l.Y ~= 0) then
          local loc = { X = l.X, Y = l.Y, Z = l.Z }
          -- a marker owned by our own HUD would report our position: not useful
          if not mine or dist3(loc, mine) > 100 then return loc end
        end
      end
    end
  end
  return nil
end

-- price a trip with the game's own formula (distance + carried weight)
local function price_trip(me, comp, inv, b)
  local a = me:K2_GetActorLocation()
  local d = dist3(a, b)
  local okw, w = pcall(function() return inv:ComputeCurrentWeight() end)
  local wfloor = math.floor(okw and w or 0) + 0.0
  local okc, cost = pcall(function() return comp:CalculateTeleportationCost(d, wfloor) end)
  local okd, item = pcall(function() return comp:GetTeleportationCostItemData() end)
  if not okc or not okd or not item then return nil, "could not work out the cost" end
  local okh, have = pcall(function() return inv:GetNumItemsByData(item) end)
  if not okh then return nil, "could not count runes" end
  return { me = me, inv = inv, comp = comp, b = b, d = d, w = wfloor, cost = cost, have = have, item = item }
end

local function compute_trip(label)
  local comp = local_component("BP_Components_LodestoneTeleportationComponent_C")
  local inv = local_component("BP_Components_Inventory_C")
  local me, others = get_me_and_others()
  if not comp or not inv or not me then return nil, "missing component or player" end

  local near = at_lodestone(me)
  if not near then return nil, "not at a lodestone" end

  local target, ps = find_friend(label, others)
  if not target and not ps then return nil, "could not match the marker to a player" end
  if not ps then ps = ps_for_pawn(target) end
  local target_id = nil
  if ps then pcall(function() target_id = ps:GetPlayerId() end) end

  local b = target and actor_loc(target) or marker_location(label, me)
  if not b then
    -- Too far away to be loaded here. The host has every player loaded, so a
    -- joined player sends the request unpriced and the host prices it.
    if is_host(me) then return nil, "friend's position unknown" end
    if not target_id then return nil, "could not find that player's id" end
    local t = { me = me, inv = inv, comp = comp, target_id = target_id, unpriced = true }
    pcall(function() t.have = inv:GetNumItemsByData(comp:GetTeleportationCostItemData()) end)
    return t
  end

  local t, err = price_trip(me, comp, inv, b)
  if not t then return nil, err end
  t.target = target
  t.target_id = target_id
  return t
end

-- ===== the map's cost panel =====
local function find_panel()
  local best = nil
  for _, w in ipairs(FindAllOf("WBP_MapLodestoneWidget_C") or {}) do
    local ok, full = pcall(function() return w:GetFullName() end)
    if ok and full and not full:find("Default__", 1, true) then
      if not full:find("^%S+ /Game/") then return w end
      best = best or w
    end
  end
  return best
end

local showing = false
local show_errs = 0

local function show_cost(label)
  ExecuteInGameThread(function()
    local t, err = compute_trip(label)
    if not t then
      show_errs = show_errs + 1
      if show_errs <= 5 then log("no cost shown: " .. tostring(err)) end
      return
    end
    local p = find_panel()
    if not p then return end
    -- an unpriced (far-away) trip is priced by the host when it is made
    pcall(function() p.RequiredQuantityText:SetText(FText(t.unpriced and "?" or tostring(t.cost))) end)
    pcall(function() p.InventoryQuantityText:SetText(FText(tostring(t.have or "?"))) end)
    pcall(function() p:UpdateTeleportationCostVisibility(true) end)
    showing = true
  end)
end

local function any_icon_hovered(pattern)
  for _, w in ipairs(FindAllOf("WBP_Dominion_MinimapInternal_Icon_C") or {}) do
    if icon_visible(w) then
      local okh, hov = pcall(function() return w:IsHovered() end)
      if okh and hov == true then
        local tex = ""
        pcall(function() tex = w.MapIconComp.IconTexture:GetFullName() end)
        if tex:find(pattern, 1, true) then return true end
      end
    end
  end
  return false
end

local function hide_cost_now()
  local p = find_panel()
  if p then pcall(function() p:UpdateTeleportationCostVisibility(false) end) end
  showing = false
end

local function hide_cost()
  ExecuteInGameThread(function()
    if not showing then return end
    if any_icon_hovered("Lodestone") or any_icon_hovered("FriendArrow") then return end
    hide_cost_now()
  end)
end

-- ===== lodestone-style teleport: black screen -> move -> arrival =====
local traveling = false

local function fancy_teleport(t)
  local me = t.me
  if not t.remote then traveling = true end
  local dest = { X = t.b.X + 150, Y = t.b.Y, Z = t.b.Z + 60 }
  local rot = { Pitch = 0.0, Yaw = 0.0, Roll = 0.0 }

  local function dest_now()
    local l = t.target and t.target:IsValid() and actor_loc(t.target)
    if not l then return dest end
    return { X = l.X + 150, Y = l.Y, Z = l.Z + 60 }
  end

  pcall(function() me:Client_NotifyTeleportWithLoadingScreenBegin() end)
  if not t.remote then pcall(hide_cost_now) end

  after(MOVE_DELAY_MS, function()
    dest = dest_now()
    local okt, rt = pcall(function() return me:K2_TeleportTo(dest, rot) end)
    if not (okt and rt == true) then log("teleport call failed") end
    if okt and rt == true and not t.remote then anchor = nil end
    local comp = t.comp or local_component("BP_Components_LodestoneTeleportationComponent_C")
    if comp then pcall(function() comp:Client_CloseMap() end) end
    pcall(function() me:DissolveTeleport() end)
  end)

  after(ARRIVE_DELAY_MS, function()
    -- a long trip can land before the area has loaded; if we ended up away
    -- from the friend (fell, got pushed back), move once more
    local here, there = actor_loc(me), t.target and t.target:IsValid() and actor_loc(t.target)
    if here and there and dist3(here, there) > ARRIVE_CHECK_DIST then
      log("landed " .. math.floor(dist3(here, there)) .. " away from the friend, moving again")
      pcall(function() me:K2_TeleportTo(dest_now(), rot) end)
    end
    pcall(function() me:Client_NotifyTeleportWithDelayComplete(true) end)
    if not t.remote then traveling = false end
  end)
  -- safety net: the black screen always ends
  after(ARRIVE_DELAY_MS + 3000, function()
    pcall(function() me:Client_NotifyTeleportWithDelayComplete(true) end)
    if not t.remote then traveling = false end
  end)
end

-- ===== HOST: handle a joined player's teleport request =====
local remote_busy = {}

local function handle_remote_request(comp, target_id)
  local okc, ctrl = pcall(function() return comp:GetOuter() end)
  if not okc or not ctrl then return end
  local cname = ""
  pcall(function() cname = ctrl:GetFullName() end)
  local now = os.clock()
  if remote_busy[cname] and now - remote_busy[cname] < 6 then return end
  remote_busy[cname] = now

  local pawn = nil
  pcall(function() pawn = ctrl:K2_GetPawn() end)
  if not pawn then pcall(function() pawn = ctrl:GetPawn() end) end
  if not pawn or not pawn:IsValid() then return end

  local inv = nil
  each_live("BP_Components_Inventory_C", function(c)
    local ok, outer = pcall(function() return c:GetOuter() end)
    if ok and outer then
      local okn, on = pcall(function() return outer:GetFullName() end)
      if okn and on == cname then inv = c end
    end
  end)
  if not inv then log("request: player's inventory not found") return end

  local target = nil
  for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
    local okid, pid = pcall(function() return ps:GetPlayerId() end)
    if okid and pid == target_id then
      local okp, pp = pcall(function() return ps:GetPawn() end)
      if okp and pp and pp:IsValid() then target = pp end
    end
  end
  if not target then log("request: target player not found") return end

  local b = actor_loc(target)
  if not b then log("request: target position unknown") return end
  local t, err = price_trip(pawn, comp, inv, b)
  if not t then log("request: " .. tostring(err)) return end
  t.target = target
  log("request: distance=" .. math.floor(t.d) .. " cost=" .. tostring(t.cost) .. " have=" .. tostring(t.have))
  if t.have < t.cost then log("request: not enough law runes") return end

  local okr, removed = pcall(function() return inv:RemoveItemByData(t.item, t.cost) end)
  if not (okr and removed == true) then log("request: rune removal failed") return end
  t.remote = true
  fancy_teleport(t)
end

local function server_try_cb(ctx, from_p, to_p)
  local okc, comp = pcall(function() return ctx:get() end)
  if not okc or not comp then return end
  local A, B = nil, nil
  pcall(function()
    local g = to_p:get()
    A = g.A
    B = g.B
  end)
  if A ~= MAGIC then return end
  ExecuteInGameThread(function() handle_remote_request(comp, B) end)
end

-- ===== clicking a friend's marker =====
local last_travel = 0

local function friend_travel(label)
  ExecuteInGameThread(function()
    if traveling then return end
    local now = os.clock()
    if now - last_travel < 2.0 then return end
    last_travel = now

    local t, err = compute_trip(label)
    if not t then log("blocked: " .. tostring(err)) return end
    if not t.unpriced and t.have < t.cost then log("not enough law runes (need " .. tostring(t.cost) .. ")") return end
    log("travel to '" .. label .. "': " .. (t.unpriced and "far away, host will price it"
      or ("distance=" .. math.floor(t.d) .. " cost=" .. tostring(t.cost))))

    if is_host(t.me) then
      local okr, removed = pcall(function() return t.inv:RemoveItemByData(t.item, t.cost) end)
      if not (okr and removed == true) then log("rune removal failed") return end
      fancy_teleport(t)
    else
      -- joined player: ask the host to do it
      if not t.target_id then log("could not find that player's id") return end
      local from = last_guid or { A = 0, B = 0, C = 0, D = 0 }
      local to = { A = MAGIC, B = t.target_id, C = math.random(1, 2000000000), D = 0 }
      local ok, e = pcall(function() t.comp:Server_TryTeleport(from, to) end)
      if not ok then log("could not send the request: " .. tostring(e)) end
      pcall(hide_cost_now)
    end
  end)
end

-- ===== once a second: friend markers clickable only at a lodestone =====
LoopAsync(1000, function()
  ExecuteInGameThread(function() pcall(refresh_markers) end)
  return false
end)

-- ===== hooks =====
local function icon_info(ctx)
  local okw, w = pcall(function() return ctx:get() end)
  if not okw or not w then return nil end
  local label, tex = "", ""
  local okm, mc = pcall(function() return w.MapIconComp end)
  if okm and mc then
    pcall(function() label = mc.IconLabel:ToString() end)
    pcall(function() tex = mc.IconTexture:GetFullName() end)
  end
  return label, tex
end

local function click_cb(ctx, ...)
  local label, tex = icon_info(ctx)
  if label and tex:find("FriendArrow", 1, true) then friend_travel(label) end
end

local function hover_cb(entering)
  return function(ctx, ...)
    local label, tex = icon_info(ctx)
    if not label or not tex:find("FriendArrow", 1, true) then return end
    if entering then show_cost(label) else hide_cost() end
  end
end

local function interact_cb(ctx, p1)
  local okc, comp = pcall(function() return ctx:get() end)
  if okc and comp and owned_by_local_controller(comp) then
    set_anchor()
    pcall(function()
      local g = p1:get()
      last_guid = { A = g.A, B = g.B, C = g.C, D = g.D }
    end)
  end
end

local function worldlode_cb(ctx, p1)
  pcall(function()
    local ch = p1:get()
    if ch:IsLocallyControlled() then set_anchor() end
  end)
end

local ok1, e1 = pcall(function() RegisterHook(P .. "WorldLodestone:OnInteraction", worldlode_cb) end)
if not ok1 then log("hook failed (WorldLodestone:OnInteraction): " .. tostring(e1)) end
local ok2, e2 = pcall(function() RegisterHook(P .. "BaseTeleportationComponent:Server_TryTeleport", server_try_cb) end)
if not ok2 then log("hook failed (Server_TryTeleport): " .. tostring(e2)) end

-- these Blueprint functions only exist once the game has loaded; retry until they do
local IC = "/Game/UI/HUD/ModifiedMinimapPlugin/WBP_Dominion_MinimapInternal_Icon.WBP_Dominion_MinimapInternal_Icon_C:"
local LODE = "/Game/Gameplay/Character/Components/BP_Components_LodestoneTeleportationComponent.BP_Components_LodestoneTeleportationComponent_C:"
local pending = {
  [IC .. "OnMouseClick_Event_0"] = click_cb,
  [IC .. "OnMouseEnter"] = hover_cb(true),
  [IC .. "OnMouseLeave"] = hover_cb(false),
  [LODE .. "OnLodestoneInteractDynamic_Event"] = interact_cb,
}
local attached = 0
LoopAsync(5000, function()
  if next(pending) == nil then return true end
  ExecuteInGameThread(function()
    for path, cb in pairs(pending) do
      local ok = pcall(function() RegisterHook(path, cb) end)
      if ok then
        pending[path] = nil
        attached = attached + 1
        if attached == 4 then log("ready") end
      end
    end
  end)
  return false
end)