GREATER FARMING
===============
Come Correct Gaming (CCG) | KPNC

Greater Farming improves several utility spells and gameplay features, making farming, gathering, and other tasks less tedious. Most features can be adjusted or disabled in config.txt.

WHAT IT CHANGES
---------------

Mucksplosion
Composts a much larger area, including groups of farming plots that aren't directly connected.

Humidify
Waters a much larger area of farming plots with a single cast.

Splinter
Increases the area for turning fallen trees into logs and allows casting from farther away. The targeting circle may still appear normal. Processing too many logs at once can cause some lag.

Axtral Projection
Increases axe travel distance, speed, and targeting width. Higher width settings reduce forward range, so around 3 is recommended. Changing your position or angle can help target trees on slopes.

Agility Orbs
Increases the pickup range of agility course orbs, including stamina orbs. Defaults to 3x normal size and is capped at 5x to prevent issues.

Carry Weight
Adjust item weight to 100%, 75%, 50%, 25%, or 0% (999999 maximum capacity). At 50%, you can carry twice as much. Uses the Legs of Lightness effect, so if you're wearing those pants, re-equip them after changing this setting.

Spell Cooldowns
Reduces equipped spell cooldowns by 50% by default. Adjustable or disabled through config.txt.

Runecrafting
Increases rune altar crafting limits from 50 to 1000. Optional autocraft bonuses provide full bonus runes and XP. This feature is experimental and can be disabled separately.


INSTALLATION
------------

Requires UE4SS. No other mods are needed.

1. Extract the download.
2. Copy the GreaterFarming folder into:

   RSDragonwilds\Binaries\Win64\ue4ss\Mods\

3. Launch the game. Enabled features apply automatically.

SETTINGS
--------

Open config.txt in Notepad to adjust settings (true = on, false = off). The notes beside each option explain what it does.

If you have the optional Mod Menu mod installed, settings can also be changed in-game through Esc > MODS > Greater Farming. Changes apply immediately and save automatically to config.txt.

A few things to know:
- Rune altar changes apply the next time you open the altar.
- Disabling the autocraft bonus requires a restart.
- Changes made directly in config.txt require a game restart.
- Ctrl+R can reload mods, but restarting is safer since reloading may crash with certain other mods.

To restore default settings, delete config.txt. A fresh copy will be created automatically the next time the mod runs.

CREDITS
-------

Created by KPNC | Come Correct Gaming (CCG)

Free to use and share. Credit is appreciated if you repost or modify it.