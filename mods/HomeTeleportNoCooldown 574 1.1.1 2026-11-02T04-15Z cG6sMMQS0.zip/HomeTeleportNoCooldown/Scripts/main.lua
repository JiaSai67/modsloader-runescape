local dir=debug.getinfo(1,'S').source:sub(2):match('(.*[/\\])')
local cooldown=dofile(dir..'cooldown.lua')
-- Settings: config.txt next to this folder, or synced on event from Mod Menu (zero background polling).
local config={Enabled=true,CooldownSeconds=0}
local function loadConfig()
 local f=io.open(dir..'../config.txt','r');if not f then return end
 for line in f:lines() do
  local k,v=line:match('^%s*([%w_]+)%s*=%s*([^#;]-)%s*$')
  if k=='Enabled' then config.Enabled=v:lower()=='true' or v=='1'
  elseif k=='CooldownSeconds' then config.CooldownSeconds=tonumber(v) or config.CooldownSeconds end
 end
 f:close()
end
local mmRev
local function modMenuSync()
 local ok,rev=pcall(function() return ModRef:GetSharedVariable('ModMenu.HomeTeleportNoCooldown.rev') end)
 if not ok or type(rev)~='number' or rev==mmRev then return false end
 mmRev=rev
 for key,default in pairs({Enabled=true,CooldownSeconds=0}) do
  local okV,v=pcall(function() return ModRef:GetSharedVariable('ModMenu.HomeTeleportNoCooldown.'..key) end)
  if okV and type(v)==type(default) then config[key]=v end
 end
 return true
end
local lastError
local function applyOnce()
 modMenuSync()
 local seconds=config.Enabled and math.max(0,config.CooldownSeconds) or nil
 local ok,found,changed,value,needs,original=pcall(cooldown.apply,seconds)
 if not ok then
  if tostring(found)~=lastError then lastError=tostring(found);print('[HomeTeleportNoCooldown] ERROR '..lastError..'\n') end
  return false
 end
 lastError=nil
 if found and changed then
  print(string.format('[HomeTeleportNoCooldown] Home Teleport cooldown=%s (original %s, %s); unlock requirement preserved=%s\n',
   tostring(value),tostring(original),config.Enabled and 'mod enabled' or 'mod disabled',tostring(needs)))
 end
 return found==true
end
local function applyWhenReady(triesLeft)
 ExecuteInGameThread(function()
  if applyOnce() or triesLeft<=0 then return end
  ExecuteInGameThreadWithDelay(1000,function() applyWhenReady(triesLeft-1) end)
 end)
end
loadConfig()
applyWhenReady(60)
pcall(RegisterHook,'/Script/Engine.PlayerController:ClientRestart',function()
 ExecuteInGameThreadWithDelay(500,function() applyWhenReady(15) end)
end)
pcall(RegisterHook,'/Script/Dominion.SpellcastingComponent:Client_NotifyAllSelectedSpells',function()
 ExecuteInGameThread(applyOnce)
end)
pcall(RegisterHook,'/Script/Engine.PlayerController:SetPause',function()
 ExecuteInGameThreadWithDelay(100,applyOnce)
end)
