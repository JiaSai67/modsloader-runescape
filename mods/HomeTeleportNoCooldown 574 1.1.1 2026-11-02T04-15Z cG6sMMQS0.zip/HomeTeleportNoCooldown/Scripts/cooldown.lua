local M={}
M.path='/Game/Gameplay/UtilityMagic/PerkSpells/HomeTeleport/USD_HomeTeleport.USD_HomeTeleport'
local original -- the spell's own cooldowns, recorded before the first change
-- Sets Home Teleport's cooldown to `seconds`, or restores the original when `seconds` is nil.
function M.apply(seconds)
 local spell=StaticFindObject(M.path)
 if not spell or not spell:IsValid() then return false end
 local needs=spell.bNeedsUnlocking
 if not original then original={spell.CooldownDuration,spell.CooldownModifierPerk.ModifiedCooldown} end
 local base=seconds or original[1]
 local perk=seconds or original[2]
 local changed=spell.CooldownDuration~=base or spell.CooldownModifierPerk.ModifiedCooldown~=perk
 -- Write only when the value differs: other mods (e.g. Utility Spells - No Cooldowns) may already
 -- set it, and rewriting it on every check was linked to a Steam crash with both installed.
 if changed then
  spell.CooldownDuration=base
  spell.CooldownModifierPerk.ModifiedCooldown=perk
  assert(spell.CooldownDuration==base and spell.CooldownModifierPerk.ModifiedCooldown==perk,'Cooldown update failed')
 end
 assert(spell.bNeedsUnlocking==needs,'Unlock requirement changed')
 return true,changed,base,needs,original[1]
end
return M
