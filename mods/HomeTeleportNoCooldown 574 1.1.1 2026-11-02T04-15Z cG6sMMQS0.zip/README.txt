Home Teleport No Cooldown 1.1.0 by alwaysh4sbeen
Requires UE4SS 3.0.1 (not bundled). Mod Menu (Nexus mod 548) is optional: without it, edit config.txt.

1. Close the game (or stop the server).
2. Back up your character and world saves.
3. Install UE4SS for your game edition. After a game update, confirm UE4SS is still installed
   (Game Pass: Content\RSDragonwilds\Binaries\WinGDK\ue4ss\UE4SS.dll must exist).
4. Copy the HomeTeleportNoCooldown folder into your UE4SS Mods folder.
5. Optional: install Mod Menu (Nexus mod 548) to change settings in game (Esc > MODS).
   Without it, edit HomeTeleportNoCooldown\config.txt and restart.
6. Start the game or server.

Install the same folder on the dedicated server (its config.txt decides the cooldown there)
and on clients. The Home Teleport unlock requirement and casting requirements are unchanged.

Developed with AI coding assistance.
