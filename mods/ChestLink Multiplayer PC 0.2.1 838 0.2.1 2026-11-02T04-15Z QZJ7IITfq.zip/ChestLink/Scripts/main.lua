-- ChestLink Multiplayer PC 0.2.1: event-driven zero-polling client range extension (1000 km).
local radius = 100000000 -- 1000 km in Unreal centimetres.
local originalRadius = nil
local lastError = nil

local function applyRadius(force)
    local settings = StaticFindObject("/Script/Dominion.Default__InventorySettings")
    if not settings or not settings:IsValid() then return false end
    if originalRadius == nil then originalRadius = settings.LinkedStorageRadius end

    local changed = (settings.LinkedStorageRadius ~= radius)
    if changed then
        settings.LinkedStorageRadius = radius
    end

    if changed or force then
        local player = FindFirstOf("DominionPlayerController")
        local crafting = StaticFindObject("/Script/Dominion.Default__CraftingFunctionLibrary")
        if player and player:IsValid() and crafting and crafting:IsValid() then
            pcall(function() crafting:ResetLinkedInventoryCache(player) end)
        elseif not force then
            -- PlayerController not spawned yet; retry during startup until cache is refreshed once.
            return false
        end
        print(string.format("[ChestLink Multiplayer PC] activeRadius=%s cm (original=%s) cacheReset=true\n",
            tostring(settings.LinkedStorageRadius), tostring(originalRadius)))
    end
    return true
end

local function applyWhenReady(triesLeft)
    ExecuteInGameThread(function()
        local ok, applied = pcall(applyRadius, false)
        if not ok then
            if tostring(applied) ~= lastError then
                lastError = tostring(applied)
                print("[ChestLink Multiplayer PC] ERROR: " .. lastError .. "\n")
            end
        else
            lastError = nil
        end
        if (ok and applied) or triesLeft <= 0 then
            return
        end
        ExecuteInGameThreadWithDelay(1000, function() applyWhenReady(triesLeft - 1) end)
    end)
end

applyWhenReady(60)

pcall(RegisterHook, "/Script/Engine.PlayerController:ClientRestart", function()
    ExecuteInGameThreadWithDelay(500, function() pcall(applyRadius, false) end)
end)

RegisterKeyBind(Key.F7, function()
    ExecuteInGameThread(function() pcall(applyRadius, true) end)
end)

print("[ChestLink Multiplayer PC] Loaded v0.2.1 (Event-Driven Zero-Polling). F7 refreshes cache.\n")
