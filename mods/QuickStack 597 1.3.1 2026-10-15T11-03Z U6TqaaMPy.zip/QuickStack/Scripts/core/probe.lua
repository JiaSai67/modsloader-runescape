-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local SLOT_TYPE_NAME = {
    [0] = "QuickAction", [1] = "InventoryItems", [2] = "InventoryRunes",
    [3] = "InventoryAmmunition", [4] = "InventoryQuestItems", [5] = "Loadout",
    [6] = "External", [7] = "FishingBaits", [8] = "None",
}
local CLS_BASE_BUILDING = "/Script/Dominion.BaseBuildingActor"
local CLS_OWNERSHIP = "/Script/Dominion.OwnershipComponent"
local function HotbarIsFirst(invApi, playerInv, hotCount)
    local mirror = H.ArrayItems(H.P(invApi, "QuickActionSlots"))
    for i = 1, mirror.n do
        local item = mirror[i]
        if H.Valid(item) then
            local ok, flat = H.C(playerInv, "GetSlotForItem", item)
            if ok and type(flat) == "number" and flat >= 0 then
                return flat < hotCount, true
            end
        end
    end
    return true, false
end
local function ProbePlayerInventory(pc, invApi)
    local okInv, inv = H.C(pc, "GetInventory")
    if not okInv or not H.Valid(inv) then
        H.Log("[A] player inventory: UNAVAILABLE")
        return
    end
    H.Log("[A] player inventory: " .. H.FullName(inv))
    local maxSlots = tonumber(H.P(inv, "MaxSlotCount")) or -1
    local hotCount = tonumber(H.P(inv, "NumberOfQuickActionSlots")) or 0
    local slots = H.ArrayItems(H.P(inv, "ItemSlots"))
    local occupied = 0
    for i = 1, slots.n do
        if H.Valid(slots[i]) then occupied = occupied + 1 end
    end
    local pages = H.P(inv, "InventoryPages")
    local pageSum = 0
    for i = 1, H.ArrayNum(pages) do
        local page = pages[i]
        local num = tonumber(H.P(page, "NumSlots")) or 0
        pageSum = pageSum + num
        H.Log(string.format("  page %d: %s NumSlots=%d",
            i, SLOT_TYPE_NAME[tonumber(H.P(page, "SlotType")) or -1] or "?", num))
    end
    local first, verified = true, false
    if invApi then first, verified = HotbarIsFirst(invApi, inv, hotCount) end
    H.Log(string.format(
        "  MaxSlotCount=%d QuickActionSlots=%d pageSum=%d hotbar+pages=%d ItemSlots.n=%d occupied=%d (hotbar %s, %s)",
        maxSlots, hotCount, pageSum, hotCount + pageSum, slots.n, occupied,
        first and "first" or "last", verified and "verified" or "assumed"))
    if maxSlots ~= hotCount + pageSum then
        H.Log(string.format(
            "  >> MISMATCH: MaxSlotCount (%d) != hotbar+pages (%d) - external resize in effect?",
            maxSlots, hotCount + pageSum))
    end
    if slots.n ~= hotCount + pageSum then
        H.Log(string.format(
            "  >> MISMATCH: ItemSlots.n (%d) != hotbar+pages (%d)", slots.n, hotCount + pageSum))
    end
    local covered = hotCount + pageSum
    local tailOccupied = 0
    for flat = covered, slots.n - 1 do
        local item = slots[flat + 1]
        if H.Valid(item) then
            tailOccupied = tailOccupied + 1
            H.Log(string.format("  >> TAIL slot flat=%d holds '%s' (page-sliced enumeration would MISS this)",
                flat, H.ItemName(item)))
        end
    end
    if slots.n > covered and tailOccupied == 0 then
        H.Log(string.format("  %d tail slot(s) beyond page coverage, all empty", slots.n - covered))
    elseif slots.n <= covered then
        H.Log("  no tail slots beyond page coverage")
    end
end
local function GateVerdict(inv, owner, own, pawn, myGuid, rangeCm, dist)
    if not H.IsA(owner, CLS_BASE_BUILDING) then return "FAIL(not BaseBuildingActor)" end
    if H.P(owner, "bIsGhosted") == true then return "FAIL(ghost)" end
    if H.P(owner, "bIsPreview") == true then return "FAIL(preview)" end
    if not H.Valid(own) then return "FAIL(no OwnershipComponent)" end
    if not dist then return "FAIL(no distance)" end
    if dist > rangeCm then return "FAIL(out of range)" end
    if H.P(inv, "bAllowAdds") ~= true then return "FAIL(bAllowAdds false)" end
    if not myGuid then return "FAIL(no player guid)" end
    local okLock, locked = H.C(own, "IsPrivatelyLockedFromPlayer", myGuid)
    if not okLock or locked ~= false then return "FAIL(private/lock check)" end
    local holder = H.P(inv, "CurrentActor")
    if H.Valid(holder) and holder ~= pawn then return "FAIL(in use)" end
    return "PASS"
end
local MAX_TRACED = 40
local function ProbeWorldContainers(pawn, myGuid, rangeM)
    local ok, invs = pcall(function() return FindAllOf("BP_Components_WorldItemInventory_C") end)
    if not ok or not invs then
        H.Log("[B] FindAllOf(BP_Components_WorldItemInventory_C) FAILED")
        return
    end
    H.Log(string.format("[B] world-item inventories loaded: %d (gate trace within %dm, cap %d)",
        #invs, rangeM * 2, MAX_TRACED))
    local ownershipCls = H.FindClass(CLS_OWNERSHIP)
    local rangeCm = rangeM * 100
    local traced = 0
    local summary = {}
    for _, inv in ipairs(invs) do
        if H.Valid(inv) then
            local owner
            pcall(function() owner = inv:GetOwner() end)
            if H.Valid(owner) then
                local cls = H.ClassName(owner)
                local maxSlots = tonumber(H.P(inv, "MaxSlotCount")) or -1
                local slotN = H.ArrayNum(H.P(inv, "ItemSlots"))
                local s = summary[cls]
                if not s then s = { count = 0, sizes = {}, arr = {} }; summary[cls] = s end
                s.count = s.count + 1
                s.sizes[maxSlots] = (s.sizes[maxSlots] or 0) + 1
                s.arr[slotN] = (s.arr[slotN] or 0) + 1
                local dist = H.DistanceCm(owner, pawn)
                if dist and dist <= rangeCm * 2 and traced < MAX_TRACED then
                    traced = traced + 1
                    local own
                    if ownershipCls then
                        local okOwn, o = H.C(owner, "GetComponentByClass", ownershipCls)
                        if okOwn then own = o end
                    end
                    local occupied = 0
                    local slots = H.ArrayItems(H.P(inv, "ItemSlots"))
                    for i = 1, slots.n do
                        if H.Valid(slots[i]) then occupied = occupied + 1 end
                    end
                    local holder = H.P(inv, "CurrentActor")
                    H.Log(string.format(
                        "  %.1fm %s Max=%d slots=%d occ=%d adds=%s own=%s holder=%s -> %s",
                        dist / 100, cls, maxSlots, slotN, occupied,
                        tostring(H.P(inv, "bAllowAdds")),
                        H.Valid(own) and "yes" or "NO",
                        H.Valid(holder) and H.ClassName(holder) or "nil",
                        GateVerdict(inv, owner, own, pawn, myGuid, rangeCm, dist)))
                end
            end
        end
    end
    H.Log("[C] per-class MaxSlotCount summary (all loaded instances):")
    for cls, s in pairs(summary) do
        local sizes, arrs = {}, {}
        for v, n in pairs(s.sizes) do sizes[#sizes + 1] = string.format("%dx%d", v, n) end
        for v, n in pairs(s.arr) do arrs[#arrs + 1] = string.format("%dx%d", v, n) end
        table.sort(sizes); table.sort(arrs)
        H.Log(string.format("  %s: count=%d MaxSlotCount={%s} ItemSlots.n={%s}",
            cls, s.count, table.concat(sizes, ","), table.concat(arrs, ",")))
    end
end
function M.Run(cfg)
    H.Log("================ PROBE RUN (v1.2 Phase 0) ================")
    local UEHelpers = require("UEHelpers")
    local pc
    pcall(function() pc = UEHelpers.GetPlayerController() end)
    if not H.Valid(pc) then H.Log("no PlayerController - in main menu?") return end
    H.Log("PlayerController: " .. H.FullName(pc))
    local pawn = H.P(pc, "Pawn")
    if not H.Valid(pawn) then H.Log("no Pawn") return end
    local myGuid
    local ps = H.P(pc, "PlayerState")
    if H.Valid(ps) then
        local ok, g = H.C(ps, "GetCharacterGuid")
        if ok then myGuid = g end
    end
    H.Log("guid: " .. (myGuid and (H.GuidStr(H.P(myGuid, "InnerGuid")) or "<struct>") or "FAILED"))
    local invApi
    local hud = FindFirstOf("HUDUISubsystem")
    if H.Valid(hud) then
        local okApi, api = H.C(hud, "GetInventoryAPI")
        if okApi and H.Valid(api) then invApi = api end
    end
    if not invApi then H.Log("InventoryUIAPI unavailable (hotbar check will be 'assumed')") end
    ProbePlayerInventory(pc, invApi)
    local rangeM = tonumber(cfg.RangeMeters) or 15
    ProbeWorldContainers(pawn, myGuid, rangeM)
    local okApi2, imApi
    if H.Valid(hud) then okApi2, imApi = H.C(hud, "GetInputManagerAPI") end
    if okApi2 and H.Valid(imApi) then
        local okOpen, open = H.C(imApi, "IsOpen", pc, 11)
        H.Log("IsOpen(Inventory) -> " .. (okOpen and tostring(open) or "FAILED"))
    end
    H.Log("================ PROBE END ================")
end
return M
