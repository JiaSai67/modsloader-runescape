-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local TAG = "[ledger] "
local function RoleName()
    local anchor
    pcall(function() anchor = require("UEHelpers").GetPlayerController() end)
    if not H.Valid(anchor) then
        pcall(function() anchor = FindFirstOf("GameStateBase") end)
    end
    if not H.Valid(anchor) then return "role unknown (no anchor)" end
    local authority
    pcall(function() authority = anchor:HasAuthority() == true end)
    local dedicated
    pcall(function()
        local ksl = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if H.Valid(ksl) then dedicated = ksl:IsDedicatedServer(anchor) == true end
    end)
    if authority == nil then return "role unknown (HasAuthority failed)" end
    if authority and dedicated then return "dedicated server" end
    if authority then return "host / single player" end
    return "client"
end
local function Unwrap(param)
    if param == nil then return nil end
    local v = param
    pcall(function() v = param:get() end)
    return v
end
local function DescribeInv(inv)
    if not H.Valid(inv) then return "nil" end
    local owner
    pcall(function() owner = inv:GetOwner() end)
    local slots = H.ArrayNum(H.P(inv, "ItemSlots"))
    local occupied = 0
    local arr = H.ArrayItems(H.P(inv, "ItemSlots"))
    for i = 1, arr.n do
        if H.Valid(arr[i]) then occupied = occupied + 1 end
    end
    return string.format("%s (owner=%s, %d/%d occupied)",
        H.ClassName(inv), H.Valid(owner) and H.ClassName(owner) or "?", occupied, slots)
end
local function HotbarState()
    local pc
    pcall(function() pc = require("UEHelpers").GetPlayerController() end)
    if not H.Valid(pc) then return "hotbar: no pc" end
    local ok, inv = H.C(pc, "GetInventory")
    if not ok or not H.Valid(inv) then return "hotbar: no inv" end
    local hot = tonumber(H.P(inv, "NumberOfQuickActionSlots")) or 0
    local arr = H.ArrayItems(H.P(inv, "ItemSlots"))
    local occ, names = 0, {}
    for i = 1, math.min(hot, arr.n) do
        if H.Valid(arr[i]) then
            occ = occ + 1
            names[#names + 1] = H.ItemName(arr[i]) or "?"
        end
    end
    return string.format("hotbar %d/%d [%s]", occ, hot, table.concat(names, ", "))
end
local HOOKS = {
    {
        fn = "/Script/Dominion.InventoryController:FillStacksBetweenInventories",
        post = true,
        describe = function(ctx, src, dst)
            return string.format("src=%s -> dst=%s", DescribeInv(Unwrap(src)), DescribeInv(Unwrap(dst)))
        end,
    },
    {
        fn = "/Script/Dominion.InventoryController:Server_FillStacksBetweenInventories",
        describe = function(ctx, src, dst)
            return string.format("src=%s -> dst=%s", DescribeInv(Unwrap(src)), DescribeInv(Unwrap(dst)))
        end,
    },
    {
        fn = "/Script/Dominion.InventoryController:MoveAllItemsBetweenInventories",
        describe = function(ctx, src, dst)
            return string.format("src=%s -> dst=%s", DescribeInv(Unwrap(src)), DescribeInv(Unwrap(dst)))
        end,
    },
    {
        fn = "/Script/Dominion.InventoryComponent:FillStacks",
        describe = function(ctx, target)
            return string.format("self=%s -> target=%s",
                DescribeInv(Unwrap(ctx)), DescribeInv(Unwrap(target)))
        end,
    },
    {
        fn = "/Script/Dominion.InventoryComponent:MoveAllItems",
        describe = function(ctx, target)
            return string.format("self=%s -> target=%s",
                DescribeInv(Unwrap(ctx)), DescribeInv(Unwrap(target)))
        end,
    },
    {
        fn = "/Script/Dominion.CraftingFunctionLibrary:GetLinkedInventories",
        post = true,
        describe = function(ctx, wco, loc, defaults, out)
            local w = Unwrap(wco)
            local o = Unwrap(out)
            local n = o and H.ArrayNum(o) or -1
            return string.format("WorldContext=%s out=%d inventories",
                H.Valid(w) and H.FullName(w) or "nil", n)
        end,
    },
    {
        fn = "/Script/Dominion.WorldActorInventoryUIAPI:HandleFillStacksByPlayer",
        describe = function() return "(chest-screen button)" end,
    },
    {
        fn = "/Script/Dominion.InventoryUIAPI:HandleFillStacksInWorldInventory",
        describe = function() return "(inventory-side fill button)" end,
    },
}
function M.Start()
    local registered, failed = {}, {}
    for _, spec in ipairs(HOOKS) do
        local short = spec.fn:match("([^.:]+)$") or spec.fn
        local function MakeCb(phase)
            return function(...)
                local args = { ... }
                local ok, desc = pcall(function()
                    return spec.describe and spec.describe(table.unpack(args)) or ""
                end)
                H.Log(string.format("%s%s %s | %s | %s | %s",
                    TAG, short, phase, RoleName(),
                    ok and desc or ("describe error: " .. tostring(desc)),
                    HotbarState()))
            end
        end
        local ok
        if spec.post then
            ok = pcall(RegisterHook, spec.fn, MakeCb("PRE"), MakeCb("POST"))
        else
            ok = pcall(RegisterHook, spec.fn, MakeCb("PRE"))
        end
        if ok then registered[#registered + 1] = short else failed[#failed + 1] = short end
    end
    H.Log(TAG .. "probe active (" .. RoleName() .. "). hooked: "
        .. table.concat(registered, ", ")
        .. (#failed > 0 and (" | FAILED: " .. table.concat(failed, ", ")) or ""))
end
return M
