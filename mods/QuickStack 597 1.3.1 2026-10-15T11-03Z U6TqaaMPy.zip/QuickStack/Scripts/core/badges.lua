-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local UI = require("core.uihelpers")
local blacklist = require("core.blacklist")
local M = {}
local GAME_TEX = "/Game/Art/UI/Farming/T_ComposterSlot_Lock.T_ComposterSlot_Lock"
local BADGE_SIZE = 30
local BADGE_PAD = { Left = -7.0, Top = 0.0, Right = 0.0, Bottom = -7.0 }
local HALIGN_LEFT, VALIGN_BOTTOM = 1, 3
local tex = nil
local texFailed = false
local function LoadGameTex()
    local t
    pcall(function()
        local obj = StaticFindObject(GAME_TEX)
        if obj and obj:IsValid() then t = obj end
    end)
    if t then return t end
    pcall(function() LoadAsset(GAME_TEX) end)
    pcall(function()
        local obj = StaticFindObject(GAME_TEX)
        if obj and obj:IsValid() then t = obj end
    end)
    return t
end
local function GetTexture()
    if H.Valid(tex) then return tex end
    tex = nil
    if texFailed then return nil end
    tex = LoadGameTex()
    if not tex then
        texFailed = true
        H.Log("badge texture unavailable - badges disabled")
    end
    return tex
end
local badges = {}
local badgeCount = 0
local MAP_CAP = 512
local function ResetMapIfBloated()
    if badgeCount <= MAP_CAP then return end
    local fresh, n = {}, 0
    for addr, entry in pairs(badges) do
        if H.Valid(entry.img) and H.Valid(entry.slot) then
            fresh[addr] = entry
            n = n + 1
        end
    end
    badges, badgeCount = fresh, n
end
local function CreateBadge(slot)
    local texture = GetTexture()
    if not texture then return nil end
    local anchor = H.P(slot, "EquippedImage")
    if not H.Valid(anchor) then return nil end
    local okPar, overlay = H.C(anchor, "GetParent")
    if not okPar or not H.Valid(overlay) then return nil end
    local img = UI.CreateNative("/Script/UMG.Image", slot)
    if not img then return nil end
    local okAdd = pcall(function()
        local oslot = overlay:AddChildToOverlay(img)
        oslot:SetHorizontalAlignment(HALIGN_LEFT)
        oslot:SetVerticalAlignment(VALIGN_BOTTOM)
        oslot:SetPadding(BADGE_PAD)
    end)
    if not okAdd then return nil end
    pcall(function() img:SetBrushFromTexture(texture, false) end)
    pcall(function() img:SetDesiredSizeOverride({ X = BADGE_SIZE, Y = BADGE_SIZE }) end)
    UI.SetVis(img, UI.HIT_TEST_INVISIBLE)
    return img
end
local function ApplySlot(slot)
    if not H.Valid(slot) then return end
    local excluded = false
    local item = H.P(slot, "ContainedItem")
    if H.Valid(item) then
        local guidStr = H.GuidStr(H.P(item, "Guid"))
        excluded = blacklist.Contains(guidStr)
        if excluded then blacklist.Touch(guidStr) end
    end
    local addr = H.AddrOf(slot)
    if not addr then return end
    local entry = badges[addr]
    if entry and (not H.Valid(entry.img)) then
        badges[addr] = nil
        entry = nil
    end
    if excluded then
        if not entry then
            local img = CreateBadge(slot)
            if not img then return end
            entry = { slot = slot, img = img }
            badges[addr] = entry
            badgeCount = badgeCount + 1
            ResetMapIfBloated()
        end
        UI.SetVis(entry.img, UI.HIT_TEST_INVISIBLE)
    elseif entry then
        UI.SetVis(entry.img, UI.COLLAPSED)
    end
end
local BODY_FIELDS = { "InventoryBody_Items", "InventoryBody_Runes", "InventoryBody_Ammunition" }
function M.ApplyAll()
    local panel = FindFirstOf("InventoryMainPanel")
    if not H.Valid(panel) then return end
    local content = H.P(panel, "InventoryContent")
    if not H.Valid(content) then return end
    for _, field in ipairs(BODY_FIELDS) do
        local body = H.P(content, field)
        if H.Valid(body) then
            local slots = H.ArrayItems(H.P(body, "InventorySlots"))
            for i = 1, slots.n do
                ApplySlot(slots[i])
            end
        end
    end
end
function M.OnInventoryClosed()
    tex = nil
end
return M
