-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local sched = require("core.sched")
local inputmethod = require("core.inputmethod")
local M = {}
local POLL_MS = 100
local HOLD_S = 0.6
local KEY_STACK = "Gamepad_FaceButton_Top"
local KEY_TOGGLE = "Gamepad_RightThumbstick"
local active = false
local callbacks = nil
local stackDownAt, stackFired = nil, false
local toggleDown = false
function M.SetActive(a)
    active = a == true
    if not active then
        stackDownAt, stackFired, toggleDown = nil, false, false
    end
end
local PlainInventoryOpen = inputmethod.PlainInventoryOpen
local function KeyDown(pc, keyName)
    local ok, down = pcall(function()
        return pc:IsInputKeyDown({ KeyName = FName(keyName) })
    end)
    if ok and type(down) == "boolean" then return down end
    return nil
end
local function Poll(pc)
    local down = KeyDown(pc, KEY_STACK)
    if down == true then
        if not stackDownAt then
            stackDownAt, stackFired = os.clock(), false
        elseif not stackFired and os.clock() - stackDownAt >= HOLD_S then
            stackFired = true
            if PlainInventoryOpen(pc) then
                H.Dbg("gamepad: hold " .. KEY_STACK .. " -> quick stack")
                callbacks.OnStack()
            end
        end
    elseif down == false then
        stackDownAt, stackFired = nil, false
    end
    down = KeyDown(pc, KEY_TOGGLE)
    if down == true then
        if not toggleDown then
            toggleDown = true
            if PlainInventoryOpen(pc) then
                H.Dbg("gamepad: press " .. KEY_TOGGLE .. " -> exclusion toggle")
                callbacks.OnToggle()
            end
        end
    elseif down == false then
        toggleDown = false
    end
end
function M.Start(cbs)
    callbacks = cbs
    sched.Loop(POLL_MS, function()
        if not active then return end
        local pc
        pcall(function() pc = require("UEHelpers").GetPlayerController() end)
        if H.Valid(pc) then pcall(Poll, pc) end
    end)
end
return M
