-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local UI = require("core.uihelpers")
local sched = require("core.sched")
local inputmethod = require("core.inputmethod")
local M = {}
local JUSTIFY_CENTER = 1
local VALIGN_CENTER = 2
local FONT_SIZE = 14
local ICON_SIZE = 32
local PS_STICK_ICON_SIZE = 40
local OPACITY = 0.85
local FADE_MS = 150
local FADE_STEP_MS = 25
local KBM_ASSET = "/Game/UI/InputData/DominionInputKeyboardMouseControllerData"
local KBM_CDO = KBM_ASSET .. ".Default__DominionInputKeyboardMouseControllerData_C"
local PAD_SOURCES = {
    Generic = { asset = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData",
                cdoName = "Default__BP_DominionInputDefaultGamepadControllerData_C" },
    PS = { asset = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData_PS",
           cdoName = "Default__BP_DominionInputDefaultGamepadControllerData_PS_C" },
}
local PAD_KEY_STACK = "Gamepad_FaceButton_Top"
local PAD_KEY_TOGGLE = "Gamepad_RightThumbstick"
local hintRow = nil
local hintContent = nil
local builtMode = nil
local suppressed = false
local failedOnce = false
local fadeToken = 0
local FKEY_ALIAS = {
    LEFT_MOUSE_BUTTON = "LeftMouseButton", RIGHT_MOUSE_BUTTON = "RightMouseButton",
    MIDDLE_MOUSE_BUTTON = "MiddleMouseButton",
    XBUTTON_ONE = "ThumbMouseButton", XBUTTON_TWO = "ThumbMouseButton2",
    SPACE = "SpaceBar", RETURN = "Enter", ESCAPE = "Escape", TAB = "Tab",
    BACKSPACE = "BackSpace", CAPS_LOCK = "CapsLock",
    LEFT_SHIFT = "LeftShift", RIGHT_SHIFT = "RightShift",
    LEFT_CONTROL = "LeftControl", RIGHT_CONTROL = "RightControl",
    LEFT_ALT = "LeftAlt", RIGHT_ALT = "RightAlt",
    UP_ARROW = "Up", DOWN_ARROW = "Down", LEFT_ARROW = "Left", RIGHT_ARROW = "Right",
    NUM_ZERO = "NumPadZero", NUM_ONE = "NumPadOne", NUM_TWO = "NumPadTwo",
    NUM_THREE = "NumPadThree", NUM_FOUR = "NumPadFour", NUM_FIVE = "NumPadFive",
    NUM_SIX = "NumPadSix", NUM_SEVEN = "NumPadSeven", NUM_EIGHT = "NumPadEight",
    NUM_NINE = "NumPadNine",
}
local function ToFKeyName(keyName)
    local s = tostring(keyName or "")
    if FKEY_ALIAS[s] then return FKEY_ALIAS[s] end
    if #s == 1 then return s:upper() end
    if s:match("^F%d+$") then return s end
    return (s:lower():gsub("_(%a)", function(a) return a:upper() end):gsub("^%a", string.upper))
end
local function PrettyKeyName(keyName)
    local s = tostring(keyName or "?")
    s = s:gsub("_", " "):lower():gsub("(%a)([%w]*)", function(a, b) return a:upper() .. b end)
    return s
end
local glyphMaps = {}
local function ReadBrushEntries(obj)
    if not H.Valid(obj) then return nil end
    local entries = H.ArrayItems(H.P(obj, "InputBrushDataMap"))
    if entries.n == 0 then return nil end
    local map, count = {}, 0
    for i = 1, entries.n do
        local entry = entries[i]
        if entry then
            local name
            pcall(function() name = entry.Key.KeyName:ToString() end)
            if name and not map[name] then
                map[name] = entry
                count = count + 1
            end
        end
    end
    if count == 0 then return nil end
    return map, count
end
local function GetGlyphMap(kind)
    kind = kind or "KBM"
    if glyphMaps[kind] ~= nil then return glyphMaps[kind] or nil end
    local candidates
    if kind == "KBM" then
        pcall(function() LoadAsset(KBM_ASSET) end)
        candidates = {
            KBM_CDO,
            KBM_ASSET .. ".DominionInputKeyboardMouseControllerData",
            KBM_ASSET .. ".DominionInputKeyboardMouseControllerData_C",
        }
    else
        local src = PAD_SOURCES[kind]
        if not src then return nil end
        pcall(function() LoadAsset(src.asset) end)
        candidates = { src.asset .. "." .. src.cdoName }
    end
    for _, path in ipairs(candidates) do
        local obj
        pcall(function()
            local found = StaticFindObject(path)
            if found and found:IsValid() then obj = found end
        end)
        if obj then
            local map, count = ReadBrushEntries(obj)
            if not map then
                local cdo
                pcall(function() cdo = obj:GetCDO() end)
                if not H.Valid(cdo) then
                    pcall(function() cdo = obj:GetClassDefaultObject() end)
                end
                map, count = ReadBrushEntries(cdo)
            end
            if map then
                glyphMaps[kind] = map
                H.Dbg(string.format("hint: %d %s glyph(s) from %s", count, kind, path))
                return map
            end
            H.Dbg("hint: found " .. path .. " but no readable brush map")
        end
    end
    glyphMaps[kind] = false
    H.Dbg("hint: " .. kind .. " controller data unresolvable - key names shown as text")
    return nil
end
local function FindKeyBrushEntry(fkeyName, kind)
    local map = GetGlyphMap(kind)
    if not map then return nil end
    local entry = map[fkeyName]
    if not entry then
        H.Dbg("hint: no " .. tostring(kind) .. " glyph for key '" .. tostring(fkeyName) .. "'")
    end
    return entry
end
local TEX_ROOT = "/Game/Art/UI/Inputs/"
local SPECIAL_TEX = {
    SpaceBar = "Keyboard/T_Keys-Special-Space",
    Tab = "Keyboard/T_Keys-Special-Tab",
    Escape = "Keyboard/T_Keys-Special-Esc",
    Enter = "Keyboard/Keys-Standard-Enter",
    LeftShift = "Keyboard/T_Keys-Special-Shift", RightShift = "Keyboard/T_Keys-Special-Shift",
    LeftControl = "Keyboard/T_Keys-Special-Ctrl", RightControl = "Keyboard/T_Keys-Special-Ctrl",
    LeftAlt = "Keyboard/T_Keys-Special-Alt", RightAlt = "Keyboard/T_Keys-Special-Alt",
    LeftMouseButton = "Mouse/T_Mouse-Buttons-Left",
    RightMouseButton = "Mouse/T_Mouse-Buttons-Right",
    MiddleMouseButton = "Mouse/T_Mouse-Buttons-Middle",
}
local PAD_TEX = {
    Generic = { [PAD_KEY_STACK] = "Controller/Xbox/T_Xbox-Y" },
    PS = { [PAD_KEY_STACK] = "Controller/Playstation/T_PS-Triangle",
           [PAD_KEY_TOGGLE] = "Controller/Playstation/T_PS-R3_Stick" },
}
local PAD_TEXT = {
    Generic = { [PAD_KEY_STACK] = "Y", [PAD_KEY_TOGGLE] = "RS press" },
    PS = { [PAD_KEY_STACK] = "Triangle", [PAD_KEY_TOGGLE] = "R3" },
}
local texByPathCache = {}
local function LoadTextureByPath(path)
    local cached = texByPathCache[path]
    if H.Valid(cached) then return cached end
    local tex
    pcall(function()
        local obj = StaticFindObject(path)
        if obj and obj:IsValid() then tex = obj end
    end)
    if not tex then
        pcall(function() LoadAsset(path) end)
        pcall(function()
            local obj = StaticFindObject(path)
            if obj and obj:IsValid() then tex = obj end
        end)
    end
    texByPathCache[path] = tex
    return tex
end
local function RelToPath(rel)
    local objName = rel:match("([^/]+)$")
    return TEX_ROOT .. rel .. "." .. objName
end
local function DirectKeyTexture(fkeyName, padFamily)
    local rel
    if padFamily then
        rel = (PAD_TEX[padFamily] or {})[fkeyName]
    else
        rel = SPECIAL_TEX[fkeyName]
        if not rel then
            if fkeyName:match("^[A-Z0-9]$") then
                rel = "Keyboard/T_Keys-Standard-" .. fkeyName
            elseif fkeyName:match("^F%d+$") then
                rel = "Keyboard/T_Keys-Special-" .. fkeyName
            end
        end
    end
    if not rel then return nil end
    return LoadTextureByPath(RelToPath(rel))
end
local function StyleText(text, template)
    pcall(function() text.Justification = JUSTIFY_CENTER end)
    if H.Valid(template) then
        pcall(function() text:SetFont(template.Font) end)
        pcall(function() text:SetColorAndOpacity(template.ColorAndOpacity) end)
        pcall(function() text:SetShadowColorAndOpacity(template.ShadowColorAndOpacity) end)
        pcall(function() text:SetShadowOffset(template.ShadowOffset) end)
    end
    pcall(function()
        local font = text.Font
        font.Size = FONT_SIZE
        text:SetFont(font)
    end)
end
local function StillPlaced()
    if not H.Valid(hintRow) then return false end
    local ok, parent = H.C(hintRow, "GetParent")
    return ok and H.Valid(parent)
end
local function AddSegment(hbox, outer, template, label, keyName, leftPad, opts)
    opts = opts or {}
    local function addText(str, pad)
        local tb = UI.CreateNative("/Script/UMG.TextBlock", outer)
        if not tb then return end
        StyleText(tb, template)
        UI.SetText(tb, str)
        pcall(function()
            local slot = hbox:AddChildToHorizontalBox(tb)
            slot:SetVerticalAlignment(VALIGN_CENTER)
            slot:SetPadding({ Left = pad or 0.0, Top = 0.0, Right = 0.0, Bottom = 0.0 })
        end)
        UI.SetVis(tb, UI.HIT_TEST_INVISIBLE)
    end
    addText(label, leftPad)
    if keyName == nil then return false end
    local fkey = opts.family and keyName or ToFKeyName(keyName)
    local tex, mat, viaStruct
    local entry = FindKeyBrushEntry(fkey, opts.family or "KBM")
    if entry then
        local res
        pcall(function() res = entry.KeyBrush.ResourceObject end)
        if H.Valid(res) then
            local cn = H.ClassName(res)
            if cn:find("Texture") then tex = res
            elseif cn:find("Material") then mat = res end
            H.Dbg("hint: key '" .. fkey .. "' brush resource: " .. cn)
        else
            H.Dbg("hint: key '" .. fkey .. "' brush has no readable ResourceObject")
        end
    end
    if not tex and not mat then
        tex = DirectKeyTexture(fkey, opts.family)
        if tex then H.Dbg("hint: key '" .. fkey .. "' using direct texture") end
    end
    if not tex and not mat and entry then viaStruct = true end
    if tex then
        pcall(function()
            H.Dbg(string.format("hint: key '%s' texture %s (%sx%s)", fkey,
                tex:GetFullName(), tostring(tex.SizeX or "?"), tostring(tex.SizeY or "?")))
        end)
    end
    local iconSize = opts.size or ICON_SIZE
    if tex or mat or viaStruct then
        local icon = UI.CreateNative("/Script/UMG.Image", outer)
        local iconBox = UI.CreateNative("/Script/UMG.SizeBox", outer)
        if icon and iconBox then
            local okAttach = pcall(function()
                iconBox:SetWidthOverride(iconSize)
                iconBox:SetHeightOverride(iconSize)
                iconBox:AddChild(icon)
                local slot = hbox:AddChildToHorizontalBox(iconBox)
                slot:SetVerticalAlignment(VALIGN_CENTER)
                slot:SetPadding({ Left = 5.0, Top = 0.0, Right = 0.0, Bottom = 0.0 })
            end)
            if okAttach then
                local applied = false
                if tex then
                    applied = pcall(function() icon:SetBrushFromTexture(tex, false) end)
                elseif mat then
                    applied = pcall(function() icon:SetBrushFromMaterial(mat) end)
                else
                    applied = pcall(function() icon:SetBrush(entry.KeyBrush) end)
                end
                if applied then
                    pcall(function() icon:SetDesiredSizeOverride({ X = iconSize, Y = iconSize }) end)
                    UI.SetVis(iconBox, UI.HIT_TEST_INVISIBLE)
                    UI.SetVis(icon, UI.HIT_TEST_INVISIBLE)
                    if opts.hold then addText("(hold)", 4.0) end
                    return true
                end
                pcall(function() iconBox:RemoveFromParent() end)
            end
        end
    end
    if opts.family then
        local words = (PAD_TEXT[opts.family] or {})[fkey] or PrettyKeyName(fkey)
        addText(words .. (opts.hold and " (hold)" or ""), 5.0)
    else
        addText(PrettyKeyName(keyName), 5.0)
    end
    return false
end
local HINT_Y = 320
local HINT_X = 20
function M.Reposition()
    if not H.Valid(hintContent) then return end
    pcall(function() hintContent:SetRenderTranslation({ X = HINT_X, Y = HINT_Y }) end)
end
function M.Ensure(cfg, hotkeyName, blacklistKeyName)
    if cfg.ShowHint == false or failedOnce then return end
    local mode = "kbm"
    local family
    if inputmethod.IsGamepad() then
        family = inputmethod.GamepadFamily()
        mode = "pad:" .. family
    end
    if family then
        local pc
        pcall(function() pc = require("UEHelpers").GetPlayerController() end)
        if not inputmethod.PlainInventoryOpen(pc) then
            if not suppressed then
                suppressed = true
                if H.Valid(hintRow) then UI.SetVis(hintRow, UI.COLLAPSED) end
            end
            return
        end
    end
    if suppressed then
        suppressed = false
        if H.Valid(hintRow) then
            UI.SetVis(hintRow, UI.HIT_TEST_INVISIBLE)
            pcall(function() hintContent:SetRenderOpacity(OPACITY) end)
        end
    end
    if StillPlaced() then
        if builtMode == mode then
            M.Reposition()
            return
        end
        pcall(function() hintRow:RemoveFromParent() end)
    end
    hintRow, hintContent = nil, nil
    local panel = FindFirstOf("InventoryMainPanel")
    if not H.Valid(panel) then return end
    local content = H.P(panel, "InventoryContent")
    if not H.Valid(content) then return end
    local weightBar = H.P(content, "WeightBar")
    local overlay = H.P(content, "TabGroupOverlay")
    if not H.Valid(weightBar) or not H.Valid(overlay) then
        H.Dbg("hint: weight bar / tab overlay unavailable")
        return
    end
    local template = H.P(weightBar, "WeightText")
    local hbox = UI.CreateNative("/Script/UMG.HorizontalBox", content)
    if not hbox then
        failedOnce = true
        H.Log("hint: widget construction failed - hint disabled this session")
        return
    end
    local stackOn = cfg.EnableQuickStack ~= false
    local g1, g3
    if family then
        if stackOn then
            g1 = AddSegment(hbox, content, template, "Quick Stack:", PAD_KEY_STACK, 0.0,
                { family = family, hold = true })
            AddSegment(hbox, content, template, "|", nil, 8.0)
        end
        g3 = AddSegment(hbox, content, template, "Exclude item:", PAD_KEY_TOGGLE,
            stackOn and 8.0 or 0.0,
            { family = family, size = family == "PS" and PS_STICK_ICON_SIZE or nil })
    else
        if stackOn then
            g1 = AddSegment(hbox, content, template, "Quick Stack:", hotkeyName, 0.0)
            AddSegment(hbox, content, template, "|", nil, 8.0)
        end
        g3 = AddSegment(hbox, content, template, "Exclude item:", blacklistKeyName,
            stackOn and 8.0 or 0.0)
    end
    H.Dbg(string.format("hint segments (%s): stack glyph=%s exclude glyph=%s",
        mode, tostring(g1), tostring(g3)))
    pcall(function() hbox:SetRenderOpacity(OPACITY) end)
    local okAdd = pcall(function()
        local slot = overlay:AddChildToOverlay(hbox)
        slot:SetHorizontalAlignment(3)
        slot:SetVerticalAlignment(1)
    end)
    if not okAdd then
        failedOnce = true
        H.Log("hint: could not attach to the tab overlay - hint disabled this session")
        return
    end
    UI.SetVis(hbox, UI.HIT_TEST_INVISIBLE)
    hintRow, hintContent = hbox, hbox
    builtMode = mode
    M.Reposition()
    H.Dbg("hint placed (" .. mode .. ", tab overlay + geometry reposition)")
end
function M.SetShown(show)
    fadeToken = fadeToken + 1
    if not H.Valid(hintRow) then return end
    if show and suppressed then show = false end
    UI.SetVis(hintRow, show and UI.HIT_TEST_INVISIBLE or UI.COLLAPSED)
    if show and H.Valid(hintContent) then
        pcall(function() hintContent:SetRenderOpacity(OPACITY) end)
    end
end
local function Fade(fadeIn)
    if not H.Valid(hintRow) or not H.Valid(hintContent) then return end
    if fadeIn and suppressed then return end
    fadeToken = fadeToken + 1
    local my = fadeToken
    UI.SetVis(hintRow, UI.HIT_TEST_INVISIBLE)
    if fadeIn then
        pcall(function() hintContent:SetRenderOpacity(0.0) end)
    end
    local t = 0.0
    sched.Loop(FADE_STEP_MS, function()
        if my ~= fadeToken then return true end
        t = t + FADE_STEP_MS / FADE_MS
        local frac = math.min(t, 1.0)
        local a = (fadeIn and frac or (1.0 - frac)) * OPACITY
        if H.Valid(hintContent) then
            pcall(function() hintContent:SetRenderOpacity(a) end)
        end
        if t >= 1.0 then
            if not fadeIn and H.Valid(hintRow) then
                UI.SetVis(hintRow, UI.COLLAPSED)
            end
            return true
        end
    end)
end
function M.FadeIn() Fade(true) end
function M.FadeOut() Fade(false) end
return M
