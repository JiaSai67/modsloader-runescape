-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local hasGtLoop = type(LoopInGameThreadWithDelay) == "function"
local hasGtDelay = type(ExecuteInGameThreadWithDelay) == "function"
local hasGt = type(ExecuteInGameThread) == "function"
M.UsingGameThreadApis = hasGtLoop and hasGtDelay
function M.Describe()
    return string.format("loop=%s delay=%s",
        hasGtLoop and "LoopInGameThreadWithDelay" or "LoopAsync+marshal",
        hasGtDelay and "ExecuteInGameThreadWithDelay" or "ExecuteWithDelay+marshal")
end
function M.OnGameThread(fn)
    if not hasGt then
        local ok, err = pcall(fn)
        if not ok then H.Log("task error: " .. tostring(err)) end
        return
    end
    pcall(ExecuteInGameThread, function()
        local ok, err = pcall(fn)
        if not ok then H.Log("task error: " .. tostring(err)) end
    end)
end
function M.Delay(ms, fn)
    local body = function()
        local ok, err = pcall(fn)
        if not ok then H.Log("delayed task error: " .. tostring(err)) end
    end
    if hasGtDelay then
        if pcall(ExecuteInGameThreadWithDelay, ms, body) then return end
    end
    if type(ExecuteWithDelay) == "function" and hasGt then
        pcall(ExecuteWithDelay, ms, function() pcall(ExecuteInGameThread, body) end)
    else
        M.OnGameThread(fn)
    end
end
function M.Loop(ms, fn)
    if hasGtLoop then
        local ok = pcall(LoopInGameThreadWithDelay, ms, function()
            local okT, stop = pcall(fn)
            if not okT then
                H.Log("loop task error: " .. tostring(stop))
                return false
            end
            return stop == true
        end)
        if ok then return end
    end
    local stopped = false
    pcall(LoopAsync, ms, function()
        if stopped then return true end
        if not hasGt then
            local okT, stop = pcall(fn)
            if not okT then H.Log("loop task error: " .. tostring(stop))
            elseif stop == true then stopped = true end
            return stopped
        end
        pcall(ExecuteInGameThread, function()
            if stopped then return end
            local okT, stop = pcall(fn)
            if not okT then H.Log("loop task error: " .. tostring(stop))
            elseif stop == true then stopped = true end
        end)
        return false
    end)
end
return M
