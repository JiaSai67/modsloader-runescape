-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local RUNTIME_LIB = "/Script/Dominion.Default__DominionRuntimeBlueprintLibrary"
local TEST_ITEMS = {
    "/Game/Gameplay/Items/Resources/Wood/ITEM_Resources_Wood_Ash.ITEM_Resources_Wood_Ash",
    "/Game/Gameplay/Items/Resources/Magic/ITEM_Rune_Air.ITEM_Rune_Air",
}
local function LoadItemData(path)
    local data
    pcall(function()
        local obj = StaticFindObject(path)
        if obj and obj:IsValid() then data = obj end
    end)
    if data then return data end
    pcall(function() LoadAsset(path) end)
    pcall(function()
        local obj = StaticFindObject(path)
        if obj and obj:IsValid() then data = obj end
    end)
    return data
end
function M.SpawnTestItems()
    local UEHelpers = require("UEHelpers")
    local pc
    pcall(function() pc = UEHelpers.GetPlayerController() end)
    if not H.Valid(pc) then H.Log("[debug] no player controller") return end
    local lib = H.FindClass(RUNTIME_LIB)
    if not lib then H.Log("[debug] DominionRuntimeBlueprintLibrary CDO not found") return end
    for _, path in ipairs(TEST_ITEMS) do
        local data = LoadItemData(path)
        if not H.Valid(data) then
            H.Log("[debug] item data not found: " .. path)
        else
            local okMax, maxStack = H.C(data, "GetMaxStackSize")
            local count = (okMax and type(maxStack) == "number" and maxStack > 0) and maxStack or 1
            local okGive, given = H.C(lib, "TryGiveItemToPlayer", pc, data, count)
            local name = "?"
            pcall(function() name = data:GetName():ToString() end)
            if okGive and given == true then
                H.Log(string.format("[debug] gave %dx %s", count, name))
            else
                H.Log(string.format("[debug] TryGiveItemToPlayer failed for %s (ok=%s ret=%s) - inventory full?",
                    name, tostring(okGive), tostring(given)))
            end
        end
    end
end
return M
