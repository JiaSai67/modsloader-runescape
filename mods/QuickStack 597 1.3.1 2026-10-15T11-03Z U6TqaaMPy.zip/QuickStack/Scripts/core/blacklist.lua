-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local PRUNE_DAYS = 5
local entries = {}
local seenDirty = false
local loaded = false
local filePath = nil
local Save
local function ResolveFilePath()
    if filePath ~= nil then return filePath or nil end
    local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
    if not ok or type(src) ~= "string" then
        filePath = false
        H.Log("WARNING: cannot resolve script path - exclusions will not persist this session")
        return nil
    end
    src = src:gsub("^@", "")
    local dir = src:match("^(.*)[/\\][^/\\]+[/\\][^/\\]+$")
    if not dir then
        filePath = false
        H.Log("WARNING: unexpected script path layout - exclusions will not persist this session")
        return nil
    end
    filePath = dir .. "\\blacklist_data.lua"
    return filePath
end
function M.Load()
    if loaded then return end
    loaded = true
    local path = ResolveFilePath()
    if not path then return end
    local fh = io.open(path, "r")
    if not fh then
        H.Log("0 excluded item(s) loaded")
        return
    end
    local body = fh:read("*a")
    fh:close()
    local okLoad, chunk = pcall(load, body, "blacklist_data", "t", {})
    if okLoad and chunk then
        local okRun, data = pcall(chunk)
        if okRun and type(data) == "table" then
            local now = os.time()
            local cutoff = now - PRUNE_DAYS * 86400
            local n, candidates = 0, 0
            for guid, v in pairs(data) do
                if type(guid) == "string" then
                    local entry
                    if type(v) == "table" then
                        entry = { name = tostring(v.name or "?"), seen = tonumber(v.seen) or now }
                    else
                        entry = { name = tostring(v), seen = now }
                    end
                    if entry.seen < cutoff then
                        entry.stale = true
                        candidates = candidates + 1
                    end
                    entries[guid] = entry
                    n = n + 1
                end
            end
            if candidates > 0 then
                H.Log(string.format(
                    "%d excluded item(s) loaded (%d unseen > %d days - kept if still in the inventory, pruned otherwise)",
                    n, candidates, PRUNE_DAYS))
            else
                H.Log(n .. " excluded item(s) loaded")
            end
            return
        end
    end
    H.Log("WARNING: blacklist_data.lua unreadable - starting with no exclusions (file kept)")
end
Save = function()
    local path = ResolveFilePath()
    if not path then return end
    local lines = { "-- QuickStack exclusions (generated; safe to delete).", "return {" }
    for guid, entry in pairs(entries) do
        lines[#lines + 1] = string.format("  [%q] = { name = %q, seen = %d },",
            guid, entry.name, entry.seen)
    end
    lines[#lines + 1] = "}"
    local fh, err = io.open(path, "w")
    if not fh then
        H.Log("WARNING: cannot write blacklist_data.lua (" .. tostring(err) .. ")")
        return
    end
    fh:write(table.concat(lines, "\n") .. "\n")
    fh:close()
    seenDirty = false
end
function M.Contains(guidStr)
    return guidStr ~= nil and entries[guidStr] ~= nil
end
function M.Touch(guidStr)
    local entry = guidStr and entries[guidStr]
    if entry then
        local now = os.time()
        if entry.stale then
            entry.stale = nil
            entry.seen = now
            seenDirty = true
        elseif now - entry.seen > 3600 then
            entry.seen = now
            seenDirty = true
        end
    end
end
function M.Flush()
    local pruned = 0
    for guid, entry in pairs(entries) do
        if entry.stale then
            entries[guid] = nil
            pruned = pruned + 1
        end
    end
    if pruned > 0 then
        H.Log(string.format("%d stale exclusion(s) pruned (unseen > %d days and not in the inventory)",
            pruned, PRUNE_DAYS))
        seenDirty = true
    end
    if seenDirty then Save() end
end
function M.Toggle(guidStr, itemName)
    if entries[guidStr] then
        entries[guidStr] = nil
        Save()
        return false
    end
    entries[guidStr] = { name = itemName or "?", seen = os.time() }
    Save()
    return true
end
function M.Count()
    local n = 0
    for _ in pairs(entries) do n = n + 1 end
    return n
end
return M
