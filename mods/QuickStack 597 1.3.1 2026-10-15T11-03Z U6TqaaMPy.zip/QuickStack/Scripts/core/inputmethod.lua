-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
local TYPE_GAMEPAD = 1
local cis = nil
local function Subsystem()
    if H.Valid(cis) then return cis end
    cis = nil
    pcall(function()
        local found = FindFirstOf("CommonInputSubsystem")
        if found and found:IsValid() then cis = found end
    end)
    return cis
end
function M.IsGamepad()
    local s = Subsystem()
    if not s then return false end
    local t
    pcall(function() t = s:GetCurrentInputType() end)
    return tonumber(t) == TYPE_GAMEPAD
end
function M.GamepadFamily()
    local s = Subsystem()
    local name
    if s then pcall(function() name = s:GetCurrentGamepadName():ToString() end) end
    if type(name) == "string" and name:find("PS") then return "PS" end
    return "Generic"
end
local PLAIN_INVENTORY_MODE = "DIM_MainInventoryMenu"
local lastModeName = nil
function M.PlainInventoryOpen(pc)
    if not H.Valid(pc) then return false end
    local mode = H.P(pc, "CurrentInputMode")
    if not H.Valid(mode) then return false end
    local ok, name = pcall(function() return mode:GetFName():ToString() end)
    if not ok then return false end
    if name ~= lastModeName then
        lastModeName = name
        H.Dbg("inputmethod: input mode now '" .. tostring(name) .. "'")
    end
    return name == PLAIN_INVENTORY_MODE
end
return M
