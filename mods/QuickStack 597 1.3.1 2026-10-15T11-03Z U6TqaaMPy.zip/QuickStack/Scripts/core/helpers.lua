-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local M = {}
local MOD = "QuickStack"
local verbose = false
function M.SetVerbose(v) verbose = v == true end
function M.IsVerbose() return verbose end
function M.Log(msg)
    print(string.format("[%s] %s\n", MOD, msg))
end
function M.Dbg(msg)
    if verbose then M.Log(msg) end
end
function M.Valid(obj)
    if not obj then return false end
    local ok, v = pcall(function() return obj:IsValid() end)
    return ok and v == true
end
function M.P(obj, name)
    local ok, v = pcall(function() return obj[name] end)
    if ok then return v end
    return nil
end
function M.C(obj, fn, ...)
    local args = { ... }
    local ok, v = pcall(function() return obj[fn](obj, table.unpack(args)) end)
    return ok, v
end
function M.FullName(obj)
    local ok, n = pcall(function() return obj:GetFullName() end)
    if ok and n then return n end
    return "<unknown>"
end
function M.ClassName(obj)
    local ok, n = pcall(function() return obj:GetClass():GetFName():ToString() end)
    if ok and n then return n end
    return "<unknown>"
end
local classCache = {}
function M.FindClass(path)
    local hit = classCache[path]
    if hit ~= nil then return hit or nil end
    local cls
    pcall(function()
        local obj = StaticFindObject(path)
        if obj and obj:IsValid() then cls = obj end
    end)
    classCache[path] = cls or false
    return cls
end
function M.IsA(obj, classPath)
    local cls = M.FindClass(classPath)
    if not cls then return false end
    local ok, r = pcall(function() return obj:IsA(cls) end)
    return ok and r == true
end
function M.ArrayNum(arr)
    if not arr then return 0 end
    local ok, n = pcall(function() return arr:GetArrayNum() end)
    if ok and type(n) == "number" then return n end
    ok, n = pcall(function() return #arr end)
    if ok and type(n) == "number" then return n end
    return 0
end
local function U32(v)
    if type(v) ~= "number" then return 0 end
    return v & 0xFFFFFFFF
end
function M.GuidStr(fguid)
    if not fguid then return nil end
    local ok, s = pcall(function()
        return string.format("%08X-%08X-%08X-%08X",
            U32(fguid.A), U32(fguid.B), U32(fguid.C), U32(fguid.D))
    end)
    if ok then return s end
    return nil
end
function M.DistanceCm(actorA, actorB)
    local okA, la = pcall(function() return actorA:K2_GetActorLocation() end)
    local okB, lb = pcall(function() return actorB:K2_GetActorLocation() end)
    if not okA or not okB or not la or not lb then return nil end
    local dx, dy, dz = la.X - lb.X, la.Y - lb.Y, la.Z - lb.Z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end
function M.AddrOf(obj)
    if obj == nil or type(obj) ~= "userdata" then return nil end
    local ok, addr = pcall(function() return obj:GetAddress() end)
    if ok and addr ~= nil and addr ~= 0 then return addr end
    return nil
end
function M.ArrayItems(arr)
    local n = M.ArrayNum(arr)
    local out, got = { n = n }, 0
    if n == 0 then return out end
    for i = 1, n do
        local ok, v = pcall(function() return arr[i] end)
        if ok and v ~= nil then
            out[i] = v
            got = got + 1
        end
    end
    if got > 0 then return out end
    pcall(function()
        arr:ForEach(function(i, elem)
            local v = elem
            pcall(function()
                local t = elem:type()
                if t == "RemoteUnrealParam" or t == "LocalUnrealParam" then v = elem:get() end
            end)
            if type(i) == "number" and v ~= nil then out[i] = v end
        end)
    end)
    return out
end
function M.ItemName(item)
    local ok, name = pcall(function() return item:GetPlayerFacingName():ToString() end)
    if ok and name and name ~= "" then return name end
    return "<unnamed item>"
end
return M
