-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local blacklist = require("core.blacklist")
local M = {}
local BODIES = {
    { field = "InventoryBody_Items", allowed = true },
    { field = "InventoryBody_Runes", allowed = true },
    { field = "InventoryBody_Ammunition", allowed = true },
    { field = "InventoryBody_QuestItems", allowed = false, why = "quest items are never quick-stacked" },
}
local function HoveredInArray(arr, inner)
    local entries = H.ArrayItems(arr)
    for i = 1, entries.n do
        local slot = entries[i]
        if H.Valid(slot) then
            local probe = slot
            if inner then probe = H.P(slot, inner) end
            if H.Valid(probe) and H.P(probe, "bIsMousedOver") == true then
                return probe
            end
        end
    end
    return nil
end
function M.HandleMiddleClick()
    local panel = FindFirstOf("InventoryMainPanel")
    if not H.Valid(panel) then return end
    local content = H.P(panel, "InventoryContent")
    if not H.Valid(content) then return end
    for _, body in ipairs(BODIES) do
        local widget = H.P(content, body.field)
        if H.Valid(widget) then
            local slot = HoveredInArray(H.P(widget, "InventorySlots"))
            if slot then
                if not body.allowed then
                    H.Log(body.why)
                    return
                end
                local item = H.P(slot, "ContainedItem")
                if not H.Valid(item) then return end
                local guidStr = H.GuidStr(H.P(item, "Guid"))
                if not guidStr then
                    H.Log("could not read item guid - not toggled")
                    return
                end
                local name = H.ItemName(item)
                local excluded = blacklist.Toggle(guidStr, name)
                H.Log(string.format("'%s' %s quick-stack (%d excluded total)",
                    name, excluded and "EXCLUDED from" or "re-included in", blacklist.Count()))
                return
            end
        end
    end
    local qab = H.P(content, "QuickAccessBar")
    if H.Valid(qab) and HoveredInArray(H.P(qab, "QuickAccessSlots"), "InventorySlot") then
        H.Log("hotbar items are never quick-stacked (no need to exclude)")
        return
    end
    local eqb = H.P(content, "EquipmentBar")
    if H.Valid(eqb) and HoveredInArray(H.P(eqb, "EquipmentSlots")) then
        H.Log("equipped items are never quick-stacked (no need to exclude)")
        return
    end
end
return M
