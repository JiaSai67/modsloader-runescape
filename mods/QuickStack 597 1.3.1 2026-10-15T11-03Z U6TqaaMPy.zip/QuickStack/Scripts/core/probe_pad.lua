-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local sched = require("core.sched")
local M = {}
local POLL_MS = 100
local PAD_KEYS = {
    "Gamepad_FaceButton_Top",
    "Gamepad_RightThumbstick",
    "Gamepad_FaceButton_Bottom",
}
local GAMEPAD_DATA_ASSETS = {
    { label = "Generic/Xbox",
      asset = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData",
      cdo = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData.Default__BP_DominionInputDefaultGamepadControllerData_C" },
    { label = "PS5",
      asset = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData_PS",
      cdo = "/Game/UI/InputData/BP_DominionInputDefaultGamepadControllerData_PS.Default__BP_DominionInputDefaultGamepadControllerData_PS_C" },
}
local INPUT_TYPE_NAME = { [0] = "MouseAndKeyboard", [1] = "Gamepad", [2] = "Touch" }
local function InputTypeString(cis)
    local t, pad
    pcall(function() t = cis:GetCurrentInputType() end)
    pcall(function() pad = cis:GetCurrentGamepadName():ToString() end)
    return string.format("type=%s(%s) pad='%s'",
        tostring(t), INPUT_TYPE_NAME[tonumber(t) or -1] or "?", tostring(pad))
end
local subsystemDone = false
local function ProbeInputSubsystem()
    if subsystemDone then return end
    local cis = FindFirstOf("CommonInputSubsystem")
    if not H.Valid(cis) then return end
    subsystemDone = true
    H.Log("[pad] CommonInputSubsystem: " .. H.FullName(cis))
    H.Log("[pad] current " .. InputTypeString(cis))
    local ok = pcall(function()
        RegisterHook("/Script/CommonInput.CommonInputSubsystem:BroadcastInputMethodChanged",
            function(Context)
                local self
                pcall(function() self = Context:get() end)
                local s = "<ctx unreadable>"
                if H.Valid(self) then s = InputTypeString(self) end
                H.Log("[pad] BroadcastInputMethodChanged FIRED -> " .. s)
            end)
    end)
    H.Log("[pad] BroadcastInputMethodChanged hook: " .. (ok and "registered" or "FAILED"))
end
local keyVariant = nil
local function ResolveKeyVariant(pc)
    local variants = {
        { name = "{KeyName=FName(k)}", make = function(k) return { KeyName = FName(k) } end },
        { name = "{KeyName=k}",        make = function(k) return { KeyName = k } end },
    }
    for _, v in ipairs(variants) do
        local ok, r = pcall(function() return pc:IsInputKeyDown(v.make("SpaceBar")) end)
        H.Log(string.format("[pad] IsInputKeyDown(SpaceBar) via %s -> ok=%s val=%s",
            v.name, tostring(ok), tostring(r)))
        if ok and type(r) == "boolean" then
            H.Log("[pad] key marshalling: " .. v.name .. " (b: PASS if edges log below)")
            return v.make
        end
    end
    H.Log("[pad] NO working IsInputKeyDown variant (b: FAIL - need capture plan B)")
    return nil
end
local keyState = {}
local function PollKeys(pc)
    if not keyVariant then return end
    for _, k in ipairs(PAD_KEYS) do
        local ok, down = pcall(function() return pc:IsInputKeyDown(keyVariant(k)) end)
        if ok and type(down) == "boolean" then
            local st = keyState[k]
            if down and (not st or not st.down) then
                keyState[k] = { down = true, since = os.clock() }
                H.Log("[pad] KEY DOWN " .. k)
                if k == "Gamepad_RightThumbstick" then M.DumpFocusedSlot("R3") end
            elseif not down and st and st.down then
                local held = os.clock() - (st.since or os.clock())
                keyState[k] = { down = false }
                H.Log(string.format("[pad] KEY UP   %s (held %.0f ms)", k, held * 1000))
            end
        end
    end
end
local FLAG_PROPS = { "bIsMousedOver", "bIsHovered", "bIsFocused", "bIsSelected" }
local FLAG_CALLS = { "IsHovered", "HasKeyboardFocus", "HasFocusedDescendants" }
local BODIES = { "InventoryBody_Items", "InventoryBody_Runes",
    "InventoryBody_Ammunition", "InventoryBody_QuestItems" }
local function SlotFlags(slot, pc)
    local hits = {}
    for _, p in ipairs(FLAG_PROPS) do
        if H.P(slot, p) == true then hits[#hits + 1] = p end
    end
    for _, fn in ipairs(FLAG_CALLS) do
        local ok, v = H.C(slot, fn)
        if ok and v == true then hits[#hits + 1] = fn .. "()" end
    end
    if H.Valid(pc) then
        local ok, v = H.C(slot, "HasUserFocus", pc)
        if ok and v == true then hits[#hits + 1] = "HasUserFocus(pc)" end
    end
    return hits
end
function M.DumpFocusedSlot(why)
    H.Log("[pad] ---- focused-slot dump (" .. tostring(why) .. ") ----")
    local pc
    pcall(function() pc = require("UEHelpers").GetPlayerController() end)
    local panel = FindFirstOf("InventoryMainPanel")
    if not H.Valid(panel) then H.Log("[pad] no InventoryMainPanel") return end
    local content = H.P(panel, "InventoryContent")
    if not H.Valid(content) then H.Log("[pad] no InventoryContent") return end
    local okT, target = H.C(panel, "GetDesiredFocusTarget")
    if okT and H.Valid(target) then
        H.Log("[pad] panel GetDesiredFocusTarget: " .. H.FullName(target))
    end
    local any = false
    for _, field in ipairs(BODIES) do
        local body = H.P(content, field)
        if H.Valid(body) then
            local okD, hasDesc = H.C(body, "HasFocusedDescendants")
            if okD and hasDesc == true then
                H.Log("[pad] body " .. field .. ": HasFocusedDescendants=true")
            end
            local slots = H.ArrayItems(H.P(body, "InventorySlots"))
            for i = 1, slots.n do
                local slot = slots[i]
                if H.Valid(slot) then
                    local hits = SlotFlags(slot, pc)
                    if #hits > 0 then
                        any = true
                        local item = H.P(slot, "ContainedItem")
                        local name = H.Valid(item) and H.ItemName(item) or "<empty>"
                        H.Log(string.format("[pad] %s[%d] '%s' (%s): %s",
                            field, i, name, H.ClassName(slot), table.concat(hits, ", ")))
                    end
                end
            end
        end
    end
    if not any then
        H.Log("[pad] NO slot reports any hover/focus flag (c: need another source)")
    end
    H.Log("[pad] ---- dump end ----")
end
local glyphsDone = false
local glyphTries, lastGlyphTry = 0, 0
local function ProbeGlyphMaps()
    if glyphsDone then return end
    local now = os.clock()
    if now - lastGlyphTry < 5.0 then return end
    lastGlyphTry = now
    glyphTries = glyphTries + 1
    if glyphTries > 24 then
        glyphsDone = true
        H.Log("[pad] glyphs: gave up after 24 attempts (e: FAIL)")
        return
    end
    local resolved = 0
    for _, a in ipairs(GAMEPAD_DATA_ASSETS) do
        pcall(function() LoadAsset(a.asset) end)
        local obj
        pcall(function()
            local found = StaticFindObject(a.cdo)
            if found and found:IsValid() then obj = found end
        end)
        if H.Valid(obj) then
            resolved = resolved + 1
            local entries = H.ArrayItems(H.P(obj, "InputBrushDataMap"))
            local want = { ["Gamepad_FaceButton_Top"] = false, ["Gamepad_RightThumbstick"] = false }
            for i = 1, entries.n do
                local e = entries[i]
                if e then
                    local name
                    pcall(function() name = e.Key.KeyName:ToString() end)
                    if name ~= nil and want[name] == false then
                        local res = "?"
                        pcall(function() res = e.KeyBrush.ResourceObject:GetFName():ToString() end)
                        want[name] = res
                    end
                end
            end
            H.Log(string.format("[pad] glyphs %s: %d entries; Triangle=%s R3=%s",
                a.label, entries.n, tostring(want["Gamepad_FaceButton_Top"]),
                tostring(want["Gamepad_RightThumbstick"])))
        end
    end
    if resolved == #GAMEPAD_DATA_ASSETS then glyphsDone = true end
end
function M.Start()
    H.Log("[pad] ===== PAD PROBE ACTIVE v2 (config.Debug.PadProbe) =====")
    H.Log("[pad] tests: 1) swap KBM<->pad (expect switch lines once in-world);")
    H.Log("[pad] 2) inventory open: press+release R3 several times, then hold Triangle;")
    H.Log("[pad] 3) press A a few times BOTH in-world and in the inventory (canary);")
    H.Log("[pad] 4) F6 dumps slot focus flags. All output is log-only.")
    if Key and Key.F6 then
        pcall(function()
            RegisterKeyBind(Key.F6, {}, function()
                sched.OnGameThread(function() pcall(M.DumpFocusedSlot, "F6") end)
            end)
        end)
    end
    local started = false
    sched.Loop(POLL_MS, function()
        local pc
        pcall(function() pc = require("UEHelpers").GetPlayerController() end)
        if not H.Valid(pc) then return end
        if not started then
            started = true
            keyVariant = ResolveKeyVariant(pc)
        end
        pcall(ProbeInputSubsystem)
        pcall(ProbeGlyphMaps)
        pcall(PollKeys, pc)
    end)
end
return M
