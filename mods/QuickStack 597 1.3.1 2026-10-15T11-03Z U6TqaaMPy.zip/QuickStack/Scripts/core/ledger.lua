-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local stackmod = require("core.stack")
local blacklist = require("core.blacklist")
local M = {}
local FILLSTACKS_FN = "/Script/Dominion.InventoryComponent:FillStacks"
local cfgRef = {}
local function Unwrap(param)
    if param == nil then return nil end
    local v = param
    pcall(function() v = param:get() end)
    return v
end
local function LocalPlayerInvAndIc()
    local pc
    pcall(function() pc = require("UEHelpers").GetPlayerController() end)
    if not H.Valid(pc) then return nil end
    local okInv, inv = H.C(pc, "GetInventory")
    local okIc, ic = H.C(pc, "GetInventoryController")
    if okInv and H.Valid(inv) and okIc and H.Valid(ic) then return inv, ic end
    return nil
end
local function CandidateItems(playerInv, suppress)
    if suppress then
        local invApi
        local hud = FindFirstOf("HUDUISubsystem")
        if H.Valid(hud) then
            local okApi, api = H.C(hud, "GetInventoryAPI")
            if okApi and H.Valid(api) then invApi = api end
        end
        return stackmod.CollectSourceItems(invApi, playerInv,
            { IncludeRunes = false, IncludeAmmo = false })
    end
    local slots = H.ArrayItems(H.P(playerInv, "ItemSlots"))
    local items = {}
    for i = 1, slots.n do
        if H.Valid(slots[i]) then items[#items + 1] = slots[i] end
    end
    return items
end
local function MoveMatching(playerInv, ic, target, suppress, honour)
    local owner
    pcall(function() owner = target:GetOwner() end)
    local chest = {
        inv = target,
        owner = H.Valid(owner) and owner or target,
        dist = 0,
        types = nil,
        slotN = H.ArrayNum(H.P(target, "ItemSlots")),
    }
    local items = CandidateItems(playerInv, suppress)
    local moved, excludedKept = 0, 0
    local usedChests = {}
    local stats = { matches = 0, moveFails = 0, noSpace = 0 }
    for _, item in ipairs(items) do
        local eligible, data, reason = stackmod.ItemEligible(item)
        if not eligible and reason == "excluded" and not honour then
            eligible = true
        end
        if eligible then
            moved = moved + stackmod.StackItem(item, data, playerInv, ic, { chest }, usedChests, stats)
        elseif reason == "excluded" then
            excludedKept = excludedKept + 1
        end
    end
    return moved, excludedKept, stats
end
local function OnFillStacksPre(Context, TargetParam)
    local suppress = cfgRef.LedgerSuppress ~= false
    local honour = cfgRef.LedgerHonoursExclusions ~= false
    if not suppress then
        local okCount, count = pcall(blacklist.Count)
        if not honour or not okCount or type(count) ~= "number" or count == 0 then
            return
        end
    end
    local selfInv = Unwrap(Context)
    local target = Unwrap(TargetParam)
    if not H.Valid(selfInv) or not H.Valid(target) then return end
    local playerInv, ic = LocalPlayerInvAndIc()
    if not playerInv then return end
    local selfAddr, playerAddr = H.AddrOf(selfInv), H.AddrOf(playerInv)
    if not selfAddr or not playerAddr or selfAddr ~= playerAddr then return end
    local okSet = pcall(function() TargetParam:set(nil) end)
    local readBack = okSet and Unwrap(TargetParam) or target
    if not okSet or H.Valid(readBack) then
        H.Dbg("ledger: could not neutralize FillStacks - vanilla behavior kept")
        return
    end
    local ok, moved, kept, stats = pcall(MoveMatching, playerInv, ic, target, suppress, honour)
    if not ok then
        H.Log("ledger: replacement move failed after neutralize (" .. tostring(moved)
            .. ") - this ledger deposit did nothing; items are safe in your inventory")
        return
    end
    H.Log(string.format(
        "ledger deposit: %d stack(s) moved to %s, %d excluded item(s) held back%s%s",
        moved, H.ClassName(target), kept,
        suppress and " (bag only)" or "",
        stats.moveFails > 0 and string.format(" (%d move failure(s))", stats.moveFails) or ""))
end
function M.Start(cfg)
    cfgRef = type(cfg) == "table" and cfg or {}
    local ok = pcall(RegisterHook, FILLSTACKS_FN, OnFillStacksPre)
    if ok then
        H.Dbg("ledger: FillStacks hook registered (suppress="
            .. tostring(cfgRef.LedgerSuppress ~= false) .. ", exclusions="
            .. tostring(cfgRef.LedgerHonoursExclusions ~= false) .. ")")
    else
        H.Log("ledger: FillStacks hook FAILED - vanilla ledger behavior")
    end
end
return M
