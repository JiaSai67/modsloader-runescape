-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local M = {}
M.VISIBLE = 0
M.COLLAPSED = 1
M.HIDDEN = 2
M.HIT_TEST_INVISIBLE = 3
M.SELF_HIT_TEST_INVISIBLE = 4
local WIDGET_LIBRARY = "/Script/UMG.Default__WidgetBlueprintLibrary"
function M.SetVis(widget, vis)
    if not H.Valid(widget) then return end
    pcall(function() widget:SetVisibility(vis) end)
    pcall(function() widget.Visibility = vis end)
end
function M.SetText(widget, text)
    if not H.Valid(widget) then return end
    pcall(function() widget:SetText(FText(text)) end)
end
function M.CreateNative(classPath, outer)
    local widget
    pcall(function()
        local cls = StaticFindObject(classPath)
        if cls and cls:IsValid() then
            widget = StaticConstructObject(cls, outer)
        end
    end)
    if H.Valid(widget) then return widget end
    return nil
end
function M.CreateUserWidget(worldContext, classPath, assetPath)
    local library = StaticFindObject(WIDGET_LIBRARY)
    local class = StaticFindObject(classPath)
    if not H.Valid(class) and assetPath then
        pcall(function() LoadAsset(assetPath) end)
        class = StaticFindObject(classPath)
    end
    if not H.Valid(library) or not H.Valid(class) or not H.Valid(worldContext) then
        return nil
    end
    local owner
    pcall(function() owner = worldContext:GetOwningPlayer() end)
    local ok, widget = pcall(function()
        return library:Create(worldContext, class, owner)
    end)
    if ok and H.Valid(widget) then return widget end
    return nil
end
local function CaptureVSlot(child)
    local props = {}
    pcall(function()
        local slot = child.Slot
        local p = slot.Padding
        props.padding = { Left = p.Left, Top = p.Top, Right = p.Right, Bottom = p.Bottom }
        local s = slot.Size
        props.size = { Value = s.Value, SizeRule = s.SizeRule }
        props.halign = slot.HorizontalAlignment
        props.valign = slot.VerticalAlignment
    end)
    return props
end
local function RestoreVSlot(slot, props)
    if not slot or not props then return end
    if props.padding then pcall(function() slot:SetPadding(props.padding) end) end
    if props.size then pcall(function() slot:SetSize(props.size) end) end
    if props.halign ~= nil then pcall(function() slot:SetHorizontalAlignment(props.halign) end) end
    if props.valign ~= nil then pcall(function() slot:SetVerticalAlignment(props.valign) end) end
end
function M.InsertVerticalChildAfter(panel, anchor, widget, anchorIndexOffset)
    if not H.Valid(panel) or not H.Valid(widget) then return nil end
    local anchorIndex, childCount
    if H.Valid(anchor) then
        pcall(function()
            anchorIndex = panel:GetChildIndex(anchor)
            childCount = panel:GetChildrenCount()
        end)
    end
    if anchorIndex == nil or anchorIndex < 0 or childCount == nil then
        local slot
        pcall(function() slot = panel:AddChildToVerticalBox(widget) end)
        return slot
    end
    anchorIndex = anchorIndex + (tonumber(anchorIndexOffset) or 0)
    if anchorIndex < -1 then anchorIndex = -1 end
    local trailing = {}
    for index = childCount - 1, anchorIndex + 1, -1 do
        local child, props
        pcall(function()
            child = panel:GetChildAt(index)
        end)
        if H.Valid(child) then props = CaptureVSlot(child) end
        pcall(function() panel:RemoveChildAt(index) end)
        if H.Valid(child) then table.insert(trailing, 1, { w = child, props = props }) end
    end
    local slot
    pcall(function() slot = panel:AddChildToVerticalBox(widget) end)
    for _, entry in ipairs(trailing) do
        local newSlot
        pcall(function() newSlot = panel:AddChildToVerticalBox(entry.w) end)
        RestoreVSlot(newSlot, entry.props)
    end
    return slot
end
function M.BuildWidgetIndex(widget)
    local index = { byName = {}, byClass = {}, nodeCount = 0 }
    if not H.Valid(widget) then return index end
    local visited = {}
    local function visit(node)
        if not H.Valid(node) then return end
        local addr = H.AddrOf(node)
        if addr then
            if visited[addr] then return end
            visited[addr] = true
        end
        index.nodeCount = index.nodeCount + 1
        local nodeName
        pcall(function() nodeName = node:GetFName():ToString() end)
        if nodeName and index.byName[nodeName] == nil then
            index.byName[nodeName] = node
        end
        local className
        pcall(function() className = node:GetClass():GetFName():ToString() end)
        if className then
            local bucket = index.byClass[className]
            if not bucket then
                bucket = {}
                index.byClass[className] = bucket
            end
            bucket[#bucket + 1] = node
        end
        local childCount
        pcall(function() childCount = node:GetChildrenCount() end)
        if childCount then
            for i = 0, childCount - 1 do
                local child
                pcall(function() child = node:GetChildAt(i) end)
                visit(child)
            end
        end
        local nestedRoot
        pcall(function() nestedRoot = node.WidgetTree.RootWidget end)
        if H.Valid(nestedRoot) then visit(nestedRoot) end
    end
    local root
    pcall(function() root = widget.WidgetTree.RootWidget end)
    if H.Valid(root) then visit(root) else visit(widget) end
    return index
end
function M.IndexFind(index, name)
    if type(index) ~= "table" then return nil end
    local found = index.byName[name]
    if H.Valid(found) then return found end
    return nil
end
return M
