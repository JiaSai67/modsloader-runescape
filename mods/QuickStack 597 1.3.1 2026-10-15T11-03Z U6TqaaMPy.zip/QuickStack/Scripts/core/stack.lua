-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local blacklist = require("core.blacklist")
local M = {}
local SLOT_TYPE = { Items = 1, Runes = 2, Ammo = 3 }
local CLS_BASE_BUILDING = "/Script/Dominion.BaseBuildingActor"
local CLS_OWNERSHIP = "/Script/Dominion.OwnershipComponent"
local function GetMyGuid(pc)
    local ps = H.P(pc, "PlayerState")
    if H.Valid(ps) then
        local ok, guid = H.C(ps, "GetCharacterGuid")
        if ok and guid then return guid end
    end
    local ok, guid = H.C(pc, "GetCharacterGuid")
    if ok and guid then return guid end
    return nil
end
local function ScanChests(pawn, myGuid, rangeCm, excludeClasses)
    local chests = {}
    local ok, invs = pcall(function() return FindAllOf("BP_Components_WorldItemInventory_C") end)
    if not ok or not invs then return chests end
    local ownershipCls = H.FindClass(CLS_OWNERSHIP)
    for _, inv in ipairs(invs) do
        repeat
            if not H.Valid(inv) then break end
            local owner
            pcall(function() owner = inv:GetOwner() end)
            if not H.Valid(owner) then break end
            if not H.IsA(owner, CLS_BASE_BUILDING) then break end
            if H.P(owner, "bIsGhosted") == true or H.P(owner, "bIsPreview") == true then break end
            if excludeClasses and excludeClasses[H.ClassName(owner)] then
                H.Dbg("skip (ExcludeContainers): " .. H.ClassName(owner))
                break
            end
            if not ownershipCls then break end
            local okOwn, own = H.C(owner, "GetComponentByClass", ownershipCls)
            if not okOwn or not H.Valid(own) then break end
            local dist = H.DistanceCm(owner, pawn)
            if not dist or dist > rangeCm then break end
            if H.P(inv, "bAllowAdds") ~= true then break end
            if not myGuid then break end
            local okLock, locked = H.C(own, "IsPrivatelyLockedFromPlayer", myGuid)
            if not okLock or locked ~= false then
                H.Dbg("skip (private): " .. H.FullName(owner))
                break
            end
            local holder = H.P(inv, "CurrentActor")
            if H.Valid(holder) and holder ~= pawn then
                H.Dbg("skip (in use): " .. H.FullName(owner))
                break
            end
            local types = {}
            local typeCount, occupied = 0, 0
            local slots = H.ArrayItems(H.P(inv, "ItemSlots"))
            local slotNum = slots.n
            for i = 1, slotNum do
                local slotItem = slots[i]
                if H.Valid(slotItem) then
                    occupied = occupied + 1
                    local data = H.P(slotItem, "ItemData")
                    local addr = data and H.AddrOf(data)
                    if addr and not types[addr] then
                        types[addr] = true
                        typeCount = typeCount + 1
                    end
                end
            end
            if occupied > 0 and typeCount == 0 then types = nil end
            H.Dbg(string.format("chest %s (%.1fm): %d slot(s), %d occupied, %s",
                H.ClassName(owner), dist / 100, slotNum, occupied,
                types and (typeCount .. " types indexed") or "INDEX FAILED - native fallback"))
            chests[#chests + 1] = { inv = inv, owner = owner, dist = dist, types = types,
                slotN = slotNum }
        until true
    end
    table.sort(chests, function(a, b) return a.dist < b.dist end)
    return chests
end
local function EligibleTypeSet(cfg)
    local set = { [SLOT_TYPE.Items] = true }
    if cfg.IncludeRunes == true then set[SLOT_TYPE.Runes] = true end
    if cfg.IncludeAmmo == true then set[SLOT_TYPE.Ammo] = true end
    return set
end
local function CollectViaApi(invApi, eligible)
    local items = {}
    for slotType in pairs(eligible) do
        local ok, arr = H.C(invApi, "GetInventorySlots", slotType)
        if ok and arr then
            local entries = H.ArrayItems(arr)
            for i = 1, entries.n do
                if H.Valid(entries[i]) then items[#items + 1] = entries[i] end
            end
        end
    end
    return items
end
local function HotbarIsFirst(invApi, playerInv, hotCount, maxSlots)
    local mirror = H.ArrayItems(H.P(invApi, "QuickActionSlots"))
    for i = 1, mirror.n do
        local item = mirror[i]
        if H.Valid(item) then
            local ok, flat = H.C(playerInv, "GetSlotForItem", item)
            if ok and type(flat) == "number" and flat >= 0 then
                return flat < hotCount, true
            end
        end
    end
    local _ = maxSlots
    return true, false
end
local function CollectViaComponent(invApi, playerInv, eligible)
    local pages = H.P(playerInv, "InventoryPages")
    local pageNum = H.ArrayNum(pages)
    if pageNum == 0 then return {} end
    local hotCount = tonumber(H.P(playerInv, "NumberOfQuickActionSlots")) or 0
    local maxSlots = tonumber(H.P(playerInv, "MaxSlotCount")) or 0
    local first, verified = HotbarIsFirst(invApi, playerInv, hotCount, maxSlots)
    local base = first and hotCount or 0
    H.Dbg(string.format("component path: hotbar %s (%s), pages base %d",
        first and "first" or "last", verified and "verified" or "assumed", base))
    local slots = H.ArrayItems(H.P(playerInv, "ItemSlots"))
    local items = {}
    local start = base
    for i = 1, pageNum do
        local page = pages[i]
        local slotType = tonumber(H.P(page, "SlotType"))
        local num = tonumber(H.P(page, "NumSlots")) or 0
        if eligible[slotType] then
            for flat = start, math.min(start + num, slots.n) - 1 do
                local item = slots[flat + 1]
                if H.Valid(item) then items[#items + 1] = item end
            end
        end
        start = start + num
    end
    return items
end
local function CollectTailItems(playerInv, have)
    local pages = H.P(playerInv, "InventoryPages")
    local pageNum = H.ArrayNum(pages)
    if pageNum == 0 then return {} end
    local pageSum = 0
    for i = 1, pageNum do
        pageSum = pageSum + (tonumber(H.P(pages[i], "NumSlots")) or 0)
    end
    if pageSum == 0 then return {} end
    local hotCount = tonumber(H.P(playerInv, "NumberOfQuickActionSlots")) or 0
    local covered = hotCount + pageSum
    local slots = H.ArrayItems(H.P(playerInv, "ItemSlots"))
    local items = {}
    for flat = covered, slots.n - 1 do
        local item = slots[flat + 1]
        if H.Valid(item) then
            local addr = H.AddrOf(item)
            if not (addr and have[addr]) then items[#items + 1] = item end
        end
    end
    return items
end
local function CollectSourceItems(invApi, playerInv, cfg)
    local eligible = EligibleTypeSet(cfg)
    local items = CollectViaApi(invApi, eligible)
    if #items > 0 then
        H.Dbg("sources via InventoryUIAPI: " .. #items)
    else
        items = CollectViaComponent(invApi, playerInv, eligible)
        H.Dbg("sources via component ItemSlots: " .. #items)
    end
    local have = {}
    for _, it in ipairs(items) do
        local addr = H.AddrOf(it)
        if addr then have[addr] = true end
    end
    local tail = CollectTailItems(playerInv, have)
    if #tail > 0 then
        H.Dbg(#tail .. " item(s) in tail slots beyond page coverage - included as bag items")
        for _, it in ipairs(tail) do items[#items + 1] = it end
    end
    return items
end
local function ItemEligible(item)
    local data = H.P(item, "ItemData")
    if not H.Valid(data) then return false, nil, "no ItemData" end
    if H.P(data, "bBoundToPlayer") == true then return false, data, "bound" end
    local okQ, quest = H.C(data, "IsQuestItem")
    if okQ and quest == true then return false, data, "quest item" end
    local guidStr = H.GuidStr(H.P(item, "Guid"))
    if guidStr and blacklist.Contains(guidStr) then return false, data, "excluded" end
    return true, data, nil
end
local function ItemGone(playerInv, item)
    if not H.Valid(item) then return true end
    local ok, flat = H.C(playerInv, "GetSlotForItem", item)
    return not ok or type(flat) ~= "number" or flat < 0
end
local MAX_MOVES_PER_CHEST = 8
local function ChestHoldsType(chest, data, dataAddr)
    if chest.types and dataAddr then
        return chest.types[dataAddr] == true
    end
    local ok, count = H.C(chest.inv, "GetNumItemsByData", data)
    return ok and type(count) == "number" and count > 0
end
local function StackItem(item, data, playerInv, ic, chests, usedChests, stats)
    local movedAny = false
    local dataAddr = H.AddrOf(data)
    for _, chest in ipairs(chests) do
        if ChestHoldsType(chest, data, dataAddr) then
            stats.matches = stats.matches + 1
            local okSpace, space = H.C(chest.inv, "GetSpaceAvailableForItemByData", data)
            if okSpace and space == 0 then
                stats.noSpace = stats.noSpace + 1
                H.Dbg(string.format("'%s': %s holds the type but has no space",
                    H.ItemName(item), H.ClassName(chest.owner)))
            else
                local cap = math.max(MAX_MOVES_PER_CHEST, chest.slotN or 0)
                for _ = 1, cap do
                    local okIdx, flat = H.C(playerInv, "GetSlotForItem", item)
                    if not okIdx or type(flat) ~= "number" or flat < 0 then
                        H.Dbg(string.format("'%s': GetSlotForItem gave %s/%s - cannot move",
                            H.ItemName(item), tostring(okIdx), tostring(flat)))
                        break
                    end
                    local before = H.P(item, "Count")
                    local okMove, moved = H.C(ic, "MoveItemBetweenInventoriesAnySlot",
                        playerInv, flat, chest.inv)
                    if not okMove or moved ~= true then
                        stats.moveFails = stats.moveFails + 1
                        H.Dbg(string.format("'%s' (flat %d) -> %s: move failed (ok=%s ret=%s)",
                            H.ItemName(item), flat, H.ClassName(chest.owner),
                            tostring(okMove), tostring(moved)))
                        break
                    end
                    movedAny = true
                    usedChests[chest] = true
                    H.Dbg(string.format("moved '%s' -> %s (%.1fm)",
                        H.ItemName(item), H.ClassName(chest.owner), chest.dist / 100))
                    if ItemGone(playerInv, item) then return 1 end
                    local after = H.P(item, "Count")
                    if type(before) ~= "number" or type(after) ~= "number"
                        or after >= before then break end
                end
                if ItemGone(playerInv, item) then return movedAny and 1 or 0 end
            end
        end
    end
    return movedAny and 1 or 0
end
M.ItemEligible = ItemEligible
M.StackItem = StackItem
M.CollectSourceItems = CollectSourceItems
function M.Run(cfg)
    local UEHelpers = require("UEHelpers")
    local pc
    pcall(function() pc = UEHelpers.GetPlayerController() end)
    if not H.Valid(pc) then H.Log("no player controller") return end
    local pawn = H.P(pc, "Pawn")
    if not H.Valid(pawn) then H.Log("no pawn") return end
    local okInv, playerInv = H.C(pc, "GetInventory")
    local okIc, ic = H.C(pc, "GetInventoryController")
    if not okInv or not H.Valid(playerInv) or not okIc or not H.Valid(ic) then
        H.Log("player inventory/controller unavailable")
        return
    end
    local hud = FindFirstOf("HUDUISubsystem")
    local invApi
    if H.Valid(hud) then
        local okApi, api = H.C(hud, "GetInventoryAPI")
        if okApi and H.Valid(api) then invApi = api end
    end
    if not invApi then H.Log("InventoryUIAPI unavailable") return end
    local myGuid = GetMyGuid(pc)
    if not myGuid then
        H.Log("could not read character guid - refusing to stack (privacy gate unavailable)")
        return
    end
    local excludeClasses
    if type(cfg.ExcludeContainers) == "table" then
        for _, name in ipairs(cfg.ExcludeContainers) do
            excludeClasses = excludeClasses or {}
            excludeClasses[tostring(name)] = true
        end
    end
    local rangeM = tonumber(cfg.RangeMeters) or 15
    local chests = ScanChests(pawn, myGuid, rangeM * 100, excludeClasses)
    if #chests == 0 then
        H.Log(string.format("no eligible chests within %d m", rangeM))
        return
    end
    local items = CollectSourceItems(invApi, playerInv, cfg)
    H.Dbg(string.format("%d source item(s) across eligible tabs, %d chest(s) in range",
        #items, #chests))
    local movedStacks, skippedExcluded = 0, 0
    local usedChests = {}
    local stats = { matches = 0, moveFails = 0, noSpace = 0 }
    for _, item in ipairs(items) do
        local eligible, data, reason = ItemEligible(item)
        if eligible then
            movedStacks = movedStacks + StackItem(item, data, playerInv, ic, chests, usedChests, stats)
        elseif reason == "excluded" then
            skippedExcluded = skippedExcluded + 1
        end
    end
    local chestCount = 0
    for _ in pairs(usedChests) do chestCount = chestCount + 1 end
    local excludedNote = skippedExcluded > 0
        and string.format(" (%d excluded by middle-click)", skippedExcluded) or ""
    if movedStacks > 0 then
        H.Log(string.format("stacked %d stack(s) into %d chest(s)%s",
            movedStacks, chestCount, excludedNote))
    elseif stats.matches > 0 and stats.moveFails == 0 and stats.noSpace >= stats.matches then
        H.Log(string.format(
            "matched %d stack(s) but every matching chest is full%s",
            stats.matches, excludedNote))
    elseif stats.matches > 0 then
        H.Log(string.format(
            "matched %d stack(s) but no move succeeded (%d move failure(s), %d full chest(s)) - enable Debug.VerboseLogging for details%s",
            stats.matches, stats.moveFails, stats.noSpace, excludedNote))
    else
        H.Log(string.format("nothing to stack - %d chest(s) in range hold no matching item types%s",
            #chests, excludedNote))
    end
end
return M
