-- QuickStack Version 1.3.1
-- by SilentlyBren - https://www.nexusmods.com/runescapedragonwilds/mods/597
local H = require("core.helpers")
local sched = require("core.sched")
local okCfg, config = pcall(require, "config")
if not okCfg or type(config) ~= "table" then config = {} end
local dbgCfg = type(config.Debug) == "table" and config.Debug or {}
H.SetVerbose(dbgCfg.VerboseLogging == true)
local VERSION = "1.3.1"
H.Log("v" .. VERSION .. " loaded - by SilentlyBren")
local blacklist = require("core.blacklist")
local stack = require("core.stack")
local toggle = require("core.toggle")
local probe = require("core.probe")
local badges = require("core.badges")
local hint = require("core.hint")
local gamepad = require("core.gamepad")
local EWidgetType_Inventory = 11
local EWidgetType_WorldInventory = 26
blacklist.Load()
local VIS_HIDDEN, VIS_COLLAPSED = 2, 1
local function InventoryIsOpen()
    local panel = FindFirstOf("InventoryMainPanel")
    if not H.Valid(panel) then return false end
    local vis = H.P(panel, "Visibility")
    return vis ~= nil and vis ~= VIS_COLLAPSED and vis ~= VIS_HIDDEN
end
local hotkeyName = tostring(config.HotKey or "Y")
local hotkey = Key and Key[hotkeyName]
if not hotkey then
    H.Log("config HotKey '" .. hotkeyName .. "' not in Key enum - falling back to Y")
    hotkeyName, hotkey = "Y", Key and Key.Y
end
local lastStack = 0
local function OnHotkey()
    local now = os.clock()
    if now - lastStack < 0.25 then return end
    lastStack = now
    if dbgCfg.Probe == true then
        local ok, err = pcall(probe.Run, config)
        if not ok then H.Log("probe error: " .. tostring(err)) end
        return
    end
    if config.EnableQuickStack == false then return end
    if not InventoryIsOpen() then return end
    local ok, err = pcall(stack.Run, config)
    if not ok then H.Log("stack error: " .. tostring(err)) end
    pcall(badges.ApplyAll)
end
if hotkey then
    local ok = pcall(function()
        RegisterKeyBind(hotkey, {}, function()
            sched.OnGameThread(OnHotkey)
        end)
    end)
    if not ok then H.Log("RegisterKeyBind(" .. hotkeyName .. ") FAILED - mod inactive") end
end
local lastToggle = 0
local function OnMiddleClick()
    local now = os.clock()
    if now - lastToggle < 0.15 then return end
    lastToggle = now
    if not InventoryIsOpen() then return end
    local ok, err = pcall(toggle.HandleMiddleClick)
    if not ok then H.Log("toggle error: " .. tostring(err)) end
    pcall(badges.ApplyAll)
end
local blacklistKeyName = tostring(config.BlacklistKey or "MIDDLE_MOUSE_BUTTON")
local blacklistKey = Key and Key[blacklistKeyName]
if not blacklistKey then
    H.Log("config BlacklistKey '" .. blacklistKeyName .. "' not in Key enum - falling back to middle mouse")
    blacklistKeyName, blacklistKey = "MIDDLE_MOUSE_BUTTON", Key and Key.MIDDLE_MOUSE_BUTTON
end
if blacklistKey then
    pcall(function()
        RegisterKeyBind(blacklistKey, {}, function()
            sched.OnGameThread(OnMiddleClick)
        end)
    end)
else
    H.Log("no usable BlacklistKey - exclusions cannot be toggled")
end
pcall(gamepad.Start, { OnStack = OnHotkey, OnToggle = OnMiddleClick })
local uiActive = false
local hintShown = false
local eventsSeen = false
local function Recompute(withFade)
    local shown = false
    local ok, v = pcall(InventoryIsOpen)
    shown = ok and v == true
    if shown and not uiActive then
        pcall(badges.ApplyAll)
    elseif not shown and uiActive then
        pcall(badges.OnInventoryClosed)
        pcall(blacklist.Flush)
    end
    if shown and not hintShown then
        sched.Delay(300, function()
            if not hintShown then return end
            pcall(hint.Ensure, config, hotkeyName, blacklistKeyName)
            if withFade then pcall(hint.FadeIn) else pcall(hint.SetShown, true) end
        end)
    elseif not shown and hintShown then
        if withFade then pcall(hint.FadeOut) else pcall(hint.SetShown, false) end
    end
    uiActive, hintShown = shown, shown
    pcall(gamepad.SetActive, shown)
end
local recheckPending = false
local function OnWidgetRequest()
    return function(Context, PlayerController, Type)
        eventsSeen = true
        pcall(Recompute, true)
        if not recheckPending then
            recheckPending = true
            sched.Delay(150, function()
                recheckPending = false
                Recompute(true)
            end)
        end
    end
end
local hooked = {}
for _, cls in ipairs({
    "/Script/Dominion.ItemHandlingLocalPlayerSubsystem",
    "/Script/Dominion.PlayerVitalsWidget",
}) do
    local okO = pcall(RegisterHook, cls .. ":HandleOnWidgetRequestedOpen", OnWidgetRequest())
    local okC = pcall(RegisterHook, cls .. ":HandleOnWidgetRequestedClose", OnWidgetRequest())
    hooked[#hooked + 1] = string.format("%s open=%s close=%s",
        cls:match("([^.]+)$"), tostring(okO), tostring(okC))
end
H.Dbg("widget-request hooks: " .. table.concat(hooked, "; "))
sched.Loop(500, function()
    if uiActive then
        Recompute(false)
        if uiActive then
            pcall(badges.ApplyAll)
            if hintShown then pcall(hint.Ensure, config, hotkeyName, blacklistKeyName) end
        end
    elseif not eventsSeen then
        Recompute(true)
    end
end)
if config.LedgerHonoursExclusions ~= false or config.LedgerSuppress ~= false then
    local okLg, lgOrErr = pcall(require, "core.ledger")
    if okLg then
        pcall(lgOrErr.Start, config)
    else
        H.Log("ledger module failed to load: " .. tostring(lgOrErr))
    end
end
if dbgCfg.LedgerProbe == true then
    local okLp, lpOrErr = pcall(require, "core.probe_ledger")
    if okLp then
        pcall(lpOrErr.Start)
    else
        H.Log("ledger probe failed to load: " .. tostring(lpOrErr))
    end
end
if dbgCfg.PadProbe == true then
    local okPad, padOrErr = pcall(require, "core.probe_pad")
    if okPad then
        pcall(padOrErr.Start)
    else
        H.Log("pad probe failed to load: " .. tostring(padOrErr))
    end
end
if dbgCfg.TestItems == true and Key and Key.F5 then
    local dbg = require("core.debug")
    local lastSpawn = 0
    pcall(function()
        RegisterKeyBind(Key.F5, {}, function()
            sched.OnGameThread(function()
                local now = os.clock()
                if now - lastSpawn < 0.25 then return end
                lastSpawn = now
                local ok, err = pcall(dbg.SpawnTestItems)
                if not ok then H.Log("debug spawn error: " .. tostring(err)) end
            end)
        end)
    end)
    H.Log("[debug] F5 = give test items (Ash Logs)")
end
H.Dbg("scheduler: " .. sched.Describe())
if config.EnableQuickStack == false then
    H.Log(string.format("quick stack OFF (EnableQuickStack=false); %s on item to exclude",
        blacklistKeyName))
else
    H.Log(string.format("%s = stack to chests within %sm; %s on item to exclude",
        hotkeyName, tostring(config.RangeMeters or 15), blacklistKeyName))
end
if dbgCfg.Probe == true then
    H.Log("PROBE MODE: hotkey runs diagnostics, no items move")
end
