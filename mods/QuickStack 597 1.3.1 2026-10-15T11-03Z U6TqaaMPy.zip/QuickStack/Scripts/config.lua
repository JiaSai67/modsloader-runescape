-- QuickStack configuration.

return {
  -- -------------------------------------------------------------------------
  -- Main settings
  -- -------------------------------------------------------------------------

  -- Master switch for quick-stacking from the inventory screen. If you'd
  -- rather use the in-game Storage Ledger building for stacking, set this
  -- to false: the hotkey and its hint go away, and only the exclusion
  -- mechanism keeps running (middle-click to exclude, slot badges, and the
  -- exclusion hint).
  EnableQuickStack = true,

  -- Make the in-game Storage Ledger honour your exclusions: excluded items
  -- stay in your inventory when the ledger deposits to linked chests
  -- (vanilla moves everything, hotbar included). Only active while you have
  -- exclusions set; works in single player / as host. Guests on someone
  -- else's server get vanilla ledger behavior.
  LedgerHonoursExclusions = true,

  -- Forces the ledger to NOT take deposit candidates from your hotbar or
  -- the rune/arrow tabs - only the bag deposits. Turn it off to keep the
  -- vanilla ledger scope (everything, hotbar included) for deposit
  -- candidates.
  LedgerSuppress = true,

  -- Chest search radius in metres.
  RangeMeters = 15,

  -- Quick-stack hotkey (UE4SS Key enum name). Active only while the
  -- inventory screen is open.
  HotKey = "Y",

  -- Key that excludes/re-includes the hovered item from quick-stacking
  -- (UE4SS Key enum name). Active only while the inventory screen is open.
  BlacklistKey = "MIDDLE_MOUSE_BUTTON",

  -- -------------------------------------------------------------------------
  -- Extra
  -- -------------------------------------------------------------------------

  -- Also stack from the rune / arrow tabs. Off by default: runes and ammo
  -- weigh nothing, and the game is designed around keeping them on you
  -- permanently. (Hotbar, armour and the quest tab are always skipped -
  -- not configurable.)
  IncludeRunes = false,
  IncludeAmmo = false,

  -- The two hints for hotkeys for quick stack and excluding items in your armour panel.
  ShowHint = true,

  -- Container classes quick stack must NEVER put items into, by Blueprint
  -- class name (shown in verbose/probe logs). Empty = all eligible storage.
  -- Mainly for storage-resizing mods (e.g. AdditionalStorageSlots) that turn
  -- display furniture into real storage, e.g.:
  --   "BP_BaseBuilding_WeaponRack_C", "BP_BaseBuilding_ArmourMannequin_C",
  --   "BP_BaseBuilding_CapeHook_C", "BP_BaseBuilding_CapeRack_C",
  ExcludeContainers = {},

  -- -------------------------------------------------------------------------
  -- Debug / development. Leave everything false for normal play.
  -- -------------------------------------------------------------------------
  Debug = {
    -- Per-move log lines and other chatty output.
    VerboseLogging = false,

    -- The hotkey runs a log-only diagnostics dump instead of stacking
    -- (no items move).
    Probe = false,

    -- F5 gives a max stack of test items (Ash Logs + Air Runes) for
    -- exercising the stacker.
    TestItems = false,

    -- v1.1.0 controller groundwork: log-only probe of pad input APIs,
    -- input-method switch events, glyph data and slot focus (F6 = dump).
    PadProbe = false,

    -- v1.3 Storage Ledger groundwork: log-only hooks on the vanilla
    -- fill-stacks / linked-inventory functions.
    LedgerProbe = false,
  },
}
