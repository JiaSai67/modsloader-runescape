-- ChestLink Multiplayer PC 0.2.0: experimental client range extension.
-- ponytail: unloaded chest access is not established by changing this radius.
local radius = 100000000 -- 1000 km in Unreal centimetres.
local originalRadius
local lastState
local lastError

local function update(force)
    local player = FindFirstOf("DominionPlayerController")
    if not player:IsValid() then return end
    local settings = StaticFindObject("/Script/Dominion.Default__InventorySettings")
    local system = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local crafting = StaticFindObject("/Script/Dominion.Default__CraftingFunctionLibrary")
    if not settings:IsValid() or not system:IsValid() or not crafting:IsValid() then
        error("Required game objects are unavailable")
    end
    if originalRadius == nil then originalRadius = settings.LinkedStorageRadius end
    local solo = true -- Enabled for this client variant, including multiplayer.
    local target = solo and radius or originalRadius
    local changed = settings.LinkedStorageRadius ~= target
    if changed then settings.LinkedStorageRadius = target end
    if settings.LinkedStorageRadius ~= target then error("Radius verification failed") end
    if changed or force then crafting:ResetLinkedInventoryCache(player) end
    if lastState ~= solo or force then
        print(string.format("[ChestLink Multiplayer PC] rangeEnabled=%s originalRadius=%s activeRadius=%s cm cacheReset=%s\n",
            tostring(solo), tostring(originalRadius), tostring(settings.LinkedStorageRadius), tostring(changed or force)))
        lastState = solo
    end
end

local pending = false
local function schedule(force)
    if pending then return end
    pending = true
    ExecuteInGameThread(function()
        local ok, message = pcall(update, force)
        if not ok and tostring(message) ~= lastError then
            lastError = tostring(message)
            print("[ChestLink Multiplayer PC] ERROR: " .. lastError .. "\n")
        elseif ok then
            lastError = nil
        end
        pending = false
    end)
end

LoopAsync(1000, function() schedule(false) end)
RegisterKeyBind(Key.F7, function() schedule(true) end)
print("[ChestLink Multiplayer PC] Loaded v0.2.0 experimental. Automatic client range; F7 refreshes cache.\n")

