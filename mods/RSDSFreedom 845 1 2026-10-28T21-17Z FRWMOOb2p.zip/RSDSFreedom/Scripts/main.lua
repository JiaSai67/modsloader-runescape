local TAG = "[RSDS Freedom] "
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

local cfg = { KeepInventory = false, NoWeight = false, NoDurability = false }
local ORDER = { "NoWeight", "KeepInventory", "NoDurability" }

local TEXT = {
    en = { NoWeight = "No Item Weight", KeepInventory = "Keep Items on Death", NoDurability = "Unbreakable Items" },
    pt = { NoWeight = "Itens Sem Peso", KeepInventory = "Manter Itens ao Morrer", NoDurability = "Itens Inquebráveis" },
    es = { NoWeight = "Objetos sin peso", KeepInventory = "Conservar objetos al morir", NoDurability = "Objetos irrompibles" },
    fr = { NoWeight = "Objets sans poids", KeepInventory = "Garder les objets à la mort", NoDurability = "Objets incassables" },
    de = { NoWeight = "Gegenstände ohne Gewicht", KeepInventory = "Gegenstände beim Tod behalten", NoDurability = "Unzerbrechliche Gegenstände" },
    it = { NoWeight = "Oggetti senza peso", KeepInventory = "Mantieni gli oggetti alla morte", NoDurability = "Oggetti indistruttibili" },
    ja = { NoWeight = "アイテムの重量なし", KeepInventory = "死亡時にアイテムを保持", NoDurability = "アイテムが壊れない" },
    ko = { NoWeight = "아이템 무게 없음", KeepInventory = "사망 시 아이템 유지", NoDurability = "부서지지 않는 아이템" },
    zhs = { NoWeight = "物品无重量", KeepInventory = "死亡时保留物品", NoDurability = "物品不会损坏" },
    zht = { NoWeight = "物品無重量", KeepInventory = "死亡時保留物品", NoDurability = "物品不會損壞" },
}

local function valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end
local function get(fn) local ok, v = pcall(fn); if ok then return v end return nil end
local function asObj(x)
    if x == nil then return nil end
    if valid(x) then return x end
    local o = get(function() return x:get() end)
    if valid(o) then return o end
    return nil
end
local function str(v)
    if v == nil then return nil end
    if type(v) == "string" then return v end
    return get(function() return v:ToString() end)
end
local function full(o) return valid(o) and str(get(function() return o:GetFullName() end)) or "" end
local function className(o) return str(get(function() return o:GetClass():GetFName() end)) or "" end
local function addr(o) return get(function() return o:GetAddress() end) end
local function now() return os.clock() end

local problems = {}
local function problem(key, msg)
    if problems[key] then return end
    problems[key] = msg
    log(msg)
end

local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    return src:match("^(.*)[/\\]Scripts[/\\][^/\\]*$")
end
local ROOT = modRoot()

local function loadConfig()
    local f = ROOT and io.open(ROOT .. "\\config.txt", "r")
    if not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if k and type(cfg[k]) == "boolean" then
            v = v:gsub("%s*[#;].*$", ""):lower()
            cfg[k] = (v == "true" or v == "1" or v == "on")
        end
    end
    f:close()
end

local function saveConfig()
    local f = ROOT and io.open(ROOT .. "\\config.txt", "w")
    if not f then problem("save", "couldn't write config.txt"); return end
    f:write("# RSDS Freedom. Change these in game: Settings > Gameplay (or here, then restart the game).\n")
    f:write("KeepInventory = " .. tostring(cfg.KeepInventory) .. "   # keep your items when you die\n")
    f:write("NoWeight = " .. tostring(cfg.NoWeight) .. "        # items weigh nothing\n")
    f:write("NoDurability = " .. tostring(cfg.NoDurability) .. "    # items never lose durability\n")
    f:close()
end
loadConfig()

local KIL = nil
local function language()
    if not valid(KIL) then KIL = get(function() return StaticFindObject("/Script/Engine.Default__KismetInternationalizationLibrary") end) end
    local l = valid(KIL) and (str(get(function() return KIL:GetCurrentLanguage() end))
        or str(get(function() return KIL:GetCurrentCulture() end))) or nil
    l = (l or "en"):lower()
    if l:find("^zh") then
        if l:find("hant") or l:find("tw") or l:find("hk") or l:find("mo") then return "zht" end
        return "zhs"
    end
    local p = l:match("^(%a%a)") or "en"
    return TEXT[p] and p or "en"
end
local function label(key, lang) return (TEXT[lang] or TEXT.en)[key] or TEXT.en[key] end

local PLAYER = { pc = nil, pawn = nil }
local function localPlayer()

    if valid(PLAYER.pc) then
        local pawn = get(function() return PLAYER.pc.Pawn end)
        PLAYER.pawn = valid(pawn) and pawn or nil
        return PLAYER.pc, PLAYER.pawn
    end
    PLAYER.pc, PLAYER.pawn = nil, nil
    for _, cls in ipairs({ "BP_PlayerController_C", "PlayerController" }) do
        for _, pc in ipairs(get(function() return FindAllOf(cls) end) or {}) do
            if valid(pc) and get(function() return pc:IsLocalController() end) == true then
                local pawn = get(function() return pc.Pawn end)
                PLAYER.pc, PLAYER.pawn = pc, valid(pawn) and pawn or nil
                return PLAYER.pc, PLAYER.pawn
            end
        end
    end
    return nil, nil
end

local function firstValid(obj, props, funcs)
    for _, p in ipairs(props or {}) do
        local c = get(function() return obj[p] end)
        if valid(c) then return c end
    end
    for _, f in ipairs(funcs or {}) do
        local c = get(function() return obj[f](obj) end)
        if valid(c) then return c end
    end
    return nil
end

local function playerItems(pc, pawn)
    local list = {}
    for _, owner in ipairs({ pc, pawn }) do
        if valid(owner) then
            local inv = firstValid(owner, { "InventoryComponent", "BP_Components_Inventory" }, { "GetInventory" })
            local slots = inv and get(function() return inv.ItemSlots end)
            local n = slots and get(function() return slots:GetArrayNum() end) or 0
            for i = 1, math.min(n, 512) do
                local it = asObj(get(function() return slots[i] end))
                if it then list[#list + 1] = it end
            end
            local lo = firstValid(owner, { "LoadoutComponent", "BP_Components_Loadout" }, { "GetLoadout" })
            if lo then
                local m = math.min(tonumber(get(function() return lo.MaxSlotCount end)) or 16, 32)
                for i = 0, m - 1 do
                    local it = asObj(get(function() return lo:GetItemFromSlot(i) end))
                    if it then list[#list + 1] = it end
                end
            end
            if #list > 0 then return list end
        end
    end
    return list
end

local KEEP = { applied = nil, origCDO = nil, pcAddr = nil }
local function console(pc, cmd)
    local ksl = get(function() return StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
    if not valid(ksl) or not valid(pc) then return false end
    return pcall(function() ksl:ExecuteConsoleCommand(pc, cmd, pc) end)
end
local function applyKeep(pc, force)
    local want = cfg.KeepInventory
    local a = addr(pc)
    if not force and KEEP.applied == want and KEEP.pcAddr == a then return end
    if KEEP.applied == nil and not want then KEEP.applied, KEEP.pcAddr = false, a; return end
    local cdo = get(function() return StaticFindObject("/Script/Dominion.Default__GravestoneSubsystemSettings") end)
    if valid(cdo) then
        if KEEP.origCDO == nil then KEEP.origCDO = get(function() return cdo.bUseGravestones end) end
        local v = want and false or (KEEP.origCDO ~= false)
        pcall(function() cdo.bUseGravestones = v end)
    else
        problem("keepcdo", "GravestoneSubsystemSettings not found (the console variable is still used)")
    end
    local orig = (KEEP.origCDO == false) and "0" or "1"
    if console(pc, "dom.UseGravestones " .. (want and "0" or orig)) then
        KEEP.applied, KEEP.pcAddr = want, a
        log("keep items on death: " .. (want and "on" or "off"))
    end
end

local W = { zeroed = false, real = nil, lastFix = 0 }
local WATTR = { pawnAddr = nil, ac = nil, idx = nil }
local function weightAttr(pawn)

    local pa = addr(pawn)
    if pa and pa == WATTR.pawnAddr and valid(WATTR.ac) and WATTR.idx then
        return WATTR.ac, WATTR.idx
    end
    local ac = firstValid(pawn, { "AttributesComponent" }, { "GetPlayerAttributesComponent" })
    if not ac then return nil end
    local attrs = get(function() return ac.FloatAttributes end)
    local n = attrs and get(function() return attrs:GetArrayNum() end) or 0
    for i = 1, n do
        local a = asObj(get(function() return attrs[i] end))
        local cn = a and className(a) or ""
        if cn:find("CurrentCarryWeight", 1, true) then
            WATTR.pawnAddr, WATTR.ac, WATTR.idx = pa, ac, i
            return ac, i
        end
    end
    return nil
end
local function setWeight(enc, pawn, value)
    local changed = false
    local cur = tonumber(get(function() return enc.CurrentCarryWeight end))
    if cur and math.abs(cur - value) > 0.001 then
        changed = pcall(function() enc.CurrentCarryWeight = value end) or changed
    end
    local ac, idx = weightAttr(pawn)
    if ac then
        local vals = get(function() return ac.AttributeValues end)
        local v = vals and tonumber(get(function() return vals[idx] end))
        if v and math.abs(v - value) > 0.001 then changed = pcall(function() vals[idx] = value end) or changed end
    end
    if changed then
        local mx = tonumber(get(function() return enc:GetMaxCarryWeight() end)) or 0
        if not pcall(function() enc:UpdateEncumberedStatus(value, mx) end) then pcall(function() enc:UpdateEncumberedStatus() end) end
        pcall(function() enc:OnRep_CurrentCarryWeight() end)
    end
    return changed
end
local function realWeight(pc, pawn)
    local sum, any = 0, false
    for _, it in ipairs(playerItems(pc, pawn)) do
        local w = tonumber(get(function() return it:GetRelativeStackWeight() end)) or tonumber(get(function() return it:GetRawStackWeight() end))
        if w then sum, any = sum + w, true end
    end
    return any and sum or nil
end
local function applyWeight(pc, pawn)
    if not valid(pawn) then return end
    local enc = firstValid(pawn, { "PlayerEncumbranceComponent", "EncumberedComponent" }, { "GetPlayerEncumbranceComponent" })
    if not enc then problem("enc", "encumbrance component not found on the player"); return end
    if cfg.NoWeight then
        local cur = tonumber(get(function() return enc.CurrentCarryWeight end)) or tonumber(get(function() return enc:GetCurrentCarryWeight() end))
        if cur and cur > 0.001 then W.real = cur end
        if setWeight(enc, pawn, 0) then W.zeroed = true end

        if get(function() return enc:IsEncumbered() end) == true and now() - W.lastFix > 2 then
            W.lastFix = now()
            pcall(function() enc:UpdateEncumberedStatus(0, tonumber(enc:GetMaxCarryWeight()) or 0) end)
        end
    elseif W.zeroed then
        local real = realWeight(pc, pawn) or W.real or 0
        setWeight(enc, pawn, real)
        W.zeroed = false
        log(string.format("item weight back on: %.1f", real))
    end
end

local D = { fixed = 0 }
local function applyDurability(pc, pawn)
    if not cfg.NoDurability then return end
    for _, it in ipairs(playerItems(pc, pawn)) do
        local cur = tonumber(get(function() return it:GetDurability() end))
        local mx = tonumber(get(function() return it:GetMaxDurability() end))
        if cur and mx and mx > 0 and cur > 0 and cur < mx and get(function() return it:IsUnbreakable() end) ~= true then
            pcall(function() it:ModifyDurability(mx - cur) end)
            local after = tonumber(get(function() return it:GetDurability() end))
            if not after or after < mx then
                if pcall(function() it.Durability = mx end) then pcall(function() it:OnRep_Durability() end) end
                after = tonumber(get(function() return it:GetDurability() end))
            end
            if after and after >= mx then D.fixed = D.fixed + 1 else problem("dur", "couldn't restore an item's durability") end
        end
    end
end

local function applyAll(force)
    local pc, pawn = localPlayer()
    if not pc then return end
    applyKeep(pc, force)
    applyWeight(pc, pawn)
    applyDurability(pc, pawn)
end

local CHECK_PATH = "/Game/UI/Settings/WBP_Settings_Checkbox"
local function loadClass(pkg)
    local asset = pkg:match("([^/]+)$")
    pcall(function() LoadAsset(pkg) end)
    local c = get(function() return StaticFindObject(pkg .. "." .. asset .. "_C") end)
    return valid(c) and c or nil
end

local function walk(w, visit, depth)
    if not valid(w) or depth > 16 then return end
    if visit(w) then return end
    local n = tonumber(get(function() return w:GetChildrenCount() end)) or 0
    for i = 0, n - 1 do
        walk(get(function() return w:GetChildAt(i) end), visit, depth + 1)
    end
    local tree = get(function() return w.WidgetTree end)
    local root = tree and get(function() return tree.RootWidget end)
    if valid(root) then walk(root, visit, depth + 1) end
end

local function isCheckRow(w) return className(w):find("WBP_Settings_Checkbox", 1, true) == 1 end

local function findList(gw)
    local tree = get(function() return gw.WidgetTree end)
    local root = tree and get(function() return tree.RootWidget end)
    if not valid(root) then return nil end
    local row, anyRow = nil, nil
    walk(root, function(w)
        if row then return true end
        if isCheckRow(w) then row = w; return true end
        if not anyRow and className(w):find("^WBP_Settings_") then anyRow = w; return true end
        return false
    end, 0)
    local ref = row or anyRow
    local parent = ref and get(function() return ref:GetParent() end)
    if not valid(parent) then return nil end
    local cls = row and get(function() return row:GetClass() end) or loadClass(CHECK_PATH)
    if not valid(cls) then return nil end
    return parent, cls
end

local UI = { tabs = {}, lang = nil, lastLang = 0 }

local function setRowText(w, text)
    pcall(function() w.LabelText = FText(text) end)
    pcall(function() w:SetLabelText(FText(text)) end)
    pcall(function() w.InputLabelButton.LabelText:SetText(FText(text)) end)
    pcall(function() w:SetToolTipText(FText(text)) end)
end

local function readSlot(w)
    local s = get(function() return w.Slot end)
    if not valid(s) then return nil end
    local t = {}
    local p = get(function() return s.Padding end)
    if p then t.pad = { Left = get(function() return p.Left end) or 0, Top = get(function() return p.Top end) or 0,
        Right = get(function() return p.Right end) or 0, Bottom = get(function() return p.Bottom end) or 0 } end
    t.h = get(function() return s.HorizontalAlignment end)
    t.v = get(function() return s.VerticalAlignment end)
    local sz = get(function() return s.Size end)
    if sz then t.size = { SizeRule = get(function() return sz.SizeRule end) or 0, Value = get(function() return sz.Value end) or 1 } end
    return t
end
local function writeSlot(s, t)
    if not (valid(s) and t) then return end
    if t.pad then pcall(function() s:SetPadding(t.pad) end) end
    if t.h then pcall(function() s:SetHorizontalAlignment(t.h) end) end
    if t.v then pcall(function() s:SetVerticalAlignment(t.v) end) end
    if t.size then pcall(function() s:SetSize(t.size) end) end
end

local function entryOf(list, w)
    local cur = w
    for _ = 1, 8 do
        local p = get(function() return cur:GetParent() end)
        if not valid(p) then return nil end
        if addr(p) == addr(list) then return cur end
        cur = p
    end
    return nil
end

local function placeAfter(list, after, rows)
    local idx = tonumber(get(function() return list:GetChildIndex(after) end))
    local n = tonumber(get(function() return list:GetChildrenCount() end))
    local like = readSlot(after)
    if not idx or idx < 0 or not n then
        for _, w in ipairs(rows) do writeSlot(get(function() return list:AddChild(w) end), like) end
        return "end"
    end
    local inserted = true
    for i, w in ipairs(rows) do
        local s = get(function() return list:InsertChildAt(idx + i, w) end)
        if not valid(s) then inserted = false; break end
        writeSlot(s, like)
    end
    if inserted then return "insert" end
    for _, w in ipairs(rows) do pcall(function() w:RemoveFromParent() end) end
    local tail = {}
    for i = idx + 1, n - 1 do
        local c = get(function() return list:GetChildAt(i) end)
        if valid(c) then tail[#tail + 1] = { w = c, slot = readSlot(c) } end
    end
    for _, t in ipairs(tail) do pcall(function() t.w:RemoveFromParent() end) end
    for _, w in ipairs(rows) do writeSlot(get(function() return list:AddChild(w) end), like) end
    for _, t in ipairs(tail) do writeSlot(get(function() return list:AddChild(t.w) end), t.slot) end
    return "moved"
end

local function nextRow(list, w)
    local idx = tonumber(get(function() return list:GetChildIndex(w) end)) or -1
    local n = tonumber(get(function() return list:GetChildrenCount() end)) or 0
    for i = idx + 1, n - 1 do
        local c = get(function() return list:GetChildAt(i) end)
        if valid(c) and className(c):find("^WBP_Settings_") then return c end
    end
    return nil
end

local UP, DOWN = 2, 3
local function link(a, b)
    if not (valid(a) and valid(b)) then return end
    for _, x in ipairs({ a, get(function() return a.InputCheckBox end) }) do
        if valid(x) then pcall(function() x:SetNavigationRuleExplicit(DOWN, b) end) end
    end
    for _, y in ipairs({ b, get(function() return b.InputCheckBox end) }) do
        if valid(y) then pcall(function() y:SetNavigationRuleExplicit(UP, a) end) end
    end
end

local function inSettingWidgets(gw, w)
    local arr = get(function() return gw.SettingWidgets end)
    local n = arr and tonumber(get(function() return arr:GetArrayNum() end)) or 0
    local a = addr(w)
    for i = 1, n do
        local e = asObj(get(function() return arr[i] end))
        if e and addr(e) == a then return i end
    end
    return nil
end

local function addToSettingWidgets(tab)
    local gw = tab.gw
    if tab.swFailed then return end
    local arr = get(function() return gw.SettingWidgets end)
    if not arr then tab.swFailed = true; problem("sw", "SettingWidgets not found: controller can't reach the options"); return end
    if inSettingWidgets(gw, tab.rows[1].w) then return end
    local n = tonumber(get(function() return arr:GetArrayNum() end)) or 0
    local pos = (tab.helm and (inSettingWidgets(gw, tab.helm) or (tab.helmInner and inSettingWidgets(gw, tab.helmInner)))) or n
    local k = #tab.rows
    for i = n + k, pos + k + 1, -1 do
        local src = get(function() return arr[i - k] end)
        if not pcall(function() arr[i] = src end) then tab.swFailed = true; problem("swgrow", "couldn't grow SettingWidgets"); return end
    end
    for i, r in ipairs(tab.rows) do pcall(function() arr[pos + i] = r.w end) end
    if inSettingWidgets(gw, tab.rows[1].w) then
        log(string.format("controller: options added to SettingWidgets after entry %d (%d -> %d)", pos, n,
            tonumber(get(function() return arr:GetArrayNum() end)) or -1))
    else
        tab.swFailed = true
        problem("swset", "couldn't add the options to SettingWidgets")
    end
end

local function inject(gw, pc)
    local wbl = get(function() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
    if not valid(wbl) then return nil end

    local helmInner = get(function() return gw.HideHelmetCheckbox end)
    local list, cls, helm = nil, nil, nil
    if valid(helmInner) then
        local opts = get(function() return gw.OptionsList end)
        list = valid(opts) and opts or get(function() return helmInner:GetParent() end)
        helm = valid(list) and entryOf(list, helmInner) or nil
        if not helm then list = get(function() return helmInner:GetParent() end); helm = helmInner end
        cls = isCheckRow(helmInner) and get(function() return helmInner:GetClass() end) or loadClass(CHECK_PATH)
    end
    if not (valid(list) and valid(cls)) then
        problem("helm", "Hide helmet row not found: options added at the end of the list")
        list, cls = findList(gw)
        helm = nil
    end
    if not valid(list) or not valid(cls) then return nil end
    local lang = language()
    local tab = { gw = gw, rows = {}, helm = helm, helmInner = helmInner }
    local made = {}
    for _, key in ipairs(ORDER) do
        local w = get(function() return wbl:Create(pc, cls, pc) end)
        if valid(w) then
            setRowText(w, label(key, lang))
            made[#made + 1] = w
            tab.rows[#tab.rows + 1] = { key = key, w = w, shown = cfg[key] }
        end
    end
    if #made == 0 then problem("inject", "couldn't create the option rows"); return nil end
    local how = helm and placeAfter(list, helm, made) or "end"
    if how == "end" and not helm then for _, w in ipairs(made) do pcall(function() list:AddChild(w) end) end end
    for _, r in ipairs(tab.rows) do
        setRowText(r.w, label(r.key, lang))
        pcall(function() r.w.InputCheckBox:SetIsChecked(cfg[r.key]) end)
    end

    local below = nextRow(list, made[#made])
    local chain = { helm }
    for _, w in ipairs(made) do chain[#chain + 1] = w end
    chain[#chain + 1] = below
    for i = 1, #chain - 1 do link(chain[i], chain[i + 1]) end
    addToSettingWidgets(tab)
    UI.lang = lang
    log(string.format("added %d options to Settings > Gameplay (%s), placed: %s, list %s, row %s, next %s", #tab.rows, lang, how,
        className(list), className(made[1]), valid(below) and className(below) or "-"))
    return tab
end

local function rowsAlive(tab)
    local w = tab.rows[1] and tab.rows[1].w
    return valid(tab.gw) and valid(w) and valid(get(function() return w:GetParent() end))
end

local UI_SCAN = { last = 0, interval = 2.0 }
local function menuMaybeOpen()
    local pc = PLAYER.pc
    if not valid(pc) then return false end
    return get(function() return pc.bShowMouseCursor end) == true
end

local function discoverTabs()
    for _, cls in ipairs({ "WBP_SettingsGameplayWidget_C", "SettingsGameplayWidget" }) do
        for _, gw in ipairs(get(function() return FindAllOf(cls) end) or {}) do
            local a = valid(gw) and addr(gw)
            if a and not UI.tabs[a] and not full(gw):find("Default__", 1, true) then
                local pc = localPlayer() or get(function() return gw:GetOwningPlayer() end)
                UI.tabs[a] = valid(pc) and inject(gw, pc) or nil
            end
        end
    end
end

local function uiTick()

    if menuMaybeOpen() or now() - UI_SCAN.last >= UI_SCAN.interval then
        UI_SCAN.last = now()
        discoverTabs()
    end

    for a, tab in pairs(UI.tabs) do
        if not valid(tab.gw) then
            UI.tabs[a] = nil
        elseif not rowsAlive(tab) then
            local pc = localPlayer() or get(function() return tab.gw:GetOwningPlayer() end)
            UI.tabs[a] = valid(pc) and inject(tab.gw, pc) or nil
        elseif now() - (tab.swCheck or 0) > 1 then
            tab.swCheck = now()
            addToSettingWidgets(tab)
        end
    end

    local changed = false
    for _, tab in pairs(UI.tabs) do
        for _, r in ipairs(tab.rows) do
            local v = get(function() return r.w.InputCheckBox:IsChecked() end)
            if type(v) == "boolean" and v ~= r.shown then
                r.shown = v
                if v ~= cfg[r.key] then cfg[r.key] = v; changed = true; log(r.key .. " = " .. tostring(v)) end
            elseif type(v) == "boolean" and r.shown ~= cfg[r.key] then
                pcall(function() r.w.InputCheckBox:SetIsChecked(cfg[r.key]) end)
                r.shown = cfg[r.key]
            end
        end
    end
    if changed then saveConfig(); applyAll(false) end

    if next(UI.tabs) and now() - UI.lastLang > 1 then
        UI.lastLang = now()
        local lang = language()
        if lang ~= UI.lang then
            UI.lang = lang
            for _, tab in pairs(UI.tabs) do
                for _, r in ipairs(tab.rows) do setRowText(r.w, label(r.key, lang)) end
            end
        end
    end
end

local T = { ui = 0, weight = 0, dur = 0, keep = 0 }
local function loop()
    local t = now()
    if t - T.ui >= 0.25 then T.ui = t; pcall(uiTick) end
    local pc, pawn = nil, nil
    if t - T.weight >= 0.25 then
        T.weight = t
        pc, pawn = localPlayer()
        if pc then pcall(applyWeight, pc, pawn) end
    end
    if t - T.dur >= 1.0 then
        T.dur = t
        if not pc then pc, pawn = localPlayer() end
        if pc then pcall(applyDurability, pc, pawn) end
    end
    if t - T.keep >= 2.0 then
        T.keep = t
        if not pc then pc = localPlayer() end
        if pc then pcall(applyKeep, pc, false) end
    end
end
if not pcall(LoopInGameThreadWithDelay, 100, function() pcall(loop) end) then
    LoopAsync(250, function() ExecuteInGameThread(function() pcall(loop) end); return false end)
end

pcall(RegisterConsoleCommandHandler, "rsdsfreedom", function()
    local pc, pawn = localPlayer()
    local enc = valid(pawn) and firstValid(pawn, { "PlayerEncumbranceComponent" }, { "GetPlayerEncumbranceComponent" }) or nil
    log(string.format("KeepInventory=%s NoWeight=%s NoDurability=%s | language %s | player %s | weight now %s, real %s | items repaired %d | items %d",
        tostring(cfg.KeepInventory), tostring(cfg.NoWeight), tostring(cfg.NoDurability), language(), tostring(valid(pc)),
        tostring(enc and get(function() return enc.CurrentCarryWeight end)), tostring(valid(pc) and realWeight(pc, pawn)),
        D.fixed, valid(pc) and #playerItems(pc, pawn) or 0))
    local n = 0
    for _ in pairs(UI.tabs) do n = n + 1 end
    log("Settings > Gameplay tabs with the options: " .. n)
    for k, v in pairs(problems) do log("problem " .. k .. ": " .. v) end
    return true
end)

log(string.format("loaded. KeepInventory=%s NoWeight=%s NoDurability=%s",
    tostring(cfg.KeepInventory), tostring(cfg.NoWeight), tostring(cfg.NoDurability)))
