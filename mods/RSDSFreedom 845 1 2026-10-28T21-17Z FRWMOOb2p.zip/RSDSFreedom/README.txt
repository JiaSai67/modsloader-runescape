RSDS Freedom 1.0.0 - RuneScape: Dragonwilds (UE4SS)

Three optional switches, added to the game's own Settings > Gameplay tab, right below "Hide helmet":
  - No Weight Limit       
  - Keep Items on Death  
  - Never lose durability

All off by default. Check a box to turn its effect on. Works with mouse and controller.


Install
  1. Install UE4SS for RuneScape: Dragonwilds.
  2. Copy the RSDSFreedom folder into your UE4SS Mods directory
     (...\Binaries\Win64\ue4ss\Mods\).
  3. Launch the game and open Settings > Gameplay.

Co-op
  Works fully in solo or Co-op. Note: The host's game decides deaths,
  weight and durability.

Uninstall
  Delete this folder (RSDSFreedom).

Problems
  Type  rsdsfreedom  in the UE4SS console and send UE4SS.log.
