Mod Menu has no pak file. This file only gives the download a Content folder, so Vortex installs
the mod to the right place. The game ignores it, and it is safe to delete.
