-- Mod Menu 2.0 built-in tables (data module, loaded by core with loadfile; docs/modmenu-2.0-design.md 1.4, 2.1).
-- Covers our own mods so they need no new release for the 2.0 row tags. A mod's own modmenu.json always wins:
-- a setting's "runsOn", then the mod's top-level "runsOn", then the per-key table below, then the per-mod table.
--
--   runsOn[id]          = "yours" | "host" | "server" | "both"   (meanings: design section 2)
--   runsOnKeys[id][Key] = the same words, for the keys that differ from the mod's word
--   live[id]            = true: the mod reads ModMenu.<id>.<key> with GetSharedVariable, so a change applies at once
--   nextLoad[id]        = true or { Key = true }: the value is read at world load (tag "next load", C8a)
--   restart[id]         = true or { Key = true }: read once at game start although its modmenu.json has no "restart"
--   libs[id]            = true: a library for other mods (Health check shows "lib", gray)
--   needsRuneSchema[id] = true: its release puts files under ue4ss/Mods/RuneSchema/mods/<Mod> (health signal 5)
--
-- Evidence per entry: M = measured (docs/server-compat-matrix.md), S = read from the code; paths are
-- mods/<Mod>/Scripts/main.lua unless named. U = unknown, no tag shipped (AutoTool, CapesOfAchievement, MaxCape,
-- QuestCape, CutContent, FastEatSleep, MountedCombat, QuickSwap; reasons in the design doc 2.1).

local B = {}

B.runsOn = {
    Blueprints = "host",            -- S :11, :210 "works for the host only"
    CameraOffsets = "yours",        -- S :2 local third-person camera
    CarrySliders = "server",        -- M srvpp2-1012 800 on server and client; :33
    CollectionLog = "yours",        -- S UI panel; matrix: on a server its file keys on the account name
    ConfigurableStacks = "server",  -- M "server is enough", client 99 vs server 990
    ConstructionToolkit = "host",   -- S :880, :1387 upgrade host only
    CosmeticKit = "yours",          -- S :36 others only via experimental ShowOnOthers
    CustomCapes = "yours",          -- S :2-3 picture from your disk on your cape
    DevMenu = "host",               -- S :3688-3691 every entry host or solo
    DurabilitySliders = "server",   -- M srvpp4 real hits; :25
    DwarfCannon = "host",           -- S :2360 fail closed
    EnemyHPNumbers = "yours",       -- S :3 UI on health bars
    EventsTuner = "server",         -- M server test, 14 trigger values; :22
    Examine = "yours",              -- S :2 hover panel
    FirstPerson = "yours",          -- S :2 local camera
    FishingSliders = "server",      -- M fishyield-1012 (data sliders); :41
    GrimShearer = "host",           -- S :8, :1643
    KeepInventory = "host",         -- S :5-7 unlocks the world's own setting
    KeyUnlocker = "yours",          -- S :7, :24-30 local input mapping contexts
    LevelCelebration = "yours",     -- S :23 "solo, host or guest"
    LootSliders = "server",         -- M 372/497 at x2; :24
    ModMenu = "yours",              -- itself
    MorphSliders = "yours",         -- S :2 meshes you wear
    MoveBuildings = "host",         -- S :20, :297
    MovementSliders = "server",     -- M sprint 1020 both sides; :28
    NoAutoPickup = "host",          -- S :15, :308
    NodeTimers = "yours",           -- S timers are local; :757-758
    OpenAll = "yours",              -- M released 1.1.0 "player only"; :30-32
    PetRock = "yours",              -- S :7 "spawned on your machine only"
    PictureSliders = "yours",       -- S :7 local PostProcessVolume
    QuestLog = "yours",             -- S UI; :860 quest array read for guests too
    QuickTeleport = "both",         -- M qt110-1013 part 2, 13 of 13
    RaidMaker = "server",           -- M raid-1013 9 of 9; :18
    RuneScapeBags = "host",         -- S :56, :2189-2194
    RuneSchemaDoctor = "yours",     -- S :2-3 reads files only
    SaveBank = "host",              -- S :5, :678
    Slayer = "both",                -- S :40, :84 net.lua; matrix batch 3 (kill credit server only)
    SpellSliders = "server",        -- M srvpp4 rune cost; :31-35
    StationFeeder = "yours",        -- M 1.8.0 "player only"; :54
    StorageSearch = "yours",        -- M 2.2.0 "player only"; :26
    SurvivalSliders = "server",     -- M 0.50 both sides; :15
    TimeControl = "server",         -- M 0.255x on server and client; :23-24
    ToolBelt = "host",              -- S :32, :1142-1147
    TorchBurnSlider = "server",     -- M srvpp4 30 s burns; :23
    Transmog = "yours",             -- S :5 "your screen only"
    VaultTraps = "server",          -- S :279-281 role gate (server LOAD ONLY measured, no join)
    WeatherControl = "server",      -- M DWP_RainyDay 10 -> 300 on the server
    XPRate = "server",              -- M srvpp2/3 join guards + x2 award; :19
    XPTracker = "yours",            -- S :2 local panel
    YieldSliders = "server",        -- M yield-1012; :24
}

B.runsOnKeys = {
    -- matrix row "stay solo/host": these act on the local world, not the server's data
    FishingSliders = { KeepFish = "host", RespawnMinutes = "host", NoRodWear = "host", AutoRebait = "host",
                       RefillKey = "host", AFKKey = "host", AllowAsClient = "host" },
    NodeTimers = { RefillDistance = "host" },                                   -- S :757-758 refill host only
    -- matrix: "messages and horn go to the players' own copies"
    RaidMaker = { ShowMessages = "yours", PlaySound = "yours", HornVolume = "yours" },
    SpellSliders = { CooldownMultiplier = "yours" },                            -- M spellcd2-1013: the joined player's own copy
    TimeControl = { SkipMorningKey = "host", SkipNightKey = "host", SkipHourKey = "host" },   -- matrix "keys do not exist on a server"
    WeatherControl = { SetWeather = "host", LockWeather = "host", NextWeatherKey = "host", SunnyKey = "host" },   -- S :25-27 "here" needs a local player
}

-- GetSharedVariable("ModMenu." .. <own id> .. "." .. key) read per mod (S, first value read, 2026-10-20).
B.live = {
    AutoTool = true,              -- :581
    Blueprints = true,            -- :1053
    CameraOffsets = true,         -- :746 MM_PREFIX, :748 sharedF
    CapesOfAchievement = true,    -- :144
    CarrySliders = true,          -- :469
    CollectionLog = true,         -- :3853
    ConstructionToolkit = true,   -- :1524
    CosmeticKit = true,           -- :787
    CustomCapes = true,           -- :439
    DevMenu = true,               -- :3744
    DurabilitySliders = true,     -- :423
    DwarfCannon = true,           -- :2185
    EnemyHPNumbers = true,        -- :164
    EventsTuner = true,           -- :383
    Examine = true,               -- :1898
    FirstPerson = true,           -- :1151 MM_PREFIX, :1153 sharedF
    FishingSliders = true,        -- :1170
    GrimShearer = true,           -- :1565
    KeyUnlocker = true,           -- :324
    LevelCelebration = true,      -- :826
    LootSliders = true,           -- :658
    MaxCape = true,               -- :140
    ModMenu = true,               -- own rows apply in the panel ("-- Own settings, read the same way"; PanelScale redraws)
    MorphSliders = true,          -- :212
    MountedCombat = true,         -- :1844
    MovementSliders = true,       -- :459
    NoAutoPickup = true,          -- :123
    NodeTimers = true,            -- :875
    OpenAll = true,               -- :654
    PetRock = true,               -- :1221
    PictureSliders = true,        -- :189
    QuestCape = true,             -- :125
    QuestLog = true,              -- :3321
    QuickSwap = true,             -- :149
    QuickTeleport = true,         -- :213
    RaidMaker = true,             -- :882
    RuneScapeBags = true,         -- :2143
    SaveBank = true,              -- :142
    Slayer = true,                -- :3563
    SpellSliders = true,          -- :219
    StationFeeder = true,         -- :2725
    StorageSearch = true,         -- :2436
    SurvivalSliders = true,       -- :381
    TimeControl = true,           -- :499
    ToolBelt = true,              -- :1096
    TorchBurnSlider = true,       -- :376
    Transmog = true,              -- :352 ModMenu.Transmog.Enabled
    VaultTraps = true,            -- :454
    WeatherControl = true,        -- :648
    XPRate = true,                -- :872
    XPTracker = true,             -- :1534
    YieldSliders = true,          -- :1413
}
-- Not live (no ModMenu.<id> read): ConfigurableStacks, FastEatSleep, KeepInventory, MoveBuildings (every key
-- "restart": true in their modmenu.json), CutContent (buttons only), RuneSchemaDoctor (see restart below).

-- No repo mod was found that applies a value only at world load (grep of every Scripts/main.lua and modmenu.json
-- for world-load wording, 2026-10-20), so nothing carries "next load" yet. Add entries with evidence.
B.nextLoad = {}

-- Read once at game start (loadConfig() at top level, never again, no shared-variable read) but the file has no "restart":
B.restart = {
    FastEatSleep = { Verbose = true },     -- :155
    KeepInventory = { Verbose = true },    -- :139
    RuneSchemaDoctor = true,               -- :641
}

B.libs = { CosmeticKit = true }   -- library for Party Hats / Hallowe'en Masks (design 2.1)

-- Release zips that write ue4ss/Mods/RuneSchema/mods/<Mod>/ (tools/ build scripts):
B.needsRuneSchema = {
    Blueprints = true,            -- tools/zip_blueprints.py:40
    CapesOfAchievement = true,    -- tools/build_capes_release.py:47
    DwarfCannon = true,           -- tools/zip_dwarfcannon.py:16
    HalloweenMasks = true,        -- tools/zip_cosmetickit_release.py:89, :105
    MaxCape = true,               -- tools/build_cape_release.py:51, :86
    PartyHats = true,             -- tools/zip_cosmetickit_release.py:89, :104
    QuestCape = true,             -- tools/build_cape_release.py:51, :86
    RuneScapeBags = true,         -- tools/zip_bags.py:15
    SlayerCape = true,            -- mods/SlayerCape/RuneSchema (the add-on's item files; no build script yet)
    VaultTraps = true,            -- tools/zip_vaulttraps.py:24
}

local WORDS = { yours = true, host = true, server = true, both = true }
B.WORDS = WORDS

-- The runsOn word for setting s of mod m (nil = no tag), and where it came from.
function B.runsOnFor(m, s)
    if s and WORDS[s.runsOn] then return s.runsOn, "setting" end
    if m and WORDS[m.runsOn] then return m.runsOn, "mod" end
    local id = m and m.id
    local keys = id and B.runsOnKeys[id]
    if keys and s and s.key and keys[s.key] then return keys[s.key], "builtin key" end
    if id and B.runsOn[id] then return B.runsOn[id], "builtin" end
    return nil, nil
end

local function hit(t, id, key)
    local e = t[id]
    if e == true then return true end
    return type(e) == "table" and key ~= nil and e[key] == true
end

-- The apply tag for setting s of mod m (C8a): "restart", "live", "next load" or nil (unknown, no tag).
function B.applyFor(m, s)
    local id = m and m.id
    if (s and s.restart) or hit(B.restart, id, s and s.key) then return "restart" end
    if id and B.live[id] then return "live" end
    if hit(B.nextLoad, id, s and s.key) then return "next load" end
    return nil
end

return B
