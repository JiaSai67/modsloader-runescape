-- Mod Menu 2.0: Health check (docs/modmenu-2.0-design.md sections 1.4 and 5; owner C-keys, batches H1 + H2).
-- Answers "is each mod running, and if not, why": switched off, stopped with an error at start, switched on but
-- never started (wrong folder), needs RuneSchema, old UE4SS. It reads FILES only (UE4SS.log, the mod folders,
-- mods.txt) and the game-folder table core already holds: no game objects, no FindAllOf, no edits to other mods.
-- Core loads it with loadfile and calls scan() at menu open (after discover), status()/summary() for the sidebar
-- dots and page header, buildPage() for the Health page and reportLines() for SAVE REPORT.
--
-- UE4SS.log facts (2026-10-20 06:38 and 07:11 logs, UE4SS v3.0.1 Beta f6d5f942):
--   line 2                  "UE4SS - v3.0.1 Beta #0 - Git SHA #f6d5f942"
--   a mod from mods.txt     "Starting Lua mod '<folder>'" (69 in one log), its main chunk's own lines follow at once
--   a mod from enabled.txt  "Mod '<folder>' has enabled.txt, starting mod." (ParityProbe, 07:11 log line 899)
--   C++ mods                "Starting C++ mod '<folder>'" (RuneSchema, MiniMap)
--   start passes            "Starting mods (from mods.txt ...)" / "(from enabled.txt ...)"; then "Event loop start"
-- The file was 326 KB after 15 minutes, over core's readFile cap (256 KB), so it is read here with io.open + seek
-- from a kept byte offset, and not at all once "Event loop start" was seen (the start phase is over; only a new
-- session, seen as a changed first line or a smaller file, makes it read again).
-- A main.lua that fails (probe H0 in game 2026-10-20, run log T0 + journal; fixture tools/fixtures/mm2_health/
-- ue4ss_h0_errors.log):
--   syntax error   "Error loading script: ...s\Binaries\Win64\ue4ss\Mods\<f>\Scripts\main.lua:4: unexpected symbol near '='"
--                  then "Failed to execute main script: D:\...\<f>\Scripts\main.lua"
--   runtime error  the mod's own prints, "Error executing script: ...\<f>\Scripts\main.lua:5: attempt to index ...",
--                  "stack traceback:", a tab-indented "...main.lua:5: in main chunk", "Failed to execute main script: ..."
--   Paths are cut with "..." at the front. A mod unpacked one folder too deep gets NO line at all.
-- An error goes to the folder named in its path when that is readable, else to the mod whose start block it is in;
-- the reason shows the message from the file name on ("main.lua:4: unexpected symbol near '='").

local H = { MM_MODULE = "health", API = 1 }
local MM = nil

H.LOG_CAP = 4 * 1024 * 1024   -- bytes read per scan at most
H.PIECE = 64 * 1024            -- bytes per read call
H.BLOCK_LINES = 400            -- a mod's start block never runs longer than this many lines
H.SCAN_GAP = 1.0               -- seconds: scan(false) closer together than this does nothing

local STATES = { running = true, off = true, error = true, notstarted = true, warn = true, unknown = true, lib = true }
local PROBLEM = { off = true, error = true, notstarted = true, warn = true }
H.STATES, H.PROBLEM = STATES, PROBLEM

local L = nil                  -- UE4SS.log state (resetLog)
local ST, EXTRA, GLOBAL = {}, {}, {}
local SUM = { problems = 0, unknown = 0, total = 0, running = 0 }
local lastScan = nil
H.lastMs = 0

local function resetLog(path)
    L = { path = path, offset = 0, head = nil, size = 0, partial = "", started = {}, startedCpp = {}, errors = {},
          nStarted = 0, version = nil, versionText = nil, done = false, cur = nil, curLines = 0,
          readable = nil, why = nil, ms = 0, bytes = 0 }
end

local function exists(path)
    local f = io.open(path, "rb")
    if f then f:close(); return true end
    return false
end

local function parentOf(path)
    if type(path) ~= "string" then return nil end
    return (path:gsub("[/\\]+$", ""):match("^(.*)[/\\][^/\\]+$"))
end

-- A line UE4SS writes for a failing main.lua, in the real H0 formats only: the three "... script:" lines,
-- "stack traceback:", or a traceback line whose path starts with "...". A mod's own prints never match.
H.ERROR_PREFIX = { "Error loading script:", "Error executing script:", "Failed to execute main script:" }
function H.isErrorLine(text)
    if type(text) ~= "string" then return false end
    for _, p in ipairs(H.ERROR_PREFIX) do if text:sub(1, #p) == p then return true end end
    if text:find("^stack traceback:") then return true end
    return text:find("^%s*%.%.%.%S-%.lua:%d+:") ~= nil
end

-- The message of an error line, its path cut to the file name: "main.lua:4: unexpected symbol near '='".
function H.errorText(text)
    local msg = tostring(text):gsub("^[%a ]-script:%s*", "", 1)
    local short = msg:match("([^/\\]+%.lua:%d+:.*)$")
    return ((short or msg):gsub("^%s+", "")):sub(1, 120)
end

-- The mod folder named in an error line's path (lower case), or nil. "..." at the front of a cut name is dropped.
function H.errorFolder(text)
    local path = tostring(text):gsub("^[%a ]-script:%s*", "", 1)
    local f = path:match("([^/\\]+)[/\\][Ss]cripts[/\\][^/\\]+%.lua")
    if not f then return nil end
    f = f:gsub("^%.%.%.", "")
    return f ~= "" and f:lower() or nil
end

local function parseLine(line)
    local text = line:gsub("\r$", ""):gsub("^%[[%d%-:%. ]+%]%s?", "", 1)
    if not L.version then
        local a, b, c = text:match("^UE4SS %- v(%d+)%.(%d+)%.(%d+)")
        if a then L.version = { tonumber(a), tonumber(b), tonumber(c) }; L.versionText = a .. "." .. b .. "." .. c end
    end
    local f = text:match("^Starting Lua mod '(.-)'") or text:match("^Mod '(.-)' has enabled%.txt, starting mod")
    if f then
        L.cur, L.curLines = f:lower(), 0
        if not L.started[L.cur] then L.started[L.cur] = true; L.nStarted = L.nStarted + 1 end
        return
    end
    local c = text:match("^Starting C%+%+ mod '(.-)'")
    if c then L.startedCpp[c:lower()] = true; L.cur = nil; return end
    if text:find("^Starting mods %(") then L.cur = nil; return end
    if text:find("^Event loop start") then L.cur = nil; L.done = true; return end
    if L.cur then
        L.curLines = L.curLines + 1
        if L.curLines > H.BLOCK_LINES then L.cur = nil end
    end
    if H.isErrorLine(text) then
        local f = H.errorFolder(text)
        local target = L.cur
        -- a whole other folder name in the path wins; a name cut by "..." that ends the current block's folder is it
        if f and f ~= L.cur and not (L.cur and L.cur:sub(-#f) == f and not L.started[f]) then target = f end
        if target and not L.errors[target] then L.errors[target] = H.errorText(text) end
    end
end

-- Reads what is new in UE4SS.log since the last scan (all of it the first time, nothing once the start phase ended).
local function readLog(path)
    if not L or L.path ~= path then resetLog(path) end
    local t0 = os.clock()
    local f = io.open(path, "rb")
    if not f then
        L.readable, L.why = false, "could not open " .. tostring(path)
        return
    end
    local ok, err = pcall(function()
        local size = f:seek("end") or 0
        f:seek("set", 0)
        local head = f:read(64) or ""
        if L.head ~= nil and (head ~= L.head or size < L.offset) then resetLog(path) end   -- a new game session
        L.head, L.size = head, size
        if L.done or size <= L.offset then return end
        f:seek("set", L.offset)
        local budget = math.min(size - L.offset, H.LOG_CAP)
        while budget > 0 and not L.done do            -- 64 KB pieces: the start phase is in the first ~100 KB
            local chunk = f:read(math.min(budget, H.PIECE)) or ""
            if #chunk == 0 then break end
            budget = budget - #chunk
            L.offset, L.bytes = L.offset + #chunk, L.bytes + #chunk
            local text, last = L.partial .. chunk, 1
            for line, nxt in text:gmatch("([^\n]*)\n()") do
                parseLine(line)
                last = nxt
                if L.done then break end
            end
            L.partial = L.done and "" or text:sub(last)
        end
    end)
    pcall(function() f:close() end)
    L.readable, L.why = ok, (not ok) and tostring(err) or nil
    L.ms = (os.clock() - t0) * 1000
end

-- mods.txt of the Mods folder: { [folder, lower case] = "0" or "1" } (same rule as core's modsTxtFor).
local function modsTxt(root)
    local t = {}
    local text = root and MM.readFile(root .. "\\mods.txt")
    for line in ((type(text) == "string" and text or "") .. "\n"):gmatch("([^\n]*)\n") do
        local name, on = line:match("^%s*([^;:][^:]-)%s*:%s*(%d)")
        if name then t[name:lower()] = on end
    end
    return t
end

-- Folder problems (signal 6): nil when Scripts\main.lua (or a C++ mod's dlls\main.dll) is where UE4SS looks.
local function folderProblem(dir, folder)
    if type(dir) ~= "string" then return nil end
    if exists(dir .. "\\Scripts\\main.lua") or exists(dir .. "\\dlls\\main.dll") then return nil end
    if folder and exists(dir .. "\\" .. folder .. "\\Scripts\\main.lua") then
        return { reason = "it was unpacked one folder too deep (" .. folder .. "\\" .. folder .. "\\Scripts)",
                 fix = "Move the inner " .. folder .. " folder's files up one level, into Mods\\" .. folder }
    end
    return { reason = "its folder has no Scripts\\main.lua", fix = "Reinstall the mod" }
end

-- RuneSchema (signal 5): "ok", "missing", "off", "notstarted"; started is only judged from a usable log.
local function runeSchemaState(root, txt, logOk)
    if not root then return "ok" end
    local base = root .. "\\RuneSchema"
    if not (exists(base .. "\\dlls\\main.dll") or exists(base .. "\\Scripts\\main.lua")) then return "missing" end
    if not (exists(base .. "\\enabled.txt") or txt["runeschema"] == "1") then return "off" end
    if logOk and not (L.started["runeschema"] or L.startedCpp["runeschema"]) then return "notstarted" end
    return "ok"
end

local RS_REASON = {
    missing = "Needs RuneSchema, which is missing",
    off = "Needs RuneSchema, which is switched off",
    notstarted = "Needs RuneSchema, which did not start",
}

local function needsRuneSchema(m, tree)
    local need = MM.builtin and MM.builtin.needsRuneSchema or {}
    if need[m.id] or (m.folder and need[m.folder]) then return true end
    local hit = false
    pcall(function() hit = type(tree.RuneSchema.mods[m.folder]) == "table" end)
    return hit
end

local function entry(state, reason, fix) return { state = state, reason = reason or "", fix = fix or "" } end

local function ownFolder()
    local ok, r = pcall(function() return MM.ownRoot and MM.ownRoot() end)
    if not ok then r = nil end
    return type(r) == "string" and (r:gsub("[/\\]+$", ""):match("([^/\\]+)$") or ""):lower() or "modmenu"
end

local function judge(m, ctx)
    local low = tostring(m.folder or m.id):lower()
    if m.id == "ModMenu" or low == ctx.own then return entry("running", "Running (this menu)") end
    if m.off then return entry("off", "Switched off", "Add enabled.txt to its folder or set it to 1 in mods.txt") end
    local where = folderProblem(m.dir, m.folder)
    if where then return entry("notstarted", "Switched on but UE4SS did not start it: " .. where.reason, where.fix) end
    if ctx.logOk then
        if L.errors[low] then
            return entry("error", "Stopped with an error at start: " .. L.errors[low],
                "Update the mod; SAVE REPORT and paste it on its page")
        end
        if not (L.started[low] or L.startedCpp[low]) then
            return entry("notstarted", "Switched on but UE4SS did not start it",
                "Check its folder name matches its mods.txt line, then restart the game")
        end
    end
    if needsRuneSchema(m, ctx.tree) and ctx.rs ~= "ok" then
        local fix = "Install RuneSchema and switch it on"
        if ctx.doctor then fix = fix .. "; RuneSchema Doctor's report says more" end
        return entry("warn", RS_REASON[ctx.rs], fix)
    end
    local libs = MM.builtin and MM.builtin.libs or {}
    if libs[m.id] then return entry("lib", "Library for other mods") end
    if not ctx.logOk then return entry("unknown", "UE4SS.log could not be read (" .. tostring(ctx.logWhy) .. ")") end
    local live = MM.builtin and MM.builtin.live or {}
    return entry("running", live[m.id] and "Running, settings apply live" or "Running")
end

-- Folders that look like a mod unpacked one level too deep but have no modmenu.json at the top, so core lists no
-- page for them: Mods\Foo has no Scripts, dlls or modmenu.json, Mods\Foo\Foo has Scripts or modmenu.json.
local function nestedExtras(tree, known)
    local out = {}
    if type(tree) ~= "table" then return out end
    for folder, sub in pairs(tree) do
        local f = tostring(folder)
        if type(sub) == "table" and not f:find("^__") and not known[f:lower()] then
            local inner = sub[folder]
            local topHas = sub.Scripts or sub.scripts or sub.dlls
            if not topHas and type(inner) == "table" and (inner.Scripts or inner.scripts) then
                out[#out + 1] = { id = f, folder = f, name = f, nested = true,
                    st = entry("notstarted", "Switched on but UE4SS did not start it: it was unpacked one folder too deep ("
                        .. f .. "\\" .. f .. "\\Scripts)", "Move the inner " .. f .. " folder's files up one level, into Mods\\" .. f) }
            end
        end
    end
    table.sort(out, function(a, b) return a.id:lower() < b.id:lower() end)
    return out
end

function H.init(ctx)
    MM = ctx
    ST, EXTRA, GLOBAL, lastScan = {}, {}, {}, nil
    resetLog(nil)
    return true
end

-- H2: ModMenu.health.<id> = the state word (design 1.5), set at each scan, only when it changed.
local shared = {}
local function publish()
    local function put(id, state)
        if shared[id] == state then return end
        local ok = pcall(function() ModRef:SetSharedVariable("ModMenu.health." .. id, state) end)
        if ok then shared[id] = state end
    end
    for id, e in pairs(ST) do put(id, e.state) end
    for _, x in ipairs(EXTRA) do put(x.id, x.st.state) end
end

function H.logPath()
    local root = MM.modsRoot and MM.modsRoot()
    local up = parentOf(root)
    return up and (up .. "\\UE4SS.log") or nil, root
end

function H.scan(force)
    local now = MM.now and MM.now() or os.clock()
    if not force and lastScan and now - lastScan < H.SCAN_GAP then return false end
    lastScan = now
    local t0 = os.clock()
    local path, root = H.logPath()
    if path then readLog(path) else resetLog(nil); L.readable, L.why = false, "the Mods folder is not known" end
    local ctx = { own = ownFolder(), tree = MM.dirTree and MM.dirTree() or nil }
    ctx.logOk = L.readable == true and L.nStarted > 0 and (L.started[ctx.own] or false)
    if L.readable and not ctx.logOk then
        L.why = L.nStarted == 0 and "it lists no mod starts" or "it does not list Mod Menu's own start"
    end
    ctx.logWhy = L.why
    ctx.rs = runeSchemaState(root, modsTxt(root), ctx.logOk)
    ctx.doctor = MM.modById and MM.modById("RuneSchemaDoctor") ~= nil
    GLOBAL = {}
    if L.version and L.version[1] < 3 then
        GLOBAL[#GLOBAL + 1] = entry("warn", "UE4SS " .. L.versionText .. " is older than 3.0", "Update UE4SS to 3.0 or newer")
    end
    if type(LoopInGameThreadWithDelay) ~= "function" or type(RegisterHook) ~= "function" then
        GLOBAL[#GLOBAL + 1] = entry("warn", "This UE4SS lacks LoopInGameThreadWithDelay or RegisterHook",
            "Update UE4SS to 3.0 or newer")
    end
    ST = {}
    local known = {}
    SUM = { problems = #GLOBAL, unknown = 0, total = 0, running = 0 }
    for _, m in ipairs(MM.mods() or {}) do
        local ok, e = pcall(judge, m, ctx)
        if not ok then e = entry("unknown", "Check failed: " .. tostring(e)) end
        ST[m.id] = e
        known[tostring(m.folder or m.id):lower()] = true
        SUM.total = SUM.total + 1
        if PROBLEM[e.state] then SUM.problems = SUM.problems + 1 end
        if e.state == "unknown" then SUM.unknown = SUM.unknown + 1 end
        if e.state == "running" or e.state == "lib" then SUM.running = SUM.running + 1 end
    end
    EXTRA = nestedExtras(ctx.tree, known)
    for _, x in ipairs(EXTRA) do
        SUM.total, SUM.problems = SUM.total + 1, SUM.problems + 1
    end
    publish()
    H.lastMs = (os.clock() - t0) * 1000
    return true
end

function H.status(id)
    if ST[id] then return ST[id] end
    for _, x in ipairs(EXTRA) do if x.id == id then return x.st end end
    return { state = "unknown", reason = "Not checked yet", fix = "" }
end

function H.summary()
    return { problems = SUM.problems, unknown = SUM.unknown, total = SUM.total, running = SUM.running,
             ms = H.lastMs, logMs = L and L.ms or 0 }
end

-- Facts for the tests and the report.
function H.logInfo()
    if not L then return {} end
    return { path = L.path, readable = L.readable, why = L.why, started = L.nStarted, version = L.versionText,
             bytes = L.bytes, ms = L.ms, done = L.done, offset = L.offset }
end
function H.extras() return EXTRA end
function H.globals() return GLOBAL end

-- Problems first (error, not started, off, warn), then unknown, library, running; names A-Z inside each group.
local ORDER = { error = 1, notstarted = 2, off = 3, warn = 4, unknown = 5, lib = 6, running = 7 }
function H.rows()
    local list = {}
    for _, m in ipairs(MM.mods() or {}) do
        local st = H.status(m.id)
        list[#list + 1] = { id = m.id, name = m.name or m.id, folder = m.folder, st = st, page = true }
    end
    for _, x in ipairs(EXTRA) do list[#list + 1] = { id = x.id, name = x.name, folder = x.folder, st = x.st, page = false } end
    table.sort(list, function(a, b)
        local oa, ob = ORDER[a.st.state] or 9, ORDER[b.st.state] or 9
        if oa ~= ob then return oa < ob end
        return tostring(a.name):lower() < tostring(b.name):lower()
    end)
    return list
end

function H.reportLines()
    local out = {}
    local li = H.logInfo()
    out[#out + 1] = string.format("Health check: %d of %d mods need a look, %d unknown (scan %.1f ms)",
        SUM.problems, SUM.total, SUM.unknown, H.lastMs)
    if li.readable then
        out[#out + 1] = string.format("    UE4SS.log: %s, UE4SS v%s, %d mod starts, %d bytes read in %.1f ms%s",
            tostring(li.path), tostring(li.version or "?"), li.started or 0, li.bytes or 0, li.ms or 0,
            li.why and (", not used: " .. li.why) or "")
    else
        out[#out + 1] = "    UE4SS.log not read: " .. tostring(li.why) .. " (only the file checks ran)"
    end
    for _, g in ipairs(GLOBAL) do out[#out + 1] = "    " .. g.reason .. ". " .. g.fix end
    for _, r in ipairs(H.rows()) do
        if r.st.state ~= "running" and r.st.state ~= "lib" then
            out[#out + 1] = "    " .. tostring(r.name) .. " (" .. tostring(r.folder) .. "): " .. r.st.reason
        end
    end
    return out
end

-- The Health page (H2, design section 3 "Checks pages"). Core draws the header (title + "n of N mods need a
-- look"); this fills the page ScrollBox: page-level warnings, where the facts came from, then one row per mod,
-- problems first: state dot 14x14 | game button with the mod's name (opens its page) | reason (state color) and
-- what to do (gray). Returns { rows = { { w = button, id = mod id } } }: core routes each button's click and pad A
-- to that mod's page (K2 contract). Every widget is new for this call (rule 1); every UObject call is pcall'd.
H.STATE_COLOR = { running = "GREEN", off = "RED", error = "RED", notstarted = "RED", warn = "AMBER", unknown = "GRAY", lib = "GRAY" }
H.NAME_W, H.DOT_W, H.ROW_H = 290, 22, 48

function H.buildPage(ui, scroll)
    local rows = {}
    if not (ui and ui.newText and scroll) then return { rows = rows } end
    local valid = MM.valid or function(o) return o ~= nil end
    local T = tonumber(ui.T) or 1
    local C = ui.COLORS or {}
    local function col(name) return C[name] or C.GREY or C.GRAY end
    local function fs(n) return math.floor(n * T + 0.5) end
    local tree = ui.tree
    if not valid(tree) then tree = nil end               -- no tree: flat page, nothing built with construct
    local RW = tonumber(ui.RW) or 1000
    local textW = RW - H.DOT_W - H.NAME_W - 16
    local function add(w) if w then pcall(function() scroll:AddChild(w) end) end end
    -- every text wraps at an explicit width (C28: AutoWrapText alone did not wrap in game; WrapTextAt does)
    local function text(s, size, color, kind, width)
        local t = ui.newText(tree, nil, s, fs(size), color, kind or "body")
        pcall(function() t:SetAutoWrapText(true) end)
        pcall(function() t.WrapTextAt = width or RW end)
        pcall(function() t:SetWrapTextAt(width or RW) end)
        return t
    end

    for _, g in ipairs(GLOBAL) do add(text(g.reason .. ". " .. g.fix, 16, col("AMBER"))) end
    local li = H.logInfo()
    if li.readable and not li.why then
        add(text(string.format("From UE4SS.log (UE4SS v%s, %d mods started) and each mod's folder.",
            tostring(li.version or "?"), li.started or 0), 13, col("GRAY")))
    else
        add(text("UE4SS.log could not be used (" .. tostring(li.why) .. "), so only the folder checks ran.", 13, col("AMBER")))
    end

    -- a game button's label is the game's font, ~17 px a character plus 26 (C28 step 7, measured), whatever T is
    local maxChars = math.max(8, math.floor((H.NAME_W - 26) / 17))
    for _, r in ipairs(H.rows()) do
        pcall(function()
            local st = r.st
            local name = tostring(r.name)
            if #name > maxChars then name = name:sub(1, maxChars - 1) .. "." end
            local color = col(H.STATE_COLOR[st.state] or "GRAY")
            local btn = nil
            if r.page and ui.makeGameButton then btn = ui.makeGameButton(ui.pc, name) end
            if not valid(btn) then btn = nil end
            local why = tostring(st.reason)          -- T3-D4: the reason alone; the dot's color carries the state
            if not tree then                                -- flat fallback
                add(btn or text(name, 16, col("CREAM")))
                add(text(why, 16, color))
                if st.fix ~= "" then add(text(st.fix, 16, col("GRAY"))) end
            else
                local hb = ui.construct("HorizontalBox", tree)
                local dot = ui.construct("Border", tree)
                pcall(function() dot:SetBrushColor(color) end)
                local dotBox = ui.sized(tree, dot, 14, 14)
                local slot = hb:AddChildToHorizontalBox(dotBox)
                -- T3-D6: the slot's default Fill alignment stretched the dot into a tall bar on two-line rows. Top
                -- (EVerticalAlignment 1) + Left (EHorizontalAlignment 1) keep it 14x14, level with the name button's middle.
                pcall(function() slot:SetVerticalAlignment(1) end)
                pcall(function() slot:SetHorizontalAlignment(1) end)
                pcall(function() slot:SetPadding({ Left = 4, Top = 17, Right = 4, Bottom = 0 }) end)
                local nameW = btn or text(name, 16, col("CREAM"), "medium", H.NAME_W)
                hb:AddChildToHorizontalBox(ui.sized(tree, nameW, H.NAME_W, H.ROW_H))
                local vb = ui.construct("VerticalBox", tree)
                vb:AddChildToVerticalBox(text(why, 16, color, "body", textW))
                if st.fix ~= "" then vb:AddChildToVerticalBox(text(st.fix, 16, col("GRAY"), "body", textW)) end
                local s2 = hb:AddChildToHorizontalBox(ui.sized(tree, vb, textW, nil))
                pcall(function() s2:SetPadding({ Left = 16, Top = 4, Right = 0, Bottom = 4 }) end)
                add(hb)
            end
            if btn then rows[#rows + 1] = { w = btn, id = r.id } end
        end)
    end
    return { rows = rows }
end

return H
