-- Mod Menu - RuneScape: Dragonwilds
--
-- One MODS entry in the pause menu (Esc). Every installed mod that ships a modmenu.json file gets a
-- page of settings there, drawn with the game's own checkboxes, sliders and buttons.
--
-- For mod authors: see README.md in this folder. In short, put a modmenu.json next to your
-- enabled.txt listing your options. Mod Menu saves the player's choices into your config file, and
-- also publishes them as UE4SS shared variables for live updates:
--   ModMenu.version          Mod Menu's version ("1.1.0") while it is loaded
--   ModMenu.<id>.<key>       current value (bool, number or string)
--   ModMenu.<id>.rev         number, +1 on every change for that mod
--   ModMenu.<id>.action      "<action>#<n>" when one of your buttons is clicked
--   ModMenu.page             (1.1.1) id of the mod whose page is shown, "" while the menu is closed
--   ModMenu.rect             (1.1.1) the menu's box on screen: "pad:x,y,w,h" (docked in the pause menu, its
--                            1920x1080 canvas units) or "view:x,y,w,h" (viewport units); "" while closed
--   ModMenu.request.set      (1.1.2, read) "<id>#<n>|Key=value|..." sets a mod's own values, as if the player had
--                            changed them on its page
-- Your mod keeps working without Mod Menu installed: it just reads its config file as before.
--
-- Verified 2026-09-16 (ModMenuProbe): shared variables cross mods (string/number/bool), the Mods
-- folder can be listed with IterateGameDirectories, and the game's settings widgets can be created.

-- 1.0.15 (2026-10-07, run c1006c): with many mods installed the pause list ran past the game's 680x205 box and a
-- controller could not reach the entries below it. The list now grows to fit every entry, top edge kept (fitPauseList).

-- 1.1.0 (safety net): a key row has CLEAR and a line under it when the key is also set somewhere else (other
-- mods, F10, F11); the key picker no longer takes Alt/Ctrl/Shift combos, which were saved as the plain key; a
-- number typed into a config file outside its slider is kept until the slider moves; a page says when its mod is
-- switched off; SAVE REPORT writes report.txt; values are sent to mods only when they change; "context" on key
-- settings and "minModMenu" at the top level (tools/modmenu_validate.py + modmenu.schema.json changed with this).

-- 1.1.1: publishes which page is shown (ModMenu.page) and where the menu is on screen (ModMenu.rect), so a mod can
-- show something beside its own page (Custom Capes' picture preview). No change to modmenu.json files.

-- 1.1.2: ModMenu.request.set lets a mod change its own settings (Custom Capes' Style choice sets Fit, Size,
-- Background and Smooth); the page, the shared variables and the config file follow. No change to modmenu.json files.
-- Also in 1.1.2: a slider row is written through its InputSlider (the game widget's own SetValue snapped to 9 steps
-- of the range: 80 showed 75 and was saved as 75 on the next close); a false sent by request.set is applied; a request
-- made while the menu is closed reads that mod's files again first (its modmenu.json may be newer than Mod Menu's copy).

-- 1.1.3: the key picker saves UE4SS's own key names (/ was saved as SLASH, which UE4SS does not know, so the key
-- did nothing) and refuses keys UE4SS has no name for; a choice of keys is in the clash check; request.open while
-- the pause menu is up opens docked; request.set PanelScale resizes the menu. New optional key field
-- "keyNames": "unreal" (Key Unlocker): that row keeps every keyboard and mouse key, saved as the Unreal name.
-- Also 1.1.3: a mouse click on a slider handle (press and release, no drag) is no change; it moved the value a step
-- when the click was off the handle's center (Spell Sliders creep, jimbot70). See handleClick.
-- Also 1.1.3 (run w3): a quick aim and click is no change too; a controller press moves a slider exactly one step;
-- after a docked request.open the pad starts on the mod's entry in the panel (PAD.focusPanel).

-- 2.0 (docs/modmenu-2.0-design.md): a new layout (search bar, sidebar with CHECKS and a running light per mod, rows
-- with their own label, a changed dot, reset and pin, tags for where a value counts and when it applies), search with
-- a jump to the row, Health check / Keys / Pinned pages, folding sections and showIf rows, "Text size" (the PanelScale
-- line), the same layout for the mouse and the controller (Start then RB opens it, LB / RB switch mods, X resets,
-- Y pins), the Quick Panel. Modules beside this file: builtin.lua, health.lua, keys.lua, quickpanel.lua (loaded with
-- loadfile; a missing one is replaced by a stub). New optional modmenu.json fields: runsOn, valueLabels, collapsed,
-- showIf (schema stays 1, so every 1.x page loads unchanged). New shared variables:
--   ModMenu.request.open   also "<id>#<n>|row=<Key>": opens the page at that row (1.1.x reads only the id)
--   ModMenu.health.<id>    the health check's state word for each mod (health.lua)
--   ModMenu.quick          "edit" while the Quick Panel holds the input, else "" (quickpanel.lua)
-- ModMenu.page is "#health", "#keys", "#pinned" or "#results" while one of those pages is shown.

local TAG = "[ModMenu] "
local VERSION = "2.0.2"
local SCHEMA = 1
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

local cfg = {
    ShowInPauseMenu = true,  -- adds MODS to the pause menu (Esc)
    MenuKey = "none",        -- optional key that opens the menu anywhere, including the main menu, e.g. HOME
    PanelScale = 100,        -- 2.0: the text size, percent, 80-140 (1.x: the size of the whole panel)
    QuickPanel = true,       -- 2.0: the Quick Panel (quickpanel.lua) is shown while playing
    QuickEditKey = "F4",     -- 2.0: hold to edit the Quick Panel with the mouse
    QuickX = 3,              -- 2.0: Quick Panel position, percent of the screen from the left
    QuickY = 30,             -- 2.0: and from the top
}

local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    local dir = src:match("^(.*)[/\\][^/\\]*$")
    if not dir then return nil end
    return (dir:match("^(.*)[/\\][^/\\]*$"))
end

local function valid(o)
    if not o then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v
end

-- JSON --------------------------------------------------------------------------------------------
-- Small strict decoder: objects, arrays, strings (with \uXXXX), numbers, true/false/null.
local json = {}
do
    local function skip(s, i)
        while true do
            local c = s:sub(i, i)
            if c == " " or c == "\t" or c == "\r" or c == "\n" then i = i + 1
            elseif c == "/" and s:sub(i + 1, i + 1) == "/" then   -- tolerate // comments
                local e = s:find("\n", i, true); i = e and e + 1 or #s + 1
            else return i end
        end
    end
    local function utf8char(cp)
        if cp < 0x80 then return string.char(cp)
        elseif cp < 0x800 then return string.char(0xC0 + math.floor(cp / 0x40), 0x80 + cp % 0x40)
        else return string.char(0xE0 + math.floor(cp / 0x1000), 0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40) end
    end
    local value
    local function err(s, i, what) error(string.format("%s at character %d", what, i), 0) end
    local function str(s, i)
        local out, j = {}, i + 1
        while true do
            local c = s:sub(j, j)
            if c == "" then err(s, j, "unterminated string") end
            if c == '"' then return table.concat(out), j + 1 end
            if c == "\\" then
                local n = s:sub(j + 1, j + 1)
                local map = { ['"'] = '"', ["\\"] = "\\", ["/"] = "/", b = "\b", f = "\f", n = "\n", r = "\r", t = "\t" }
                if map[n] then out[#out + 1] = map[n]; j = j + 2
                elseif n == "u" then
                    local hex = s:sub(j + 2, j + 5)
                    if not hex:match("^%x%x%x%x$") then err(s, j, "bad \\u escape") end
                    out[#out + 1] = utf8char(tonumber(hex, 16)); j = j + 6
                else err(s, j, "bad escape") end
            else out[#out + 1] = c; j = j + 1 end
        end
    end
    value = function(s, i)
        i = skip(s, i)
        local c = s:sub(i, i)
        if c == "{" then
            local obj = {}
            i = skip(s, i + 1)
            if s:sub(i, i) == "}" then return obj, i + 1 end
            while true do
                i = skip(s, i)
                if s:sub(i, i) ~= '"' then err(s, i, "expected a quoted key") end
                local k; k, i = str(s, i)
                i = skip(s, i)
                if s:sub(i, i) ~= ":" then err(s, i, "expected ':'") end
                obj[k], i = value(s, i + 1)
                i = skip(s, i)
                local d = s:sub(i, i)
                if d == "}" then return obj, i + 1 end
                if d ~= "," then err(s, i, "expected ',' or '}'") end
                i = skip(s, i + 1)
                if s:sub(i, i) == "}" then return obj, i + 1 end   -- tolerate a trailing comma
            end
        elseif c == "[" then
            local arr = {}
            i = skip(s, i + 1)
            if s:sub(i, i) == "]" then return arr, i + 1 end
            while true do
                arr[#arr + 1], i = value(s, i)
                i = skip(s, i)
                local d = s:sub(i, i)
                if d == "]" then return arr, i + 1 end
                if d ~= "," then err(s, i, "expected ',' or ']'") end
                i = skip(s, i + 1)
                if s:sub(i, i) == "]" then return arr, i + 1 end   -- tolerate a trailing comma
            end
        elseif c == '"' then return str(s, i)
        elseif s:sub(i, i + 3) == "true" then return true, i + 4
        elseif s:sub(i, i + 4) == "false" then return false, i + 5
        elseif s:sub(i, i + 3) == "null" then return nil, i + 4
        else
            local num = s:match("^-?%d+%.?%d*[eE]?[-+]?%d*", i)
            if num and num ~= "" and tonumber(num) then return tonumber(num), i + #num end
            err(s, i, "unexpected '" .. c .. "'")
        end
    end
    function json.decode(s)
        s = s:gsub("^\239\187\191", "")                       -- UTF-8 BOM
        local ok, v, i = pcall(value, s, 1)
        if not ok then return nil, v end
        i = skip(s, i)
        if i <= #s then return nil, "extra text after the end at character " .. i end
        return v
    end
    local function esc(str)
        return '"' .. str:gsub('[%c"\\]', function(ch)
            local m = { ['"'] = '\\"', ["\\"] = "\\\\", ["\n"] = "\\n", ["\r"] = "\\r", ["\t"] = "\\t" }
            return m[ch] or string.format("\\u%04x", ch:byte())
        end) .. '"'
    end
    function json.encodeFlat(obj, order)
        local lines = {}
        for _, k in ipairs(order) do
            local v = obj[k]
            local out
            if type(v) == "boolean" then out = tostring(v)
            elseif type(v) == "number" then out = tostring(v)
            else out = esc(tostring(v)) end
            lines[#lines + 1] = "  " .. esc(k) .. ": " .. out
        end
        return "{\n" .. table.concat(lines, ",\n") .. "\n}\n"
    end
end

-- Files -------------------------------------------------------------------------------------------
local MAX_FILE = 256 * 1024
local function readFile(path)
    local f = io.open(path, "rb")
    if not f then return nil end
    local s = f:read(MAX_FILE + 1)
    f:close()
    if s and #s > MAX_FILE then return nil, "file is larger than 256 KB" end
    return s or ""
end

local function writeFile(path, text)
    local f = io.open(path, "wb")
    if not f then return false end
    f:write(text)
    f:close()
    return true
end

-- Schemas -----------------------------------------------------------------------------------------
-- The schema file has two accepted names. CurseForge's "RSDragonwilds UE4SS Mods" category only
-- accepts .txt/.lua/.dll/.pak/.utoc/.ucas and rejects the whole archive over a .json, so builds for
-- that site ship the identical file as modmenu.txt. The contents are JSON either way; only the name
-- differs. .json is tried first so an existing install keeps loading exactly the file it always did.
local SCHEMA_FILES = { "modmenu.json", "modmenu.txt" }

local TYPES = { header = true, toggle = true, slider = true, number = true, choice = true, key = true, text = true, button = true }
-- 1.1: where a key works. Two settings on one key only clash when they share a place, or one is "anywhere".
local CONTEXTS = { world = true, chest = true, build = true, menus = true, anywhere = true }
local mods = {}          -- sorted list of mod entries
local modsById = {}

-- "1.0.15" < "1.1.0", compared number by number.
local function verLess(a, b)
    local pa, pb = {}, {}
    for d in tostring(a):gmatch("%d+") do pa[#pa + 1] = tonumber(d) end
    for d in tostring(b):gmatch("%d+") do pb[#pb + 1] = tonumber(d) end
    for i = 1, math.max(#pa, #pb) do
        local x, y = pa[i] or 0, pb[i] or 0
        if x ~= y then return x < y end
    end
    return false
end

local function round(v, decimals)
    local m = 10 ^ (decimals or 0)
    return math.floor(v * m + 0.5) / m
end

local function decimalsFor(s)
    if s.decimals then return math.max(0, math.min(4, math.floor(s.decimals))) end
    local step = s.step or 1
    if step >= 1 then return 0 end
    local d = 0
    while d < 4 and math.abs(step * 10 ^ d - math.floor(step * 10 ^ d + 0.5)) > 1e-9 do d = d + 1 end
    return d
end

-- Validates one setting. Returns a cleaned copy or nil plus a reason.
local function checkSetting(raw, idx, seen, restartDefault)
    if type(raw) ~= "table" then return nil, "setting " .. idx .. " is not an object" end
    local t = raw.type
    if type(t) ~= "string" or not TYPES[t] then return nil, "setting " .. idx .. ": unknown type '" .. tostring(t) .. "'" end
    if t == "number" then t = "slider" end
    local s = { type = t, label = type(raw.label) == "string" and raw.label:sub(1, 80) or nil,
                tooltip = type(raw.tooltip) == "string" and raw.tooltip:sub(1, 300) or nil }
    -- 2.0 (design 2): optional fields; 1.x copies known fields only, so a file using them still loads there.
    -- runsOn = where the value counts; a word it does not know is left out (no tag).
    local ro = raw.runsOn
    if ro == "yours" or ro == "host" or ro == "server" or ro == "both" then s.runsOn = ro end
    if t == "header" then
        s.label = s.label or ""
        s.idx = idx                                         -- 2.0: the fold state is kept per header
        if raw.collapsed == true then s.collapsed = true end   -- C10: anything but true = the section starts open
        return s
    end
    -- 2.0: showIf = { key = <a key in this file>, is = value or list }; checked against the file in loadSchema
    if type(raw.showIf) == "table" and type(raw.showIf.key) == "string" and raw.showIf.is ~= nil then
        s.showIf = { key = raw.showIf.key, is = raw.showIf.is }
    end
    if t == "button" then
        if type(raw.action) ~= "string" or raw.action == "" then return nil, "button " .. idx .. " needs an \"action\"" end
        s.action = raw.action:sub(1, 60)
        s.label = s.label or s.action
        return s
    end
    if type(raw.key) ~= "string" or not raw.key:match("^[%w_%.%-]+$") then
        return nil, "setting " .. idx .. " needs a \"key\" made of letters, digits, _ . -"
    end
    if seen[raw.key] then return nil, "setting " .. idx .. ": key '" .. raw.key .. "' is used twice" end
    s.key = raw.key
    s.label = s.label or raw.key
    if raw.restart == nil then s.restart = restartDefault == true else s.restart = raw.restart == true end
    if t == "toggle" then
        s.default = raw.default == true
    elseif t == "slider" then
        local mn, mx = tonumber(raw.min), tonumber(raw.max)
        if not mn or not mx or mn >= mx then return nil, "slider '" .. s.key .. "' needs min < max" end
        s.min, s.max = mn, mx
        s.step = tonumber(raw.step)
        if not s.step or s.step <= 0 then s.step = (mx - mn) / 100 end
        s.decimals = decimalsFor({ decimals = tonumber(raw.decimals), step = s.step })
        s.suffix = type(raw.suffix) == "string" and raw.suffix:sub(1, 8) or ""
        local d = tonumber(raw.default) or mn
        s.default = math.max(mn, math.min(mx, d))
    elseif t == "choice" then
        if type(raw.options) ~= "table" or #raw.options < 1 then return nil, "choice '" .. s.key .. "' needs an \"options\" list" end
        s.options = {}
        for _, o in ipairs(raw.options) do
            if type(o) == "string" or type(o) == "number" then s.options[#s.options + 1] = tostring(o):sub(1, 40) end
            if #s.options >= 50 then break end
        end
        if #s.options == 0 then return nil, "choice '" .. s.key .. "' has no usable options" end
        s.default = tostring(raw.default or s.options[1])
        local found = false
        for _, o in ipairs(s.options) do if o == s.default then found = true end end
        if not found then s.default = s.options[1] end
    elseif t == "key" then
        s.default = type(raw.default) == "string" and raw.default or "none"
        local c = type(raw.context) == "string" and raw.context:lower() or "anywhere"
        s.context = CONTEXTS[c] and c or "anywhere"
        -- 1.1.3: "keyNames": "unreal" = the mod binds Unreal key names itself (Key Unlocker), so keys UE4SS has no
        -- name for (Shift, Ctrl, Alt, the mouse wheel) are saved as the Unreal name instead of refused.
        if raw.keyNames == "unreal" then s.keyNames = "unreal" end
    elseif t == "text" then
        s.maxLength = math.max(1, math.min(200, tonumber(raw.maxLength) or 60))
        s.default = type(raw.default) == "string" and raw.default:sub(1, s.maxLength) or ""
    end
    -- 2.0: valueLabels = { "<value as formatValue prints it>" = "word" } for sliders, choices and toggles (C10)
    if type(raw.valueLabels) == "table" and (t == "slider" or t == "choice" or t == "toggle") then
        local vl, any = {}, false
        for k, v in pairs(raw.valueLabels) do
            if type(k) == "string" and type(v) == "string" then vl[k] = v:sub(1, 40); any = true end
        end
        if any then s.valueLabels = vl end
    end
    seen[s.key] = true
    return s
end

-- Converts a stored string (or JSON value) into the setting's type. nil = unusable.
local function coerce(s, v)
    if v == nil then return nil end
    if s.type == "toggle" then
        if type(v) == "boolean" then return v end
        local l = tostring(v):lower()
        if l == "true" or l == "1" or l == "yes" or l == "on" then return true end
        if l == "false" or l == "0" or l == "no" or l == "off" then return false end
        return nil
    elseif s.type == "slider" then
        -- 1.1: the number in the file is kept as it is, also outside min/max (a player's MaxResults = 200 on a
        -- 0-100 slider was cut to 100 and sent to the mod). Only moving the slider replaces it (panelTick).
        local n = tonumber(v)
        if not n or n ~= n or n == math.huge or n == -math.huge then return nil end
        return n
    elseif s.type == "choice" then
        v = tostring(v)
        for _, o in ipairs(s.options) do if o:lower() == v:lower() then return o end end
        return nil
    elseif s.type == "key" or s.type == "text" then
        v = tostring(v):gsub("[\r\n]", " ")
        if s.maxLength then v = v:sub(1, s.maxLength) end
        return v
    end
    return nil
end

local function formatValue(s, v)
    if s.type == "toggle" then return v and "true" or "false" end
    if s.type == "slider" then
        if s.decimals == 0 then return tostring(math.floor(v + 0.5)) end
        local str = string.format("%." .. s.decimals .. "f", v)
        return (str:gsub("0+$", ""):gsub("%.$", ""))
    end
    return tostring(v)
end

-- Config files ------------------------------------------------------------------------------------
local function stripComment(v)
    -- "value   # note" -> "value". A # or ; only starts a comment after whitespace.
    local cut = v:find("%s[#;]")
    if cut then return (v:sub(1, cut - 1):gsub("%s+$", "")), v:sub(cut) end
    return (v:gsub("%s+$", "")), ""
end

-- Lua files: settings written as plain assignments near the top of the script, e.g.
--     local MaxStack = 999          -- comment kept
--     ShowIcons = true,             (a field inside a settings table)
-- Only the first assignment to each name, with a literal number, true/false or quoted string, is used.
local function luaLiteral(v)
    local q = v:sub(1, 1)
    if q == '"' or q == "'" then
        local i = 2
        while i <= #v do
            local ch = v:sub(i, i)
            if ch == "\\" then i = i + 2
            elseif ch == q then
                local body = v:sub(2, i - 1):gsub("\\(.)", "%1")
                return body, v:sub(i + 1), q
            else i = i + 1 end
        end
        return nil
    end
    local b = v:match("^true") or v:match("^false")
    if b then return b == "true", v:sub(#b + 1) end
    local n = v:match("^%-?%d+%.?%d*")
    if n and tonumber(n) then return tonumber(n), v:sub(#n + 1) end
    return nil
end

local function luaLine(line)
    local indent, loc, name, eq, rest = line:match("^(%s*)(local%s+)([%a_][%w_]*)(%s*=%s*)(.-)%s*$")
    if not indent then
        indent, name, eq, rest = line:match("^(%s*)([%a_][%w_]*)(%s*=%s*)(.-)%s*$")
        loc = ""
    end
    if not indent or #indent > 8 then return nil end
    local val, tail, q = luaLiteral(rest)
    if val == nil then return nil end
    if not (tail:match("^%s*,?%s*$") or tail:match("^%s*,?%s*%-%-")) then return nil end
    return { pre = indent .. loc .. name .. eq, name = name, value = val, tail = tail, quote = q }
end

local function readConfig(m)
    local text = readFile(m.cfgPath)
    local found = {}
    if not text then return found end
    if m.format == "json" then
        local obj = json.decode(text)
        if type(obj) == "table" then found = obj
        else m.errors[#m.errors + 1] = "config file is not valid JSON; defaults shown" end
        return found
    end
    if m.format == "lua" then
        for line in (text .. "\n"):gmatch("([^\n]*)\n") do
            local l = luaLine((line:gsub("\r$", "")))
            if l and found[l.name] == nil then found[l.name] = l.value end
        end
        for _, st in ipairs(m.settings) do
            if st.key and found[st.key] == nil then
                m.errors[#m.errors + 1] = "'" .. st.key .. "' is not a plain value in " .. (m.cfgPath:match("[^\\]+$") or "the Lua file") .. ", so it cannot be changed here"
                st.locked = true
            end
        end
        return found
    end
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        line = line:gsub("\r$", "")
        local k, v = line:match("^%s*([%w_%.%-]+)%s*=%s*(.-)%s*$")
        if k then found[k] = (stripComment(v)) end
    end
    return found
end

local function loadValues(m)
    local found = readConfig(m)
    m.values = {}
    for _, s in ipairs(m.settings) do
        if s.key then
            local v = coerce(s, found[s.key])
            if v == nil then v = s.default end
            m.values[s.key] = v
        end
    end
end

local function saveValues(m)
    if m.format == "json" then
        local text = readFile(m.cfgPath)
        local obj = (text and json.decode(text)) or {}
        if type(obj) ~= "table" then obj = {} end
        local order, seenK = {}, {}
        for _, s in ipairs(m.settings) do
            if s.key then obj[s.key] = m.values[s.key]; order[#order + 1] = s.key; seenK[s.key] = true end
        end
        for k in pairs(obj) do if not seenK[k] and type(obj[k]) ~= "table" then order[#order + 1] = k end end
        return writeFile(m.cfgPath, json.encodeFlat(obj, order))
    end
    local text = readFile(m.cfgPath) or ""
    local nl = text:find("\r\n", 1, true) and "\r\n" or "\n"
    if m.format == "lua" then
        if text == "" then return false end
        local out, doneL, byKeyL = {}, {}, {}
        for _, st in ipairs(m.settings) do if st.key and not st.locked then byKeyL[st.key] = st end end
        for line in (text .. "\n"):gmatch("([^\n]*)\n") do
            line = line:gsub("\r$", "")
            local l = luaLine(line)
            local st = l and byKeyL[l.name]
            if st and not doneL[l.name] and coerce(st, l.value) == m.values[l.name] then
                doneL[l.name] = true                        -- 1.1: unchanged, the line stays as it was typed
            elseif st and not doneL[l.name] then
                local v = m.values[l.name]
                local lit
                if type(v) == "boolean" then lit = tostring(v)
                elseif type(v) == "number" then lit = formatValue(st, v)
                else
                    local q = l.quote or '"'
                    lit = q .. (tostring(v):gsub("\\", "\\\\"):gsub(q, "\\" .. q)) .. q
                end
                line = l.pre .. lit .. l.tail
                doneL[l.name] = true
            end
            out[#out + 1] = line
        end
        while #out > 0 and out[#out] == "" do out[#out] = nil end
        return writeFile(m.cfgPath, table.concat(out, nl) .. nl)
    end
    local lines, done = {}, {}
    local byKey = {}
    for _, s in ipairs(m.settings) do if s.key then byKey[s.key] = s end end
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        line = line:gsub("\r$", "")
        local indent, k, v = line:match("^(%s*)([%w_%.%-]+)%s*=%s*(.-)%s*$")
        local s = k and byKey[k]
        if s and not done[k] and coerce(s, (stripComment(v))) == m.values[k] then
            done[k] = true                                  -- 1.1: unchanged, the line stays as it was typed
        elseif s and not done[k] then
            local _, comment = stripComment(v)
            line = indent .. k .. " = " .. formatValue(s, m.values[k]) .. (comment ~= "" and ("   " .. comment:gsub("^%s+", "")) or "")
            done[k] = true
        end
        lines[#lines + 1] = line
    end
    while #lines > 0 and lines[#lines] == "" do lines[#lines] = nil end
    -- Settings missing from the file are only added when they differ from the default, so files stay tidy.
    local header = text:find("# Set in Mod Menu", 1, true) ~= nil
    for _, s in ipairs(m.settings) do
        if s.key and not done[s.key] and m.values[s.key] ~= s.default then
            if not header then lines[#lines + 1] = ""; lines[#lines + 1] = "# Set in Mod Menu"; header = true end
            lines[#lines + 1] = s.key .. " = " .. formatValue(s, m.values[s.key])
        end
    end
    return writeFile(m.cfgPath, table.concat(lines, nl) .. nl)
end

-- Shared variables --------------------------------------------------------------------------------
-- 1.1: a value is sent only when it differs from what Mod Menu sent last. Before, every menu open sent every
-- value of every mod again.
local sent = {}
local function share(name, v)
    if v ~= nil and sent[name] == v then return end
    local ok, e = pcall(function() ModRef:SetSharedVariable(name, v) end)
    if ok then sent[name] = v
    else log("could not publish " .. name .. ": " .. tostring(e)) end
end

local function publishAll(m)
    for _, s in ipairs(m.settings) do
        if s.key then share("ModMenu." .. m.id .. "." .. s.key, m.values[s.key]) end
    end
    share("ModMenu." .. m.id .. ".rev", m.rev)
end

-- Discovery ---------------------------------------------------------------------------------------
-- 1.1: is the mod switched on? UE4SS starts a mod whose folder has an enabled.txt, or that has a
-- "<folder> : 1" line in mods.txt. A page is drawn from modmenu.json either way, so say when neither is there.
local modsTxtCache = {}  -- Mods folder -> { [folder name, lower case] = "0" or "1" }; emptied on every discover()
local function modsTxtFor(root)
    local t = modsTxtCache[root]
    if t then return t end
    t = {}
    local text = readFile(root .. "\\mods.txt")
    for line in ((text or "") .. "\n"):gmatch("([^\n]*)\n") do
        local name, on = line:match("^%s*([^;:][^:]-)%s*:%s*(%d)")
        if name then t[name:lower()] = on end
    end
    modsTxtCache[root] = t
    return t
end

local function switchedOff(folder, dir)
    local f = io.open(dir .. "\\enabled.txt", "r")
    if f then f:close(); return nil end
    local root = dir:match("^(.*)[/\\][^/\\]*$")
    if not root then return nil end
    if modsTxtFor(root)[folder:lower()] == "1" then return nil end
    return "This mod is switched off: its folder has no enabled.txt and mods.txt does not set it to 1. "
        .. "Changes made here are saved, but do nothing until the mod is switched on."
end

local function loadSchema(folderName, dirPath)
    local m = { folder = folderName, dir = dirPath, errors = {}, settings = {}, values = {}, rev = 0, actionN = 0 }
    m.off = switchedOff(folderName, dirPath)
    local text, ferr = nil, nil
    for _, fname in ipairs(SCHEMA_FILES) do
        text, ferr = readFile(dirPath .. "\\" .. fname)
        if text then break end
    end
    if not text then m.errors[#m.errors + 1] = ferr or "modmenu.json could not be read"; text = nil end
    local doc, jerr = nil, nil
    if text then doc, jerr = json.decode(text) end
    if text and type(doc) ~= "table" then
        m.errors[#m.errors + 1] = "modmenu.json is not valid JSON: " .. tostring(jerr)
        doc = {}
    end
    doc = doc or {}
    m.id = (type(doc.id) == "string" and doc.id:match("^[%w_%-]+$")) and doc.id or folderName
    m.name = type(doc.name) == "string" and doc.name:sub(1, 40) or folderName
    m.author = type(doc.author) == "string" and doc.author:sub(1, 40) or nil
    m.version = (type(doc.version) == "string" or type(doc.version) == "number") and tostring(doc.version):sub(1, 20) or nil
    m.description = type(doc.description) == "string" and doc.description:sub(1, 300) or nil
    local ro = doc.runsOn                                      -- 2.0: the mod's own runsOn word (a setting's wins)
    if ro == "yours" or ro == "host" or ro == "server" or ro == "both" then m.runsOn = ro end
    if type(doc.minModMenu) == "string" and doc.minModMenu:match("^%d+[%d%.]*$") and verLess(VERSION, doc.minModMenu) then
        m.errors[#m.errors + 1] = "this page was made for Mod Menu " .. doc.minModMenu:sub(1, 12) .. " or newer and you have "
            .. VERSION .. "; update Mod Menu to see every setting"
    end
    local schema = tonumber(doc.schema) or 1
    if schema > SCHEMA then
        m.errors[#m.errors + 1] = "this mod needs a newer Mod Menu (file format " .. schema .. ")"
        return m
    end
    local c = type(doc.config) == "table" and doc.config or {}
    local file = type(c.file) == "string" and c.file or "config.txt"
    if file:find("%.%.") or file:find("^[/\\]") or file:find(":") then
        m.errors[#m.errors + 1] = "config file must be inside the mod folder"
        file = "config.txt"
    end
    m.format = (c.format == "json" or c.format == "lua") and c.format or "keyvalue"
    if m.format == "lua" and type(c.file) ~= "string" then file = "Scripts/main.lua" end
    m.cfgPath = dirPath .. "\\" .. file:gsub("/", "\\")
    local seen = {}
    if type(doc.settings) == "table" then
        for i, raw in ipairs(doc.settings) do
            if i > 200 then m.errors[#m.errors + 1] = "only the first 200 settings are shown"; break end
            local s, why = checkSetting(raw, i, seen, m.format == "lua")
            if s then m.settings[#m.settings + 1] = s else m.errors[#m.errors + 1] = why end
        end
    elseif text then
        m.errors[#m.errors + 1] = "modmenu.json has no \"settings\" list"
    end
    -- 2.0 (C10): a showIf naming no key of this file, or its own row, is dropped: that row always shows
    local keys = {}
    for _, st in ipairs(m.settings) do if st.key then keys[st.key] = true end end
    for _, st in ipairs(m.settings) do
        if st.showIf and (not keys[st.showIf.key] or st.showIf.key == st.key) then st.showIf = nil end
    end
    loadValues(m)
    return m
end

-- The Mods folder, whatever platform folder the game runs from. Steam is Binaries\Win64, Game Pass is
-- Binaries\WinGDK (reported by JourneyOver 2026-09-17: on Game Pass this returned nothing, so Mod Menu
-- listed 0 configurable mods on every launch).
local PLATFORM_DIRS = { "Win64", "WinGDK", "Win32", "WinArm64" }

local function modsDirTable()
    local ok, dirs = pcall(IterateGameDirectories)
    if not ok or type(dirs) ~= "table" then return nil end
    local bin = nil
    pcall(function() bin = dirs.Game.Binaries end)
    if type(bin) ~= "table" then return nil end
    -- 1.0.11: the platform folder this script runs from goes first. A Game Pass install with a stray
    -- Binaries\Win64\ue4ss (left from a Steam guide) used to list THAT folder, find 0 mods and never
    -- look in WinGDK (548 ssamanda8, 26 Sep; renaming the stray folder fixed it).
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    local own = src:match("[/\\][Bb]inaries[/\\]([^/\\]+)[/\\]")
    local order = { own }
    for _, plat in ipairs(PLATFORM_DIRS) do
        if plat ~= own then order[#order + 1] = plat end
    end
    for _, plat in ipairs(order) do
        local t = nil
        pcall(function() t = bin[plat].ue4ss.Mods end)
        if not t then pcall(function() t = bin[plat].Mods end) end
        if type(t) == "table" then return t end
    end
    -- any other platform folder that has a ue4ss/Mods inside it
    local found = nil
    pcall(function()
        for name, node in pairs(bin) do
            if not found and type(node) == "table" and not tostring(name):find("^__") then
                local t = nil
                pcall(function() t = node.ue4ss.Mods end)
                if not t then pcall(function() t = node.Mods end) end
                if type(t) == "table" then found = t end
            end
        end
    end)
    return found
end

-- Fallback when the directory listing gives nothing (seen on Game Pass, JourneyOver 2026-09-17: Mod Menu
-- found 0 configurable mods on every launch there). This script's own path tells us where the Mods folder
-- is, and a plain directory listing names the folders in it; each one is then probed for a modmenu.json by
-- opening the file. UE4SS's mods.txt is no use here: it only lists the built-in mods, not ones with enabled.txt.
--
-- Measured in game 2026-09-17: the io.popen call costs 5.5 s the first time (cmd.exe warm-up) and 500 ms
-- when warm, while the modmenu.json probes are free. discover() also runs from openPanel() ON THE GAME
-- THREAD, so this result is cached for the session: nobody installs a mod without restarting the game, and
-- half a second of freeze on every menu open would be worse than the bug this fixes.
local dirListCache = nil   -- nil = not tried, false = tried and found nothing, table = the result

local function modsFromDirListing()
    if dirListCache == false then return nil end
    if dirListCache then return dirListCache.list, dirListCache.root end
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    local scripts = src:match("^(.*)[/\\][^/\\]*$")
    local myFolder = scripts and scripts:match("^(.*)[/\\][^/\\]*$")
    local modsRoot = myFolder and myFolder:match("^(.*)[/\\][^/\\]*$")
    if not modsRoot then dirListCache = false; return nil end
    local ok, pipe = pcall(io.popen, 'dir /b /ad "' .. modsRoot .. '"')
    if not ok or not pipe then dirListCache = false; return nil end
    local out = {}
    local okRead = pcall(function()
        for line in pipe:lines() do
            local name = tostring(line):gsub("%s+$", "")
            if name ~= "" and #out < 100 then
                local found = false
                for _, fname in ipairs(SCHEMA_FILES) do
                    local probe = io.open(modsRoot .. "\\" .. name .. "\\" .. fname, "r")
                    if probe then probe:close(); found = true; break end
                end
                if found then
                    out[#out + 1] = { folder = name, path = modsRoot .. "\\" .. name }
                end
            end
        end
    end)
    pcall(function() pipe:close() end)
    if not okRead or #out == 0 then dirListCache = false; return nil end
    dirListCache = { list = out, root = modsRoot }
    return out, modsRoot
end

local function addMod(list, byId, folder, path, count)
    local okL, m = pcall(loadSchema, tostring(folder), tostring(path))
    if okL and m then
        local prev = modsById[m.id]
        if prev and prev.folder == m.folder then m.rev = prev.rev; m.actionN = prev.actionN end
        if byId[m.id] then
            m.errors[#m.errors + 1] = "id '" .. m.id .. "' is also used by " .. byId[m.id].folder
            m.id = m.id .. "_" .. m.folder
        end
        byId[m.id] = m
        list[#list + 1] = m
    else
        log("could not load " .. tostring(folder) .. ": " .. tostring(m))
    end
end

local warnedNoList, saidDirect = false, false
local DISC = { root = nil, how = "not listed yet" }   -- 1.1: which Mods folder the list came from (SAVE REPORT)

local function discover()
    modsTxtCache = {}
    local dirT = modsDirTable()
    DISC.tree = dirT                                       -- 2.0: MM.dirTree() (nil on the folder listing fallback)
    local list, byId = {}, {}
    if not dirT then
        -- Game Pass and any other layout IterateGameDirectories cannot walk: list the folder ourselves.
        local fallback, root = modsFromDirListing()
        -- discover() runs again on every menu open, so say each of these once, not every time.
        if not fallback then
            if not warnedNoList then
                warnedNoList = true
                log("could not list the Mods folder, and the folder listing fallback found nothing either")
            end
            return
        end
        if not saidDirect then
            saidDirect = true
            log("listed the Mods folder directly: " .. tostring(root))
        end
        DISC.root, DISC.how = tostring(root), "folder listing fallback"
        for i, entry in ipairs(fallback) do
            if i <= 100 then addMod(list, byId, entry.folder, entry.path) end
        end
        table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end)
        mods, modsById = list, byId
        for _, m in ipairs(mods) do publishAll(m) end
        return
    end
    DISC.root, DISC.how = nil, "the game's folder list"
    pcall(function() DISC.root = tostring(dirT.__absolute_path) end)
    local count = 0
    for folder, sub in pairs(dirT) do
        if type(sub) == "table" and not tostring(folder):find("^__") then
            local has = false
            for _, f in pairs(sub.__files or {}) do
                local okN, n = pcall(function() return tostring(f.__name) end)
                if okN then
                    local low = n:lower()
                    for _, fname in ipairs(SCHEMA_FILES) do
                        if low == fname then has = true end
                    end
                end
            end
            if has and count < 100 then
                count = count + 1
                local okL, m = pcall(loadSchema, tostring(folder), tostring(sub.__absolute_path))
                if okL and m then
                    local prev = modsById[m.id]
                    if prev and prev.folder == m.folder then m.rev = prev.rev; m.actionN = prev.actionN end
                    if byId[m.id] then
                        m.errors[#m.errors + 1] = "id '" .. m.id .. "' is also used by " .. byId[m.id].folder
                        m.id = m.id .. "_" .. m.folder
                    end
                    byId[m.id] = m
                    list[#list + 1] = m
                else
                    log("could not load " .. tostring(folder) .. ": " .. tostring(m))
                end
            end
        end
    end
    table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end)
    mods, modsById = list, byId
    for _, m in ipairs(mods) do publishAll(m) end
end

-- Keys --------------------------------------------------------------------------------------------
-- Config files use UE4SS key names (HOME, PAGE_UP, F8). The key picker uses Unreal names (Home, PageUp).
-- The numpad is the one family where the two naming schemes disagree on more than case: UE4SS says
-- NUM_SEVEN, Unreal says NumPadSeven, and the generic rule produced "NumSeven", which the key picker
-- does not know. Every numpad bind set from the menu was silently dead (found in game 2026-09-22).
-- 1.1.3: more keys differ than the numpad. UE4SS names keys after Windows (Slash is OEM_TWO, Enter is RETURN,
-- Up is UP_ARROW, the thumb buttons are XBUTTON_ONE / XBUTTON_TWO), and the generic rule saved names UE4SS does
-- not have (SLASH, ENTER, NUM_SLASH), so mods skipped the key without a word (Nexus 596). Checked 2026-10-20
-- against the real tables: Unreal names from the game exe's key list, UE4SS names from the installed UE4SS.dll,
-- what each OEM key is from the Windows SDK WinUser.h (VK_OEM_2 = '/?' on a US keyboard).
local TO_UE4SS = {
    NumPadZero = "NUM_ZERO", NumPadOne = "NUM_ONE", NumPadTwo = "NUM_TWO", NumPadThree = "NUM_THREE",
    NumPadFour = "NUM_FOUR", NumPadFive = "NUM_FIVE", NumPadSix = "NUM_SIX", NumPadSeven = "NUM_SEVEN",
    NumPadEight = "NUM_EIGHT", NumPadNine = "NUM_NINE", NumLock = "NUM_LOCK",
    Up = "UP_ARROW", Down = "DOWN_ARROW", Left = "LEFT_ARROW", Right = "RIGHT_ARROW",
    Enter = "RETURN", SpaceBar = "SPACE", BackSpace = "BACKSPACE", Insert = "INS", Delete = "DEL",
    Semicolon = "OEM_ONE", Equals = "OEM_PLUS", Comma = "OEM_COMMA", Hyphen = "OEM_MINUS", Period = "OEM_PERIOD",
    Slash = "OEM_TWO", Tilde = "OEM_THREE", LeftBracket = "OEM_FOUR", Backslash = "OEM_FIVE",
    RightBracket = "OEM_SIX", Apostrophe = "OEM_SEVEN",
    ThumbMouseButton = "XBUTTON_ONE", ThumbMouseButton2 = "XBUTTON_TWO",
}
local FROM_UE4SS = {}
for k, v in pairs(TO_UE4SS) do FROM_UE4SS[v] = k end
-- Names 1.1.2 and older saved for the numpad keys: still read as the right key.
local OLD_NUMPAD = { NUM_PERIOD = "Decimal", NUM_PLUS = "Add", NUM_MINUS = "Subtract", NUM_ASTERISK = "Multiply",
    NUM_SLASH = "Divide" }
-- The key names in UE4SS's Key table that the generic rule can produce (letters, digits and F keys added below).
local UE4SS_KEYS = {}
for n in ("TAB PAUSE CAPS_LOCK ESCAPE PAGE_UP PAGE_DOWN END HOME SCROLL_LOCK MULTIPLY ADD SUBTRACT DECIMAL DIVIDE "
    .. "LEFT_MOUSE_BUTTON RIGHT_MOUSE_BUTTON MIDDLE_MOUSE_BUTTON"):gmatch("%S+") do UE4SS_KEYS[n] = true end
for _, n in pairs(TO_UE4SS) do UE4SS_KEYS[n] = true end
for _, n in ipairs({ "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE" }) do
    UE4SS_KEYS[n] = true
end
for c = 65, 90 do UE4SS_KEYS[string.char(c)] = true end
for i = 1, 24 do UE4SS_KEYS["F" .. i] = true end

local function toUnrealKey(name)
    if not name or name == "" or name:lower() == "none" then return "None" end
    if name:match("^F%d+$") then return name end
    if not name:find("_") and name:find("%l") and name:find("%u", 2) then return name end   -- already Unreal: LeftShift
    local up = name:upper()
    if FROM_UE4SS[up] then return FROM_UE4SS[up] end
    if OLD_NUMPAD[up] then return OLD_NUMPAD[up] end
    local parts = {}
    for p in name:gmatch("[^_]+") do parts[#parts + 1] = p:sub(1, 1):upper() .. p:sub(2):lower() end
    return table.concat(parts)
end

-- The UE4SS name for a key the picker gave, or nil when UE4SS has none (Shift, Ctrl, Alt, the mouse wheel,
-- controller buttons, keys only some layouts have): those are refused, since no mod could use them.
local function fromUnrealKey(name)
    if not name or name == "" or name == "None" then return "none" end
    if name:match("^F%d+$") then return UE4SS_KEYS[name] and name or nil end
    if TO_UE4SS[name] then return TO_UE4SS[name] end
    local k = (name:gsub("(%l)(%u)", "%1_%2"):gsub("(%a)(%d)", "%1_%2"):upper())
    if UE4SS_KEYS[k] then return k end
    return nil
end

-- 1.1: key clash check on the values in use right now (the offline validator only sees defaults). Returns the
-- line for under a key row, or nil. Mods that are switched off are left out: their keys do nothing.
local RESERVED_KEYS = { F10 = "F10 opens the UE4SS console", F11 = "F11 is the game's fullscreen key" }

-- 1.1.3: a choice of keys takes part in the clash check like a key row (Storage Search's OpenKey: ALT+F, F,
-- none). It counts when its key name ends in "Key" and every option is a key, Alt/Ctrl/Shift + a key, or none.
-- A combo is compared whole, so ALT+F clashes with ALT+F, not with a plain F. It works everywhere.
local function isKeySetting(s)
    if s.type == "key" then return true end
    if s.type ~= "choice" or type(s.key) ~= "string" or not s.key:find("Key$") or type(s.options) ~= "table" then
        return false
    end
    if s.keyChoice == nil then
        s.keyChoice = #s.options > 0
        for _, o in ipairs(s.options) do
            local base = tostring(o):upper():gsub("^ALT%+", ""):gsub("^CTRL%+", ""):gsub("^SHIFT%+", "")
            if base ~= "NONE" and not UE4SS_KEYS[base] then s.keyChoice = false end
        end
    end
    return s.keyChoice
end

local function keyClash(m, s)
    local v = m.values[s.key]
    if m.off or type(v) ~= "string" or not isKeySetting(s) then return nil end
    local k = toUnrealKey(v)
    if k == "None" then return nil end
    local parts, others, more = {}, {}, 0
    if RESERVED_KEYS[v:upper()] then parts[#parts + 1] = RESERVED_KEYS[v:upper()] end
    for _, om in ipairs(mods) do
        if not om.off then
            for _, ost in ipairs(om.settings) do
                local ov = isKeySetting(ost) and not ost.locked and not (om == m and ost == s) and om.values[ost.key]
                local c1, c2 = s.context or "anywhere", ost.context or "anywhere"
                if type(ov) == "string" and toUnrealKey(ov) == k
                   and (c1 == "anywhere" or c2 == "anywhere" or c1 == c2) then
                    if #others < 3 then others[#others + 1] = (om == m and "" or (om.name .. ": ")) .. ost.label
                    else more = more + 1 end
                end
            end
        end
    end
    if #others > 0 then
        parts[#parts + 1] = v:upper() .. " is also the key for " .. table.concat(others, ", ")
            .. (more > 0 and (" and " .. more .. " more") or "")
    end
    if #parts == 0 then return nil end
    return "! " .. table.concat(parts, ". ") .. "."
end

-- A number as typed: 200, 0.125 (formatValue would round it to the slider's decimals).
local function plainNumber(n)
    if n == math.floor(n) and math.abs(n) < 1e15 then return string.format("%d", n) end
    return (string.format("%.6g", n))
end

-- Pause menu entry -------------------------------------------------------------------------------
-- Same block as our other mods (mods/_shared/pausemenu.lua).
-- The local, in-world player controller (never the front-end one, never a remote player's).
-- FindAllOf walks every object in the game (about 50 ms on the game thread, measured 2026-09-17),
-- so the controller is cached and a missing one is looked for at most every 3 seconds.
local cachedPC, nextPCScan = nil, 0
local function localPC()
    if cachedPC and valid(cachedPC) then
        local okL, isLocal = pcall(function() return cachedPC:IsLocalController() end)
        if okL and isLocal then return cachedPC end
    end
    cachedPC = nil
    local now = os.clock()
    if now < nextPCScan then return nil end
    nextPCScan = now + 3
    local ok, all = pcall(FindAllOf, "PlayerController")
    if not ok or not all then return nil end
    for _, pc in ipairs(all) do
        if valid(pc) then
            local okN, n = pcall(function() return pc:GetFullName() end)
            local okL, isLocal = pcall(function() return pc:IsLocalController() end)
            if okN and not tostring(n):find("MainMenu", 1, true) and okL and isLocal then cachedPC = pc; return pc end
        end
    end
    return nil
end

-- Any local controller, including the main menu's, so the menu also opens from the title screen.
local function anyPC()
    local pc = localPC()
    if pc then return pc end
    local ok, all = pcall(FindAllOf, "PlayerController")
    if not ok or not all then return nil end
    for _, p in ipairs(all) do
        local okL, isLocal = pcall(function() return p:IsLocalController() end)
        if valid(p) and okL and isLocal then return p end
    end
    return nil
end

local MENU = { label = "MOD", onOpen = nil, onClose = nil, labelFn = nil, shownLabel = nil, btn = nil, btnName = nil, pm = nil, closeName = nil, pending = nil, hooked = false, wait = 0, broken = false }

-- Controller support (1.0.12). A pad's A reaches CommonButtonBase:HandleButtonClicked from C++, so the UE4SS hook
-- that the mouse path relies on never sees it (measured 2026-09-29: 0 hooks fire for a pad click, even on the
-- game's own RESUME). But a SELECTABLE button does get selected by it, so pad presses are read by polling
-- GetSelected. The pad panel is docked inside the pause menu, where the game's own pad navigation reaches it,
-- with explicit navigation links (the pause list stops at its edges). Mouse, keyboard and the menu key keep the
-- overlay exactly as before. Functions are filled in next to the panel code below.
-- 1.0.13: laid out at 1580x910 with a 430-wide mod list (the game's slider row needs ~1000 wide and long mod
-- names ~420; at 1260 slider values and names were cut off) and drawn at 0.80 from the top-left corner, so it
-- still fills the same ~1260x730 space right of the pause list.
local PAD = { X = 600, Y = 180, W = 1580, H = 910, LEFT = 430, SCALE = 0.80, seen = false,
              -- C22 (T1-D5): short enough for one line at Text size 140 in the 1440 content width
              HINT = "Pad: Right enters, A selects, LB / RB switch mods, X resets, tap Y pins, B closes (your place is kept)." }
-- 1.0.14: one docked pause-menu panel at a time, shared with other mods (Storage Search 2.1 docks at the same spot).
-- Functions are next to the PAD ones below.
local DOCK = { ID = "ModMenu", rev = nil }
local ALLCAPS = "/Game/UI/Common/WBP_DomAllCapsButton"

local function makeGameButton(pc, label, like)
    local cls = nil
    pcall(function() LoadAsset(ALLCAPS) end)
    pcall(function() cls = StaticFindObject(ALLCAPS .. ".WBP_DomAllCapsButton_C") end)
    if not valid(cls) then return nil end
    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local b = nil
    pcall(function() b = wbl:Create(pc, cls, pc) end)
    if not valid(b) then return nil end
    if valid(like) then
        pcall(function() b:SetStyle(like.Style) end)
        pcall(function() b:SetTextTransformPolicy(like.TextTransformPolicy) end)
        pcall(function() b.bCenterAlignText = like.bCenterAlignText end)
        pcall(function() b.LeftAlignTextPadding = like.LeftAlignTextPadding end)
        pcall(function() b.bScrollText = like.bScrollText end)
    end
    pcall(function() b:SetLabelText(FText(label)) end)
    return b
end

-- The game creates its pause menu the first time Esc is pressed. Searching for it with FindFirstOf
-- walks every object (35-50 ms on the game thread), so instead the game tells us when one is created
-- (the callback only stores it), plus one fallback search shortly after Esc.
local pauseSeen, pauseKnown, pauseLookAt = {}, nil, 0
pcall(NotifyOnNewObject, "/Script/Dominion.PauseMenuScreen", function(obj) pauseSeen[#pauseSeen + 1] = obj end)
pcall(RegisterKeyBind, Key.ESCAPE, function() pauseLookAt = os.clock() + 0.5 end)
local function usablePause(pm)
    if not valid(pm) then return false end
    local okN, n = pcall(function() return pm:GetFName():ToString() end)
    return okN and not tostring(n):find("^Default__")
end
local function findPauseMenu()
    if valid(MENU.pm) then return MENU.pm end
    while #pauseSeen > 0 do                            -- newest first
        local pm = table.remove(pauseSeen)
        if usablePause(pm) then pauseSeen = {}; pauseKnown = pm end
    end
    if usablePause(pauseKnown) then return pauseKnown end
    if pauseLookAt > 0 and os.clock() >= pauseLookAt then
        pauseLookAt = 0
        local ok, pm = pcall(FindFirstOf, "WBP_PauseMenuScreen_C")
        if ok and usablePause(pm) then pauseKnown = pm; return pm end
    end
    return nil
end

local function hookClicks()
    if MENU.hooked then return end
    MENU.hooked = true
    local ok = pcall(RegisterHook, "/Script/CommonUI.CommonButtonBase:HandleButtonClicked", function(self)
        local okN, n = pcall(function() return self:get():GetFullName() end)
        if not okN then return end
        if n == MENU.btnName then MENU.pending = "open"
        elseif MENU.closeName and n == MENU.closeName then MENU.pending = "close" end
    end)
    if not ok then log("could not watch menu clicks; use the key instead") end
end

local function menuHas(box, w)
    local ok, idx = pcall(function() return box:GetChildIndex(w) end)
    return ok and type(idx) == "number" and idx >= 0
end

-- BEGIN pause-list-fit (the same block in every mod with a pause entry; tools/test_pausemenu_pad_offline.lua checks every copy)
-- The game's VerticalBox_PauseMenu sits in a CanvasPanelSlot 680x205 with AutoSize off. Entries drawn below that
-- box still take a mouse click, but a controller's D-pad stops at the last entry near it (run c1006c, 2026-10-06:
-- 15 entries, Down stopped at the 9th). AutoSize on reached every entry but moved the list up ~145 px, under the
-- logo. So this grows the slot's height to the list's desired height and moves its offset so the TOP edge stays
-- where the game put it (non-stretched slot: top = Offsets.Top - Alignment.Y * height). It never shrinks the slot,
-- and every mod runs the same math, so several mods calling it agree: a call with nothing new is a no-op. Called
-- after our entry is added (force) and on every later tick, where it only reads the entry count and the height,
-- and measures again when either changed (another mod added an entry, or the game reset the slot).
local fitPauseList = nil
do
    local FIT = { n = -1, h = -1, again = 0, warned = false }
    local function rd(f)
        local ok, v = pcall(f)
        if ok and type(v) == "number" and v == v then return v end
        return nil
    end
    function fitPauseList(box, force)
        if force then FIT.again = 3 end                       -- the new button's size settles over a layout pass or two
        if not valid(box) then return nil end
        local slot = nil
        pcall(function() slot = box.Slot end)
        if not valid(slot) then return nil end
        local n = rd(function() return box:GetChildrenCount() end)
        local h = rd(function() return slot:GetOffsets().Bottom end)
        if not (n and h) then return nil end
        if n == FIT.n and FIT.again <= 0 and h >= FIT.h - 0.5 then return h end
        FIT.n = n
        FIT.h = h
        if FIT.again > 0 then FIT.again = FIT.again - 1 end
        local auto = false
        pcall(function() auto = slot:GetAutoSize() end)
        if auto == true then return h end                     -- already sized by its content
        local top = rd(function() return slot:GetOffsets().Top end)
        local left = rd(function() return slot:GetOffsets().Left end)
        local right = rd(function() return slot:GetOffsets().Right end)
        local minY = rd(function() return slot:GetAnchors().Minimum.Y end)
        local maxY = rd(function() return slot:GetAnchors().Maximum.Y end)
        local alY = rd(function() return slot:GetAlignment().Y end)
        if not (top and left and right and minY and maxY and alY) then return nil end
        if math.abs(maxY - minY) > 0.0001 then                -- stretched: its height comes from the parent
            if not FIT.warned then FIT.warned = true; log("pause list: stretched slot, height left to the game") end
            return h
        end
        pcall(function() box:ForceLayoutPrepass() end)
        local need = rd(function() return box:GetDesiredSize().Y end)
        if not need or need <= 0 then
            if not FIT.warned then FIT.warned = true; log("pause list: could not read its desired height") end
            return nil
        end
        need = math.ceil(need)
        if need <= h + 0.5 then return h end                  -- tall enough already: never shrink
        local edge = top - alY * h                            -- the top edge the game laid out
        local ok = pcall(function() slot:SetOffsets({ Left = left, Top = edge + alY * need, Right = right, Bottom = need }) end)
        if not ok then return nil end
        FIT.h = need
        log(string.format("pause list: %d entries, height %d -> %d, top edge kept at %d", n, math.floor(h + 0.5), need, math.floor(edge + 0.5)))
        return need
    end
end
-- END pause-list-fit

local function ensureMenuButton()
    if valid(MENU.pm) and valid(MENU.btn) then
        local box = MENU.pm.VerticalBox_PauseMenu
        if valid(box) and menuHas(box, MENU.btn) then
            fitPauseList(box)
            if MENU.labelFn then
                local l = MENU.labelFn()
                if l ~= MENU.shownLabel then pcall(function() MENU.btn:SetLabelText(FText(l)) end); MENU.shownLabel = l end
            end
            return
        end
    end
    if MENU.broken then return end
    if MENU.wait > 0 then MENU.wait = MENU.wait - 1; return end
    MENU.wait = 4
    MENU.pm = nil
    local pc = localPC()                               -- no world, no pause menu: skip the object search
    if not pc then return end
    local pm = findPauseMenu()
    if not pm then return end
    local box = pm.VerticalBox_PauseMenu
    if not valid(box) then return end
    local label = MENU.labelFn and MENU.labelFn() or MENU.label
    local b = makeGameButton(pc, label, pm.SettingsButton)
    if not b then return end
    local own = {}
    for _, name in ipairs({ "ResumeButton", "AgilityCourseSection", "PlayerListButton", "WorldDetails",
                            "SettingsButton", "ExitToMainMenuButton", "ExitToDesktopMenu" }) do
        local w = pm[name]
        if valid(w) then own[w:GetFullName()] = true end
    end
    local function sortKey(w)
        local okL, l = pcall(function() return w.ButtonLabel:ToString() end)
        l = okL and tostring(l) or ""
        return (l:gsub("^SHOW ", ""):gsub("^HIDE ", ""))
    end
    local extras = { b }
    for i = box:GetChildrenCount() - 1, 0, -1 do
        local c = box:GetChildAt(i)
        if valid(c) and not own[c:GetFullName()] then extras[#extras + 1] = c end
    end
    local exits = {}
    for _, name in ipairs({ "ExitToMainMenuButton", "ExitToDesktopMenu" }) do
        local e = pm[name]
        if valid(e) and menuHas(box, e) then exits[#exits + 1] = e end
    end
    for _, w in ipairs(extras) do if w ~= b then pcall(function() box:RemoveChild(w) end) end end
    for _, e in ipairs(exits) do pcall(function() box:RemoveChild(e) end) end
    table.sort(extras, function(x, y) return sortKey(x) < sortKey(y) end)
    for _, w in ipairs(extras) do pcall(function() box:AddChildToVerticalBox(w) end) end
    for _, e in ipairs(exits) do pcall(function() box:AddChildToVerticalBox(e) end) end
    MENU.pm, MENU.btn, MENU.btnName = pm, b, b:GetFullName()
    if not menuHas(box, b) then
        MENU.broken = true
        log("pause menu button could not be confirmed; use the key instead")
        return
    end
    fitPauseList(box, true)                          -- c1006c: grow the list so a D-pad reaches every entry, top kept
    hookClicks()
    pcall(function() b:SetIsSelectable(true) end)      -- after it is built: a pad's A then selects it (PAD.pollMods)
    MENU.shownLabel = label
    log("added " .. MENU.label .. " to the pause menu")
end

local function menuTick()
    if MENU.pending == "open" then
        MENU.pending = "open2"
        PAD.unselect(MENU.btn)                         -- the mouse click selected it too; not a pad press
        pcall(function() MENU.pm:Resume() end)
    elseif MENU.pending == "open2" then
        MENU.pending = nil
        local ok, err = pcall(MENU.onOpen)
        if not ok then log("menu error: " .. tostring(err)) end
    elseif MENU.pending == "close" then
        MENU.pending = nil
        if MENU.onClose then pcall(MENU.onClose) end
    elseif cfg.ShowInPauseMenu then
        ensureMenuButton()
        PAD.pollMods()
    end
end

-- Panel -------------------------------------------------------------------------------------------
-- C44: UE takes LINEAR colors (FLinearColor, brushes and text alike); these are the mockup's sRGB hexes converted
-- (the old values were sRGB numbers read as linear, so every color drew paler than the mockup)
local GOLD  = { R = 0.694, G = 0.445, B = 0.107, A = 1.0 }   -- #d9b25c
local CREAM = { R = 0.863, G = 0.791, B = 0.644, A = 1.0 }   -- #efe6d2 (ink)
local GREY  = { R = 0.397, G = 0.337, B = 0.231, A = 1.0 }   -- #a99d84 (dim)
local RED   = { R = 0.584, G = 0.162, B = 0.102, A = 1.0 }   -- #c9705a (off)

local function loadClass(pkg)
    local asset = pkg:match("([^/]+)$")
    pcall(function() LoadAsset(pkg) end)
    local c = nil
    pcall(function() c = StaticFindObject(pkg .. "." .. asset .. "_C") end)
    return valid(c) and c or nil
end

local function construct(cls, tree)
    local c = StaticFindObject("/Script/UMG." .. cls)
    return StaticConstructObject(c, tree)
end

local panel = { open = false, page = 1, rows = {}, buttons = {}, pending = nil, dirty = {}, lastEdit = 0 }
local buildModList   -- defined below the page builder

-- 2.0 (docs/modmenu-2.0-design.md 1.3): MM is the one table core hands its modules (quickpanel, keys, health,
-- builtin); they get nothing else from core. Core's own new state lives in LAY (layout) and NAV (views, the kept
-- place, controller), never in new top-level locals: this chunk is near Lua's limit of 200 locals per function.
local MM = { VERSION = VERSION, builtin = {}, modState = {} }
local LAY = { T = 1.0 }
local NAV = {}
local modCall            -- a pcall'd module call; defined with the module loader near the end
local saveOwn            -- edits one line of Mod Menu's own config.txt; defined with the own settings near the end

-- Whole-panel size. A render transform scales the frame and everything inside it together, which is
-- the only approach that keeps the layout intact: the panel's width comes from fixed SizeBox
-- overrides (LEFT, rightW, the 440-wide label column), not from a size value, so a font setting
-- would leave the boxes behind.
--
-- Two things differ from the same setting in XP Tracker, and both matter:
--
--  * The pivot is the center, not (0,0). XP Tracker anchors its panel to a corner the position
--    sliders set, so it grows down and right from there. This panel is re-centered every time it
--    opens, so it has to grow from its middle or it drifts off center as it scales.
--  * The value is clamped to what actually fits. At 100% the panel is already 1500x920, most of a
--    1080p screen, so an unclamped 200% would push CLOSE and RESET past the edge with no way to
--    reach them. maxFit below makes that unreachable regardless of what is in config.txt.
local function fitScale(s, vw, vh, w, h)
    if s < 50 then s = 50 elseif s > 200 then s = 200 end
    s = s / 100
    if w > 0 and h > 0 then
        local maxFit = math.min((vw - 40) / w, (vh - 40) / h)
        if maxFit > 0 and s > maxFit then s = maxFit end
    end
    return s
end

-- 1.1.1: ModMenu.rect, the box the panel covers on screen (after its scale), for mods that dock beside it.
local function shareRect(p)
    local r = ""
    if p.open then
        local function n(v) return math.floor(v + 0.5) end
        if p.mode == "pad" then
            r = ("pad:%d,%d,%d,%d"):format(PAD.X, PAD.Y, n(PAD.W * PAD.SCALE), n(PAD.H * PAD.SCALE))
        else
            local s = fitScale(100, p.vw or 1920, p.vh or 1080, p.w or 0, p.h or 0)   -- 2.0: fit only (C8b)
            local vw, vh, w, h = p.vw or 1920, p.vh or 1080, (p.w or 0) * s, (p.h or 0) * s
            r = ("view:%d,%d,%d,%d"):format(n((vw - w) / 2), n((vh - h) / 2), n(w), n(h))
        end
    end
    share("ModMenu.rect", r)
end

local function applyScale(p)
    if valid(p.frame) and p.mode ~= "pad" then             -- the docked pad panel keeps the menu's layout
        -- 2.0: only shrunk to fit the screen; PanelScale is now the text size (ruling C8b), see LAY.textSize
        local s = fitScale(100, p.vw or 1920, p.vh or 1080, p.w or 0, p.h or 0)
        pcall(function() p.frame:SetRenderTransformPivot({ X = 0.5, Y = 0.5 }) end)
        pcall(function() p.frame:SetRenderScale({ X = s, Y = s }) end)
    end
    shareRect(p)
end

local function newText(tree, cls, s, size, color, kind)
    local tb = StaticConstructObject(cls, tree)
    -- C28: the game's own fonts on OUR text (LAY.font: loaded once, cached; nil = the text block's own font)
    local fo = LAY.font and LAY.font(kind or "body") or nil
    pcall(function()
        local f = tb.Font
        f.Size = size
        if fo then
            f.FontObject = fo
            local tf = LAY.TYPEFACE and LAY.TYPEFACE[kind or "body"]
            if tf then f.TypefaceFontName = FName(tf) end
        end
        tb:SetFont(f)
    end)
    pcall(function() tb:SetColorAndOpacity({ SpecifiedColor = color, ColorUseRule = 0 }) end)
    pcall(function() tb:SetAutoWrapText(true) end)
    pcall(function() tb:SetText(FText(s)) end)
    return tb
end

local function setInputUI(pc, focusWidget, on)
    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    pcall(function() pc.bShowMouseCursor = on end)
    if on then
        -- UI only while a panel is open. With game-and-UI, a click that lands on the window but not on a
        -- button falls through to the game and swings your weapon, which near a cliff can walk you off it
        -- (reported by CabolaDK, 2026-09-17). Esc still closes the panel: that is a UE4SS key bind, not game input.
        local okUI = pcall(function() wbl:SetInputMode_UIOnlyEx(pc, focusWidget, 0, false) end)
        if not okUI then pcall(function() wbl:SetInputMode_GameAndUIEx(pc, focusWidget, 0, false, false) end) end
    else
        pcall(function() wbl:SetInputMode_GameOnly(pc, false) end)
    end
end

-- Dark, game-colored look for the native text box and key picker (they default to white).
-- Must run before the widget is added to a panel (the style is copied when it is built).
-- Verified in game 2026-09-16: writing the style struct back works for both widget types.
local function styleInput(w)
    if not valid(w) then return end
    local function col(r, g, b, a) return { SpecifiedColor = { R = r, G = g, B = b, A = a }, ColorUseRule = 0 } end
    pcall(function()
        local st = w.WidgetStyle
        local cls = w:GetClass():GetFName():ToString()
        if cls == "EditableTextBox" then
            st.BackgroundColor = col(0.03, 0.028, 0.025, 1.0)
            st.ForegroundColor = col(CREAM.R, CREAM.G, CREAM.B, 1.0)
            st.FocusedForegroundColor = col(1.0, 0.95, 0.85, 1.0)
            for _, name in ipairs({ "BackgroundImageNormal", "BackgroundImageHovered", "BackgroundImageFocused" }) do
                local br = st[name]
                br.TintColor = col(name == "BackgroundImageNormal" and 0.06 or 0.10, 0.055, 0.05, 1.0)
                st[name] = br
            end
        else
            for _, name in ipairs({ "Normal", "Hovered", "Pressed" }) do
                local br = st[name]
                local v = name == "Normal" and 0.05 or (name == "Hovered" and 0.12 or 0.08)
                br.TintColor = col(v, v * 0.92, v * 0.85, 1.0)
                st[name] = br
            end
            pcall(function() w:SetNoKeySpecifiedText(FText("Not set")) end)
            pcall(function() w:SetKeySelectionText(FText("Press a key...")) end)
            local ts = w.TextStyle
            ts.ColorAndOpacity = col(GOLD.R, GOLD.G, GOLD.B, 1.0)
            w.TextStyle = ts
        end
        w.WidgetStyle = st
    end)
end

local function sized(tree, w, width, height)
    local sz = construct("SizeBox", tree)
    if width then pcall(function() sz:SetWidthOverride(width) end) end
    if height then pcall(function() sz:SetHeightOverride(height) end) end
    sz:AddChild(w)
    return sz
end

-- 1.0.14: slider values stay on the setting's "step", and a controller press moves exactly one step.
-- The game's slider row (native SliderUIInput) moves a pad press by (max - min) / 9 from the current value
-- (its NumGamepadSliderIncrements; measured 2026-10-06, run c1006: +1.055 on 0.5-10, -0.22 on Spell Sliders,
-- +16.7 on 0-150; probe 2026-09-29: +11 on 0-100), and SetStepSize does not change that, so 2.00x or 60 px
-- could not be set with a pad. In the docked controller panel a change of whole native presses since the
-- last tick becomes the same number of steps; any other change (a mouse drag) snaps to the nearest step.
-- panelTick writes the result back to the widget (settleSlider), so the next press starts on the grid.
-- 1.1.3 (run w3, game 1.0.1, also on 1.1.2): one press moved 1 to 7 steps, the native press no longer adds a ninth
-- of the range to the value, so the press count could not be read from the change. In the controller panel a slider
-- that moved since the last tick now moves exactly one step in that direction; the exact value is written back.
-- BEGIN slider-step (tools/test_modmenu_slider_steps_offline.lua loads this block on its own)
local NATIVE_PAD_STEPS = 9

-- Float tolerance: the widget stores a float32, so compare with a margin relative to the slider's size.
local function stepEps(s)
    return math.max(s.max - s.min, math.abs(s.max), math.abs(s.min)) * 1e-6
end

-- 1.1.3 (Spell Sliders "creep", jimbot70 2026-10-19; measured run w2 T3): the native slider jumps to the cursor on a
-- press, so a click on the handle more than half a step from its center moved the value a step (cooldown 1.70 ->
-- 1.75 -> 1.80 with clicks 6 px right of center; handle ~14 px wide, track 360 px). A press and release with no drag
-- is now no change. Called each tick in mouse mode with base = the value the row showed before (row.hold or
-- row.last), raw = what the slider reads now, cur = { still = the cursor has not moved since the last tick, cap = the
-- slider holds the mouse (nil = unknown), x, y }. True = the slider's value is a click to put back.
-- A change counts as a click when it is small (at most one step, or 2.5% of the range: half a handle) and shows no
-- drag: the cursor stood still since the last tick, or (once HasMouseCapture has been seen to work) the press began
-- and ended between two ticks. While the press is held, moving the cursor or the value makes it a drag.
-- 1.1.3 (run w3: a quick aim and click still moved a step 5 times in 8, the tick landed during the press after the
-- cursor had moved): a tick that sees the press held (cap) and a small change holds it, "hold" = no write. The press
-- point is the cursor at the first tick that saw the capture. The cursor more than 2 px from it while held = a drag,
-- kept at once; released without that = a click, put back.
-- 2.0 (W4 in game: a quick one-step drag, press + 2 moves 40 ms apart + 150 ms still, was put back 2 times in 7): the
-- first capture tick can land after such a drag ended, so the cursor there is the drag's end. When the tick before it
-- saw no press, its cursor is the press point instead, if it looks like the start of a drag: the same height (3 px),
-- 3 to DRAG_REACH px away, on the side the value moved to. A quick aim and click comes from farther away or from
-- another height (W4: 62 px below), so it still reads as a click.
local DRAG_REACH = 30
local CAPTURE_SEEN = false
local function handleClick(row, s, base, raw, cur)
    if cur.cap then CAPTURE_SEEN = true end
    local capPrev = row.capPrev
    row.capPrev = cur.cap
    local before = row.freeAt
    row.freeAt = (cur.cap ~= true and cur.x ~= nil) and { x = cur.x, y = cur.y } or nil
    if cur.cap == true and capPrev ~= true then
        row.pressAt = { x = cur.x, y = cur.y }
        if before and cur.x and cur.y and type(base) == "number" then
            local dx, dy = cur.x - before.x, cur.y - before.y
            if math.abs(dy) <= 3 and math.abs(dx) > 2 and math.abs(dx) <= DRAG_REACH and (dx > 0) == (raw > base) then
                row.pressAt = before
            end
        end
    end
    local press = row.pressAt
    if cur.cap ~= true then row.pressAt = nil end
    local eps = stepEps(s)
    if type(base) ~= "number" or math.abs(raw - base) <= eps then row.click = nil; return false end
    local c = row.click
    local again = false
    if c and math.abs(raw - c.raw) > eps then c = nil; again = true end   -- the value moved again since: a drag
    if not c then
        if math.abs(raw - base) > math.max(s.step, (s.max - s.min) * 0.025) + eps then row.click = nil; return false end
        local quick = CAPTURE_SEEN and cur.cap == false and capPrev == false
        local held = cur.cap == true and not again
        if not (cur.still or quick or held) then row.click = nil; return false end
        c = { raw = raw, x = cur.x, y = cur.y }
        row.click = c
    end
    if cur.cap then
        local a = press or c
        if cur.x == nil or a.x == nil or math.abs(cur.x - a.x) > 2 or math.abs(cur.y - a.y) > 2 then
            row.click = nil                                  -- held and dragged: an ordinary change
            return false
        end
        return "hold"
    end
    return true
end

local function snapToStep(s, v)
    local eps = stepEps(s)
    if v >= s.max - eps then return round(s.max, s.decimals) end
    if v <= s.min + eps then return round(s.min, s.decimals) end
    local lo = s.min + math.floor((v - s.min) / s.step) * s.step
    local hi = math.min(s.max, lo + s.step)
    return round((v - lo <= hi - v) and lo or hi, s.decimals)
end

-- k steps from `last` in direction dir: the first grid point past it, then k - 1 more.
local function stepFrom(s, last, dir, k)
    local n = (last - s.min) / s.step
    local i = dir > 0 and (math.floor(n + 1e-6) + k) or (math.ceil(n - 1e-6) - k)
    local v = snapToStep(s, s.min + i * s.step)
    -- "decimals" coarser than the grid (Gravity: 0.25 + 0.1 steps shown with 1 decimal) can round a step back
    -- onto the old value; take one more step so a press always moves
    if v == last then v = snapToStep(s, s.min + (i + dir) * s.step) end
    return v
end

-- The value to keep for a slider whose widget reads `raw` (unrounded), given the value kept last tick.
-- shown = what the widget held after last tick (row.shown, set by settleSlider): unchanged = not a new press.
local function sliderStep(s, last, raw, pad, shown)
    if type(last) ~= "number" then return snapToStep(s, raw) end
    local eps = stepEps(s)
    local d = raw - last
    if math.abs(d) <= eps then return last end              -- untouched: a stored off-grid value stays as it is
    if pad and (type(shown) ~= "number" or math.abs(raw - shown) > eps) then
        return stepFrom(s, last, d > 0 and 1 or -1, 1)       -- 1.1.3: one press = exactly one step
    end
    return snapToStep(s, raw)
end
-- END slider-step

local function readWidget(row)
    local s, w = row.setting, row.widget
    if not valid(w) then return nil end
    if s.type == "toggle" then
        local ok, v = pcall(function() return w.InputCheckBox:IsChecked() end)
        if ok and type(v) == "boolean" then return v end
    elseif s.type == "slider" then
        local ok, v = pcall(function() return w:GetValue() end)
        if ok and type(v) == "number" then return round(v, s.decimals), v end   -- 1.0.14: + the raw value
    elseif s.type == "choice" then
        if row.cycle then return row.cycleValue end
        local ok, t = pcall(function() return w.SelectionDisplayText:GetText():ToString() end)
        if ok and t then
            for _, o in ipairs(s.options) do if o:lower() == tostring(t):lower() then return o end end
        end
    elseif s.type == "key" then
        local ok, n = pcall(function() return w.SelectedKey.Key.KeyName:ToString() end)
        if ok and n then
            local k = fromUnrealKey(tostring(n))
            if k then return k end
            -- A file value with no UE4SS name (LEFT_SHIFT typed for Key Unlocker) is kept as typed, no message.
            if tostring(n):lower() == toUnrealKey(row.last):lower() then return nil end
            -- A row marked "keyNames": "unreal" takes any keyboard or mouse key, saved as its Unreal name.
            if s.keyNames == "unreal" and not tostring(n):find("^Gamepad") then return tostring(n) end
            -- 1.1.3: a key UE4SS has no name for is not saved; the picker goes back to the key it had.
            panel.flash = { text = "! " .. tostring(n) .. " cannot be used: UE4SS has no name for it, so no mod could "
                .. "read it. Pick another key.", till = os.clock() + 8 }
            log("key picker: " .. tostring(n) .. " refused for " .. tostring(s.key) .. " (no UE4SS key name)")
            pcall(function() w:SetSelectedKey({ Key = { KeyName = FName(toUnrealKey(row.last)) } }) end)
        end
    elseif s.type == "text" then
        local ok, t = pcall(function() return w:GetText():ToString() end)
        if ok and t then return tostring(t):sub(1, s.maxLength) end
    end
    return nil
end

local function writeWidget(row, v)
    local s, w = row.setting, row.widget
    if s.type == "toggle" then pcall(function() w:SetValue(v) end)
    elseif s.type == "slider" then
        -- 1.1.2: the slider inside the row takes the exact value. The row's own SetValue snaps to 9 steps of the
        -- range (80 -> 76.67 on 30-100, read back as 75; 70 showed "69%"); found by run ccall 2026-10-14.
        local sl = nil
        pcall(function() sl = w.InputSlider end)
        if valid(sl) then pcall(function() sl:SetValue(v) end)
        else pcall(function() w:SetValue(v) end) end
        pcall(function() w:UpdateValueText() end)
    elseif s.type == "choice" then
        if row.cycle then
            row.cycleValue = v
            -- 2.0: the label is in the row's own column; the button shows the value (its valueLabel when it has one)
            local t = (MM.display and MM.display(s, v)) or tostring(v)
            if row.cycleText then LAY.setText(row.cycleText, t)       -- C45.4: our text over the button (wraps)
            else
                if row.fitW and LAY.fit then t = LAY.fit(t, row.fitW) end   -- C27: never past the button's box
                pcall(function() w:SetLabelText(FText(t)) end)
            end
        else
            for i, o in ipairs(s.options) do
                if o == v then pcall(function() w:SetSelectedIndex(i - 1) end) end
            end
        end
    elseif s.type == "key" then
        pcall(function() w:SetSelectedKey({ Key = { KeyName = FName(toUnrealKey(v)) } }) end)
    elseif s.type == "text" then
        pcall(function() w:SetText(FText(v)) end)
    end
end

-- 1.0.14: show the kept slider value. With a controller (docked panel) at once, so the next press starts on the
-- grid; with the mouse only once the slider has stopped moving for a tick, so a drag is never fought. A value
-- the widget did not take is not written again until the slider moves (no write every tick).
local function settleSlider(row, raw, v, pad)
    local eps = stepEps(row.setting)
    local prev = row.raw
    row.raw, row.shown = raw, raw                       -- 1.1.3: shown = what the widget holds after this tick
    if math.abs(raw - v) <= eps then row.refused = nil; return end
    if row.refused and math.abs(raw - row.refused) <= eps then return end
    if pad or (prev and math.abs(raw - prev) <= eps) then
        writeWidget(row, v)
        row.refused = raw
        -- 1.1.3: read it back. A write that took clears refused, so the next press is written even when it lands on
        -- the same raw value (a press at the end of the range); one that did not take is not read as a new press.
        local _, now = readWidget(row)
        if type(now) == "number" then
            row.shown = now
            if math.abs(now - v) <= eps then row.refused = nil end
        end
    end
end

-- Settings that only apply after a restart get a * after their label.
-- 2.0 layout (docs/modmenu-2.0-design.md section 3). Units are the frame's own layout units, before its render
-- scale. T = text size (Mod Menu's own PanelScale setting, shown as "Text size", 80-140, ruling C8b) scales our own
-- text and row heights; the game's widgets keep the game's size. One layout for the mouse and the docked panel.
LAY.W, LAY.H, LAY.SW = 1580, 910, 420
LAY.BTN_H = 52                  -- C28: a game button is up to 49 tall docked (in-game lint); every button box is 52
LAY.ICON_R, LAY.ICON_P = 48, 72 -- C28: reset "R" needs 24 + 12 + 2, "PIN" 24 + 43 + 2 (measured)
-- Probe L0 (T0, 2026-10-20): the game slider row is root DomSizeBox > HorizontalBox [label SizeBox 416 | ControlBorder
-- 446 (track 383 + value 34) | tail SizeBox 416]; a blank label keeps its 416 box, so the label and the tail are
-- Collapsed (LAY.trimSlider) and the control needs 446 (ruling p).
LAY.CTRL_MIN = 446
-- Glyphs measured in L0 (ruling p): the reset arrows (U+21BA, U+27F2, U+21BB) and small triangles draw nothing in the
-- game's fonts; U+25CF (black circle) renders. Reset "R", changed dot U+25CF, fold "+" / "-", pin "PIN".
-- C22 (T1-D5): "UNPIN" was cut to "UNPI" in the 64 px button; a pinned row shows the same "PIN" in gold, an unpinned
-- one in gray (LAY.pinLook).
LAY.RESET_LABEL, LAY.PIN_LABEL = "R", "PIN"
LAY.DOT_GLYPH = "\226\151\143"
LAY.MIDDOT = "\194\183"         -- C39: U+00B7 between version and author
LAY.BTN_CHAR, LAY.BTN_PAD = 17, 28   -- C27: a game button's caps text: ~11 px per char + ~20 padding (T1-D5: UNPIN showed
                                     -- 4 of 5 chars in 64); the game's button font does not follow Text size
LAY.VALUE_ROOM = 44         -- C25: room for the slider's value text between its slot and the reset icon (x T)
LAY.NAV_W = 64 + 64 + 96 + 3 * 8   -- [<] [>] [BACK] beside the page title
LAY.CHROME = 68
LAY.FOOT_W = 280                -- C40: every footer button the same width
LAY.CARD_PAD = 12
LAY.CARD_FILL = { R = 0.012, G = 0.0095, B = 0.0065, A = 0.98 }   -- shot r1: the first fill read lighter than the mockup   -- C37: linear of #2a251d (the Quick Panel card's family)
LAY.SIDE_BTN = 270          -- C29: sidebar entry = 4 bar + 18 dot + 270 + 8 + 24 count + 56 version = 380 = 420 - its list's scrollbar
LAY.SCROLLBAR = 40          -- C22: the page ScrollBox's bar and its padding, kept free of rows
LAY.SHOWN = 4               -- SelfHitTestInvisible: a shown container never takes a click its children do not

function LAY.fs(size) return math.max(8, math.floor(size * LAY.T + 0.5)) end
-- C28 fonts (ruling w): BonaNovaSC (through the game's UFont that holds it) for titles, captions and section headers,
-- Poppins for the rest; a font that does not load falls back to the text block's own font, silently. LoadAsset and
-- StaticFindObject run once per font on the game thread (openPanel / buildPage), the result is cached (false = failed).
-- In game (C28 probe 2026-10-20): Poppins-Regular_Font / Poppins-Medium_Font / Amiri-Regular_Font are UFonts (the pause
-- menu's own text uses all three); Jancient and BonaNovaSC-Regular are FontFaces, which draw NOTHING as a FontObject
-- (the titles vanished). Titles use the game's title UFont (Amiri-Regular_Font, the pause menu heading), else Poppins Medium.
LAY.FONT_PATHS = {
    title = { "/Game/UI/Fonts/Amiri-Regular_Font", "/Game/UI/Fonts/Poppins-Medium_Font" },
    body = { "/Game/UI/Fonts/Poppins-Regular_Font" },
    medium = { "/Game/UI/Fonts/Poppins-Medium_Font" },
}
LAY.TYPEFACE = {}
LAY.fontCache = {}
function LAY.font(kind)
    local c = LAY.fontCache[kind]
    if c ~= nil then return c or nil end
    LAY.fontCache[kind] = false
    for _, path in ipairs(LAY.FONT_PATHS[kind] or {}) do
        local name = path:match("([^/]+)$")
        pcall(function() LoadAsset(path) end)
        local f = nil
        pcall(function() f = StaticFindObject(path .. "." .. name) end)
        local cls = ""
        pcall(function() cls = f:GetClass():GetFName():ToString() end)
        if valid(f) and cls ~= "FontFace" then LAY.fontCache[kind] = f; return f end   -- a FontFace draws nothing
    end
    return nil
end
-- Text metrics per font (em per char, line height per point): the game's text block font measured in L0 / T3;
-- Poppins estimated until MM2L.calib() measures it in game.
-- body measured in game 2026-10-20 (data/cmd/mm2b/cbx.lua): Poppins 18 pt "Spell cooldown" 182 x 37, "Enabled" 98 x 37,
-- 12 pt "server" 52 x 25 -> ~0.72-0.78 em per char, line 2.05 x pt; title (Amiri UFont) assumed the same until measured
LAY.METRIC = { game = { em = 1.03, line = 2.05 }, body = { em = 0.78, line = 2.10 }, medium = { em = 0.82, line = 2.10 },
               title = { em = 0.85, line = 2.50 } }   -- title: Amiri UFont, lint in game: 26 pt "MOD MENU" 63 tall, 14 pt 34
function LAY.metric(kind)
    if LAY.fontCache[kind or "body"] then return LAY.METRIC[kind or "body"] or LAY.METRIC.game end
    return LAY.METRIC.game
end
function LAY.lineH(size, kind) return math.ceil(LAY.fs(size) * LAY.metric(kind).line) end

-- The game slider row with its label and tail boxes Collapsed and its root sized to the control column (ruling p),
-- so only the 446 control (track + value) is drawn. True when the tree had the measured shape.
function LAY.trimSlider(w, width)
    local root, hb = nil, nil
    pcall(function() root = w.WidgetTree.RootWidget end)
    if valid(root) then pcall(function() hb = root:GetChildAt(0) end) end
    if not valid(hb) then return false end
    local n = 0
    pcall(function() n = hb:GetChildrenCount() end)
    if (n or 0) < 2 then return false end
    -- in game (C28, 2026-10-20): slider row = [label 416 | control | tail 416]; checkbox row = [label 420 | control
    -- 72 with a 76 left pad] (2 children). The label and any tail are Collapsed, the control kept.
    for _, i in ipairs(n >= 3 and { 0, 2 } or { 0 }) do
        local c = nil
        pcall(function() c = hb:GetChildAt(i) end)
        if valid(c) then pcall(function() c:SetVisibility(1) end) end
    end
    -- C25 (T2-D3): the control's own slot padding pushed the track and value ~60 px right of the slot (L0: the box
    -- desired 565 for a 446 control), so the value drew over the reset icon; its left and right padding go to 0
    local ctl = nil
    pcall(function() ctl = hb:GetChildAt(1) end)
    if valid(ctl) then
        local top, bottom = 0, 0
        pcall(function() local pd = ctl.Slot.Padding; top, bottom = tonumber(pd.Top) or 0, tonumber(pd.Bottom) or 0 end)
        pcall(function() ctl.Slot:SetPadding({ Left = 0, Top = top, Right = 0, Bottom = bottom }) end)
    end
    if width then pcall(function() root:SetWidthOverride(width) end) end
    return true
end

-- C40 (round 2 shots: a white bar on the warm card): the ScrollBox thumb in the card's dim gold. ScrollBox has no
-- style setter UFunction here; its WidgetBarStyle fields take a write before Slate builds the bar (probe sbar.lua).
-- C41.6: a ScrollBox draws dark shadow bands over its top / bottom rows when it can scroll; clear them (the list
-- clips cleanly at its edge). gold = also the gold thumb.
function LAY.scrollLook(sc, gold)
    for _, k in ipairs({ "TopShadowBrush", "BottomShadowBrush", "LeftShadowBrush", "RightShadowBrush" }) do
        pcall(function() sc.WidgetStyle[k].TintColor.SpecifiedColor = { R = 0, G = 0, B = 0, A = 0 } end)
    end
    if gold then LAY.barGold(sc) end
end

function LAY.barGold(sc)
    for _, k in ipairs({ "NormalThumbImage", "HoveredThumbImage", "DraggedThumbImage" }) do
        local a = k == "NormalThumbImage" and 0.55 or 0.9
        pcall(function()
            sc.WidgetBarStyle[k].TintColor.SpecifiedColor = { R = 0.69, G = 0.45, B = 0.10, A = a }
        end)
    end
end

-- C27 (T3-D1): a row box that is at least h tall and grows when its content (a wrapped label) needs more.
-- C41.7: every text inside a game control (the slider's value) in our normal ink, not the game's dim gray
function LAY.ink(w)
    local col = { SpecifiedColor = CREAM, ColorUseRule = 0 }
    local function walk(x, depth)
        if depth > 8 or not valid(x) then return end
        local okT = pcall(function() return x:GetText():ToString() end)
        if okT then pcall(function() x:SetColorAndOpacity(col) end) end
        local n = 0
        pcall(function() n = x:GetChildrenCount() end)
        for i = 0, (n or 0) - 1 do
            local c = nil
            pcall(function() c = x:GetChildAt(i) end)
            walk(c, depth + 1)
        end
    end
    pcall(function() walk(w.WidgetTree.RootWidget, 0) end)
end

function LAY.minHeight(ui, w, h)
    local sz = construct("SizeBox", ui.tree)
    pcall(function() sz:SetMinDesiredHeight(h) end)
    sz:AddChild(w)
    return sz
end

-- C27 (3): text for a game button that is width wide, cut with "..." so it never draws past its box.
function LAY.fit(text, width)
    text = tostring(text or "")
    local n = math.max(1, math.floor((width - LAY.BTN_PAD) / LAY.BTN_CHAR))
    if #text <= n then return text end
    if n <= 3 then return text:sub(1, n) end
    return text:sub(1, n - 3) .. "..."
end

-- Our text cut to fit width at size pt (estimate from the font's metric), "..." when cut.
-- Lines a greedy word wrap at n characters a line gives (long words split), for sizing a box before it is drawn.
function LAY.wrapLines(text, n)
    local lines, cur = 0, 0
    for word in tostring(text or ""):gmatch("%S+") do
        local l = #word
        if cur == 0 then cur, lines = l, 1
        elseif cur + 1 + l <= n then cur = cur + 1 + l
        else cur, lines = l, lines + 1 end
        while cur > n do cur, lines = cur - n, lines + 1 end
    end
    return math.max(1, lines)
end

function LAY.fitText(text, width, size, kind)
    text = tostring(text or "")
    local n = math.max(1, math.floor(width / (LAY.metric(kind).em * LAY.fs(size))))
    if #text <= n then return text end
    if n <= 3 then return text:sub(1, n) end
    return text:sub(1, n - 3) .. "..."
end

function LAY.textSize()
    local v = tonumber(cfg.PanelScale) or 100
    return math.max(80, math.min(140, v)) / 100
end

-- Widths at the current T: content CW, sidebar SW, page column PW, row RW, label column LW, control column CC;
-- stacked = rows put the control on a second line because CC is under the slider's minimum (one choice per page).
function LAY.dims()
    local d = { W = LAY.W, H = LAY.H, SW = LAY.SW }
    d.CW = d.W - 140 - 2 * (1 + LAY.CARD_PAD)                -- C37: our card's 1 px edge and its inner padding
    d.PW = d.CW - d.SW - 20
    -- C22 (T1-D5): rows stop LAY.SCROLLBAR short of the page column, so the icon column never sits under the
    -- ScrollBox's bar (it touched it at 140 with only 20 left)
    d.RW = d.PW - LAY.SCROLLBAR
    d.LW = math.floor(320 * LAY.T + 0.5)
    d.CC = d.RW - 20 - d.LW - LAY.ICON_R - LAY.ICON_P - 16
    d.stacked = d.CC < LAY.CTRL_MIN
    -- line heights from probe L0: a WBP_DomTextBlock line is ~2.05 x its point size tall (14 pt 30, 18 pt 37,
    -- 25 pt 51); boxes sized from the point size alone cut the text (T0: title over CHECKS at 1.4, Running line covered)
    d.topH = math.max(56, LAY.lineH(26, "title"))
    local hintLines = math.max(1, math.ceil(#PAD.HINT * (LAY.metric("body").em + 0.1) * LAY.fs(16) / (d.CW - 16)))
    d.hintH = math.max(48, LAY.lineH(16) + (hintLines - 1) * math.ceil(LAY.fs(16) * 1.6))
    d.capH = math.max(24, LAY.lineH(14, "title"))
    -- the frame's own border and margins take LAY.CHROME of the 910 (in game the old 138 left an empty band under
    -- the footer, C28 shot c28m2)
    d.BH = d.H - d.topH - d.hintH - (LAY.BTN_H + 16 + LAY.ruleH()) - LAY.CHROME - 2 * (1 + LAY.CARD_PAD) - 8   -- C41.5 bar
    d.titleH = math.max(LAY.BTN_H, LAY.lineH(20, "title"))   -- the title row also holds [<] [>] [BACK]
    d.healthH = LAY.lineH(16)
    d.metaH = LAY.lineH(14)                                   -- C39: "v1.2.0 - by Author"; the description is in the list
    d.headH = d.titleH + d.metaH + d.healthH + 8
    return d
end

-- A child into a HorizontalBox, centered on the row's height, with optional padding (FMargin).
function LAY.hadd(hb, w, vcenter, pad)
    local ok, slot = pcall(function() return hb:AddChildToHorizontalBox(w) end)
    if ok and slot then
        if vcenter then pcall(function() slot:SetVerticalAlignment(2) end) end
        if pad then pcall(function() slot:SetPadding(pad) end) end
    end
    return slot
end

function LAY.gap(ui, w, h)
    local sz = construct("SizeBox", ui.tree)
    if w then pcall(function() sz:SetWidthOverride(w) end) end
    if h then pcall(function() sz:SetHeightOverride(h) end) end
    return sz
end

-- C29: a text line in the page list, wrapped at the row width (clear of the scrollbar).
-- C28: wrap a text at an explicit width. In game AutoWrapText alone did not wrap our labels ("Repair mode: aimed piece"
-- ran into its checkbox, lint 381 in 320), so every wrapping text of ours gets WrapTextAt.
function LAY.wrapAt(t, w)
    if not valid(t) or not w then return end
    pcall(function() t:SetAutoWrapText(true) end)
    pcall(function() t.WrapTextAt = w end)
    pcall(function() t:SetWrapTextAt(w) end)
end

function LAY.line(ui, s, size, color)
    local RW = LAY.dims().RW
    local t = LAY.text(ui, s, size, color)
    -- in game a wrapped line measured 987 in its 960 box: wrap it a little inside the box, explicitly
    LAY.wrapAt(t, RW - 16)
    return sized(ui.tree, t, RW, nil)
end

-- C28 (mockup .where): a small tag chip, dim background, its word in color, padding on the 8 px grid.
-- (brush colors are LINEAR: the first try at sRGB values drew the chips light tan in game)
LAY.CHIP = { R = 0.042, G = 0.032, B = 0.019, A = 1.0 }    -- mockup --g-sel #3a3226
LAY.LINE = { R = 0.067, G = 0.054, B = 0.034, A = 1.0 }    -- mockup --g-line #4a4234
-- C40: a game button (mouse click, pad A, hover look) with an empty label and OUR text over it, so its words use our
-- font, size and color in both modes. align: 1 left (8 px in), 2 center. Returns box, button, text.
function LAY.textButton(ui, label, w, h, size, color, kind, align, opts)
    opts = opts or {}
    local b = makeGameButton(panel.pc, "", ui.like)
    if not b then return nil end
    local ov = construct("Overlay", ui.tree)
    -- wrap = the text wraps and the button grows with it (a min height); fixed = the size does not follow Text size
    pcall(function() ov:AddChildToOverlay(opts.wrap and LAY.minHeight(ui, sized(ui.tree, b, w, nil), h) or sized(ui.tree, b, w, h)) end)
    local t
    if opts.fixed then
        t = newText(ui.tree, ui.textC, label, size, color or CREAM, kind)
        pcall(function() t:SetAutoWrapText(false) end)
    else
        t = LAY.text(ui, label, size, color or CREAM, opts.wrap == true, kind)
    end
    if opts.wrap then LAY.wrapAt(t, w - 24) end
    pcall(function() t:SetVisibility(3) end)
    local ok, slot = pcall(function() return ov:AddChildToOverlay(t) end)
    if ok and slot then
        pcall(function() slot:SetVerticalAlignment(2) end)
        pcall(function() slot:SetHorizontalAlignment(align or 2) end)
        if (align or 2) == 1 then pcall(function() slot:SetPadding({ Left = 12, Top = 0, Right = 8, Bottom = 0 }) end) end
    end
    return ov, b, t
end

-- C34: a chip is a fixed-width cell (w), so the tag columns line up from row to row.
-- C41.4: a chip hugs its word: 8 px each side, 2 above and below, the word at Text size
function LAY.chip(ui, word, color)
    local b = construct("Border", ui.tree)
    pcall(function() b:SetBrushColor(LAY.CHIP) end)
    pcall(function() b:SetPadding({ Left = 8, Top = 2, Right = 8, Bottom = 2 }) end)
    local t = newText(ui.tree, ui.textC, word, LAY.fs(12), color, "body")
    pcall(function() t:SetAutoWrapText(false) end)
    pcall(function() b:SetContent(t) end)
    return b, math.ceil(#word * LAY.metric("body").em * LAY.fs(12)) + 16
end
LAY.CHIP_RUNS, LAY.CHIP_APPLY = 96, 104

function LAY.text(ui, s, size, color, wrap, kind)
    local t = newText(ui.tree, ui.textC, s, LAY.fs(size), color, kind)
    if wrap == false then pcall(function() t:SetAutoWrapText(false) end) end
    return t
end

function LAY.setText(w, t)
    if valid(w) then pcall(function() w:SetText(FText(t or "")) end) end
end

-- A colored square (Border + brush color, never a font glyph) centered in a w x h cell.
function LAY.dot(ui, size, color, w, h)
    local b = construct("Border", ui.tree)
    pcall(function() b:SetBrushColor(color) end)
    local inner = sized(ui.tree, b, size, size)
    local cell = LAY.gap(ui, w, h)
    local ok, slot = pcall(function() return cell:AddChild(inner) end)
    if ok and slot then
        pcall(function() slot:SetHorizontalAlignment(2) end)
        pcall(function() slot:SetVerticalAlignment(2) end)
    end
    return b, cell, inner
end

function LAY.stateColor(state)
    local C = MM.ui and MM.ui.COLORS or {}
    if state == "running" then return C.GREEN or GOLD end
    if state == "off" or state == "error" or state == "notstarted" then return RED end
    if state == "warn" then return C.AMBER or GOLD end
    return GREY
end

-- The tags of a row: where the value counts (runsOn) and when it applies (C8a: live, next load, restart).
-- builtin.lua's helpers when it loaded; else the setting's and the mod's own fields.
function LAY.tags(m, s)
    local B, runsOn, apply = MM.builtin or {}, nil, nil
    if type(B.runsOnFor) == "function" then
        local ok, r = pcall(B.runsOnFor, m, s)
        if ok then runsOn = r end
    else
        runsOn = s.runsOn or m.runsOn
    end
    if type(B.applyFor) == "function" then
        local ok, a = pcall(B.applyFor, m, s)
        if ok then apply = a end
    elseif s.restart then
        apply = "restart"
    end
    return runsOn, apply
end

LAY.RUNS = {
    yours = "Your own game uses this, also in a world you join.",
    host = "The world's host decides this (you, when you play alone or host).",
    server = "The host decides this, or a dedicated server's own config.txt.",
    both = "Needs the mod on the host or server AND on your game.",
}
LAY.APPLY = { restart = "Applies after restarting the game.", ["next load"] = "Applies when a world loads.",
              live = "Applies at once." }
LAY.JOINED = "The host decides this in a joined world. Your value is kept for when you host or play alone."

-- The footer hint for a hovered row: tooltip, then where and when it applies.
function LAY.hintFor(row)
    local s = row.setting
    local parts = {}
    if s.tooltip then parts[#parts + 1] = s.tooltip end
    if row.joinedGray then parts[#parts + 1] = LAY.JOINED
    elseif row.runsOn and LAY.RUNS[row.runsOn] then parts[#parts + 1] = LAY.RUNS[row.runsOn] end
    if row.apply and LAY.APPLY[row.apply] then parts[#parts + 1] = LAY.APPLY[row.apply] end
    if #parts == 0 then return nil end
    return table.concat(parts, "  ")
end

-- One settings row (design 3 "Row"): changed dot | own label (wraps; the game row's label cannot, journal 13898) +
-- tag line | the game's control with its own label blanked | reset | pin. Side by side, or stacked (the control on a
-- second line) when the control column is under CTRL_MIN. prefix = text before the label (the PINNED page: mod name).
function LAY.buildRow(ui, m, s, d, prefix)
    local tree, pc = ui.tree, panel.pc
    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local row = { setting = s, mod = m }
    if s.locked then return row end                       -- could not be read from the mod's file; error shown above
    if s.type == "header" then
        row.folded = NAV.isFolded and NAV.isFolded(m, s) or false
        -- C40 (review): a section header is its own full-width row above its settings: 16 px of space, then one button
        -- across the row with "- Name" / "+ Name" in gold title type (the sign at the name's size, right beside it);
        -- the rule under the previous row is the line above it
        local vb = construct("VerticalBox", tree)
        vb:AddChildToVerticalBox(LAY.gap(ui, nil, 16))
        local box, b, t = LAY.textButton(ui, (row.folded and "+  " or "-  ") .. s.label, d.RW - 20, LAY.BTN_H, 18, GOLD, "title", 1,
            { wrap = true })
        if b then
            row.header, row.button, row.headText = b, b, t
            panel.buttons.actions[b:GetFullName()] = { fold = row }
            vb:AddChildToVerticalBox(box)
        else
            vb:AddChildToVerticalBox(LAY.text(ui, s.label, 18, GOLD, true, "title"))
        end
        vb:AddChildToVerticalBox(LAY.gap(ui, nil, 8))
        row.holder = vb
        return row
    end
    if s.type == "button" then
        local b = makeGameButton(pc, LAY.fit(s.label, math.min(420, d.RW - 40)), ui.like)
        if not b then return row end
        panel.buttons.actions[b:GetFullName()] = { mod = m, action = s.action }
        row.button = b
        local hb = construct("HorizontalBox", tree)
        LAY.hadd(hb, LAY.gap(ui, 20, 56))
        LAY.hadd(hb, sized(tree, b, math.min(420, d.RW - 40), 56), true)
        row.holder = hb
        return row
    end
    -- C40: only a row whose control truly cannot fit stacks: a slider needs CTRL_MIN, a key picker + CLEAR 360; a
    -- toggle, choice or text box keeps the side-by-side design at every text size
    local stacked = (s.type == "slider" and d.CC < LAY.CTRL_MIN) or (s.type == "key" and d.CC < 360)
    local cw = stacked and (d.RW - 20) or d.CC
    -- C45.2: side by side, a toggle's label gets the control column's free width (the switch is SWITCH_W at its right
    -- end); "Group complete message" broke with ~400 px free
    local LWr = d.LW
    if s.type == "toggle" and not stacked then cw = LAY.SWITCH_W + 16; LWr = d.LW + d.CC - cw end
    local control = nil
    if s.type == "toggle" and ui.checkC then
        local w = wbl:Create(pc, ui.checkC, pc)
        pcall(function() w.LabelText = FText("") end)
        -- C27 (T3-D2): the game checkbox row is built like the slider row (label box | control | tail box) and drew
        -- its full width over the reset and pin icons; trimmed the same way, its box sits at the left of the slot
        -- C40 (round 2 shots): the checkbox box is trimmed to the switch's 72 and both sit at the column's right end
        row.widget, row.trimW = w, LAY.SWITCH_W
        row.trimmed = LAY.trimSlider(w, LAY.SWITCH_W)
        if not row.trimmed and not LAY.saidCheckShape then
            LAY.saidCheckShape = true
            log("checkbox row: not the measured widget shape, left untrimmed")
        end
        local sw = LAY.switch(ui)
        local ov = sw and construct("Overlay", tree) or nil
        if sw and valid(ov) then
            local okC, cslot = pcall(function() return ov:AddChildToOverlay(sized(tree, w, LAY.SWITCH_W, 56)) end)
            if okC and cslot then pcall(function() cslot:SetHorizontalAlignment(3) end) end
            local okO, slot = pcall(function() return ov:AddChildToOverlay(sw.root) end)
            if okO and slot then
                pcall(function() slot:SetHorizontalAlignment(3) end)
                pcall(function() slot:SetVerticalAlignment(2) end)
            end
            ov = sized(tree, ov, cw, nil)
            pcall(function() w:SetRenderOpacity(0) end)       -- still Visible: the click and pad A reach it
            row.switch = sw
            control = ov
        else
            control = sized(tree, w, cw, 56)                  -- fallback: the game checkbox as it is
        end
    elseif s.type == "slider" and ui.sliderC then
        local w = wbl:Create(pc, ui.sliderC, pc)
        pcall(function() w.InitialMinSliderValue = s.min end)
        pcall(function() w.InitialMaxSliderValue = s.max end)
        pcall(function() w.AmountDecimalPlacesToShow = s.decimals end)
        pcall(function() w.bShowPostfix = s.suffix ~= "" end)
        pcall(function() w.Postfix = FString(s.suffix) end)
        pcall(function() w.LabelText = FText("") end)
        -- C25 (T2-D3): side by side, the slot gives up to LAY.VALUE_ROOM * T of the control column to a gap before the
        -- reset icon, so the game's value text has room after the 446 control; the row width stays the same
        local room = stacked and 0 or math.max(0, math.min(math.floor(LAY.VALUE_ROOM * LAY.T + 0.5), cw - LAY.CTRL_MIN))
        row.valueRoom = room
        row.widget, row.trimW = w, math.max(cw - room, LAY.CTRL_MIN)
        row.trimmed = LAY.trimSlider(w, row.trimW)
        LAY.ink(w)                                            -- C41.7
        -- in game the slider's Construct (when it first draws) sets its value text back to the game's gray: once
        -- more on the next two panel ticks (the color then stays through value changes, probe sval.lua)
        panel.inkQ = panel.inkQ or { n = 2 }
        panel.inkQ.n = 2
        panel.inkQ[#panel.inkQ + 1] = w
        control = sized(tree, w, row.trimW, 56)
    elseif s.type == "choice" then
        -- Always the cycling game button, never the game's carousel (WBP_SelectorWidget_WithLabel): filling its
        -- SelectableChoices (an FText array) from Lua corrupted the game's memory (crash within 3-6 opens, found
        -- 2026-09-25 on Weather Control's page).
        -- C45.4: it reads as a control: "<" and ">" at the ends, the value centered (our text, wraps, never cut)
        row.fitW = cw
        local box, b, t = LAY.textButton(ui, MM.display(s, m.values[s.key]), cw, 56, 16, CREAM, "medium", 2, { wrap = true })
        row.widget, row.cycle, row.cycleText = b, true, t
        if b then
            LAY.wrapAt(t, cw - 96)
            for _, side in ipairs({ { "<", 1 }, { ">", 3 } }) do
                local a = LAY.text(ui, side[1], 16, GOLD, false, "medium")
                pcall(function() a:SetVisibility(3) end)
                local okA, sl = pcall(function() return box:AddChildToOverlay(a) end)
                if okA and sl then
                    pcall(function() sl:SetVerticalAlignment(2) end)
                    pcall(function() sl:SetHorizontalAlignment(side[2]) end)
                    pcall(function() sl:SetPadding({ Left = 20, Top = 0, Right = 20, Bottom = 0 }) end)
                end
            end
            panel.buttons.actions[b:GetFullName()] = { cycle = row }
            control = box
        end
    elseif s.type == "key" then
        local w = construct("InputKeySelector", tree)
        styleInput(w)
        -- 1.1: plain keys only. The picker took Alt+F and showed it, but only the key name is stored, so the
        -- player got plain F (measured 2026-09-29 with real keys).
        pcall(function() w:SetAllowModifierKeys(false) end)
        row.widget = w
        local hb = construct("HorizontalBox", tree)
        LAY.hadd(hb, sized(tree, w, math.max(200, cw - 150), 50), true)
        local cb = makeGameButton(pc, "CLEAR", ui.like)   -- 1.1: the picker itself cannot unset a key
        if cb then
            LAY.hadd(hb, sized(tree, cb, 140, LAY.BTN_H), true, { Left = 8, Top = 0, Right = 0, Bottom = 0 })
            panel.buttons.actions[cb:GetFullName()] = { clear = row }
            row.clearB = cb
        end
        control = hb
    elseif s.type == "text" then
        local w = construct("EditableTextBox", tree)
        styleInput(w)
        row.widget = w
        control = sized(tree, w, cw, 44)
    end
    if not control then return row end
    -- label column: our own text + the tag line (runsOn word, apply word, the current value's word)
    row.runsOn, row.apply = LAY.tags(m, s)
    row.joinedGray = (row.runsOn == "host" or row.runsOn == "server") and LAY.joined == true
    local lab = construct("VerticalBox", tree)
    local text = (prefix and (prefix .. ": ") or "") .. s.label
    -- 2.0.1 item 1 (PINNED page): "Carry Sliders: Carry weight" wrapped in the 320 px label column while the label alone
    -- fits one line. When the prefixed text would wrap, the label alone fits, and the mod name still fits on the tag
    -- line next to the chips, the mod name goes to the tag line (dim) and the label keeps its own line.
    local modTag, modTagW = nil, 0
    if prefix and not s.locked then
        local labW0 = stacked and (d.RW - 20 - LAY.ICON_R - LAY.ICON_P - 16) or LWr
        local em18 = LAY.metric("body").em * 18 * LAY.T
        local cplFit = math.max(4, math.floor((labW0 - 16) / em18))
        local chipsW = 0
        for _, word in ipairs({ row.runsOn or "", row.apply or "" }) do
            if word ~= "" then chipsW = chipsW + math.ceil(#word * LAY.metric("body").em * LAY.fs(12)) + 16 + 8 end
        end
        modTagW = math.ceil(#prefix * LAY.metric("body").em * LAY.fs(12)) + 8
        if #text > cplFit and #s.label <= cplFit and modTagW + chipsW <= labW0 - 16 then   -- 16 clear of the control, as wrapAt below (a second 16 missed T80 by 3 px)
            modTag, text = prefix, s.label
        end
    end
    row.label = LAY.text(ui, text, 18, row.joinedGray and GREY or CREAM)
    LAY.wrapAt(row.label, (stacked and (d.RW - 20 - LAY.ICON_R - LAY.ICON_P - 16) or LWr) - 16)   -- 16 clear of the control
    lab:AddChildToVerticalBox(row.label)
    local tagLine = construct("HorizontalBox", tree)
    -- C41.4: tag chips hug their words, 8 px apart (runsOn, apply, then the value's word)
    local p8 = { Left = 0, Top = 0, Right = 8, Bottom = 0 }
    local tagsW = 0
    if modTag then
        LAY.hadd(tagLine, LAY.text(ui, modTag, 12, GREY, false), true, p8)
        tagsW = tagsW + modTagW
    end
    for _, tg in ipairs({ { row.runsOn, GOLD }, { row.apply, row.apply == "restart" and RED or GREY } }) do
        if tg[1] then
            local chip, cw0 = LAY.chip(ui, tg[1], tg[2])
            LAY.hadd(tagLine, chip, true, p8)
            tagsW = tagsW + cw0 + 8
        end
    end
    row.vlabel = LAY.text(ui, "", 12, CREAM, false)
    local vlW = (stacked and (d.RW - 20 - LAY.ICON_R - LAY.ICON_P - 16) or LWr) - tagsW - 16
    LAY.hadd(tagLine, sized(tree, row.vlabel, math.max(16, vlW), nil), true)
    lab:AddChildToVerticalBox(tagLine)
    local labW = stacked and (d.RW - 20 - LAY.ICON_R - LAY.ICON_P - 16) or LWr   -- dot column, icons + 8 pads
    -- C27 (T3-D1): the game font wraps an 18 pt label after ~17 chars in 320 (T3), so ~18.5 x T per char
    local cpl = math.max(4, math.floor((labW - 16) / (LAY.metric("body").em * 18 * LAY.T)))
    local lines = math.max(1, math.ceil(#text / cpl))
    local rowH = math.max(56, LAY.lineH(18) + (lines - 1) * math.ceil(LAY.fs(18) * 1.6) + LAY.lineH(12) + 8)
    row.lines = lines
    local dotCol
    -- ruling p: U+25CF renders; a fixed 12 pt so it fits its 20 column at every text size (lint at 1.2: 22 in 20)
    -- C45.3: a round 8 px gold dot at the left of the fixed 20 px marker column (the 12 pt glyph touched the label)
    row.dot = construct("Border", tree)
    pcall(function() row.dot:SetBrushColor(GOLD) end)
    LAY.round(row.dot)
    local dotHb = construct("HorizontalBox", tree)
    LAY.hadd(dotHb, sized(tree, row.dot, 8, 8), true, { Left = 2, Top = 0, Right = 0, Bottom = 0 })
    dotCol = sized(tree, dotHb, 20, nil)
    local rb = makeGameButton(pc, LAY.RESET_LABEL, ui.like)
    if rb then
        row.resetB = rb
        panel.buttons.actions[rb:GetFullName()] = { reset = row }
        row.resetBox = sized(tree, rb, LAY.ICON_R, LAY.BTN_H)
    end
    if modCall(MM.QP, "canPin", m, s) then
        local pb = makeGameButton(pc, LAY.PIN_LABEL, ui.like)
        if pb then
            row.pinB = pb
            panel.buttons.actions[pb:GetFullName()] = { pin = row }
            row.pinChip = LAY.pinChip(ui)
            local pov = construct("Overlay", tree)
            pcall(function() pov:AddChildToOverlay(sized(tree, pb, LAY.ICON_P, LAY.BTN_H)) end)
            if row.pinChip then
                pcall(function() pb:SetRenderOpacity(0) end)       -- C50: our chip shows the state; click / pad A as before
                local okP, ps = pcall(function() return pov:AddChildToOverlay(row.pinChip.root) end)
                if okP and ps then
                    pcall(function() ps:SetHorizontalAlignment(2) end)
                    pcall(function() ps:SetVerticalAlignment(2) end)
                end
            end
            row.pinBox = pov
        end
    end
    local pad8 = { Left = 8, Top = 0, Right = 0, Bottom = 0 }
    local line1 = construct("HorizontalBox", tree)
    LAY.hadd(line1, dotCol, true)
    LAY.hadd(line1, sized(tree, lab, labW, nil), true)
    if not stacked then LAY.hadd(line1, control, true) end
    if row.resetBox then
        LAY.hadd(line1, row.resetBox, true, { Left = 8 + (row.valueRoom or 0), Top = 0, Right = 0, Bottom = 0 })
    end
    if row.pinBox then LAY.hadd(line1, row.pinBox, true, pad8) end
    if stacked then
        local vb = construct("VerticalBox", tree)
        vb:AddChildToVerticalBox(LAY.minHeight(ui, line1, rowH))
        local line2 = construct("HorizontalBox", tree)
        LAY.hadd(line2, LAY.gap(ui, 20, 56))
        LAY.hadd(line2, control, true)
        vb:AddChildToVerticalBox(line2)
        row.holder = LAY.rowBg(ui, row, vb)
    else
        row.holder = LAY.rowBg(ui, row, LAY.minHeight(ui, line1, rowH))
    end
    row.stacked = stacked
    return row
end

-- C28 (mockup .row.foc): each settings row sits on a background that lights up while the pad is on it.
LAY.CLEAR = { R = 0, G = 0, B = 0, A = 0 }
function LAY.rowBg(ui, row, content)
    local bg = construct("Border", ui.tree)
    pcall(function() bg:SetBrushColor(LAY.CLEAR) end)
    pcall(function() bg:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
    local vb = construct("VerticalBox", ui.tree)               -- C34: a 1 px rule under every settings row
    vb:AddChildToVerticalBox(content)
    vb:AddChildToVerticalBox(LAY.rule(ui, LAY.dims().RW))
    pcall(function() bg:SetContent(vb) end)
    row.bg = bg
    return bg
end

-- Docked panel, every main tick: the row with the pad focus (probe P-pad2 call) gets the highlight.
function LAY.focusTick()
    for _, sr in ipairs(panel.segRings or {}) do              -- C51.2: the Keys toggle segment with the pad's focus
        local f = false
        if valid(sr.w) then pcall(function() f = sr.w:HasUserFocusedDescendants(panel.pc) == true end) end
        if sr.lit ~= f then
            sr.lit = f
            pcall(function() sr.ring:SetVisibility(f and 3 or 1) end)
        end
    end
    local row = PAD.focusedRow and PAD.focusedRow() or nil
    if row == LAY.focusRow then return end
    if LAY.focusRow and valid(LAY.focusRow.bg) then pcall(function() LAY.focusRow.bg:SetBrushColor(LAY.CLEAR) end) end
    LAY.focusRow = row
    if row and valid(row.bg) then pcall(function() row.bg:SetBrushColor(LAY.CHIP) end) end
end

-- C22: the pin icon's look: "PIN" always; gold and full opacity when pinned, gray and dimmed when not. The label is
-- colored through the button's own text widget when one is found (pcall), the opacity works on any button.
-- C50.1: the PIN chip: an outer Border (its 1 px padding is the outline) around an inner Border with "PIN".
LAY.PIN_W, LAY.PIN_H = 52, 26
function LAY.pinChip(ui)
    local tree = ui.tree
    local outer, inner = construct("Border", tree), construct("Border", tree)
    if not (valid(outer) and valid(inner)) then return nil end
    pcall(function() outer:SetPadding({ Left = 1, Top = 1, Right = 1, Bottom = 1 }) end)
    pcall(function() inner:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
    pcall(function() inner:SetHorizontalAlignment(2) end)
    pcall(function() inner:SetVerticalAlignment(2) end)
    local t = newText(tree, ui.textC, LAY.PIN_LABEL, 11, GREY, "medium")   -- fixed 11 pt: the chip keeps its size
    pcall(function() t:SetAutoWrapText(false) end)
    pcall(function() inner:SetContent(t) end)
    pcall(function() outer:SetContent(inner) end)
    local root = sized(tree, outer, LAY.PIN_W, LAY.PIN_H)
    pcall(function() root:SetVisibility(3) end)               -- HitTestInvisible: the game button under it is clicked
    local c = { root = root, outer = outer, inner = inner, text = t }
    LAY.pinChipState(c, false)
    return c
end
function LAY.pinChipState(c, pinned)
    pcall(function() c.outer:SetBrushColor(pinned and GOLD or { R = GREY.R, G = GREY.G, B = GREY.B, A = 0.7 }) end)
    pcall(function() c.inner:SetBrushColor(pinned and GOLD or LAY.CARD_FILL) end)
    pcall(function() c.text:SetColorAndOpacity({ SpecifiedColor = pinned and LAY.SWITCH_ON_TEXT or GREY, ColorUseRule = 0 }) end)
end

function LAY.pinLook(b, pinned, chip)
    if not valid(b) then return end
    if chip then                                              -- C50.1: the chip shows it; the game button stays at 0
        pcall(function() b:SetLabelText(FText(LAY.PIN_LABEL)) end)
        LAY.pinChipState(chip, pinned)
        return
    end
    pcall(function() b:SetLabelText(FText(LAY.PIN_LABEL)) end)
    pcall(function() b:SetRenderOpacity(pinned and 1.0 or 0.8) end)   -- C40: unpinned dim but readable
    local col = { SpecifiedColor = pinned and GOLD or GREY, ColorUseRule = 0 }
    local function walk(w, depth)
        if depth > 8 or not valid(w) then return end
        local t = nil
        pcall(function() t = w:GetText():ToString() end)
        if t == LAY.PIN_LABEL then pcall(function() w:SetColorAndOpacity(col) end) end
        local n = 0
        pcall(function() n = w:GetChildrenCount() end)
        for i = 0, (n or 0) - 1 do
            local c = nil
            pcall(function() c = w:GetChildAt(i) end)
            walk(c, depth + 1)
        end
    end
    pcall(function() walk(b.WidgetTree.RootWidget, 0) end)
end

-- A row's changed dot, reset icon, pin label and value word, from the current value (after a build or any change).
function LAY.rowState(row)
    local m, s = row.mod, row.setting
    if not (m and s and s.key) or s.locked then return end
    local changed = not MM.isDefault(m, s)
    if row.dot then pcall(function() row.dot:SetVisibility(changed and LAY.SHOWN or 2) end) end
    if row.resetBox then pcall(function() row.resetBox:SetVisibility(changed and LAY.SHOWN or 2) end) end
    row.changed = changed
    LAY.switchState(row)
    if row.vlabel then
        local v = m.values[s.key]
        local f = v ~= nil and formatValue(s, v) or ""
        local word = (s.type ~= "choice" and type(s.valueLabels) == "table" and type(s.valueLabels[f]) == "string") and s.valueLabels[f] or ""
        if word ~= row.vlabelText then row.vlabelText = word; LAY.setText(row.vlabel, word) end
    end
    if row.pinB then
        local p = modCall(MM.QP, "isPinned", m.id, s.key) == true
        if p ~= row.pinned then
            row.pinned = p
            LAY.pinLook(row.pinB, p, row.pinChip)
        end
    end
end

-- How many of a mod's settings differ from their default (the gold count in the sidebar).
function LAY.changedCount(m)
    local n = 0
    for _, s in ipairs(m.settings) do
        if s.key and not s.locked and s.type ~= "button" and not MM.isDefault(m, s) then n = n + 1 end
    end
    return n
end

-- 1.1: a line under a row (key clash, a kept file value). Collapsed while it has nothing to say.
local function addNote(ui, row, color)
    local tb = newText(ui.tree, ui.textC, "", LAY.fs(16), color)
    LAY.wrapAt(tb, LAY.dims().RW - 16)
    pcall(function() tb:SetVisibility(1) end)
    ui.scroll:AddChild(sized(ui.tree, tb, LAY.dims().RW, nil))   -- C29: a row wide, clear of the scrollbar
    row.note = tb
end

local function setNote(row, text)
    if not valid(row.note) or row.noteText == text then return end
    row.noteText = text
    pcall(function() row.note:SetText(FText(text or "")) end)
    pcall(function() row.note:SetVisibility((text and not row.hidden) and 4 or 1) end)   -- 2.0: a hidden row hides it too
end

-- The slider part of panelTick: the value to keep for a slider row whose widget reads raw. cur = nil with a
-- controller; in mouse mode see handleClick. Its own function since 1.1.3 so the offline test runs this code.
local function sliderRowTick(row, raw, pad, cur)
    local s = row.setting
    local base = row.hold ~= nil and row.hold or row.last
    local click = (not pad and cur) and handleClick(row, s, base, raw, cur) or false
    if click == "hold" then                              -- 1.1.3: press held on a small change, nothing written yet
        row.raw = raw
        return row.last
    end
    if click then
        row.refused = nil                                -- a second click right after the first: write again
        settleSlider(row, raw, base, pad)                -- shown back at its old value once the slider is still
        return row.last
    end
    if row.hold ~= nil and math.abs(raw - row.hold) <= stepEps(s) then
        return row.last                                  -- 1.1: not moved, the file's own value stays
    end
    local from = row.last
    if row.hold ~= nil then                              -- moved: from here on it is an ordinary slider
        from, row.hold, row.last = row.hold, nil, nil
        setNote(row, nil)
    end
    local v = sliderStep(s, from, raw, pad, row.shown)   -- 1.0.14: on the step grid, one step per pad press
    settleSlider(row, raw, v, pad)
    return v
end

-- 1.1.3: the mouse cursor, read once a tick while the panel is open with the mouse. still = not moved since the
-- last tick (2 units of slack). Unreadable = not still.
local function cursorTick()
    local p = nil
    pcall(function()
        local wll = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
        local v = wll:GetMousePositionOnViewport(panel.pc)
        if type(v.X) == "number" and type(v.Y) == "number" then p = { x = v.X, y = v.Y } end
    end)
    local prev = panel.cursor
    panel.cursor = p
    local still = p ~= nil and prev ~= nil and math.abs(p.x - prev.x) <= 2 and math.abs(p.y - prev.y) <= 2
    return { still = still, x = p and p.x, y = p and p.y }
end

local function refreshKeyNotes()
    for _, row in ipairs(panel.rows) do
        if row.note and isKeySetting(row.setting) then setNote(row, keyClash(row.mod, row.setting)) end
    end
end

-- Empties the page column for a new view: rows, their buttons, pad order, scroll position.
function LAY.clearPage(ui)
    LAY.focusRow = nil
    pcall(function() ui.scroll:ClearChildren() end)
    pcall(function() ui.scroll:SetScrollOffset(0) end)
    LAY.pageSetH(ui, ui.pageViewH)                           -- 2.0.1 item 3: a new page starts at the full height
    LAY.pageOff, LAY.pageSnapped = nil, nil
    panel.rows, panel.buttons.actions, panel.order, panel.checkRows, panel.checkHints = {}, {}, {}, nil, nil
    panel.segRings, panel.keysSegs = nil, nil                -- C51.2 / C54: never a widget of a page that is gone
end

-- The page header: title line, health line (red / amber when the mod is not running), description.
-- C39 (user photo: "The dev is cut off in a lot of entries"): the header has its own lines, none ever cut: the name
-- (title font), then "v1.2.0 - by Author" in dim body text, then the running line. The description is the first line
-- of the page list, wrapped in full (it scrolls with the page instead of being cut to a fixed box).
function LAY.header(ui, title, health, healthColor, desc, meta)
    LAY.setText(ui.title, title)
    -- a name too long for the title row gets a smaller title size instead of a cut (C39)
    if valid(ui.title) then
        local d = LAY.dims()
        local room = d.PW - LAY.NAV_W
        local m = LAY.metric("title")
        local size = LAY.fs(20)
        local need = #tostring(title or "") * m.em * size
        if need > room then size = math.max(10, math.floor(room / (#tostring(title) * m.em))) end
        pcall(function() local f = ui.title.Font; f.Size = size; ui.title:SetFont(f) end)
    end
    LAY.setText(ui.meta, meta or "")
    LAY.setText(ui.healthLine, health)
    if valid(ui.healthLine) then
        pcall(function() ui.healthLine:SetColorAndOpacity({ SpecifiedColor = healthColor or GREY, ColorUseRule = 0 }) end)
    end
    ui.descH = 0
    if desc and desc ~= "" and valid(ui.scroll) then
        ui.scroll:AddChild(LAY.line(ui, tostring(desc), 16, GREY))
        -- C48: its height, so MM.ui.PH (what a check page has under it) leaves it out
        local per = math.max(1, math.floor((LAY.dims().RW - 16) / (LAY.metric().em * LAY.fs(16))))
        ui.descH = LAY.wrapLines(tostring(desc), per) * LAY.lineH(16)
        ui.scroll:AddChild(LAY.gap(ui, nil, 8))
    end
end

-- After a page, check page or results view is filled: the sidebar marks, controller links.
function LAY.afterView(ui)
    LAY.sideMarks(ui)
    if panel.mode == "pad" then
        local okP, e = pcall(PAD.afterFill, ui)
        if not okP then log("controller links: " .. tostring(e)) end
    end
end

-- A mod's settings page (view "page").
local function fillPage(ui, idx)
    local scroll = ui.scroll
    LAY.clearPage(ui)
    NAV.view = "page"
    local m = mods[idx]
    share("ModMenu.page", m and m.id or "")                 -- 1.1.1
    if not m then
        LAY.header(ui, "No mods to configure", "", GREY, "")
        scroll:AddChild(LAY.line(ui, "No installed mod has a modmenu.json yet. Mod authors: see README.md in the ModMenu folder.", 18, GREY))
        LAY.afterView(ui)
        return
    end
    local title = m.name                                     -- C39: version and author on their own line
    local st = modCall(MM.HEALTH, "status", m.id) or { state = "unknown" }
    local state = m.off and "off" or st.state
    local hl, hc = "", GREY
    if state == "running" then
        hl = LAY.DOT_GLYPH .. " Running" .. ((MM.builtin.live and MM.builtin.live[m.id]) and ", settings apply live" or "")
        hc = LAY.stateColor("running")
    elseif state ~= "unknown" and state ~= "lib" then
        hl = tostring(st.reason or (m.off and "Switched off" or state)) .. (st.fix and ("  " .. st.fix) or "")
        hc = LAY.stateColor(state)
    elseif state == "lib" then
        hl = tostring(st.reason or "Library for other mods")
    end
    local meta = {}
    if m.version then meta[#meta + 1] = "v" .. m.version end
    if m.author then meta[#meta + 1] = "by " .. m.author end
    LAY.header(ui, title, hl, hc, m.description or "", table.concat(meta, "  " .. LAY.MIDDOT .. "  "))
    for _, e in ipairs(m.errors) do scroll:AddChild(LAY.line(ui, "! " .. e, 16, RED)) end
    if m.off then scroll:AddChild(LAY.line(ui, "! " .. m.off, 16, RED)) end
    local pc = panel.pc
    local d = LAY.dims()
    for _, s in ipairs(m.settings) do
        local row = LAY.buildRow(ui, m, s, d)
        if row.holder then
            scroll:AddChild(row.holder)
            local cur = s.key and m.values[s.key]
            if isKeySetting(s) and row.widget then addNote(ui, row, RED)
            elseif s.type == "slider" and row.widget and type(cur) == "number" and (cur < s.min or cur > s.max) then
                addNote(ui, row, GOLD)
            end
            panel.order[#panel.order + 1] = row
            if row.widget or s.tooltip or row.runsOn or row.apply then panel.rows[#panel.rows + 1] = row end
        end
    end
    LAY.fillValues()
    if #m.settings == 0 and #m.errors == 0 then
        scroll:AddChild(LAY.line(ui, "This mod has no settings.", 18, GREY))
    end
    if NAV.applyVisibility then NAV.applyVisibility() end
    LAY.afterView(ui)
end

-- Values and slider ranges after the widgets are constructed (construction resets them), for every row shown.
function LAY.fillValues()
    for _, row in ipairs(panel.rows) do
        local s, m = row.setting, row.mod
        if row.widget and s.key then
            if row.trimW and s.type == "toggle" then row.trimmed = LAY.trimSlider(row.widget, row.trimW) or row.trimmed end
            if s.type == "slider" then
                if row.trimW then row.trimmed = LAY.trimSlider(row.widget, row.trimW) or row.trimmed end
                pcall(function() row.widget.InputSlider:SetMinValue(s.min) end)
                pcall(function() row.widget.InputSlider:SetMaxValue(s.max) end)
                pcall(function() row.widget.InputSlider:SetStepSize(s.step) end)
            end
            if not row.cycle then                           -- 2.0: our own label column carries the text
                pcall(function() row.widget.InputLabelButton.LabelText:SetText(FText("")) end)
            end
            local cur = m.values[s.key]
            local show = cur
            if s.type == "slider" and row.note then           -- 1.1: outside the slider: shown at its end, kept
                show = math.max(s.min, math.min(s.max, cur))
                row.hold = show
                setNote(row, "The config file says " .. plainNumber(cur) .. ", outside this slider (" .. formatValue(s, s.min)
                    .. " to " .. formatValue(s, s.max) .. "). It is kept until you move the slider.")
            end
            writeWidget(row, show)
            row.last = cur
        end
        LAY.rowState(row)
    end
    refreshKeyNotes()
end

-- A check page (view "health" or "keys"): drawn by its module into the page column. Its rows are buttons that
-- open a mod's page ({ w = button, id = mod id, key = row key }); core routes their clicks and pad links.
function LAY.fillCheck(ui, which)
    LAY.clearPage(ui)
    NAV.view = which
    share("ModMenu.page", "#" .. which)
    local mod = which == "health" and MM.HEALTH or MM.KEYS
    if which == "health" then
        local sm = modCall(mod, "summary") or {}
        local n, total = tonumber(sm.problems) or 0, tonumber(sm.total) or #mods     -- C12: the health check's own total
        LAY.header(ui, "HEALTH CHECK", n > 0 and (n .. " of " .. total .. " mods need a look") or ("All " .. total .. " mods look fine"),
            n > 0 and RED or LAY.stateColor("running"), "Which mods are running, and what to do about the ones that are not.")
    else
        local n = tonumber(modCall(mod, "clashCount")) or 0
        -- C51.1: the description goes on the header's meta line (not the list's first line), so the toggle, the
        -- picture and its legend fit the first screen of the list
        LAY.header(ui, "KEYS", n > 0 and (n .. " key clash" .. (n == 1 and "" or "es")) or "No key clashes",
            n > 0 and RED or GREY, nil, "Every key mods and the game use. Red = a clash.")   -- one line at T 1.4
    end
    MM.ui.T, MM.ui.tree, MM.ui.pc = LAY.T, ui.tree, panel.pc
    MM.ui.PH = ui.pageViewH and (ui.pageViewH - (ui.descH or 0)) or nil   -- C48: the list's visible height under the description
    local res = modCall(mod, "buildPage", MM.ui, ui.scroll)
    panel.checkRows, panel.segRings, panel.keysSegs = {}, {}, {}
    -- C38: { w = widget, text = hint } pairs from the module: the footer shows text while w is hovered
    panel.checkHints = (type(res) == "table" and type(res.hints) == "table") and res.hints or nil
    for _, r in ipairs(type(res) == "table" and type(res.rows) == "table" and res.rows or {}) do
        local w = type(r) == "table" and (r.w or r.widget) or r
        if valid(w) then
            panel.checkRows[#panel.checkRows + 1] = w
            local okN, n = pcall(function() return w:GetFullName() end)
            if okN and type(r) == "table" and r.id then panel.buttons.actions[n] = { open = r.id, row = r.key }
            elseif okN and type(r) == "table" and (r.view == "keyboard" or r.view == "controller") then
                panel.buttons.actions[n] = { keysView = r.view }   -- C48: the Keys page's Keyboard | Controller toggle
                panel.keysSegs[r.view] = w                           -- C54 (F-2): for the pad's Left / Right links
                -- C51.2: the game button sits invisible over the module's segment, so a pad's focus on it showed
                -- nothing: our own light tint over the segment while it has the focus (LAY.focusTick)
                local ring = construct("Border", ui.tree)
                pcall(function() ring:SetBrushColor({ R = CREAM.R, G = CREAM.G, B = CREAM.B, A = 0.22 }) end)
                pcall(function() ring:SetVisibility(1) end)
                local par = nil
                pcall(function() par = w:GetParent() end)
                local okR, rs = pcall(function() return par:AddChildToOverlay(ring) end)
                if okR and rs then
                    pcall(function() rs:SetHorizontalAlignment(0) end)
                    pcall(function() rs:SetVerticalAlignment(0) end)
                    panel.segRings[#panel.segRings + 1] = { w = w, ring = ring }
                end
            end
        end
    end
    LAY.afterView(ui)
end

-- The PINNED page (view "pinned"): every Quick Panel pin as a full row, editable with a mouse or a controller.
-- It is also the controller's way to edit pins when the Quick Panel's own pad edit is off (ruling D0 10.2).
function LAY.fillPinned(ui)
    LAY.clearPage(ui)
    NAV.view = "pinned"
    share("ModMenu.page", "#pinned")
    local pins = modCall(MM.QP, "pinnedRows") or {}          -- C12: the Quick Panel's live pins
    LAY.header(ui, "PINNED", #pins .. " pinned setting" .. (#pins == 1 and "" or "s"), GREY,
        "The settings you pinned for the Quick Panel. Changes here are the same as on each mod's page.")
    local d = LAY.dims()
    local shown = 0
    for _, p in ipairs(pins) do
        local m = modsById[p.id]
        local s = m and MM.setting(m, p.key)
        if s and not s.locked then
            local row = LAY.buildRow(ui, m, s, d, m.name)
            if row.holder then
                ui.scroll:AddChild(row.holder)
                panel.order[#panel.order + 1] = row
                if row.widget then panel.rows[#panel.rows + 1] = row end
                shown = shown + 1
            end
        end
    end
    if shown == 0 then
        ui.scroll:AddChild(LAY.line(ui, "Nothing pinned yet. Use PIN on a setting's row to add it here and to the Quick Panel.", 18, GREY))
    end
    LAY.fillValues()
    LAY.afterView(ui)
end

-- One sidebar entry, 48 high: current-page bar | state dot | game button | meta (version, changed count).
-- C34 (user photo: "neater, lines so it is aligned"): the sidebar is a ruled table. Fixed columns on one left edge:
-- gold bar 4 + 4 | 12 px square dot | 12 | name 284 | version 56 | changed count 40 at the right edge (both right-
-- aligned) | 8, and a 1 px
-- gold rule under every entry. The name is OUR text (Poppins, it fits at T 1.0) laid over the game button, whose own
-- label stays empty: the button still takes the mouse click and the pad's A (GetSelected), the text never takes input.
LAY.SIDE_NAME, LAY.SIDE_CNT, LAY.SIDE_VER = 284, 40, 56   -- 4 bar + 4 + 12 dot + 12 + 284 + 56 + 40 + 8 = 420
LAY.RULE = { R = 0.694, G = 0.445, B = 0.107, A = 0.22 }   -- gold at low alpha (dividers), linear (C44)
LAY.RULE_EDGE = { R = 0.694, G = 0.445, B = 0.107, A = 0.85 }   -- C37: the card's 1 px gold edge, linear (C44)

-- A 1 px rule, w wide (nil = fill).
function LAY.rule(ui, w)
    local b = construct("Border", ui.tree)
    pcall(function() b:SetBrushColor(LAY.RULE) end)
    return sized(ui.tree, b, w, LAY.ruleH())
end
function LAY.ruleH() return panel.mode == "pad" and 2 or 1 end   -- docked: 2 (the 0.8 render scale dropped 1 px lines)

-- Text in a fixed cell, right-aligned (the count and version columns).
function LAY.rightCell(ui, t, w)
    pcall(function() t:SetJustification(2) end)
    local cell = LAY.gap(ui, w, nil)
    local ok, slot = pcall(function() return cell:AddChild(t) end)
    if ok and slot then
        pcall(function() slot:SetHorizontalAlignment(3) end)
        pcall(function() slot:SetVerticalAlignment(2) end)
    end
    return cell
end

function LAY.sideEntry(ui, label, metaColor)
    local tree = ui.tree
    local hb = construct("HorizontalBox", tree)
    local bar = construct("Border", tree)
    pcall(function() bar:SetBrushColor(GOLD) end)
    local barBox = sized(tree, bar, 3, 40)                  -- C41.2: our 3 px gold bar marks the page shown
    pcall(function() barBox:SetVisibility(2) end)
    LAY.hadd(hb, barBox, true)
    LAY.hadd(hb, LAY.gap(ui, 5, nil))
    local dot, dotCell = LAY.dot(ui, 12, GREY, 12, 56)
    LAY.hadd(hb, dotCell, true)
    LAY.hadd(hb, LAY.gap(ui, 12, nil))
    local b = makeGameButton(panel.pc, "", ui.like)
    if not b then return nil end
    pcall(function() b:SetRenderOpacity(0) end)               -- C41.2: no game glow; still Visible for click and pad A
    -- C40: a name longer than one line wraps (never cut); the entry is as tall as its lines
    local perLine = math.max(1, math.floor((LAY.SIDE_NAME - 16) / (LAY.metric().em * LAY.fs(15))))
    local lines = math.min(3, LAY.wrapLines(label, perLine))
    local rowH = math.max(56, lines * LAY.lineH(15) + 8)
    local ov = construct("Overlay", tree)
    pcall(function() ov:AddChildToOverlay(sized(tree, b, LAY.SIDE_NAME, rowH - 4)) end)
    local shown = lines < 3 and label or LAY.fitText(label, 3 * (LAY.SIDE_NAME - 16), 15)
    local name = LAY.text(ui, shown, 15, CREAM, lines > 1)
    if lines > 1 then LAY.wrapAt(name, LAY.SIDE_NAME - 16) end
    pcall(function() name:SetVisibility(3) end)                -- HitTestInvisible: the button under it gets the input
    local ok, ns = pcall(function() return ov:AddChildToOverlay(name) end)
    if ok and ns then
        pcall(function() ns:SetVerticalAlignment(2) end)
        pcall(function() ns:SetPadding({ Left = 8, Top = 0, Right = 8, Bottom = 0 }) end)
    end
    LAY.hadd(hb, ov, true)
    local cnt = LAY.text(ui, "", 12, metaColor or GOLD, false)
    local ver = LAY.text(ui, "", 12, GREY, false)
    LAY.hadd(hb, LAY.rightCell(ui, ver, LAY.SIDE_VER), true)
    LAY.hadd(hb, LAY.rightCell(ui, cnt, LAY.SIDE_CNT), true)
    LAY.hadd(hb, LAY.gap(ui, 8, nil))
    local vb = construct("VerticalBox", tree)
    vb:AddChildToVerticalBox(sized(tree, hb, nil, rowH))
    vb:AddChildToVerticalBox(LAY.rule(ui, LAY.SW))
    local bg = construct("Border", tree)                    -- the selected entry's background (mockup .sel)
    pcall(function() bg:SetBrushColor({ R = 0, G = 0, B = 0, A = 0 }) end)
    pcall(function() bg:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
    pcall(function() bg:SetContent(vb) end)
    return { holder = bg, bg = bg, w = b, name = name, bar = barBox, dot = dot, dotCell = dotCell, ver = ver, cnt = cnt,
             full = shown ~= label and label or nil,   -- a cut name shows whole in the hint on hover
             h = rowH + LAY.ruleH() }                  -- C41.1: its height in the list, for whole-row scrolling
end

-- Dot color, version and changed count of a mod entry; count of a check entry.
function LAY.sideState(e)
    local m = e.mod
    if m then
        local st = modCall(MM.HEALTH, "status", m.id) or { state = "unknown" }
        pcall(function() e.dot:SetBrushColor(LAY.stateColor(m.off and "off" or st.state)) end)
        local ver = (LAY.T <= 1.2 and m.version) and LAY.fitText(m.version, LAY.SIDE_VER, 12) or ""
        if ver ~= e.verText then e.verText = ver; LAY.setText(e.ver, ver) end
        local n = LAY.changedCount(m)
        local c = n > 0 and tostring(n) or ""
        if c ~= e.cntText then e.cntText = c; LAY.setText(e.cnt, c) end
    elseif e.view then
        local n = 0
        if e.view == "health" then n = tonumber((modCall(MM.HEALTH, "summary") or {}).problems) or 0
        elseif e.view == "keys" then n = tonumber(modCall(MM.KEYS, "clashCount")) or 0
        elseif e.view == "pinned" then n = #(modCall(MM.QP, "pinnedRows") or {}) end
        local c = n > 0 and tostring(n) or ""
        if c ~= e.cntText then e.cntText = c; LAY.setText(e.cnt, c) end
        local col = e.view == "pinned" and GREY or (n > 0 and RED or LAY.stateColor("running"))
        pcall(function() e.dot:SetBrushColor(col) end)
    end
end

-- The gold bar on the entry of the view shown.
function LAY.sideMarks(ui)
    local function mark(e, on)
        if e.marked ~= on then
            e.marked = on
            e.lit = nil                                     -- C41.2: sideTick redraws its hover / focus tint
            pcall(function() e.bar:SetVisibility(on and LAY.SHOWN or 2) end)
            pcall(function() e.bg:SetBrushColor(on and LAY.SIDE_SEL or LAY.CLEAR) end)
        end
    end
    for _, e in ipairs(ui.checks or {}) do mark(e, NAV.view == e.view) end
    for _, e in ipairs(ui.modBtns or {}) do mark(e, NAV.view == "page" and e.idx == panel.page) end
end

LAY.SIDE_SEL = { R = 0.69, G = 0.45, B = 0.10, A = 0.14 }      -- C41.2: soft gold tint (linear) of the page shown

-- C41.1 / C41.2, every panel tick: the sidebar entry under the pointer (mouse) or with the pad's focus gets the dark
-- tint (the game's own glow is hidden), and once the list stops moving it settles on a whole-row boundary, keeping
-- the shown or focused entry whole.
function LAY.sideTick()
    local ui = panel.ui
    if not ui then return end
    local pad = panel.mode == "pad"
    local function tint(e)
        local lit = false
        if not e.marked and valid(e.w) then
            pcall(function()
                if pad then lit = e.w:HasUserFocusedDescendants(panel.pc) == true
                else lit = e.w:IsHovered() == true end
            end)
        end
        if e.lit ~= lit then
            e.lit = lit
            if not e.marked then pcall(function() e.bg:SetBrushColor(lit and LAY.CHIP or LAY.CLEAR) end) end
        end
    end
    for _, e in ipairs(ui.checks or {}) do tint(e) end
    for _, e in ipairs(ui.modBtns or {}) do tint(e) end
    local sc, view = ui.leftScroll, ui.leftViewH
    if not (valid(sc) and view and #(ui.modBtns or {}) > 0) then return end
    local okO, off = pcall(function() return sc:GetScrollOffset() end)
    if not okO or type(off) ~= "number" then return end
    if off ~= LAY.sideOff then LAY.sideOff = off; return end   -- still moving: wait for it to settle
    local bounds, y = { 0 }, 0
    for _, e in ipairs(ui.modBtns) do y = y + (e.h or 0); bounds[#bounds + 1] = y end
    local lo, hi = 0, nil
    for _, b in ipairs(bounds) do
        if b <= off + 0.5 then lo = b elseif not hi then hi = b end
    end
    if off - lo < 1 or not hi then return end
    local tgt = (off - lo <= hi - off) and lo or hi
    for i, e in ipairs(ui.modBtns) do                    -- the shown / focused entry stays whole when it is in view
        if e.marked or e.lit then
            local top, bot = bounds[i], bounds[i + 1]
            if top < off + view and bot > off then
                if bot > tgt + view then tgt = hi end
                if top < tgt then tgt = lo end
            end
        end
    end
    pcall(function() sc:SetScrollOffset(tgt) end)
    LAY.sideOff = tgt
end

-- C45.1, every panel tick: once the page list stops moving, it settles on a whole-row boundary (row heights from
-- GetDesiredSize, which works under UE4SS), never past the end, keeping the pad's focused row whole.
-- 2.0.1 item 3 (F-1: "the last row of a list shows cut off at the bottom"): the list is as tall as its box, and rows are
-- not, so the row at the bottom edge was cut. At rest (the list stopped on a row boundary, or is at the top) the box is
-- made as tall as the whole rows that fit, like the sidebar (C41.1): the rest is empty space above the footer rule.
-- Moving again, the box goes back to its full height, so a scroll always fills the view. Never more than
-- PAGE_FIT_MAX px are given up; a row taller than the view (the Keys picture) leaves the box as it is.
LAY.PAGE_FIT_MAX = 140
function LAY.pageSetH(ui, h)
    if not (ui and ui.pageBox) or LAY.pageBoxH == h then return end
    if valid(ui.pageBox) then pcall(function() ui.pageBox:SetHeightOverride(h) end) end
    LAY.pageBoxH = h
end
function LAY.pageFit(ui, off)
    local sc, full = ui.scroll, ui.pageViewH
    if not (valid(sc) and full) then return end
    local n = 0
    pcall(function() n = sc:GetChildrenCount() end)
    local y, best, over = 0, nil, false
    for i = 0, (n or 0) - 1 do
        local c, h = nil, nil
        pcall(function() c = sc:GetChildAt(i) end)
        pcall(function() h = c:GetDesiredSize().Y end)
        if type(h) ~= "number" then LAY.pageSetH(ui, full); return end
        y = y + h
        if y > off + 0.5 then
            if y - off <= full + 0.5 then best = y - off else over = true; break end
        end
    end
    local want = full
    if over and best and full - best <= LAY.PAGE_FIT_MAX then want = math.floor(best) end
    LAY.pageSetH(ui, want)
end

function LAY.pageSnap()
    local ui = panel.ui
    local sc = ui and ui.scroll
    if not (valid(sc) and ui.pageViewH) then return end
    local okO, off = pcall(function() return sc:GetScrollOffset() end)
    if not okO or type(off) ~= "number" then return end
    if off ~= LAY.pageOff then LAY.pageOff = off; LAY.pageSetH(ui, ui.pageViewH); return end     -- still moving: full height
    if LAY.pageSnapped == off then return end
    if off < 1 then LAY.pageSnapped = off; LAY.pageFit(ui, 0); return end
    LAY.pageSnapped = off
    local okE, endOff = pcall(function() return sc:GetScrollOffsetOfEnd() end)
    if not (okE and type(endOff) == "number") then endOff = nil end
    if endOff and off >= endOff - 1 then LAY.pageSetH(ui, ui.pageViewH); return end
    local n = 0
    pcall(function() n = sc:GetChildrenCount() end)
    local focusRow = panel.mode == "pad" and PAD.focusedRow and PAD.focusedRow() or nil
    local y, lo, hi, fTop, fBot = 0, 0, nil, nil, nil
    for i = 0, (n or 0) - 1 do
        local c, h = nil, nil
        pcall(function() c = sc:GetChildAt(i) end)
        pcall(function() h = c:GetDesiredSize().Y end)
        if type(h) ~= "number" then return end
        if focusRow and (c == focusRow.holder or c == focusRow.bg) then fTop, fBot = y, y + h end
        y = y + h
        if y <= off + 0.5 then lo = y elseif not hi then hi = y end
        if hi and (not focusRow or fTop) then break end
    end
    if not hi or off - lo < 1 then LAY.pageFit(ui, off); return end
    local tgt = (off - lo <= hi - off) and lo or hi
    if fTop then                                                 -- the focused row stays whole
        if fBot > tgt + ui.pageViewH then tgt = hi end
        if fTop < tgt then tgt = lo end
    end
    if endOff and tgt > endOff then tgt = lo end
    pcall(function() sc:SetScrollOffset(tgt) end)
    LAY.pageOff, LAY.pageSnapped = tgt, tgt
    LAY.pageFit(ui, tgt)
end

-- After a value changed: the shown rows of that setting, the mod's sidebar count.
function LAY.refreshMod(m)
    local ui = panel.ui
    if not ui then return end
    for _, e in ipairs(ui.modBtns or {}) do if e.mod == m then LAY.sideState(e) end end
    for _, e in ipairs(ui.checks or {}) do LAY.sideState(e) end
end

-- Sidebar: CHECKS entries are built with the frame; this fills the MODS list (every mod, in name order).
buildModList = function(ui)
    pcall(function() ui.leftScroll:ClearChildren() end)
    panel.buttons.mods = {}
    ui.modBtns = {}                                         -- in list order, for the controller links
    for i, m in ipairs(mods) do
        local e = LAY.sideEntry(ui, m.name)
        if e then
            e.idx, e.mod = i, m
            ui.leftScroll:AddChild(e.holder)
            panel.buttons.mods[e.w:GetFullName()] = i
            ui.modBtns[#ui.modBtns + 1] = e
            LAY.sideState(e)
        end
    end
    for _, e in ipairs(ui.checks or {}) do LAY.sideState(e) end
    if #ui.modBtns == 0 then ui.leftScroll:AddChild(LAY.text(ui, "No mods with settings", 16, GREY)) end
    if panel.mode == "pad" and panel.ui == ui then pcall(PAD.afterFill, ui) end
end

-- The view kept in NAV.view, drawn again (page switch, text size, fold).
function LAY.fillView(ui)
    local v = NAV.view or "page"
    if v == "health" or v == "keys" then LAY.fillCheck(ui, v)
    elseif v == "pinned" then LAY.fillPinned(ui)
    elseif v == "results" and NAV.fillResults then NAV.fillResults(ui, NAV.query or "")
    else fillPage(ui, panel.page) end
end

local function saveDirty(force)
    for id in pairs(panel.dirty) do
        local m = modsById[id]
        if m and (force or os.clock() - panel.lastEdit > 1.0) then
            local ok, res = pcall(saveValues, m)
            if not ok or not res then
                log("could not save settings for " .. m.name .. ": " .. tostring(res))
                panel.flash = { text = "! " .. m.name .. ": the config file could not be written, so this change is not saved.",
                                till = os.clock() + 8 }
            else log("saved " .. m.name) end
            panel.dirty[id] = nil
        end
    end
end

local function closePanel(keepInput)
    if not panel.open then return end
    if NAV.keep then pcall(NAV.keep) end                  -- 2.0: the place the next open goes back to
    saveDirty(true)
    if panel.frame then pcall(function() panel.frame:RemoveFromParent() end) end
    -- In a world, hand input back to the game. Outside one (title screen) the game's own menus need the
    -- cursor and UI input, so leave them as they were.
    if panel.mode == "pad" then
        PAD.unwire()                                   -- the pause menu owns input there; only our links go
        -- 1.0.14: not when another mod's docked panel took the spot: the pad is on that mod's pause entry
        if not panel.displaced then PAD.refocus(panel.pm) end
        DOCK.rev = nil
    elseif panel.pc and not keepInput and panel.inWorld then setInputUI(panel.pc, nil, false) end
    panel.open, panel.frame, panel.ui, panel.rows = false, nil, nil, {}
    share("ModMenu.page", "")                               -- 1.1.1
    shareRect(panel)
    panel.buttons = {}
    panel.mode, panel.padBtns, panel.order, panel.pm, panel.padCur = nil, nil, nil, nil, nil
    PAD.held = nil                                          -- 2.0: pad buttons read fresh at the next open
    PAD.focusNext = nil
    panel.displaced = nil
    modCall(MM.QP, "onPanel", false)
end

-- The game's panel frames (WBP_Panel, WBP_Panel_Processing) carry a UI ember effect (a NiagaraSystemWidget)
-- sized by the game's own layout events; on our panels it traces a phantom box across the screen (Nexus report,
-- proven in game 2026-09-30: collapsing it by a tree walk removes the sweep, the frame art is unchanged).
local function hideEmbers(frame)
    local function walk(w, depth)
        if depth > 10 or not (w and w:IsValid()) then return end
        local cls = ""
        pcall(function() cls = w:GetClass():GetFName():ToString() end)
        if cls == "NiagaraSystemWidget" then pcall(function() w:SetVisibility(1) end); return end
        local n = 0
        pcall(function() n = w:GetChildrenCount() end)
        for i = 0, (n or 0) - 1 do
            local c = nil
            pcall(function() c = w:GetChildAt(i) end)
            walk(c, depth + 1)
        end
    end
    pcall(function() walk(frame.WidgetTree.RootWidget, 0) end)
end

local function openPanel(mode)                     -- mode "pad": docked in the pause menu for a controller
    if panel.open then return end
    local pc = anyPC()
    if not pc then log("no local player controller yet"); return end
    panel.inWorld = localPC() ~= nil
    discover()
    modCall(MM.HEALTH, "scan", false)                      -- 2.0: running lights for the sidebar and pages
    modCall(MM.KEYS, "warm")                               -- C12: the live game keys (keys.lua throttles it)

    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local panelC = loadClass("/Game/UI/Panels/WBP_Panel")
    local textC = loadClass("/Game/UI/Common/WBP_DomTextBlock")
    if not (panelC and textC) then log("the game's UI pieces were not found"); return end

    local vw, vh = 1920, 1080
    pcall(function()
        local wll = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
        local size, scale = wll:GetViewportSize(pc), wll:GetViewportScale(pc)
        -- size.X > 0 matters: for the first seconds after launch the viewport reports 0x0 while
        -- still returning a sensible-looking scale, and dividing that through built a -40x-40
        -- panel (seen in ScaleHitProbe, 2026-09-20). Fall back to the 1920x1080 defaults instead.
        if size and scale and scale > 0 and size.X > 0 and size.Y > 0 then
            vw, vh = size.X / scale, size.Y / scale
        end
    end)
    -- 2.0: one layout, 1580 x 910, for the mouse and the docked panel (the mouse one is scaled down to fit a small
    -- screen); the text size comes from Mod Menu's own PanelScale setting
    LAY.T = LAY.textSize()
    LAY.font("title"); LAY.font("body"); LAY.font("medium")   -- C28: loaded before the sizes that use their metrics
    LAY.joined = MM.joined()
    MM.ui.T = LAY.T
    local d = LAY.dims()
    MM.ui.RW = d.RW                                        -- C12: modules size their pages to the row width
    local W, H = d.W, d.H
    panel.pc = pc
    panel.cursor = nil                               -- 1.1.3: cursorTick starts fresh
    local frame = wbl:Create(pc, panelC, pc)
    hideEmbers(frame)
    local tree = frame.WidgetTree
    local ui = { tree = tree, textC = textC, frame = frame,
                 checkC = loadClass("/Game/UI/Settings/WBP_Settings_Checkbox"),
                 sliderC = loadClass("/Game/UI/Settings/WBP_Settings_Slider"),
                 like = nil }   -- C40: the same button style docked and with the mouse (no pause-menu style)
    panel.buttons = { mods = {}, actions = {}, fixed = {} }
    panel.mode = mode == "pad" and "pad" or nil

    local vb = construct("VerticalBox", tree)
    -- C37: the game panel's textured art and double border are hidden (LAY.cardFrame) and our flat card (warm dark
    -- fill, 1 px gold edge) holds the content; built here, in the same call, nothing re-parented
    local card = LAY.card(ui, vb)
    if card and LAY.cardFrame(frame) then frame.PanelContent:AddChild(card)
    else
        if card then pcall(function() card:RemoveFromParent() end) end
        frame.PanelContent:AddChild(vb)
    end
    -- top bar: title, search box (mouse and keyboard; a pad cannot type)
    local top = construct("HorizontalBox", tree)
    LAY.hadd(top, sized(tree, LAY.text(ui, "MOD MENU", 26, GOLD, false, "title"), d.CW - 584, d.topH), true)
    ui.search = construct("EditableTextBox", tree)
    pcall(function() ui.search:SetHintText(FText("Search every setting")) end)
    styleInput(ui.search)
    LAY.hadd(top, sized(tree, ui.search, 560, 44), true, { Left = 20, Top = 0, Right = 0, Bottom = 0 })
    vb:AddChildToVerticalBox(sized(tree, top, nil, d.topH))
    ui.query = ""

    local body = construct("HorizontalBox", tree)
    -- sidebar: CHECKS (health, keys, pinned), then every mod
    local side = construct("VerticalBox", tree)
    side:AddChildToVerticalBox(sized(tree, LAY.text(ui, "CHECKS", 14, GREY, false, "title"), nil, d.capH))
    side:AddChildToVerticalBox(LAY.rule(ui, d.SW))
    ui.checks = {}
    for _, c in ipairs({ { "health", "Health check" }, { "keys", "Keys" }, { "pinned", "Pinned" } }) do
        if c[1] ~= "pinned" or (MM.QP and not MM.QP.stub and type(MM.QP.pinnedRows) == "function") then
            local e = LAY.sideEntry(ui, c[2], RED)
            if e then
                e.view = c[1]
                panel.buttons.fixed[e.w:GetFullName()] = { view = c[1] }
                side:AddChildToVerticalBox(e.holder)
                ui.checks[#ui.checks + 1] = e
            end
        end
    end
    side:AddChildToVerticalBox(sized(tree, LAY.text(ui, "MODS", 14, GREY, false, "title"), nil, d.capH))
    side:AddChildToVerticalBox(LAY.rule(ui, d.SW))
    ui.leftScroll = construct("ScrollBox", tree)
    pcall(function() ui.leftScroll:SetScrollBarVisibility(1) end)   -- C34: no bar between sidebar and page (wheel / pad scroll)
    ui.leftW = d.SW
    local availH = d.BH - 2 * d.capH - 2 * LAY.ruleH()
    for _, e in ipairs(ui.checks) do availH = availH - (e.h or (56 + LAY.ruleH())) end
    local stepH = 56 + LAY.ruleH()                            -- C41.1: the list shows whole rows; the rest is space
    ui.leftViewH = math.max(stepH, math.floor(availH / stepH) * stepH)
    LAY.sideOff = nil
    LAY.scrollLook(ui.leftScroll, false)
    side:AddChildToVerticalBox(sized(tree, ui.leftScroll, d.SW, ui.leftViewH))
    if availH > ui.leftViewH then side:AddChildToVerticalBox(LAY.gap(ui, nil, availH - ui.leftViewH)) end
    LAY.hadd(body, sized(tree, side, d.SW, d.BH))
    LAY.hadd(body, LAY.gap(ui, 9, d.BH))                       -- C34: a 1 px gold divider between sidebar and page
    do
        local vr = construct("Border", tree)
        pcall(function() vr:SetBrushColor(LAY.RULE) end)
        LAY.hadd(body, sized(tree, vr, 1, d.BH))
    end
    LAY.hadd(body, LAY.gap(ui, 10, d.BH))
    buildModList(ui)
    -- page column: title + [<] [>] [BACK], health line, description, rows
    local col = construct("VerticalBox", tree)
    local head = construct("HorizontalBox", tree)
    ui.title = LAY.text(ui, "", 20, CREAM, false, "title")
    LAY.hadd(head, sized(tree, ui.title, d.PW - LAY.NAV_W, d.titleH), true)
    ui.nav = {}
    for _, n in ipairs({ { "prev", "<", 64 }, { "next", ">", 64 }, { "back", "BACK", 96 } }) do   -- BACK docked: needs 92 (lint)
        local box, b = LAY.textButton(ui, n[2], n[3], LAY.BTN_H, 16, CREAM, "medium", 2, { fixed = true })   -- C40: readable
        if b then
            LAY.hadd(head, box, true, { Left = 8, Top = 0, Right = 0, Bottom = 0 })
            panel.buttons.fixed[b:GetFullName()] = { nav = n[1] }
            ui.nav[#ui.nav + 1] = b
            ui.nav[n[1]] = b
        end
    end
    col:AddChildToVerticalBox(head)
    ui.meta = LAY.text(ui, "", 14, GREY, false)
    col:AddChildToVerticalBox(sized(tree, ui.meta, d.PW, d.metaH))
    ui.healthLine = LAY.text(ui, "", 16, GREY, false)
    col:AddChildToVerticalBox(sized(tree, ui.healthLine, d.PW, d.healthH + 8))
    ui.scroll = construct("ScrollBox", tree)
    col:AddChildToVerticalBox(LAY.rule(ui, d.RW))            -- C45.1: rows scroll under a rule, not the Running line
    col:AddChildToVerticalBox(LAY.gap(ui, nil, 8))
    ui.pageViewH = d.BH - d.headH - 16 - LAY.ruleH()
    LAY.pageOff, LAY.pageSnapped = nil, nil
    ui.pageBox = sized(tree, ui.scroll, d.PW, ui.pageViewH)       -- 2.0.1 item 3: LAY.pageFit shrinks it to whole rows at rest
    LAY.pageBoxH = ui.pageViewH
    col:AddChildToVerticalBox(ui.pageBox)
    col:AddChildToVerticalBox(LAY.gap(ui, nil, 8))             -- C41.6: the list ends clear of the footer rule
    LAY.hadd(body, sized(tree, col, d.PW, d.BH))
    vb:AddChildToVerticalBox(body)
    -- 1.0.13: repaint both lists every frame in every mode. Without it a fast scroll can leave stale rows drawn
    -- over the new ones (Nexus report: text crammed at the bottom; same fix as Collection Log 2.0 and the pad path).
    for _, sc in ipairs({ ui.scroll, ui.leftScroll }) do pcall(function() sc:ForceVolatile(true) end) end
    pcall(function() ui.scroll:SetScrollbarThickness({ X = 4, Y = 4 }) end)   -- C40: a thin bar, inside the page column
    LAY.scrollLook(ui.scroll, true)

    ui.hint = LAY.text(ui, "", 16, GREY)
    LAY.wrapAt(ui.hint, d.CW - 16)                            -- C39: the pad hint wraps inside the panel
    vb:AddChildToVerticalBox(LAY.gap(ui, nil, 8))           -- C40: clear of the lists above
    vb:AddChildToVerticalBox(sized(tree, ui.hint, d.CW, d.hintH))

    vb:AddChildToVerticalBox(LAY.rule(ui, d.CW))              -- C34: the footer is a bar with a rule above it
    -- C41.5: the buttons share the whole bar in equal widths, 16 apart, our text centered in each; bar = button + 16
    local foot = construct("HorizontalBox", tree)
    local nF = (MM.QP and MM.QP.stub) and 3 or 4
    ui.footW = math.floor((d.CW - (nF - 1) * 16) / nF)
    local function fbtn(label)
        local box, b = LAY.textButton(ui, label, ui.footW, LAY.BTN_H, 14, CREAM, "medium", 2)
        if b then LAY.hadd(foot, box, true, { Left = foot:GetChildrenCount() > 0 and 16 or 0, Top = 0, Right = 0, Bottom = 0 }) end
        return b
    end
    local resetB = fbtn("RESET PAGE")
    local closeB = fbtn("CLOSE")
    local reportB = fbtn("SAVE REPORT")                       -- 1.1
    if resetB then panel.buttons.reset = resetB:GetFullName() end
    if closeB then panel.buttons.close = closeB:GetFullName() end
    if reportB then panel.buttons.report = reportB:GetFullName() end
    ui.resetB, ui.closeB, ui.reportB = resetB, closeB, reportB
    if NAV.footer then NAV.footer(ui, foot) end
    vb:AddChildToVerticalBox(LAY.gap(ui, nil, 8))
    vb:AddChildToVerticalBox(sized(tree, foot, nil, LAY.BTN_H))
    vb:AddChildToVerticalBox(LAY.gap(ui, nil, 8))

    if mode == "pad" then
        -- Docked in THIS call: a frame docked a call later crashed the Lua state in testing (2026-09-29).
        local okD, why = PAD.dock(frame, W, H)
        if not okD then
            log("controller panel not opened: " .. tostring(why))
            pcall(function() frame:RemoveFromParent() end)
            panel.mode = nil
            return
        end
    else
        frame:AddToViewport(9000)
        pcall(function() frame:SetPositionInViewport({ X = (vw - W) / 2, Y = (vh - H) / 2 }, false) end)
        pcall(function() frame:SetDesiredSizeInViewport({ X = W, Y = H }) end)
    end
    panel.frame, panel.ui, panel.open = frame, ui, true
    if panel.mode == "pad" then DOCK.claim() end      -- 1.0.14: another mod's docked panel closes itself
    -- Kept so the size can be re-clamped against this screen without reopening the panel.
    panel.vw, panel.vh, panel.w, panel.h = vw, vh, W, H
    applyScale(panel)
    if NAV.restore then pcall(NAV.restore, ui) end          -- 2.0: request.open's page, else the kept place
    if panel.page > #mods then panel.page = 1 end
    local ok, e = pcall(LAY.fillView, ui)
    if not ok then log("page error: " .. tostring(e)) end
    if panel.mode == "pad" then pcall(function() ui.hint:SetText(FText(PAD.HINT)) end)
    else
        setInputUI(pc, frame, true)
        pcall(function() ui.hint:SetText(FText(LAY.MOUSE_HINT)) end)
    end
    modCall(MM.QP, "onPanel", true)
    log("opened (" .. #mods .. " mods" .. (panel.mode == "pad" and ", controller" or "") .. ")")
end

-- RESET PAGE: every setting of the mod back to its default, each through MM.setValue (published, saved, rows written).
local function resetMod(m)
    for _, s in ipairs(m.settings) do
        if s.key and not s.locked then MM.setValue(m, s, s.default, "reset") end
    end
    panel.lastEdit = os.clock()
end

-- One dispatch for a panel button, reached by the mouse (the hook below) and by a pad (PAD.pollPanel).
-- C42 (user: an unpin click sometimes did nothing): panel.pending held ONE click per 250 ms tick, so a second click
-- in the same tick overwrote the first (two quick PIN clicks = one toggle). Clicks now queue (up to 8) and the tick
-- takes them in order, one per tick.
local function clickPanelButton(n)
    local b = panel.buttons
    local item = nil
    if b.mods and b.mods[n] then item = { page = b.mods[n] }
    elseif b.fixed and b.fixed[n] then item = b.fixed[n]                        -- 2.0: { view = } / { nav = }
    elseif b.actions and b.actions[n] then item = { action = b.actions[n] }
    elseif n == b.reset then item = { reset = true }
    elseif n == b.report then item = { report = true }
    elseif n == b.pinLast then item = { pinLast = true }
    elseif n == b.close then item = { close = true } end
    if not item then return end
    if not panel.pending then panel.pending = item; return end
    panel.clickQ = panel.clickQ or {}
    if #panel.clickQ < 8 then panel.clickQ[#panel.clickQ + 1] = item end
end

local panelHooked = false
local function hookPanel()
    if panelHooked then return end
    panelHooked = true
    pcall(RegisterHook, "/Script/CommonUI.CommonButtonBase:HandleButtonClicked", function(self)
        if not panel.open then return end
        local okN, n = pcall(function() return self:get():GetFullName() end)
        if not okN then return end
        clickPanelButton(n)
    end)
end

-- Controller path (PAD table and constants: next to MENU). Measured in game 2026-09-29, game in front
-- (data/cmd/mm2 passes 3-8): pad A selects a selectable CommonUI button with no hook firing; SetIsSelected(false)
-- is ignored on these buttons but toggling SetIsSelectable clears it; explicit navigation links carry pad focus
-- from the pause list into a docked panel; the game's checkbox takes A and its slider takes left/right; B closes
-- the pause menu.
function PAD.unselect(b)
    if not valid(b) then return end
    pcall(function() b:SetIsSelectable(false) end)
    pcall(function() b:SetIsSelectable(true) end)
end

-- MODS is selected, the mouse hook has not claimed it after a full tick: that was a pad press.
function PAD.pollMods()
    if panel.open or not valid(MENU.btn) then PAD.seen = false; return end
    local ok, sel = pcall(function() return MENU.btn:GetSelected() end)
    if not (ok and sel) then PAD.seen = false; return end
    if MENU.pending then return end
    if not PAD.seen then PAD.seen = true; return end
    PAD.seen = false
    PAD.unselect(MENU.btn)
    local okO, err = pcall(openPanel, "pad")
    if not okO then log("controller panel error: " .. tostring(err)) end
end

-- Dock the frame into the open pause menu: its root is a BackgroundBlur holding a CanvasPanel.
function PAD.dock(frame, W, H)
    local pm = findPauseMenu()
    if not valid(pm) then return false, "no pause menu" end
    local okA, act = pcall(function() return pm:IsActivated() end)
    if not (okA and act) then return false, "the pause menu is closed" end
    local root = nil
    pcall(function() root = pm.WidgetTree.RootWidget end)
    if not valid(root) then return false, "no pause menu layout" end
    local canvas, cls = root, ""
    pcall(function() cls = root:GetClass():GetFName():ToString() end)
    if cls ~= "CanvasPanel" then pcall(function() canvas = root:GetContent() end) end
    local okS, slot = pcall(function() return canvas:AddChildToCanvas(frame) end)
    if not (okS and valid(slot)) then return false, "could not dock into the pause menu" end
    pcall(function() slot:SetPosition({ X = PAD.X, Y = PAD.Y }) end)
    pcall(function() slot:SetSize({ X = W, Y = H }) end)
    pcall(function() slot:SetZOrder(100) end)
    pcall(function() frame:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() frame:SetRenderScale({ X = PAD.SCALE, Y = PAD.SCALE }) end)
    panel.pm = pm
    return true
end

-- After every view build: make the buttons selectable (only once the game has built them), keep them for polling,
-- and link pad navigation (EUINavigation 0 Left, 1 Right, 2 Up, 3 Down). 2.0: sidebar column = CHECKS then the mods;
-- page column = [<] [>] [BACK], the rows shown (hidden and folded rows skipped), the footer. Right from a non-slider
-- control goes on to its reset and pin icons, and Up/Down from an icon stays in the icon column; sliders keep
-- Left/Right for their value. Key pickers and text boxes need a keyboard: a key row's pad stop is its CLEAR button,
-- text rows are skipped. The ends of each column link to themselves: without a rule, Up on the first mod left the
-- panel for the pause list's PLAYER LIST (1.0.13 test).
function PAD.afterFill(ui)
    local btns, side, cur, firstMod = {}, {}, nil, nil
    local function sel(b) if valid(b) then pcall(function() b:SetIsSelectable(true) end); btns[#btns + 1] = b end end
    local function link(from, dir, to) if valid(from) and valid(to) then pcall(function() from:SetNavigationRuleExplicit(dir, to) end) end end
    local view = NAV.view or "page"
    for _, e in ipairs(ui.checks or {}) do
        sel(e.w); side[#side + 1] = e.w
        if view == e.view then cur = e.w end
    end
    for _, e in ipairs(ui.modBtns or {}) do
        sel(e.w); side[#side + 1] = e.w
        firstMod = firstMod or e.w
        if e.idx == panel.page and not cur and view ~= "health" and view ~= "keys" and view ~= "pinned" then cur = e.w end
    end
    cur = cur or firstMod or side[1]
    local navRow = {}
    for _, b in ipairs(ui.nav or {}) do if valid(b) then sel(b); navRow[#navRow + 1] = b end end
    local col = {}
    for _, row in ipairs(panel.order or {}) do
        local s, w = row.setting, nil
        if row.hidden or s.locked then
            w = nil
        elseif s.type == "header" and row.header then w = row.header; sel(w)
        elseif s.type == "toggle" and valid(row.widget) then pcall(function() w = row.widget.InputCheckBox end)
        elseif s.type == "slider" and valid(row.widget) then pcall(function() w = row.widget.InputSlider end)
        elseif s.type == "choice" and row.cycle then w = row.widget; sel(w)
        elseif s.type == "key" and valid(row.clearB) then w = row.clearB; sel(w)   -- 1.1: a pad can clear a key
        elseif s.type == "button" and row.button then w = row.button; sel(w) end
        if valid(w) then
            local icons = {}
            if valid(row.resetB) and row.changed then sel(row.resetB); icons[#icons + 1] = row.resetB end
            if valid(row.pinB) then sel(row.pinB); icons[#icons + 1] = row.pinB end
            col[#col + 1] = { w = w, slider = s.type == "slider", icons = icons }
        end
    end
    for _, w in ipairs(panel.checkRows or {}) do sel(w); col[#col + 1] = { w = w, icons = {} } end
    local foot = {}
    for _, fb in ipairs({ ui.resetB, ui.closeB, ui.reportB, ui.pinLastB }) do if valid(fb) then sel(fb); foot[#foot + 1] = fb end end
    panel.padBtns, panel.padCur, panel.padCol = btns, cur, col
    local firstRow = col[1] and col[1].w
    link(MENU.btn, 1, cur)
    for i, w in ipairs(side) do
        link(w, 2, i > 1 and side[i - 1] or w)
        link(w, 3, i < #side and side[i + 1] or w)
        link(w, 1, firstRow or navRow[#navRow] or foot[1])
        link(w, 0, MENU.btn)
    end
    for i, b in ipairs(navRow) do
        link(b, 0, i > 1 and navRow[i - 1] or cur)
        link(b, 1, i < #navRow and navRow[i + 1] or b)
        link(b, 2, b)
        link(b, 3, firstRow or foot[1] or b)
    end
    for i, c in ipairs(col) do
        local above, below = col[i - 1], col[i + 1]
        link(c.w, 2, above and above.w or navRow[#navRow] or c.w)
        link(c.w, 3, below and below.w or foot[1] or c.w)
        if not c.slider then
            link(c.w, 0, cur)
            link(c.w, 1, c.icons[1] or c.w)
        end
        for k, ic in ipairs(c.icons) do
            link(ic, 0, c.icons[k - 1] or c.w)
            link(ic, 1, c.icons[k + 1] or ic)
            link(ic, 2, above and (above.icons[k] or above.w) or navRow[#navRow] or ic)
            link(ic, 3, below and (below.icons[k] or below.w) or foot[1] or ic)
        end
    end
    -- C54 (F-2): the Keys toggle's segments sit side by side: Right from Keyboard to Controller, Left back
    local ks = panel.keysSegs
    if ks and valid(ks.keyboard) and valid(ks.controller) then
        link(ks.keyboard, 1, ks.controller)
        link(ks.controller, 0, ks.keyboard)
    end
    for i, fb in ipairs(foot) do
        link(fb, 0, i > 1 and foot[i - 1] or cur)
        link(fb, 1, i < #foot and foot[i + 1] or fb)
        link(fb, 2, col[#col] and col[#col].w or navRow[1] or fb)
        link(fb, 3, fb)
    end
    for _, sc in ipairs({ ui.scroll, ui.leftScroll }) do
        pcall(function() sc:SetScrollWhenFocusChanges(1) end)   -- follow pad focus
        pcall(function() sc:ForceVolatile(true) end)            -- no stale rows once it scrolls (tested)
    end
end

-- 1.1.3 (run w3): after a docked request.open the pad stayed on the pause list's RESUME, and only MODS has the Right
-- link into the panel. Put the focus on the open mod's entry in the panel's list instead (one tick after the open,
-- from panelTick). The button is a CommonButton: focus its root widget, the RuneScape Bags route (round1008e).
function PAD.focusPanel()
    local b = panel.padCur
    if not valid(b) or not valid(panel.pc) then return end
    local r = nil
    pcall(function() r = b.WidgetTree.RootWidget end)
    local tgt = valid(r) and r or b
    pcall(function() tgt:SetUserFocus(panel.pc) end)
end

-- A pad press on a panel button shows up as a selection: route it like a click. A mouse click in the docked
-- panel fires the hook AND selects the button; the hook's pending wins and the selection is just cleared.
function PAD.pollPanel()
    for _, b in ipairs(panel.padBtns or {}) do
        local ok, sel = pcall(function() return b:GetSelected() end)
        if ok and sel then
            PAD.unselect(b)
            local okN, n = pcall(function() return b:GetFullName() end)
            if okN and not panel.pending then clickPanelButton(n) end
            return
        end
    end
end

-- 2.0 (design 4): pad buttons read with IsInputKeyDown inside the docked menu (probe P-pad1), on the press, never
-- on a hold: a button already down when the menu opened (RB of the chord) does nothing until it is pressed again.
-- LB / RB = previous / next mod (the [<] [>] buttons are the fallback); X = reset the focused setting, Y = pin it
-- (fallbacks: the row's own icons, PIN LAST in the footer).
PAD.KEYS = { lb = "Gamepad_LeftShoulder", rb = "Gamepad_RightShoulder", x = "Gamepad_FaceButton_Left",
             y = "Gamepad_FaceButton_Top" }
function PAD.down(pc, key)
    local d = false
    pcall(function() d = pc:IsInputKeyDown({ KeyName = FName(key) }) == true end)
    return d
end

function PAD.buttons()
    local pc = panel.pc
    if not valid(pc) then return end
    local held = PAD.held or {}
    PAD.held = held
    local press = {}
    for name, key in pairs(PAD.KEYS) do
        local d = PAD.down(pc, key)
        press[name] = d and held[name] == false
        held[name] = d
    end
    if press.lb or press.rb then
        NAV.step(press.rb and 1 or -1)
        PAD.focusNext = true                                 -- the page was drawn again: the pad onto the new entry
    elseif press.x then PAD.rowAction("reset")
    elseif press.y then PAD.rowAction("pin") end
end

-- The row whose control has the pad focus, or nil. Probe P-pad2 (ruling q): the row widget (settings row, CLEAR,
-- a game button) answers HasUserFocusedDescendants(pc) (1 param + return) while the pad is on it.
function PAD.focusedRow()
    local pc = panel.pc
    for _, row in ipairs(panel.order or {}) do
        if not row.hidden and row.setting.key then
            for _, w in ipairs({ row.widget, row.clearB, row.resetB, row.pinB }) do
                if valid(w) then
                    local ok, f = pcall(function() return w:HasUserFocusedDescendants(pc) end)
                    if ok and f == true then return row end
                end
            end
        end
    end
    return nil
end

-- X / Y (and PIN LAST): reset or pin the focused row, else the last row changed or jumped to on this view.
function PAD.rowAction(kind, lastOnly)
    local row = (not lastOnly) and PAD.focusedRow() or nil
    if not row then
        for _, r in ipairs(panel.order or {}) do if r == panel.lastRow then row = r end end
    end
    local s = row and row.setting
    if not (s and s.key and row.mod) then
        panel.flash = { text = "Change a setting first: then " .. (kind == "pin" and "Y pins" or "X resets") .. " it.", till = os.clock() + 5 }
        return
    end
    if kind == "reset" then
        MM.setValue(row.mod, s, s.default, "reset")
        panel.flash = { text = s.label .. ": back to " .. MM.display(s, s.default) .. ".", till = os.clock() + 4 }
    elseif not modCall(MM.QP, "canPin", row.mod, s) then
        panel.flash = { text = s.label .. " cannot be pinned to the Quick Panel.", till = os.clock() + 5 }
    else
        local on, why = modCall(MM.QP, "togglePin", row.mod.id, s.key)
        LAY.rowState(row)
        LAY.refreshMod(row.mod)
        panel.flash = { text = why and tostring(why) or ((on and "Pinned to the Quick Panel: " or "Unpinned: ") .. s.label .. "."),
                        till = os.clock() + 4 }
        if NAV.unpinned then NAV.unpinned(on, why) end
    end
end

-- Chord (ruling D0 10.4): Start (the pause menu opens), then RB within 0.75 s (or RB already held when it opens)
-- opens Mod Menu docked at the kept place with the pad in it. Shoulder reads in the pause menu: probe P-pad1 (RB
-- readable). C26: run from the 50 ms pad loop; RB is read only while the pause menu is up.
PAD.CHORD_WINDOW = 0.75
-- C54 (F-3): Start then a quick RB missed 1 in 9: the tap could end before the pause menu was active. With the pause
-- menu closed, Start is read (one read per 50 ms tick, nothing else); an RB press within PAD.EARLY_RB after Start
-- is kept and counts when the pause menu becomes active.
PAD.EARLY_RB = 0.5
PAD.START_KEY = "Gamepad_Special_Right"
function PAD.chordTick()
    local c = PAD.chord or {}
    PAD.chord = c
    if panel.open or not cfg.ShowInPauseMenu then c.at = nil; return end
    local pc = localPC()
    if not pc then c.at = nil; return end
    local pm = MENU.pm
    if not valid(pm) then pm = findPauseMenu() end
    local okA, act = pcall(function() return pm:IsActivated() end)
    local now = os.clock()
    if not (valid(pm) and okA and act == true) then
        c.at, c.done = nil, nil
        local st = PAD.down(pc, PAD.START_KEY)                 -- C54 (F-3)
        if st and not c.startHeld then c.startAt, c.rbAt = now, nil end
        c.startHeld = st
        if c.startAt and not c.rbAt and now - c.startAt <= PAD.EARLY_RB and PAD.down(pc, PAD.KEYS.rb) then c.rbAt = now end
        return
    end
    if c.at == nil then c.at = now end                     -- the pause menu just opened
    if c.done or now - c.at > PAD.CHORD_WINDOW then return end
    local early = c.rbAt ~= nil and c.startAt ~= nil and now - c.startAt <= PAD.EARLY_RB + PAD.CHORD_WINDOW
    c.startAt, c.rbAt = nil, nil
    if early or PAD.down(pc, PAD.KEYS.rb) then
        c.done = true
        PAD.unselect(MENU.btn)
        local ok, err = pcall(openPanel, "pad")
        if not ok then log("controller chord: " .. tostring(err)) end
        if panel.open and panel.mode == "pad" then
            PAD.focusNext = true
            log("opened with the controller (Start, RB)")
        end
    end
end

-- C26 (T2-D5): pad edges at 50 ms. A ~100 ms tap fell between two 250 ms main ticks most of the time. This runs
-- from its own id-guarded 50 ms game-thread loop and does nothing (no pad reads) unless the docked menu is open in
-- pad mode, or the pause menu is up (the chord). Everything else stays on the 250 ms main loop.
-- 2.0.1 item 5 (G-1: LB/RB/X/Y taps missed ~1 in 5 at 15-20 fps): the loop runs every PAD.FAST_MS = 16 ms, which is once
-- per frame at any frame rate under 60 (a 50 ms delay was 2-3 frames apart in game, so a ~100 ms tap could fall between
-- two reads; the 16 ms game-thread loop is the one Fishing Sliders has run per frame without trouble). Docked in pad
-- mode it reads the four buttons every run; with the menu closed it still does one Start read per 50 ms (PAD.CHORD_MS),
-- so the idle cost is the clock call and a subtraction.
PAD.FAST_MS, PAD.CHORD_MS = 16, 0.045
function PAD.fastTick()
    if panel.open then
        if panel.mode == "pad" and valid(panel.frame) then PAD.buttons() end
    else
        local now = os.clock()
        if now - (PAD.chordAt or -1) < PAD.CHORD_MS then return end
        PAD.chordAt = now
        PAD.chordTick()
    end
end

function PAD.unwire()
    pcall(function() MENU.btn:SetNavigationRuleBase(1, 0) end)   -- MODS gets its own Right rule back
    panel.padBtns = nil
end

-- After CLOSE the focused button is gone and the pause menu kept no focus, so the pad did nothing until B or
-- Start (test 2026-09-29). Ask the pause menu to refocus itself (its own focus, which the pad follows); if that
-- call is missing, focus MODS.
function PAD.refocus(pm)
    local okA, act = pcall(function() return pm:IsActivated() end)
    if not (okA and act) then return end
    if pcall(function() pm:RequestRefreshFocus() end) then return end
    pcall(function() MENU.btn:SetUserFocus(panel.pc) end)
    pcall(function() MENU.btn:SetKeyboardFocus() end)
end

-- 1.0.14: pause-menu dock protocol, the same block in Mod Menu and Storage Search 2.1 (test 2026-10-06, run
-- c1006: both docked at once drew Mod Menu over Storage Search and the pad landed on hidden rows). A mod that
-- docks a panel sets PauseDock.owner to its id and adds 1 to PauseDock.rev; a mod whose docked panel is open
-- closes it once the rev moved on AND another mod owns the dock. Called from the game-thread tick only.
-- With one of the mods installed the variables are only ever ours, so nothing changes.
-- BEGIN pause-dock (tools/test_modmenu_slider_steps_offline.lua loads this block on its own)
function DOCK.claim()
    local okR, r = pcall(function() return ModRef:GetSharedVariable("PauseDock.rev") end)
    local rev = math.floor(((okR and tonumber(r)) or 0) + 1)
    local okO = pcall(function() ModRef:SetSharedVariable("PauseDock.owner", DOCK.ID) end)
    local okV = pcall(function() ModRef:SetSharedVariable("PauseDock.rev", rev) end)
    DOCK.rev = (okO and okV) and rev or nil              -- not published: never close ourselves on a stale read
end

function DOCK.lost()
    if not DOCK.rev then return false end
    local okR, r = pcall(function() return ModRef:GetSharedVariable("PauseDock.rev") end)
    local okO, o = pcall(function() return ModRef:GetSharedVariable("PauseDock.owner") end)
    if not (okR and okO) or tonumber(r) == nil or tonumber(r) == DOCK.rev then return false end
    if type(o) ~= "string" or o == "" or o == DOCK.ID then return false end
    DOCK.owner = o
    return true
end
-- END pause-dock

-- 1.1: SAVE REPORT. One text file a player can paste into a comment: the folders in use, every mod with a
-- page, and what Mod Menu found wrong. Written next to this mod's config (ue4ss/Mods/ModMenu/report.txt).
local function writeReport()
    local root = modRoot()
    if not root then return false end
    local L = {}
    local function add(s) L[#L + 1] = s end
    local okD, stamp = pcall(os.date, "%Y-%m-%d %H:%M")
    add("Mod Menu report")
    add("Mod Menu " .. VERSION .. (okD and ("   " .. tostring(stamp)) or ""))
    add("Runs from: " .. tostring(root))
    add("Mods folder read: " .. tostring(DISC.root or "unknown") .. " (" .. DISC.how .. ")")
    add("Opened with: " .. (panel.mode == "pad" and "controller" or "mouse and keyboard")
        .. (panel.inWorld and ", in a world" or ", outside a world"))
    add("")
    add(#mods .. " mods with a settings page:")
    local problems = 0
    for _, m in ipairs(mods) do
        add("- " .. m.name .. (m.version and (" " .. m.version) or "") .. "   [folder " .. m.folder .. ", id " .. m.id .. "]"
            .. (m.off and "   SWITCHED OFF" or ""))
        local cf = readFile(m.cfgPath)
        add("    settings file: " .. tostring(m.cfgPath):sub(#tostring(m.dir) + 2) .. " (" .. m.format .. ")"
            .. (cf and "" or ", not there yet"))
        if m.off then problems = problems + 1 end
        for _, e in ipairs(m.errors) do add("    ! " .. e); problems = problems + 1 end
        for _, s in ipairs(m.settings) do
            local v = s.key and m.values[s.key]
            if s.type == "slider" and type(v) == "number" and (v < s.min or v > s.max) then
                add("    kept from the file: " .. s.key .. " = " .. plainNumber(v) .. " (slider " .. formatValue(s, s.min)
                    .. " to " .. formatValue(s, s.max) .. ")")
            elseif isKeySetting(s) then
                local c = keyClash(m, s)
                if c then add("    " .. s.key .. " = " .. tostring(v) .. "  " .. c); problems = problems + 1 end
            end
        end
    end
    add("")
    -- 2.0: the modules, and what the health check found
    local st = {}
    for _, n in ipairs({ "builtin", "health", "keys", "quickpanel" }) do st[#st + 1] = n .. " " .. tostring(MM.modState[n] or "?") end
    add("Modules: " .. table.concat(st, ", "))
    for _, l in ipairs(modCall(MM.HEALTH, "reportLines") or {}) do add(tostring(l)) end
    add("")
    add(problems .. " thing(s) to look at.")
    return writeFile(root .. "\\report.txt", table.concat(L, "\r\n") .. "\r\n")
end

-- 2.0 views (design 3, 4): "page" (a mod's settings), "health", "keys", "pinned", "results" (search). NAV.show draws
-- one; to = { view = ..., page = index, row = key }.
function NAV.show(to)
    local ui = panel.ui
    if not ui then return end
    saveDirty(true)
    -- BACK steps through the views shown before (design 4); a jump to a row on the same page is no new step
    local cur = NAV.view or "page"
    if not to.back and (cur ~= to.view or (to.view == "page" and to.page and to.page ~= panel.page)) then
        NAV.stack = NAV.stack or {}
        NAV.stack[#NAV.stack + 1] = { view = cur, page = panel.page, query = ui.query }
        if #NAV.stack > 20 then table.remove(NAV.stack, 1) end
    end
    NAV.jump, NAV.jumped = nil, nil
    if to.view == "page" and to.row then NAV.jump = { key = to.row, stage = 0 } end
    if to.view ~= "results" and ui.query ~= "" then           -- leaving the results: the box keeps its text, quietly
        NAV.lastQuery = ui.query
    end
    if to.view == "results" and not to.back then NAV.query = ui.query end
    if to.view == "page" then
        if to.page then panel.page = to.page end
        NAV.view = "page"
    else
        NAV.view = to.view
    end
    local ok, e = pcall(LAY.fillView, ui)
    if not ok then log("page error: " .. tostring(e)) end
end

-- [<] / [>] (and LB / RB): the previous / next mod in sidebar order, from any view.
function NAV.step(dir)
    if #mods == 0 then return end
    local i = panel.page
    if (NAV.view or "page") == "page" then i = (i - 1 + dir) % #mods + 1 end
    NAV.show({ view = "page", page = i })
end

-- 2.0: PIN LAST in the docked menu's footer (a slider keeps Left / Right for its value, so a pad cannot reach its
-- row's pin icon from it; design 4 fallback when Y is unreadable).
function NAV.footer(ui, foot)
    if MM.QP and MM.QP.stub then return end                -- C40: in both modes, so the bar is the same everywhere
    local box, b = LAY.textButton(ui, "PIN LAST", ui.footW or LAY.FOOT_W, LAY.BTN_H, 14, CREAM, "medium", 2)
    if not b then return end
    LAY.hadd(foot, box, true, { Left = 16, Top = 0, Right = 0, Bottom = 0 })
    panel.buttons.pinLast, ui.pinLastB = b:GetFullName(), b
end
function NAV.pinLast() PAD.rowAction("pin", true) end
-- C42 (user: "You can't unpin"): on the PINNED page an unpinned row stayed in the list (only its PIN went gray), so
-- the unpin looked refused. The page is drawn again without it; the hint line says "Unpinned: <setting>."
function NAV.unpinned(on, why)
    if on or why or NAV.view ~= "pinned" then return end
    NAV.show({ view = "pinned" })
    if panel.mode == "pad" then PAD.focusNext = true end
end

-- 2.0 search (design 3 "Search"): every setting of every mod, over the mod name, label, key, tooltip, options and
-- valueLabels; up to 50 hits, mods in sidebar order. A mod-name hit is that mod's page (no row).
NAV.MAX_HITS = 50
function NAV.search(q)
    q = tostring(q or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local hits = {}
    if q == "" then return hits end
    local function has(t) return type(t) == "string" and t:lower():find(q, 1, true) ~= nil end
    for i, m in ipairs(mods) do
        if has(m.name) and #hits < NAV.MAX_HITS then hits[#hits + 1] = { idx = i, m = m } end
        for _, s in ipairs(m.settings) do
            if #hits >= NAV.MAX_HITS then return hits end
            if s.type ~= "header" and not s.locked then
                local hit = has(s.label) or has(s.key) or has(s.tooltip)
                if not hit and type(s.valueLabels) == "table" then
                    for _, w in pairs(s.valueLabels) do if has(w) then hit = true end end
                end
                if not hit and s.type == "choice" then
                    for _, o in ipairs(s.options) do if has(o) then hit = true end end
                end
                if hit then hits[#hits + 1] = { idx = i, m = m, s = s } end
            end
        end
    end
    return hits
end

-- The Results view: one game button per hit, "Mod: Label   value"; a hit opens its page at that row.
function NAV.fillResults(ui, q)
    LAY.clearPage(ui)
    NAV.view, NAV.query = "results", q
    share("ModMenu.page", "#results")
    local hits = NAV.search(q)
    local more = #hits >= NAV.MAX_HITS and " (the first " .. NAV.MAX_HITS .. ")" or ""
    LAY.header(ui, "SEARCH", #hits .. " result" .. (#hits == 1 and "" or "s") .. " for \"" .. tostring(q) .. "\"" .. more, GREY,
        #hits > 0 and "Pick one to open its page at that setting. BACK returns to where you were." or "Nothing matches. Try another word.")
    local d = LAY.dims()
    panel.checkRows = {}
    for _, h in ipairs(hits) do
        local text = h.m.name .. (h.s and (": " .. h.s.label .. (h.s.key and ("   " .. MM.display(h.s, h.m.values[h.s.key])) or "")) or "")
        local b = makeGameButton(panel.pc, LAY.fit(text, d.RW - 20), ui.like)
        if b then
            ui.scroll:AddChild(sized(ui.tree, b, d.RW - 20, 56))
            panel.buttons.actions[b:GetFullName()] = { open = h.m.id, row = h.s and h.s.key or nil }
            panel.checkRows[#panel.checkRows + 1] = b
        end
    end
    LAY.afterView(ui)
end

-- The search box, read once a tick (mouse and keyboard: a pad cannot type). Typing shows the results; emptying the
-- box goes back to the view before them.
function NAV.searchTick()
    local ui = panel.ui
    local okS, q = pcall(function() return ui.search:GetText():ToString() end)
    if not okS or q == nil then return end
    q = tostring(q)
    if q == ui.query then return end
    ui.query = q
    if q:gsub("%s", "") ~= "" then
        if NAV.view ~= "results" then NAV.show({ view = "results" }) else NAV.fillResults(ui, q) end
    elseif NAV.view == "results" then
        NAV.back()
    end
end

-- BACK (button; a pad's B closes the pause menu and cannot be caught, journal 13927): a jumped-to row goes to the
-- page top first, then each press returns to the view shown before.
function NAV.back()
    local ui = panel.ui
    if not ui then return end
    if (NAV.view or "page") == "page" and NAV.jumped then
        NAV.jumped = nil
        pcall(function() ui.scroll:SetScrollOffset(0) end)
        return
    end
    local prev = NAV.stack and table.remove(NAV.stack)
    if not prev then
        if (NAV.view or "page") ~= "page" then NAV.show({ view = "page", back = true }) end
        return
    end
    if NAV.view == "results" and prev.view ~= "results" then          -- leaving the results empties the box
        ui.query = ""
        pcall(function() ui.search:SetText(FText("")) end)
    end
    if prev.view == "results" then
        ui.query = prev.query or ""
        pcall(function() ui.search:SetText(FText(ui.query)) end)
        NAV.query = ui.query
    end
    NAV.show({ view = prev.view, page = prev.page, back = true })
end

-- The jump after a page is drawn (design 3, ghost-row fix journal 13915): the tick after fillPage scrolls the row
-- into the middle (its folded section opened first), the next two ticks invalidate the list's layout; the row's
-- label shows gold for 3 s. A row its showIf hides is not shown: the hint says so.
function NAV.jumpTick()
    local j, ui = NAV.jump, panel.ui
    if not j or not ui then return end
    if j.stage == 0 then
        local target, header = nil, nil
        for _, row in ipairs(panel.order or {}) do
            if row.setting.type == "header" then header = row end
            if row.setting.key == j.key then target = row; break end
        end
        if not target then NAV.jump = nil; return end
        if header and header.folded then NAV.toggleFold(header) end
        if target.hidden then
            panel.flash = { text = target.setting.label .. " shows only when another setting on this page is set for it.",
                            till = os.clock() + 6 }
        end
        pcall(function() ui.scroll:ScrollWidgetIntoView(target.holder, true, 2, 0) end)
        if valid(target.label) then
            pcall(function() target.label:SetColorAndOpacity({ SpecifiedColor = GOLD, ColorUseRule = 0 }) end)
            NAV.flashRow = { row = target, till = os.clock() + 3 }
        end
        panel.lastRow, NAV.jumped = target, true
        j.stage = 1
    elseif j.stage <= 2 then
        pcall(function() ui.scroll:InvalidateLayoutAndVolatility() end)
        j.stage = j.stage + 1
        if j.stage > 2 then NAV.jump = nil end
    end
end

-- Every tick while open: the jump, the gold label going back, a kept scroll offset put back after a page is drawn.
function NAV.tick()
    NAV.jumpTick()
    local f = NAV.flashRow
    if f and os.clock() >= f.till then
        NAV.flashRow = nil
        if valid(f.row.label) then
            pcall(function() f.row.label:SetColorAndOpacity({ SpecifiedColor = f.row.joinedGray and GREY or CREAM, ColorUseRule = 0 }) end)
        end
    end
    if NAV.scrollTo and panel.ui then
        local off = NAV.scrollTo
        NAV.scrollTo = nil
        pcall(function() panel.ui.scroll:SetScrollOffset(off) end)
        NAV.jump = NAV.jump or { stage = 1 }                   -- then the same two layout invalidations
    end
end

-- The kept place (design 4): view, mod, last row, scroll offset; folds are kept in NAV.folds, the search text in the
-- box's query. Taken at every close; the mod (or check page) is saved as LastPage for the next game session.
function NAV.keep()
    local ui = panel.ui
    if not ui then return end
    local m = mods[panel.page]
    local off = nil
    pcall(function() off = ui.scroll:GetScrollOffset() end)
    NAV.place = { view = NAV.view or "page", id = m and m.id, scroll = type(off) == "number" and off or 0,
                  row = panel.lastRow and panel.lastRow.setting and panel.lastRow.setting.key, query = ui.query }
    local last = (NAV.place.view == "page" or NAV.place.view == "results") and NAV.place.id or ("#" .. NAV.place.view)
    if last and last ~= cfg.LastPage then pcall(saveOwn, "LastPage", last) end
end

-- At open: a request.open's page and row; else the kept place of this session; else LastPage from config.txt.
function NAV.restore(ui)
    local to = NAV.openTo
    NAV.openTo, NAV.stack, NAV.jump, NAV.jumped = nil, {}, nil, nil
    if to and to.view then                                  -- a check page or search asked for by request.open
        NAV.view = to.view
        if to.view == "results" then
            ui.query, NAV.query = to.query or "", to.query or ""
            pcall(function() ui.search:SetText(FText(ui.query)) end)
        end
        return
    end
    if to then
        NAV.view = "page"
        panel.page = to.page
        if to.row then NAV.jump = { key = to.row, stage = 0 } end
        return
    end
    local p = NAV.place
    if not p and type(cfg.LastPage) == "string" and cfg.LastPage ~= "" then
        local v = cfg.LastPage:match("^#(%a+)$")
        p = { view = (v == "health" or v == "keys" or v == "pinned") and v or "page", id = not v and cfg.LastPage or nil }
    end
    if not p then return end
    for i, m in ipairs(mods) do if m.id == p.id then panel.page = i end end
    NAV.view = (p.view == "results") and "page" or p.view
    if p.view == "results" and p.query and p.query ~= "" then
        NAV.view = "results"
        ui.query = p.query
        pcall(function() ui.search:SetText(FText(p.query)) end)
        NAV.query = p.query
    end
    if (NAV.view == "page" or NAV.view == "results") and (p.scroll or 0) > 0 then NAV.scrollTo = p.scroll end
end

-- 2.0 folding sections and showIf rows (design 2). Fold state per mod and header, kept for the session; a header's
-- "collapsed": true sets where it starts. Hidden rows are Collapsed in place (no rebuild, so a drag or the pad focus
-- elsewhere on the page is not lost), their notes too, and the controller links skip them.
NAV.folds = {}
function NAV.foldKey(m, s) return tostring(m.id) .. "#" .. tostring(s.idx or s.label) end
function NAV.isFolded(m, s)
    local f = NAV.folds[NAV.foldKey(m, s)]
    if f == nil then return s.collapsed == true end
    return f
end

-- Does a row's showIf hold for its mod's current values? C10: "is" is typed to the target (a toggle's true/false, a
-- slider's number, a choice's option text); a list = any of them.
function NAV.showIfOk(m, s)
    local c = s.showIf
    if not c then return true end
    local t = MM.setting(m, c.key)
    if not t then return true end
    local v = m.values[t.key]
    local list = (type(c.is) == "table") and c.is or { c.is }
    for _, e in ipairs(list) do
        if t.type == "slider" then
            local n = tonumber(e)
            if n and type(v) == "number" and math.abs(n - v) <= stepEps(t) then return true end
        elseif t.type == "toggle" or t.type == "choice" then
            if coerce(t, e) == v then return true end
        elseif tostring(e) == tostring(v) then
            return true
        end
    end
    return false
end

function NAV.applyVisibility()
    local folded, changed = false, false
    for _, row in ipairs(panel.order or {}) do
        local s, hide = row.setting, false
        if s.type == "header" then folded = row.folded == true
        else hide = folded or not NAV.showIfOk(row.mod, s) end
        if hide ~= (row.hidden == true) then
            changed = true
            row.hidden = hide or nil
            if valid(row.holder) then
                if hide and row.shownVis == nil then
                    local ok, v = pcall(function() return row.holder:GetVisibility() end)
                    row.shownVis = (ok and type(v) == "number") and v or 0
                end
                local vis = hide and 1 or (row.shownVis or 0)
                pcall(function() row.holder:SetVisibility(vis) end)
            end
            if valid(row.note) then pcall(function() row.note:SetVisibility((row.noteText and not hide) and 4 or 1) end) end
        end
    end
    if changed and panel.mode == "pad" then LAY.relink = true end
    if changed then LAY.pageSnapped = nil end                -- 2.0.1 item 3: row heights changed, fit the box again once still
end

function NAV.toggleFold(row)
    row.folded = not row.folded
    NAV.folds[NAV.foldKey(row.mod, row.setting)] = row.folded
    if valid(row.header) then
        LAY.setText(row.headText, (row.folded and "+  " or "-  ") .. row.setting.label)
    end
    NAV.applyVisibility()
end

-- A value changed: rows of the shown page whose showIf names it are checked again.
function NAV.onSet(m, s)
    if (NAV.view or "page") ~= "page" or mods[panel.page] ~= m then return end
    for _, st in ipairs(m.settings) do
        if st.showIf and st.showIf.key == s.key then NAV.applyVisibility(); return end
    end
end

-- 2.0: after MM.setValue (any source) while the menu is open: the rows of that setting (dot, reset, value word,
-- pin), the mod's changed count; a row whose reset icon came or went needs new controller links.
function MM.afterSet(m, s, v, source)
    if not panel.open then return end
    for _, row in ipairs(panel.rows or {}) do
        if row.setting == s then
            local was = row.changed
            LAY.rowState(row)
            if was ~= row.changed then LAY.relink = true end
        end
    end
    LAY.refreshMod(m)
    if NAV.onSet then NAV.onSet(m, s, v, source) end
    -- Text size (PanelScale, C8b): the menu is drawn again at the new size, at once for a request.set, else once the
    -- slider has been still for 0.6 s and is not held (a drag is never cut off)
    if m.id == "ModMenu" and s.key == "PanelScale" and LAY.textSize() ~= LAY.T then
        LAY.redrawAt = os.clock() + (source == "page" and 0.6 or 0)
    end
end

-- C37: the card: gold edge Border (1 px padding) > warm dark Border (CARD_PAD) > content.
function LAY.card(ui, content)
    local edge = construct("Border", ui.tree)
    local fill = construct("Border", ui.tree)
    if not (valid(edge) and valid(fill)) then return nil end
    pcall(function() edge:SetBrushColor(LAY.RULE_EDGE) end)
    pcall(function() edge:SetPadding({ Left = 1, Top = 1, Right = 1, Bottom = 1 }) end)
    pcall(function() fill:SetBrushColor(LAY.CARD_FILL) end)
    local p = LAY.CARD_PAD
    pcall(function() fill:SetPadding({ Left = p, Top = p, Right = p, Bottom = p }) end)
    pcall(function() fill:SetContent(content) end)
    pcall(function() edge:SetContent(fill) end)
    return edge
end

-- C37: hide the game panel's own art: every widget of its tree that is not on the way to PanelContent is Collapsed,
-- a Border on that way gets a clear brush. False (nothing changed) when PanelContent is not found in the tree.
function LAY.cardFrame(frame)
    local content, root = nil, nil
    pcall(function() content = frame.PanelContent end)
    pcall(function() root = frame.WidgetTree.RootWidget end)
    if not (valid(content) and valid(root)) then return false end
    local target = ""
    pcall(function() target = content:GetFullName() end)
    local function fullOf(w) local n = ""; pcall(function() n = w:GetFullName() end); return n end
    local function kids(w)
        local t, n = {}, 0
        pcall(function() n = w:GetChildrenCount() end)
        for i = 0, (n or 0) - 1 do local c = nil; pcall(function() c = w:GetChildAt(i) end); if valid(c) then t[#t + 1] = c end end
        return t
    end
    local onPath = {}
    local function find(w, d)
        if d > 14 or not valid(w) then return false end
        if fullOf(w) == target then return true end
        for _, c in ipairs(kids(w)) do
            if find(c, d + 1) then onPath[fullOf(w)] = true; return true end
        end
        return false
    end
    if not find(root, 0) then return false end
    local function strip(w, d)
        if d > 14 or not valid(w) then return end
        local n = fullOf(w)
        if n == target then return end
        if onPath[n] then
            pcall(function() w:SetBrushColor(LAY.CLEAR) end)
            pcall(function() w:SetColorAndOpacity({ R = 0, G = 0, B = 0, A = 0 }) end)
            for _, c in ipairs(kids(w)) do strip(c, d + 1) end
        else
            pcall(function() w:SetVisibility(1) end)
        end
    end
    strip(root, 0)
    return true
end

-- C37 (2): our On / Off pill over the game checkbox. The checkbox stays where it is, Visible, at render opacity 0, so
-- the mouse click and the pad's A still reach it; the pill takes no input (HitTestInvisible). nil = not built.
-- C41.8: a Border drawn as a rounded box, half its height as the radius (a capsule; a circle when square). Set
-- before Slate builds it, like the scroll bar style (probe sbar.lua: struct fields take a write).
function LAY.round(b)
    pcall(function() b.Background.DrawAs = 4 end)                      -- ESlateBrushDrawType::RoundedBox
    pcall(function() b.Background.OutlineSettings.RoundingType = 1 end) -- ESlateBrushRoundingType::HalfHeightRadius
end

function LAY.switch(ui)
    local tree = ui.tree
    local pill = construct("Border", tree)
    if not valid(pill) then return nil end
    pcall(function() pill:SetPadding({ Left = 4, Top = 4, Right = 4, Bottom = 4 }) end)
    LAY.round(pill)                                           -- C41.8: a capsule
    local hb = construct("HorizontalBox", tree)
    local function knob()
        local k = construct("Border", tree)
        pcall(function() k:SetBrushColor({ R = 0.79, G = 0.71, B = 0.57, A = 1 }) end)
        LAY.round(k)                                          -- C41.8: a round knob
        return sized(tree, k, 24, 24)
    end
    local kL, kR = knob(), knob()
    local text = newText(tree, ui.textC, "OFF", 11, CREAM, "medium")   -- fixed 11 pt: the pill keeps its size
    pcall(function() text:SetAutoWrapText(false) end)
    pcall(function() text:SetJustification(1) end)
    LAY.hadd(hb, kL, true)
    LAY.hadd(hb, LAY.rightCell(ui, text, 36), true)
    LAY.hadd(hb, kR, true)
    pcall(function() pill:SetContent(hb) end)
    local root = sized(tree, pill, LAY.SWITCH_W, 32)
    pcall(function() root:SetVisibility(3) end)
    return { root = root, pill = pill, kL = kL, kR = kR, text = text }
end

function LAY.switchState(row)
    local sw = row.switch
    if not sw then return end
    local on = row.mod.values[row.setting.key] == true
    if row.switchOn == on then return end
    row.switchOn = on
    pcall(function() sw.pill:SetBrushColor(on and LAY.SWITCH_ON or LAY.SWITCH_OFF) end)
    LAY.setText(sw.text, on and "ON" or "OFF")
    pcall(function() sw.text:SetColorAndOpacity({ SpecifiedColor = on and LAY.SWITCH_ON_TEXT or GREY, ColorUseRule = 0 }) end)
    pcall(function() sw.kL:SetVisibility(on and 1 or LAY.SHOWN) end)
    pcall(function() sw.kR:SetVisibility(on and LAY.SHOWN or 1) end)
end
LAY.MOUSE_HINT = "Point at a setting to read about it here."   -- C40: the hint band with the mouse
LAY.SWITCH_W = 72                                              -- the pill and the trimmed checkbox box
LAY.SWITCH_ON = { R = 0.69, G = 0.45, B = 0.10, A = 1 }        -- gold (linear)
LAY.SWITCH_OFF = { R = 0.06, G = 0.055, B = 0.05, A = 1 }      -- dark gray (linear)
LAY.SWITCH_ON_TEXT = { R = 0.05, G = 0.04, B = 0.02, A = 1 }

-- Draws the whole menu again (text size changed): closed and opened in the same mode and view, in one call.
function LAY.redraw()
    LAY.redrawAt = nil
    if not panel.open then return end
    local mode = panel.mode
    if NAV.keep then NAV.keep() end
    closePanel(true)
    openPanel(mode)
    if mode == "pad" and panel.open then PAD.focusNext = true end   -- the pad back into the menu (C6 route)
    log("text size " .. math.floor(LAY.T * 100 + 0.5) .. ": menu drawn again")
end

-- The footer line: a message for a few seconds, else the hovered row's tooltip, else the controller help.
local function showHint(hint)
    if panel.flash then
        if os.clock() < panel.flash.till then hint = panel.flash.text else panel.flash = nil end
    end
    hint = hint or (panel.mode == "pad" and PAD.HINT or LAY.MOUSE_HINT)
    if hint ~= panel.hintShown then
        panel.hintShown = hint
        pcall(function() panel.ui.hint:SetText(FText(hint)) end)
    end
end

local function panelTick()
    if not panel.open then saveDirty(false); return end
    if not valid(panel.frame) then panel.open = false; share("ModMenu.page", ""); shareRect(panel); return end
    if panel.mode == "pad" then
        local okA, act = pcall(function() return panel.pm:IsActivated() end)
        if not (okA and act) then closePanel(true); return end   -- B (or RESUME) closed the pause menu: go with it
        if DOCK.lost() then                                      -- 1.0.14: another mod docked its panel here
            panel.displaced = true
            log("closed: " .. tostring(DOCK.owner) .. " opened its panel in the pause menu")
            closePanel(true)
            return
        end
        if PAD.focusNext then PAD.focusNext = nil; PAD.focusPanel() end   -- 1.1.3: docked request.open
        if PAD.focusSeg then                                     -- C54 (F-2): the Keys segment just chosen
            local sw = panel.keysSegs and panel.keysSegs[PAD.focusSeg]
            PAD.focusSeg = nil
            if valid(sw) and valid(panel.pc) then
                local r = nil
                pcall(function() r = sw.WidgetTree.RootWidget end)
                local tgt = valid(r) and r or sw
                pcall(function() tgt:SetUserFocus(panel.pc) end)
            end
        end
        PAD.pollPanel()
        if not PAD.fastLoop then PAD.buttons() end              -- 2.0: LB / RB / X / Y (C26: on the 50 ms loop)
        pcall(LAY.focusTick)                                     -- C28: highlight the row the pad is on
    end
    pcall(LAY.sideTick)                                          -- C41.1 / C41.2
    pcall(LAY.pageSnap)                                          -- C45.1
    if panel.inkQ then                                           -- C41.7: the slider value text after its Construct
        local q = panel.inkQ
        for _, w in ipairs(q) do LAY.ink(w) end
        q.n = q.n - 1
        if q.n <= 0 then panel.inkQ = nil end
    end
    if LAY.relink and panel.mode == "pad" then LAY.relink = nil; pcall(PAD.afterFill, panel.ui) end   -- 2.0
    if LAY.redrawAt and os.clock() >= LAY.redrawAt then
        local held = false
        for _, row in ipairs(panel.rows) do if row.capPrev == true then held = true end end
        if not held then LAY.redraw(); return end
    end
    if not panel.pending and panel.clickQ and #panel.clickQ > 0 then panel.pending = table.remove(panel.clickQ, 1) end   -- C42
    local p = panel.pending
    panel.pending = nil
    local view = NAV.view or "page"
    local m = view == "page" and mods[panel.page] or nil
    if p then
        if p.close then closePanel(); return end
        if p.page and (p.page ~= panel.page or view ~= "page" or p.row) then
            NAV.show({ view = "page", page = p.page, row = p.row })
            return
        end
        if p.view then NAV.show({ view = p.view }); return end              -- 2.0: CHECKS entries
        if p.nav == "prev" or p.nav == "next" then NAV.step(p.nav == "next" and 1 or -1); return end
        if p.nav == "back" and NAV.back then NAV.back(); return end
        if p.reset then
            if m then resetMod(m) else panel.flash = { text = "Open a mod's page to reset it.", till = os.clock() + 5 } end
            return
        end
        if p.report then
            local okW, res = pcall(writeReport)
            if okW and res then log("report saved")
            else log("report not saved: " .. tostring(res)) end
            panel.flash = { till = os.clock() + 8, text = (okW and res)
                and "Report saved: ue4ss\\Mods\\ModMenu\\report.txt. Paste its text when you ask for help."
                or "! The report could not be written to the ModMenu folder." }
        end
        if p.pinLast and NAV.pinLast then NAV.pinLast() end
        if p.action then
            local a = p.action
            if a.clear then
                writeWidget(a.clear, "none")                 -- read back below like any other change
            elseif a.cycle then
                local row, s = a.cycle, a.cycle.setting
                local i = 1
                for k, o in ipairs(s.options) do if o == row.cycleValue then i = k end end
                writeWidget(row, s.options[i % #s.options + 1])
            elseif a.mod then
                a.mod.actionN = a.mod.actionN + 1
                share("ModMenu." .. a.mod.id .. ".action", a.action .. "#" .. a.mod.actionN)
                log(a.mod.name .. ": " .. a.action)
            elseif a.reset then                              -- 2.0: reset one setting
                local row = a.reset
                MM.setValue(row.mod, row.setting, row.setting.default, "reset")
                panel.lastRow = row
            elseif a.pin then                                -- 2.0: pin / unpin for the Quick Panel
                local row = a.pin
                local on, why = modCall(MM.QP, "togglePin", row.mod.id, row.setting.key)
                -- C12: a refusal shows its reason; C42 (user: "You can't unpin"): pin and unpin both say what they did
                panel.flash = { text = why and tostring(why) or ((on and "Pinned to the Quick Panel: " or "Unpinned: ")
                    .. row.setting.label .. "."), till = os.clock() + (why and 5 or 4) }
                LAY.rowState(row)
                LAY.refreshMod(row.mod)
                if NAV.unpinned then NAV.unpinned(on, why) end
            elseif a.fold and NAV.toggleFold then
                NAV.toggleFold(a.fold)
            elseif a.keysView then                           -- C48: Keyboard | Controller on the Keys page
                modCall(MM.KEYS, "setView", a.keysView)
                NAV.show({ view = "keys" })
                if panel.mode == "pad" then PAD.focusSeg = a.keysView end   -- C54 (F-2): stay on the chosen segment
                return
            elseif a.open then                               -- 2.0: a check page row opens that mod's page
                for i, om in ipairs(mods) do
                    if om.id == a.open then NAV.show({ view = "page", page = i, row = a.row }); return end
                end
            end
        end
    end
    if NAV.tick then NAV.tick() end                          -- 2.0: jump, gold label, kept scroll offset
    if panel.ui and panel.ui.search and NAV.searchTick then NAV.searchTick() end
    local sideHint = nil                                     -- C34: a sidebar name cut with "..." shows whole on hover
    for _, e in ipairs(panel.ui and panel.ui.modBtns or {}) do
        if e.full and valid(e.w) then
            local okH, h = pcall(function() return e.w:IsHovered() end)
            if okH and h then sideHint = e.full end
        end
    end
    for _, h in ipairs(panel.checkHints or {}) do           -- C38: a check page's hover hints (keyboard caps ...)
        if type(h) == "table" and valid(h.w) then
            local okH, hov = pcall(function() return h.w:IsHovered() end)
            if okH and hov then sideHint = tostring(h.text or ""); break end
        end
    end
    if #panel.rows == 0 then showHint(sideHint); return end
    local hint, keysChanged = nil, false
    local pad = panel.mode == "pad"
    local mouse = (not pad) and cursorTick() or nil          -- 1.1.3: a click on a slider handle is no change
    for _, row in ipairs(panel.rows) do
        local s, rm = row.setting, row.mod or m
        if row.widget and s.key and rm then
            local v, raw = readWidget(row)
            if s.type == "slider" and type(raw) == "number" then   -- 1.0.14: on the step grid, one step per pad press
                local cur = nil
                if mouse then
                    local cap = nil
                    pcall(function() local c = row.widget.InputSlider:HasMouseCapture(); if type(c) == "boolean" then cap = c end end)
                    cur = { still = mouse.still, cap = cap, x = mouse.x, y = mouse.y }
                end
                v = sliderRowTick(row, raw, pad, cur)
            end
            if v ~= nil and v ~= row.last then
                row.last = v
                -- 2.0: one write path for every source (MM.setValue, below the request handlers)
                if MM.setValue(rm, s, v, "page") then
                    panel.lastRow = row
                    if isKeySetting(s) then keysChanged = true end
                end
            end
        end
        if not hint and (s.tooltip or row.runsOn or row.apply) and valid(row.holder) then
            local ok, h = pcall(function() return row.holder:IsHovered() end)
            if ok and h then hint = LAY.hintFor(row) end
        end
    end
    if keysChanged then refreshKeyNotes() end
    saveDirty(false)
    showHint(hint or sideHint)
end

-- Other mods can open the menu at their own page: SetSharedVariable("ModMenu.request.open", "<id>#<n>")
-- with n changing each time (so a repeat request is still seen).
local lastOpenReq = nil

-- 2.0 (design 1.3): THE write path for a value, game thread only: a page edit (panelTick, source "page"), a Quick
-- Panel step ("quick"), a reset ("reset"), a request.set ("request"). Keeps the value, publishes it with a new rev,
-- marks the mod for saving, mirrors Mod Menu's own settings into cfg (they are read from the file only at startup),
-- writes the widget when the row is shown (not for "page": the widget is where the value came from) and tells the
-- Quick Panel. Returns true when the value changed.
function MM.setValue(m, s, v, source)
    if not (m and s and s.key) or v == nil or v == m.values[s.key] then return false end
    m.values[s.key] = v
    m.rev = m.rev + 1
    share("ModMenu." .. m.id .. "." .. s.key, v)
    share("ModMenu." .. m.id .. ".rev", m.rev)
    panel.dirty[m.id] = true
    panel.lastEdit = os.clock()
    if m.id == "ModMenu" and cfg[s.key] ~= nil then
        cfg[s.key] = v
        if s.key == "PanelScale" then
            applyScale(panel)
            if MM.ui and LAY.textSize then MM.ui.T = LAY.textSize() end   -- C12: the Quick Panel rebuilds on it
        end
    end
    if source ~= "page" and panel.open then
        for _, row in ipairs(panel.rows or {}) do
            if row.setting == s and row.widget then
                writeWidget(row, v)
                row.last, row.hold, row.raw, row.refused, row.click = v, nil, v, nil, nil   -- read back as no change
            end
        end
    end
    if MM.QP then pcall(MM.QP.onValue, m.id, s.key, v) end
    if MM.afterSet then pcall(MM.afterSet, m, s, v, source) end
    return true
end
local function requestTick()
    local ok, r = pcall(function() return ModRef:GetSharedVariable("ModMenu.request.open") end)
    if not ok or type(r) ~= "string" or r == lastOpenReq then return end
    lastOpenReq = r
    local id = r:match("^([^#]*)")
    -- 2.0: "<id>#<n>|row=<Key>" opens the page at that row (1.1.x reads only the id, so the suffix is safe there)
    local rowKey = r:match("|row=([%w_%.%-]+)")
    if not panel.open then discover() end
    -- 2.0 (C29, the lint opens every page): "#health#<n>", "#keys#<n>", "#pinned#<n>", "#search#<n>|q=<text>",
    -- "#close#<n>" closes the menu
    local view = id == "" and r:match("^#(%a+)") or nil
    if view == "close" then if panel.open then closePanel() end return end
    if view == "health" or view == "keys" or view == "pinned" or view == "search" then
        local to = view == "search" and { view = "results", query = r:match("|q=([^|]*)") or "" } or { view = view }
        if panel.open then
            if to.view == "results" then
                panel.ui.query = to.query
                pcall(function() panel.ui.search:SetText(FText(to.query)) end)
            end
            NAV.show(to)
            return
        end
        NAV.openTo = to
        local pm = findPauseMenu()
        local okA, act = pcall(function() return pm:IsActivated() end)
        if valid(pm) and okA and act then
            PAD.unselect(MENU.btn)
            openPanel("pad")
            PAD.focusNext = panel.open and panel.mode == "pad" or nil
        else
            openPanel()
        end
        return
    end
    for i, m in ipairs(mods) do
        if m.id == id then
            if panel.open then
                if i ~= panel.page or rowKey or NAV.view ~= "page" then NAV.show({ view = "page", page = i, row = rowKey }) end
            else
                panel.page = i
                NAV.openTo = { page = i, row = rowKey }    -- 2.0: this page, not the kept place
                -- 1.1.3: with the pause menu up, open docked in it as MODS does for a controller. The mouse
                -- layout opened under the pause menu's dimmer and looked blank (journal 2026-10-14).
                local pm = findPauseMenu()
                local okA, act = pcall(function() return pm:IsActivated() end)
                if valid(pm) and okA and act then
                    PAD.unselect(MENU.btn)                 -- a pending pad press on MODS must not reopen it later
                    openPanel("pad")
                    PAD.focusNext = panel.open and panel.mode == "pad" or nil   -- the pad goes into the panel
                else
                    openPanel()
                end
            end
            return
        end
    end
    log("open request for unknown mod '" .. tostring(id) .. "'")
end

-- 1.1.2: a mod can change its OWN settings (for example a "Style" choice that sets several others):
-- SetSharedVariable("ModMenu.request.set", "<id>#<n>|Key=value|Key=value"), n changing each time. Each value is
-- checked like a value read from the config file (a wrong key, type or option is skipped), then kept, shown on
-- the page if it is open, published and saved exactly like a change made by the player. Key settings are skipped.
-- 1.1.2: while the menu is closed, a request reads the mod's files again first. The mod may have rewritten its
-- modmenu.json after Mod Menu loaded it (Custom Capes writes its picture list), so a new option would be refused
-- against the old list, and a value refused at load (shown as the default) would be saved over its config file.
-- Values that differ from what was sent are published with a new rev, like a change made on the page.
local function reloadMod(m)
    if panel.open or panel.dirty[m.id] then return m end
    local ok, n = pcall(loadSchema, m.folder, m.dir)
    if not ok or type(n) ~= "table" then return m end
    n.id, n.rev, n.actionN = m.id, m.rev, m.actionN
    local moved = false
    for _, s in ipairs(n.settings) do
        if s.key and n.values[s.key] ~= m.values[s.key] then moved = true end
    end
    if moved then n.rev = n.rev + 1 end
    for i, x in ipairs(mods) do if x == m then mods[i] = n end end
    modsById[m.id] = n
    publishAll(n)
    return n
end

local lastSetReq = nil
local function setRequestTick()
    local ok, r = pcall(function() return ModRef:GetSharedVariable("ModMenu.request.set") end)
    if not ok or type(r) ~= "string" or r == lastSetReq then return end
    lastSetReq = r
    local id = r:match("^([^#|]*)")
    local m = modsById[id]
    if not m then log("set request for unknown mod '" .. tostring(id) .. "'"); return end
    m = reloadMod(m)
    local shown = panel.open and mods[panel.page] == m
    local changed = false
    for key, raw in r:gmatch("|([%w_%.%-]+)=([^|]*)") do
        local s = nil
        for _, st in ipairs(m.settings) do if st.key == key then s = st end end
        local v = nil                                       -- 1.1.2: `cond and coerce() or nil` dropped false
        if s and s.type ~= "key" and not s.locked then v = coerce(s, raw) end
        -- 1.1.3: Mod Menu's own settings go to cfg too (journal 2026-10-14); 2.0: all of it is MM.setValue, which
        -- also writes the row when the page is shown (read back as no change)
        if v ~= nil and MM.setValue(m, s, v, "request") then changed = true end
    end
    if changed and not shown then saveDirty(true) end       -- the next menu open reads the file again
end

-- Own settings, read the same way other mods' are ---------------------------------------------------
local function loadOwnConfig()
    local root = modRoot()
    if not root then return end
    local ok, m = pcall(loadSchema, "ModMenu", root)
    if not ok or not m then return end
    for k, v in pairs(m.values) do if cfg[k] ~= nil then cfg[k] = v end end
    -- 2.0: lines that are no settings rows (Quick Panel pins, the page to reopen), kept as typed
    local text = readFile(root .. "\\config.txt") or ""
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        local k, v = line:gsub("\r$", ""):match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if k == "QuickPins" or k == "LastPage" then cfg[k] = (stripComment(v)) end
    end
end

-- 2.0: edits or appends one `Key = value` line in Mod Menu's own config.txt, keeping every other line as typed
-- (comments, QuickPins, LastPage). The settings rows are saved by saveValues as for any mod; this is for the rest.
function saveOwn(key, text)
    local root = modRoot()
    if not root or type(key) ~= "string" or not key:match("^[%w_]+$") then return false end
    text = tostring(text):gsub("[\r\n]", " ")
    local path = root .. "\\config.txt"
    local old = readFile(path) or ""
    local nl = old:find("\r\n", 1, true) and "\r\n" or "\n"
    local out, done = {}, false
    for line in (old .. "\n"):gmatch("([^\n]*)\n") do
        line = line:gsub("\r$", "")
        local indent, k, v = line:match("^(%s*)([%w_%.%-]+)%s*=%s*(.-)%s*$")
        if k == key and not done then
            local _, comment = stripComment(v)
            line = indent .. key .. " = " .. text .. (comment ~= "" and ("   " .. comment:gsub("^%s+", "")) or "")
            done = true
        end
        out[#out + 1] = line
    end
    while #out > 0 and out[#out] == "" do out[#out] = nil end
    if not done then out[#out + 1] = key .. " = " .. text end
    local ok = writeFile(path, table.concat(out, nl) .. nl)
    if ok then cfg[key] = text end
    return ok
end

-- 2.0 modules (design 1.2, 1.4) ----------------------------------------------------------------------------------
-- Each module is Scripts\<name>.lua, loaded by its absolute path (loadfile: a shared\keys.lua of another mod cannot
-- shadow it, as it could with require) and checked: it returns a table with MM_MODULE = its name and API = 1 and every
-- function core calls, and init(MM) does not fail. A missing module is replaced by its stub quietly, a broken one by
-- its stub and one log line; the reason stays in MM.modState for SAVE REPORT. builtin is data: any table.
local MODULE_FNS = {
    quickpanel = { "init", "tick", "canPin", "isPinned", "togglePin", "onValue", "onPanel", "pins", "shutdown" },
    keys = { "init", "gameKeys", "clashExtra", "clashCount", "buildPage" },
    health = { "init", "scan", "status", "summary", "buildPage", "reportLines" },
}

local function moduleStub(name, why)
    local function line(ui, scroll, text)
        pcall(function() scroll:AddChild(ui.newText(nil, nil, text, 16, ui.COLORS.GRAY)) end)
        return { rows = {} }
    end
    local t = { MM_MODULE = name, API = 1, stub = true, why = why }
    for _, fn in ipairs(MODULE_FNS[name] or {}) do t[fn] = function() end end
    if name == "quickpanel" then
        t.canPin = function() return false end
        t.isPinned = function() return false end
        t.togglePin = function() return false end
        t.pins = function() return {} end
    elseif name == "keys" then
        t.gameKeys = function() return {} end
        t.clashCount = function() return 0 end
        t.buildPage = function(ui, scroll) return line(ui, scroll, "Keys page did not load: " .. tostring(why)) end
    elseif name == "health" then
        t.status = function() return { state = "unknown" } end
        t.summary = function() return { problems = 0, unknown = 0 } end
        t.buildPage = function(ui, scroll) return line(ui, scroll, "Health check did not load: " .. tostring(why)) end
        t.reportLines = function() return {} end
    elseif name == "builtin" then
        return {}
    end
    return t
end

local function loadModule(name)
    local root = modRoot()
    local path = root and (root .. "\\Scripts\\" .. name .. ".lua")
    local function fail(why, quiet)
        MM.modState[name] = why
        if not quiet then log("module " .. name .. " not loaded (" .. why .. "); using the stub") end
        return moduleStub(name, why)
    end
    local f = path and io.open(path, "rb")
    if not f then return fail("missing", true) end
    f:close()
    local chunk, err = loadfile(path)
    if not chunk then return fail("syntax: " .. tostring(err)) end
    local ok, t = pcall(chunk)
    if not ok then return fail("error: " .. tostring(t)) end
    if type(t) ~= "table" then return fail("did not return a table") end
    if name ~= "builtin" then
        if t.MM_MODULE ~= name then return fail("MM_MODULE is " .. tostring(t.MM_MODULE)) end
        if t.API ~= 1 then return fail("API is " .. tostring(t.API)) end
        for _, fn in ipairs(MODULE_FNS[name]) do
            if type(t[fn]) ~= "function" then return fail("no function " .. fn) end
        end
        local okI, r = pcall(t.init, MM)
        if not okI then return fail("init error: " .. tostring(r)) end
        if r == false then return fail("init returned false") end
    end
    MM.modState[name] = "loaded"
    return t
end

-- A module call from core: pcall'd, the first 3 errors per module logged, never fatal to core.
local modErrors = {}
function modCall(mod, fn, ...)
    if type(mod) ~= "table" or type(mod[fn]) ~= "function" then return nil end
    local ok, a, b = pcall(mod[fn], ...)
    if ok then return a, b end
    local n = mod.MM_MODULE or "?"
    modErrors[n] = (modErrors[n] or 0) + 1
    if modErrors[n] <= 3 then log("module " .. n .. "." .. fn .. " error: " .. tostring(a)) end
    return nil
end

-- The rest of MM (design 1.3), filled once every helper above exists.
local function fillMM()
    MM.log, MM.valid = log, valid
    MM.now = function() return os.clock() end
    MM.mods = function() return mods end
    MM.modById = function(id) return modsById[id] end
    MM.setting = function(m, key)
        for _, s in ipairs(m and m.settings or {}) do if s.key == key then return s end end
        return nil
    end
    MM.getValue = function(m, key) return m and m.values[key] end
    MM.isDefault = function(m, s)
        local v = m.values[s.key]
        if s.type == "slider" and type(v) == "number" then return math.abs(v - s.default) <= stepEps(s) end
        return v == s.default
    end
    -- the value as shown: its valueLabel when the file has one, else the number with its suffix, or the option
    MM.display = function(s, v)
        if v == nil then return "" end
        local f = formatValue(s, v)
        if type(s.valueLabels) == "table" and type(s.valueLabels[f]) == "string" then return s.valueLabels[f] end
        if s.type == "slider" and s.suffix and s.suffix ~= "" then return f .. s.suffix end
        if s.type == "toggle" then return v and "On" or "Off" end
        if s.type == "choice" then return (tostring(f):gsub("^%l", string.upper)) end   -- C50.2: "overview" -> "Overview"
        return f
    end
    MM.stepFrom, MM.snapToStep, MM.coerce, MM.formatValue = stepFrom, snapToStep, coerce, formatValue
    MM.keyTools = { isKeySetting = isKeySetting, keyClash = keyClash, toUnrealKey = toUnrealKey,
                    fromUnrealKey = fromUnrealKey, UE4SS_KEYS = UE4SS_KEYS, RESERVED_KEYS = RESERVED_KEYS }
    MM.localPC, MM.anyPC, MM.findPauseMenu = localPC, anyPC, findPauseMenu
    MM.joined = function()
        local pc = localPC()
        if not pc then return false end
        local ok, a = pcall(function() return pc:HasAuthority() end)
        return ok and a == false
    end
    MM.cfg, MM.saveOwn = cfg, saveOwn
    MM.ui = { construct = construct, sized = sized, loadClass = loadClass, styleInput = styleInput, T = LAY.T,
              COLORS = { CREAM = CREAM, GOLD = GOLD, GRAY = GREY, GREY = GREY, RED = RED,
                         GREEN = { R = 0.212, G = 0.474, B = 0.209, A = 1.0 }, AMBER = { R = 0.745, G = 0.392, B = 0.045, A = 1.0 } } }
    -- modules build into the open panel's tree with its text class; tree/cls given by a module are used otherwise
    -- C33: the 6th argument is the font kind ("title", "medium", "body"), as core's own text
    MM.ui.newText = function(tree, cls, s, size, color, kind)
        local u = panel.ui
        return newText((u and u.tree) or tree, cls or (u and u.textC) or loadClass("/Game/UI/Common/WBP_DomTextBlock"),
            s, size, color, kind)
    end
    MM.ui.makeGameButton = function(pc, label, like)
        return makeGameButton(pc or panel.pc or localPC(), label, like or (panel.ui and panel.ui.like))
    end
    MM.panelOpen = function() return panel.open == true end
    MM.panelMode = function() if not panel.open then return nil end return panel.mode == "pad" and "pad" or "mouse" end
    MM.flash = function(text, secs) panel.flash = { text = tostring(text), till = os.clock() + (tonumber(secs) or 5) } end
    MM.openPage = function(id, rowKey)
        for i, m in ipairs(mods) do
            if m.id == id then panel.pending = { page = i, row = rowKey }; return true end
        end
        return false
    end
    MM.readFile, MM.ownRoot = readFile, modRoot
    MM.modsRoot = function()
        if DISC.root then return DISC.root end
        local r = modRoot()
        return r and r:match("^(.*)[/\\][^/\\]*$")
    end
    MM.dirTree = function() return DISC.tree end
    -- C12: seconds since this world's player controller appeared (nil outside a world); see LAY.worldTick
    MM.worldAge = function() return LAY.worldAt and (os.clock() - LAY.worldAt) or nil end
    MM.ui.T, MM.ui.RW = LAY.textSize(), LAY.dims().RW
    -- C31: the modules (Quick Panel, Keys, Health) use core's fonts and text metrics for their own text
    MM.ui.font, MM.ui.metric, MM.ui.TYPEFACE = LAY.font, LAY.metric, LAY.TYPEFACE
end

-- C12: world entry = the local controller's full name appearing or changing. Called every main tick (localPC() is
-- cached; it searches at most every 3 s while there is none).
function LAY.worldTick()
    local pc = localPC()
    local name = nil
    if pc then pcall(function() name = pc:GetFullName() end) end
    if name ~= LAY.worldName then
        LAY.worldName = name
        LAY.worldAt = name and os.clock() or nil
    end
end

loadOwnConfig()
share("ModMenu.version", VERSION)
share("ModMenu.page", "")                                   -- 1.1.1: set, so a mod can tell this Mod Menu publishes it
pcall(discover)
hookPanel()
-- 2.0: modules last, once MM is complete (design 1.2 order: builtin, health, keys, quickpanel)
fillMM()
MM.builtin = loadModule("builtin")
MM.HEALTH = loadModule("health")
MM.KEYS = loadModule("keys")
MM.QP = loadModule("quickpanel")

MENU.label = "MODS"
MENU.onOpen = function() openPanel() end
MENU.onClose = function() closePanel() end

local menuKey = Key[(cfg.MenuKey or ""):upper()]
local noKey = (cfg.MenuKey or ""):lower() == "none" or cfg.MenuKey == ""
if menuKey and not noKey then
    RegisterKeyBind(menuKey, function()
        ExecuteInGameThread(function()
            local ok, err = pcall(function() if panel.open then closePanel() else openPanel() end end)
            if not ok then log("panel error: " .. tostring(err)) end
        end)
    end)
elseif not noKey then
    log("MenuKey '" .. tostring(cfg.MenuKey) .. "' is not a recognized key; use the pause menu instead")
end

-- Esc closes the panel and normally lands in the game's pause menu, which wants the cursor. If a text
-- box had focus, the game never sees that Esc and no pause menu opens, so give input back to the game.
local escCheck = nil
RegisterKeyBind(Key.ESCAPE, function()
    ExecuteInGameThread(function()
        if panel.open then
            local inWorld, pc = panel.inWorld, panel.pc
            pcall(closePanel, true)
            if inWorld and pc then escCheck = { at = os.clock() + 0.6, pc = pc } end
        end
    end)
end)

local function escTick()
    if not escCheck or os.clock() < escCheck.at then return end
    local pc = escCheck.pc
    escCheck = nil
    local pm = findPauseMenu()
    -- IsInViewport is false even while the pause menu shows (it lives in the game's widget stack);
    -- IsActivated is true only while it is open (checked in game 2026-09-16).
    local ok, shown = pcall(function() return pm:IsActivated() end)
    if not (ok and shown) and valid(pc) and not panel.open then setInputUI(pc, nil, false) end
end

log("loaded v" .. VERSION .. ", " .. #mods .. " configurable mods found.")

local tickErrors = 0
-- Game-thread work only when the previous job has finished. Queuing a job every tick regardless
-- piles them up during a world-load stall and ABORTS UE4SS (Open All, 2026-09-17: abort
-- 0x40000015 the moment a world finished loading, after a 6.8 s stall).
-- The 5 s release is for the case where UE4SS drops the job and never runs it, which would
-- otherwise latch `queued` true forever and freeze the mod (Open All's second audit found that).
local queued, queuedAt = false, 0
-- Main loop ON THE GAME THREAD. UE4SS runs LoopAsync callbacks on a separate thread without the lock
-- its game-thread side holds, so a LoopAsync mod's Lua can run on two OS threads at once (measured
-- 2026-09-23: ~1,480 overlaps in 150 jobs on stable and latest UE4SS alike; on the newer build it
-- corrupted a mod's Lua state under load). LoopInGameThreadWithDelay keeps all of it on one thread.
local function mainTick()
    local ok, err = pcall(panelTick)
    if not ok then
        tickErrors = tickErrors + 1
        if tickErrors <= 5 then log("tick error: " .. tostring(err)) end
    end
    pcall(menuTick)
    if not PAD.fastLoop then pcall(PAD.chordTick) end      -- 2.0: Start then RB (C26: on the 50 ms loop)
    pcall(escTick)
    local okR, errR = pcall(requestTick)
    if not okR then log("open request error: " .. tostring(errR)) end
    local okS, errS = pcall(setRequestTick)
    if not okS then log("set request error: " .. tostring(errS)) end
    pcall(LAY.worldTick)                                   -- C12: MM.worldAge()
    modCall(MM.QP, "tick", os.clock())                     -- 2.0: the Quick Panel's work, on this game-thread tick
end
local okLoop = pcall(LoopInGameThreadWithDelay, 250, function()
    local ok, err = pcall(mainTick)
    if not ok then print("main loop error: " .. tostring(err) .. "\n") end
end)
if okLoop then print("[ModMenu] main loop on the game thread\n") end
-- C26: the pad loop (PAD.fastTick). id-guarded: a loop whose id is not the current one ends itself.
if okLoop then
    PAD.fastId = (PAD.fastId or 0) + 1
    local myId, errs = PAD.fastId, 0
    PAD.fastLoop = pcall(LoopInGameThreadWithDelay, PAD.FAST_MS, function()
        if myId ~= PAD.fastId then return true end
        local ok, err = pcall(PAD.fastTick)
        if not ok then
            errs = errs + 1
            if errs <= 3 then log("pad loop error: " .. tostring(err)) end
        end
    end)
end
if not okLoop then
    -- Older UE4SS without LoopInGameThreadWithDelay: the previous guarded LoopAsync route.
    local queued, queuedAt = false, 0
    LoopAsync(250, function()
        if queued and os.clock() - queuedAt > 5 then queued = false end
        if queued then return false end
        queued, queuedAt = true, os.clock()
        local sent = pcall(ExecuteInGameThread, function() queued = false; pcall(mainTick) end)
        if not sent then queued = false end
        return false
    end)
end
