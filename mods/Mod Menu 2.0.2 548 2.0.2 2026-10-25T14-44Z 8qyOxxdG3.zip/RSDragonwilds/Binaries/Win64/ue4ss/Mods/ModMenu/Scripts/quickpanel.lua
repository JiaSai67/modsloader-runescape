-- Mod Menu 2.0: the Quick Panel (docs/modmenu-2.0-design.md section 6). A small box on the game screen with the
-- settings the player pinned from their pages, so a value can be changed without opening the menu.
--
-- Loaded by main.lua (loadfile + pcall, design 1.2) and given the ctx table MM (design 1.3); it gets nothing else
-- from core. Every function core calls is in the table at the bottom (design 1.4). Rules this file keeps:
--   * No game calls at load or in init; only in tick() and the module's own game-thread loop.
--   * The box is built in one call, never re-parented, added to the viewport at layer 9000 (layer 60 is covered by a
--     game HUD widget, journal 2026-10-19 Trap 2) and SelfHitTestInvisible while playing, so it never takes a click.
--   * Values are written only through MM.setValue(m, s, v, "quick"), from a game-thread tick.
--   * Hidden = root Collapsed, not destroyed (W2 P5: 10 hide/show + 10 rebuilds, no ghost paint).

local M = { MM_MODULE = "quickpanel", API = 1 }
local MM = nil

local VIS, COLL, SELF_INV = 0, 1, 4         -- ESlateVisibility: Visible, Collapsed, SelfHitTestInvisible
local LAYER = 9000
local MAX_PINS = 8
local WAIT = 45                             -- seconds after world entry before the box is built (40 s load rule + margin)
local LOOP_MS = 50                          -- own loop's tick; it WORKS every 50 ms only in edit mode (C17: a 90 ms
local IDLE_S = 0.1                          -- click was missed half the time at 100 ms), every 100 ms otherwise (W2 clean)

-- All state in one table (tests read it as M._S).
local S = { pins = {}, box = nil, shown = false, pcName = nil, worldAt = nil, panel = false, loopId = 0,
            loopStarted = false, errors = 0, valsDirty = false }
M._S = S
local KB = {}                                       -- 2.0.2: key binds registered per edit key name (true = registered)

local function valid(o) return MM ~= nil and MM.valid(o) end
local function log(s) if MM then MM.log("Quick Panel: " .. tostring(s)) end end
local function now() return MM.now() end
local function cfg(k, d)
    local v = MM and MM.cfg and MM.cfg[k]
    if v == nil then return d end
    return v
end
local function cfgOn(k, d)
    local v = cfg(k, d)
    if type(v) == "string" then v = v:lower(); return not (v == "false" or v == "0" or v == "no" or v == "off") end
    return v ~= false
end
local function cfgNum(k, d, lo, hi)
    local n = tonumber(cfg(k, d)) or d
    if n < lo then n = lo elseif n > hi then n = hi end
    return n
end
local function fullName(o) local n = nil; pcall(function() n = o:GetFullName() end); return n end

-- ------------------------------------------------------------------ pins (QuickPins = Id.Key,Id.Key in config.txt)
-- Mod ids have no ".", so the first "." splits. Pins whose mod or setting is gone stay in the list (and the file)
-- and are skipped when the box is drawn.
local function parsePins(text)
    local list, seen = {}, {}
    for part in (tostring(text or "") .. ","):gmatch("([^,]*),") do
        part = part:gsub("^%s+", ""):gsub("%s+$", "")
        local id, key = part:match("^([^%.]+)%.(.+)$")
        if id and key and not seen[id .. "." .. key] then
            seen[id .. "." .. key] = true
            list[#list + 1] = { id = id, key = key }
        end
    end
    return list
end

-- Can setting s of mod m go on the Quick Panel? Toggles, sliders and choices that apply while playing: not a
-- "restart" or "next load" setting (own field or builtin.applyFor; ruling (l), run 2026-10-20), not locked, not a mod whose config is Lua (live push does not reach
-- those, findings-A), not Mod Menu's own settings.
function M.canPin(m, s)
    if type(m) ~= "table" or type(s) ~= "table" or not s.key or m.id == "ModMenu" then return false end
    if s.type ~= "toggle" and s.type ~= "slider" and s.type ~= "choice" then return false end
    if s.restart == true or s.locked == true or m.format == "lua" then return false end
    local b = MM and MM.builtin
    if type(b) == "table" and type(b.applyFor) == "function" then
        local ok, tag = pcall(b.applyFor, m, s)
        if ok and (tag == "restart" or tag == "next load") then return false end
    end
    return true
end

-- The pinned rows that can be shown now, in pin order, at most MAX_PINS: { {id, key, m, s} }.
local function liveRows()
    local rows = {}
    for _, p in ipairs(S.pins) do
        local m = MM.modById(p.id)
        local s = m and MM.setting(m, p.key)
        if s and M.canPin(m, s) then
            rows[#rows + 1] = { id = p.id, key = p.key, m = m, s = s }
            if #rows >= MAX_PINS then break end
        end
    end
    return rows
end

function M.isPinned(id, key)
    for _, p in ipairs(S.pins) do if p.id == id and p.key == key then return true end end
    return false
end
function M.pins()
    local out = {}
    for _, p in ipairs(S.pins) do out[#out + 1] = { id = p.id, key = p.key } end
    return out
end

-- ------------------------------------------------------------------ the box
local function T() local t = tonumber(MM.ui and MM.ui.T) or 1; return (t > 0) and t or 1 end
local function px(n) return math.floor(n * T() + 0.5) end
local function construct(cls, outer) return MM.ui.construct(cls, outer) end
local function color(w, c)
    if not valid(w) then return end                 -- C20: never call a widget the engine may have freed
    pcall(function() w:SetColorAndOpacity({ SpecifiedColor = c, ColorUseRule = 0 }) end)
end

-- ---- C28/C29 look (the mockup's QUICK PANEL card, runs/2026-10-19-modmenu-2/mod-menu-2.html .qp): warm dark card with
-- a 1 px gold edge, title in the heading font (gold) with the key hint in dim gray on the right, rows of label |
-- control (2.0.2: a slider row is [drag slider | value]) in FIXED columns on an 8 px grid (all sizes below are at Text size 1.0 and scale with it).
-- Fonts come only from core (MM.ui.font / MM.ui.metric, C-core's LAY.font cache); without them the text block keeps
-- its own font and the game font's metric is used, which is the widest, so nothing is ever cut too little.
local L = { PAD_X = 16, PAD_Y = 8, GAP = 8, ROW_H = 32, LABEL_W = 192, STEP_W = 48, VALUE_W = 96, TITLE_PT = 16,
            TEXT_PT = 14, HINT_PT = 12, STEP_PT = 14, BTN_PAD = 12 }
L.CTRL_W = L.STEP_W + L.GAP + L.VALUE_W + L.GAP + L.STEP_W                      -- 208: the -/value/+ block, or one button
L.SVAL_W = 88                                                                   -- 2.0.2: a slider row's value text (slider 112 + 8 + 88; "Normal" fits at the widest font metric)
L.TOGGLE_CTRL_W = 96                                                            -- 2.0.1: a toggle row's control cell (pill 72 + 24)
L.ROW_W = L.LABEL_W + L.GAP + L.CTRL_W                                          -- 408 inside the card's padding
-- C43: brush and text colors are LINEAR (FLinearColor); the mockup's colors are sRGB bytes, converted here (the
-- sRGB numbers used directly drew the card light gray in game)
local function lin(byte)
    local c = byte / 255
    return c <= 0.04045 and c / 12.92 or ((c + 0.055) / 1.055) ^ 2.4
end
local function srgb(r, g, b, a) return { R = lin(r), G = lin(g), B = lin(b), A = a or 1.0 } end
L.CARD = srgb(42, 37, 29, 0.94)                                                 -- mockup .qp rgba(42,37,29,.94)
L.EDGE = srgb(217, 178, 92)                                                     -- mockup --g-gold #d9b25c
L.DIM = srgb(169, 157, 132)                                                     -- mockup --g-dim #a99d84
L.STEP_BG = srgb(58, 50, 38)                                                    -- mockup --g-sel #3a3226
L.GAME_METRIC = { em = 1.03, line = 2.05 }                                      -- the game text block font (L0 / T3)
M._L = L
-- C43: what the layout needs to know about a text (font size, font kind, a button's inner width) is kept HERE, in a
-- plain Lua table keyed by the widget handle (weak keys), never as a Lua field on the widget: a UE4SS widget is
-- userdata, such a field does not stick and reading it back gives a TrivialObject (a width read back from a widget broke the box, C43).
local TXT = setmetatable({}, { __mode = "k" })
M._txt = TXT

local function metric(kind)
    local f = MM.ui and MM.ui.metric
    if type(f) == "function" then
        local ok, mt = pcall(f, kind)
        if ok and type(mt) == "table" and tonumber(mt.em) and tonumber(mt.line) then return mt end
    end
    return L.GAME_METRIC
end
local function fs(pt) return math.max(8, math.floor(pt * T() + 0.5)) end        -- same rule as core's LAY.fs
-- text cut to width at pt (estimate from the font's metric), "..." when cut (core's LAY.fitText rule)
local function fitText(text, width, pt, kind)
    text = tostring(text or "")
    local n = math.max(1, math.floor(width / (metric(kind).em * fs(pt))))
    if #text <= n then return text end
    if n <= 3 then return text:sub(1, n) end
    return text:sub(1, n - 3) .. "..."
end

local function newText(tree, s, pt, c, kind, fixed)
    local t = construct("TextBlock", tree)
    local fo, tf = nil, nil
    if MM.ui and type(MM.ui.font) == "function" then pcall(function() fo = MM.ui.font(kind or "body") end) end
    if fo and MM.ui and type(MM.ui.TYPEFACE) == "table" then tf = MM.ui.TYPEFACE[kind or "body"] end
    pcall(function()
        local f = t.Font
        f.Size = fixed and pt or fs(pt)                                 -- fixed: the pill's word keeps 11 pt
        if fo then f.FontObject = fo; if tf then f.TypefaceFontName = FName(tf) end end
        t:SetFont(f)
    end)
    pcall(function() t:SetAutoWrapText(false) end)
    color(t, c or MM.ui.COLORS.CREAM)
    pcall(function() t:SetText(FText(tostring(s))) end)
    pcall(function() t:SetVisibility(SELF_INV) end)
    TXT[t] = { pt = fixed and pt or fs(pt), kind = kind or "body" }                          -- for the layout lint, never a field on t
    return t
end
local function sizeBox(tree, w, h)
    local b = construct("SizeBox", tree)
    pcall(function() if w then b:SetWidthOverride(w) end; if h then b:SetHeightOverride(h) end end)
    pcall(function() b:SetVisibility(SELF_INV) end)
    return b
end
-- a fixed cell: SizeBox w x h, its child centered vertically (left, or centered when center)
local function cell(tree, child, w, h, center)
    local box = sizeBox(tree, w, h)
    local ok, slot = pcall(function() return box:AddChild(child) end)
    if ok and slot then
        pcall(function() slot:SetVerticalAlignment(2) end)
        pcall(function() slot:SetHorizontalAlignment(center and 2 or (center == false and 3 or 0)) end)
    end
    return box
end
-- a plain UMG Button with a text inside, in a fixed cell (built and filled in this call; nothing is moved later)
local function newButton(tree, label, w, h, pt)
    local b = construct("Button", tree)
    pcall(function() b:SetBackgroundColor(L.STEP_BG) end)
    local t = newText(tree, label, pt or L.STEP_PT)
    local ok, slot = pcall(function() return b:SetContent(t) end)
    if ok and slot then pcall(function() slot:SetHorizontalAlignment(2) end) end
    pcall(function() b:SetVisibility(SELF_INV) end)
    local inner = w - 2 * L.BTN_PAD                                          -- the button style's own padding
    if TXT[t] then TXT[t].inner = inner end
    return cell(tree, b, w, h), b, t, inner
end
local function gapBox(tree, w, h) return sizeBox(tree, w, h) end

-- C50 (3): the menu's On / Off pill (user approved), the same build as core's LAY.switch (main.lua ~3791): a 72 x 32
-- capsule, 4 padding, two 24 round knobs around a 36 wide ON / OFF word at a fixed 11 pt; gold with the knob right =
-- ON, dark gray with the knob left = OFF; it takes no input (HitTestInvisible), the row's button around it is the hit
-- area (mouse click, pad X / Y). Core's builder is not exposed on MM, so this mirrors it; a drift-guard test keeps the
-- numbers equal to main.lua's LAY.SWITCH_*.
local PILL = { W = 72, H = 32, PAD = 4, KNOB = 24, WORD_W = 36, PT = 11,
               ON = { R = 0.69, G = 0.45, B = 0.10, A = 1 },                   -- core's LAY.SWITCH_ON (linear)
               OFF = { R = 0.06, G = 0.055, B = 0.05, A = 1 },                 -- core's LAY.SWITCH_OFF (linear)
               ON_TEXT = { R = 0.05, G = 0.04, B = 0.02, A = 1 },              -- core's LAY.SWITCH_ON_TEXT
               KNOB_C = { R = 0.79, G = 0.71, B = 0.57, A = 1 } }
L.PILL = PILL
local function round(w)
    pcall(function() w.Background.DrawAs = 4 end)                      -- ESlateBrushDrawType::RoundedBox (core's LAY.round)
    pcall(function() w.Background.OutlineSettings.RoundingType = 1 end) -- HalfHeightRadius
end
local function newPill(tree)
    local pill = construct("Border", tree)
    pcall(function() pill:SetPadding({ Left = PILL.PAD, Top = PILL.PAD, Right = PILL.PAD, Bottom = PILL.PAD }) end)
    pcall(function() pill:SetVisibility(SELF_INV) end)                  -- nothing in the pill ever takes a click
    round(pill)
    local hb = construct("HorizontalBox", tree)
    pcall(function() hb:SetVisibility(SELF_INV) end)
    local function knob()
        local k = construct("Border", tree)
        pcall(function() k:SetBrushColor(PILL.KNOB_C) end)
        pcall(function() k:SetVisibility(SELF_INV) end)
        round(k)
        local box = sizeBox(tree, PILL.KNOB, PILL.KNOB)
        box:AddChild(k)
        return box
    end
    local kL, kR = knob(), knob()
    local word = newText(tree, "OFF", PILL.PT, nil, "medium", true)
    pcall(function() word:SetJustification(1) end)
    hb:AddChildToHorizontalBox(kL)
    hb:AddChildToHorizontalBox(cell(tree, word, PILL.WORD_W, PILL.KNOB, true))
    hb:AddChildToHorizontalBox(kR)
    pcall(function() pill:SetContent(hb) end)
    local root = sizeBox(tree, PILL.W, PILL.H)
    root:AddChild(pill)
    -- (every part SelfHitTestInvisible like the rest of the box: the button around it takes the click)
    return { root = root, pill = pill, kL = kL, kR = kR, word = word }
end
local function pillState(row, on)
    local sw = row.pill
    if not sw or row.pillOn == on then return end
    row.pillOn = on
    pcall(function() sw.pill:SetBrushColor(on and PILL.ON or PILL.OFF) end)
    pcall(function() sw.word:SetText(FText(on and "ON" or "OFF")) end)
    color(sw.word, on and PILL.ON_TEXT or MM.ui.COLORS.GRAY)
    pcall(function() sw.kL:SetVisibility(on and COLL or SELF_INV) end)
    pcall(function() sw.kR:SetVisibility(on and SELF_INV or COLL) end)
end
-- a toggle's control cell: an invisible button the size of the control column (the hit area), the pill inside it a
-- FIXED 72 x 32 capsule, right-aligned the same way in every row (C53: a Fill slot stretched it across the column)
local function pillButton(tree, w, h)
    local b = construct("Button", tree)
    pcall(function() b:SetBackgroundColor({ R = 0, G = 0, B = 0, A = 0 }) end)
    local p = newPill(tree)
    local ok, slot = pcall(function() return b:SetContent(p.root) end)
    if ok and slot then
        pcall(function() slot:SetHorizontalAlignment(3) end)              -- EHorizontalAlignment Right (0 = Fill)
        pcall(function() slot:SetVerticalAlignment(2) end)                -- Center
    end
    pcall(function() b:SetVisibility(SELF_INV) end)
    return cell(tree, b, w, h), b, p, w - 2 * L.BTN_PAD
end

-- 2.0.2: a slider row's control is a real drag slider, a plain /Script/UMG.Slider (proven to drag in this box, run
-- 2026-10-25-qp-drag-probe) that wears the GAME's own settings-slider look: the audio settings slider
-- (/Game/UI/Settings/WBP_Settings_Slider) is itself a UMG Slider named InputSlider (offline read, data/cmd/mm202/
-- design.md) whose FSliderStyle holds the game's textures (T_Slider_Bar_*, T_Slider_Diamond_*). Its style is copied
-- from the class's archetype before the slider is added to any panel (Slate copies the style when it builds), with the
-- in-place nested struct write core already uses (LAY.scrollLook). Found once per Lua state; missing = the stock
-- slider in the card's colors, logged once.
local LOOK = { pkg = "/Game/UI/Settings/WBP_Settings_Slider",
               obj = "/Game/UI/Settings/WBP_Settings_Slider.WBP_Settings_Slider_C:WidgetTree.InputSlider",
               panel = "/Game/UI/Settings/WBP_Settings_Slider.WBP_Settings_Slider_C:WidgetTree.ControlBorder",
               brushes = { "NormalBarImage", "HoveredBarImage", "DisabledBarImage", "NormalThumbImage", "HoveredThumbImage",
                           "DisabledThumbImage" } }
M._LOOK = LOOK
local function lookSource()
    if S.lookSrc == false then return nil end
    if S.lookSrc ~= nil and valid(S.lookSrc) then return S.lookSrc end
    S.lookSrc = false
    pcall(function() if MM.ui and type(MM.ui.loadClass) == "function" then MM.ui.loadClass(LOOK.pkg) end end)
    local src = nil
    pcall(function() src = StaticFindObject(LOOK.obj) end)
    if valid(src) then S.lookSrc = src
    else log("slider look: the game's settings slider was not found; plain sliders") end
    return S.lookSrc or nil
end
-- a brush's texture name; a brush with no texture gives nil without a call on the null object (2.0.2 game pass: a
-- method call on an empty ResourceObject crashed UE4SS, AV +0x2AC897, which pcall does not catch)
local function resName(br)
    local o, n = nil, nil
    pcall(function() o = br.ResourceObject end)
    if not valid(o) then return nil end
    pcall(function() n = o:GetFullName() end)
    return n
end
-- the game look onto slider sl: true when the thumb texture reads back as the game's
local function copyLook(sl, src)
    local ok = pcall(function() sl.WidgetStyle = src.WidgetStyle end)           -- the whole struct, when UE4SS copies it
    local want = nil
    pcall(function() want = resName(src.WidgetStyle.NormalThumbImage) end)
    local function took() return want ~= nil and resName(sl.WidgetStyle.NormalThumbImage) == want end
    if not (ok and took()) then                                                  -- else field by field, in place
        for _, k in ipairs(LOOK.brushes) do
            pcall(function()
                local a, d = src.WidgetStyle[k], sl.WidgetStyle[k]
                d.ResourceObject = a.ResourceObject
                d.ImageSize = { X = a.ImageSize.X, Y = a.ImageSize.Y }
                d.DrawAs = a.DrawAs
                d.Tiling = a.Tiling
                d.Margin = { Left = a.Margin.Left, Top = a.Margin.Top, Right = a.Margin.Right, Bottom = a.Margin.Bottom }
                local c = a.TintColor.SpecifiedColor
                d.TintColor.SpecifiedColor = { R = c.R, G = c.G, B = c.B, A = c.A }
            end)
        end
        pcall(function() sl.WidgetStyle.BarThickness = src.WidgetStyle.BarThickness end)
    end
    pcall(function() local c = src.SliderBarColor; sl:SetSliderBarColor({ R = c.R, G = c.G, B = c.B, A = c.A }) end)
    pcall(function() local c = src.SliderHandleColor; sl:SetSliderHandleColor({ R = c.R, G = c.G, B = c.B, A = c.A }) end)
    pcall(function() sl:SetIndentHandle(src.IndentHandle == true) end)
    return took()
end
-- 2.0.2 game pass: the game's settings row draws its slider on a dark inset panel, the ControlBorder's background
-- (T_Slider_Bg, read in game). The same brush goes behind ours: a Border in the slider's cell, background copied from
-- the archetype's ControlBorder (whole struct, else field by field). Missing = the slider alone, as before.
local function lookPanel()
    if S.lookPanel == false then return nil end
    if S.lookPanel ~= nil and valid(S.lookPanel) then return S.lookPanel end
    S.lookPanel = false
    if not lookSource() then return nil end                                     -- loads the package once
    local src = nil
    pcall(function() src = StaticFindObject(LOOK.panel) end)
    if valid(src) then S.lookPanel = src end
    return S.lookPanel or nil
end
-- one FSlateBrush copied in place, field by field (the nested struct write of LAY.scrollLook); used when the whole
-- struct assignment does not read back
local function copyBrush(d, a)
    pcall(function()
        d.ResourceObject = a.ResourceObject
        d.ImageSize = { X = a.ImageSize.X, Y = a.ImageSize.Y }
        d.DrawAs = a.DrawAs
        d.Tiling = a.Tiling
        d.Margin = { Left = a.Margin.Left, Top = a.Margin.Top, Right = a.Margin.Right, Bottom = a.Margin.Bottom }
        local c = a.TintColor.SpecifiedColor
        d.TintColor.SpecifiedColor = { R = c.R, G = c.G, B = c.B, A = c.A }
    end)
end
-- a Border whose background is the game brush `brush` (whole struct, else field by field); true when it took
local function brushBorder(tree, getSrc)
    local bd = construct("Border", tree)
    local a = nil
    pcall(function() a = getSrc() end)
    if a == nil then return bd, false end
    local ok = pcall(function() bd.Background = a end)
    local want = resName(a)
    if not (ok and want ~= nil and resName(bd.Background) == want) then
        local d = nil
        pcall(function() d = bd.Background end)
        if d ~= nil then copyBrush(d, a) end
    end
    pcall(function() bd:SetVisibility(SELF_INV) end)
    return bd, want ~= nil and resName(bd.Background) == want
end
-- 2.0.2: the slider's control cell. The game's settings row draws its slider on a dark inset panel (ControlBorder's
-- background, T_Slider_Bg, read in game); the panel goes behind ours. The part of the bar left of the diamond is filled
-- with the game's own full-bar brush (the slider style's HoveredBarImage, T_Slider_Bar_Full), under the slider, as wide
-- as the handle's center: thumb/2 + frac * (slider width - thumb) (measured in game: a click 28 px into the 112 cell
-- gave 20 % on 0-100). Missing pieces = the slider alone, as before.
local PANEL_PAD = 6
local function sliderCell(tree, sl, w, h, row)
    local panelSrc, src = lookPanel(), lookSource()
    if not (panelSrc and src) then return cell(tree, sl, w, h) end
    local bd, okPanel = brushBorder(tree, function() return panelSrc.Background end)
    pcall(function() bd:SetPadding({ Left = px(PANEL_PAD), Top = 0, Right = px(PANEL_PAD), Bottom = 0 }) end)
    local ov = construct("Overlay", tree)
    pcall(function() ov:SetVisibility(SELF_INV) end)
    local fill, okFill = brushBorder(tree, function() return src.WidgetStyle.HoveredBarImage end)
    local thick, thumb = 23, 23
    pcall(function() thick = tonumber(src.WidgetStyle.BarThickness) or thick end)
    pcall(function() thumb = tonumber(src.WidgetStyle.NormalThumbImage.ImageSize.X) or thumb end)
    local fb = sizeBox(tree, 0, thick)
    fb:AddChild(fill)
    local s1 = nil
    pcall(function() s1 = ov:AddChildToOverlay(fb) end)
    if s1 then pcall(function() s1:SetHorizontalAlignment(1) end); pcall(function() s1:SetVerticalAlignment(2) end) end
    local s2 = nil
    pcall(function() s2 = ov:AddChildToOverlay(sl) end)
    if s2 then pcall(function() s2:SetHorizontalAlignment(0) end); pcall(function() s2:SetVerticalAlignment(2) end) end
    pcall(function() bd:SetContent(ov) end)
    pcall(function() bd:SetVerticalAlignment(2) end)
    row.fill, row.fillW, row.thumbW = fb, w - 2 * px(PANEL_PAD), thumb
    S.panelStyled, S.fillStyled = okPanel, okFill
    local box = sizeBox(tree, w, h)
    box:AddChild(bd)                                                            -- the panel fills the cell
    return box
end
-- the fill to value v (raw or kept); SetWidthOverride only when the width changes
local function setFill(row, st, v)
    local fb = row.fill
    v = tonumber(v)
    if not (fb and v and valid(fb)) then return end
    local span = (tonumber(st.max) or 1) - (tonumber(st.min) or 0)
    local frac = span > 0 and (v - st.min) / span or 0
    if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
    local wpx = math.floor(row.thumbW / 2 + frac * math.max(0, row.fillW - row.thumbW) + 0.5)
    if wpx == row.fillPx then return end
    row.fillPx = wpx
    pcall(function() fb:SetWidthOverride(wpx) end)
end
local function newSlider(tree, s)
    local sl = construct("Slider", tree)
    pcall(function() sl:SetMinValue(s.min) end)
    pcall(function() sl:SetMaxValue(s.max) end)
    pcall(function() sl:SetStepSize(s.step) end)
    pcall(function() sl.MouseUsesStep = true end)      -- drags land on the step grid (probe: only multiples of 5)
    pcall(function() sl.IsFocusable = false end)       -- keyboard and pad focus stay off it
    local src = lookSource()
    local styled = src ~= nil and copyLook(sl, src)
    if not styled then
        if src and not S.lookWarned then S.lookWarned = true; log("slider look: the game style did not take; plain sliders") end
        pcall(function() sl:SetSliderBarColor(L.STEP_BG) end)
        pcall(function() sl:SetSliderHandleColor(L.EDGE) end)
    end
    S.styled = styled
    pcall(function() sl:SetVisibility(SELF_INV) end)
    return sl
end

-- C50 (4): a choice's option in sentence case ("overview" -> "Overview") unless the mod gave a valueLabel for it
local function sentence(s)
    s = tostring(s or "")
    return (s:gsub("^%l", string.upper))
end

local function editKeyName()
    local k = tostring(cfg("QuickEditKey", "F4") or "")
    if k == "" or k:lower() == "none" then return nil end
    return k
end

-- 2.0.2: the title row's hint. The edit key is a toggle (press once to edit, again to finish); the pad's View is still
-- held. editing = the mouse edit is on now.
local function hintFor(editing, w)
    local key = editKeyName()
    local s
    if editing then s = key and (key:upper() .. " to finish") or ""
    elseif key and M.PAD_EDIT == true then s = key:upper() .. " or hold View"
    elseif key then s = key:upper() .. " to edit"
    elseif M.PAD_EDIT == true then s = "hold View"
    else s = "" end
    return fitText(s, w, L.HINT_PT, "body")
end
local function setHint(editing)
    local b = S.box
    if not (b and b.hintW) then return end
    local s = hintFor(editing, b.hintW)
    if s == b.hintText then return end
    b.hintText = s
    if valid(b.hint) then pcall(function() b.hint:SetText(FText(s)) end) end
end

-- Everything that changes the box's shape; a different signature means rebuild.
local function signature(rows)
    local parts = { tostring(px(100)), tostring(cfgNum("QuickX", 3, 0, 100)), tostring(cfgNum("QuickY", 30, 0, 100)),
                    tostring(editKeyName()), tostring(M.PAD_EDIT == true) }
    -- C24: tostring(m) too: core's discover() builds NEW mod tables (menu open), and a box holding the old ones would
    -- show and step stale values (T2-D2); a new table = a rebuild
    for _, r in ipairs(rows) do parts[#parts + 1] = r.id .. "." .. r.key .. "@" .. tostring(r.m) end
    return table.concat(parts, "|")
end

local function dropBox()
    local b = S.box
    S.box, S.shown = nil, false
    if b and valid(b.root) then pcall(function() b.root:RemoveFromParent() end) end
end

local function build(rows, sig)
    dropBox()
    local gi = S.gi
    if not valid(gi) then
        gi = nil
        pcall(function() gi = FindFirstOf("GameInstance") end)
        if not valid(gi) then return false end
        S.gi = gi
    end
    local C = MM.ui.COLORS
    local b = { rows = {}, sig = sig }
    local ok, err = pcall(function()
        b.root = construct("UserWidget", gi)
        b.tree = construct("WidgetTree", b.root)
        b.root.WidgetTree = b.tree
        b.canvas = construct("CanvasPanel", b.tree)
        b.tree.RootWidget = b.canvas
        pcall(function() b.canvas:SetVisibility(SELF_INV) end)
        -- backdrop: a transparent full-screen button under the box, Collapsed until edit mode, where it eats the
        -- clicks outside the box so the game does not swing (W2 P2: 3 of 3 eaten at layer 9000)
        b.back = construct("Button", b.tree)
        pcall(function() b.back:SetBackgroundColor({ R = 0, G = 0, B = 0, A = 0 }) end)
        local bs = b.canvas:AddChildToCanvas(b.back)
        pcall(function() bs:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } }) end)
        pcall(function() bs:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
        pcall(function() b.back:SetVisibility(COLL) end)
        -- the card: anchored at QuickX / QuickY percent of the screen, aligned the same way so it stays on screen;
        -- a gold edge (outer Border, 1 px) around the dark card (inner Border, 8 / 16 padding)
        b.edge = construct("Border", b.tree)
        pcall(function() b.edge:SetBrushColor(L.EDGE) end)
        pcall(function() b.edge:SetPadding({ Left = 1, Top = 1, Right = 1, Bottom = 1 }) end)
        pcall(function() b.edge:SetVisibility(SELF_INV) end)
        b.border = construct("Border", b.tree)
        pcall(function() b.border:SetBrushColor(L.CARD) end)
        pcall(function() b.border:SetPadding({ Left = px(L.PAD_X), Top = px(L.PAD_Y), Right = px(L.PAD_X), Bottom = px(L.PAD_Y) }) end)
        pcall(function() b.border:SetVisibility(SELF_INV) end)
        b.edge:SetContent(b.border)
        local slot = b.canvas:AddChildToCanvas(b.edge)
        local x, y = cfgNum("QuickX", 3, 0, 100) / 100, cfgNum("QuickY", 30, 0, 100) / 100
        pcall(function() slot:SetAnchors({ Minimum = { X = x, Y = y }, Maximum = { X = x, Y = y } }) end)
        pcall(function() slot:SetAlignment({ X = x, Y = y }) end)
        pcall(function() slot:SetPosition({ X = 0, Y = 0 }) end)
        pcall(function() slot:SetAutoSize(true) end)
        b.slot = slot
        b.vbox = construct("VerticalBox", b.tree)
        pcall(function() b.vbox:SetVisibility(SELF_INV) end)
        b.border:SetContent(b.vbox)
        -- rows at least the pill's fixed 32 (core's switch does not scale), so a toggle row never clips it at T 0.8
        local rowH = math.max(px(L.ROW_H), math.ceil(fs(L.TEXT_PT) * metric("body").line), PILL.H)
        local titleH = math.max(px(L.ROW_H), math.ceil(fs(L.TITLE_PT) * metric("title").line))
        local labW, ctlW = px(L.LABEL_W), px(L.CTRL_W)
        b.rowH, b.titleH = rowH, titleH
        -- title row: QUICK PANEL (heading font, gold) | the key hint (dim gray, right-aligned), same two columns as the rows
        local th = construct("HorizontalBox", b.tree)
        pcall(function() th:SetVisibility(SELF_INV) end)
        b.title = newText(b.tree, fitText("QUICK PANEL", labW, L.TITLE_PT, "title"), L.TITLE_PT, C.GOLD, "title")
        th:AddChildToHorizontalBox(cell(b.tree, b.title, labW, titleH))
        th:AddChildToHorizontalBox(gapBox(b.tree, px(L.GAP), titleH))
        b.hintW = ctlW
        b.hintText = hintFor(false, ctlW)
        b.hint = newText(b.tree, b.hintText, L.HINT_PT, L.DIM, "body")
        th:AddChildToHorizontalBox(cell(b.tree, b.hint, ctlW, titleH, false))
        b.vbox:AddChildToVerticalBox(th)
        b.titleRow = th
        for i, r in ipairs(rows) do
            b.vbox:AddChildToVerticalBox(gapBox(b.tree, nil, px(L.GAP)))
            local hb = construct("HorizontalBox", b.tree)
            pcall(function() hb:SetVisibility(SELF_INV) end)
            -- 2.0.1 item 1: a toggle row's control is a 72 px pill at the right of its 208 column, so its label may use the
            -- free part: label | gap | 96 wide control (pill + 24), the same 408 inside the card; the other rows are as before
            local isToggle = r.s.type == "toggle"
            local tctl = math.min(ctlW, math.max(PILL.W + 2 * L.BTN_PAD, px(L.TOGGLE_CTRL_W)))   -- the button style pads the pill 12 a side
            local labW2 = isToggle and (labW + ctlW - tctl) or labW
            local lab = newText(b.tree, fitText(r.s.label or r.key, labW2, L.TEXT_PT, "body"), L.TEXT_PT, nil, "body")
            hb:AddChildToHorizontalBox(cell(b.tree, lab, labW2, rowH))
            hb:AddChildToHorizontalBox(gapBox(b.tree, px(L.GAP), rowH))
            local row = { id = r.id, key = r.key, m = r.m, s = r.s, hb = hb, label = lab }
            if r.s.type == "slider" then
                -- 2.0.2: [ drag slider | gap | value ], the value on the right like the game's settings rows
                row.valW = px(L.SVAL_W)
                local slW = ctlW - row.valW - px(L.GAP)                  -- the columns add up to ctlW exactly
                row.slider = newSlider(b.tree, r.s)
                hb:AddChildToHorizontalBox(sliderCell(b.tree, row.slider, slW, rowH, row))
                hb:AddChildToHorizontalBox(gapBox(b.tree, px(L.GAP), rowH))
                row.val = newText(b.tree, "", L.TEXT_PT, nil, "body")
                hb:AddChildToHorizontalBox(cell(b.tree, row.val, row.valW, rowH))
            elseif r.s.type == "toggle" then
                local tb, btn, p, inner = pillButton(b.tree, tctl, rowH)
                hb:AddChildToHorizontalBox(tb)
                row.btn, row.pill, row.valW = btn, p, inner                  -- plain values on the Lua row table
            else
                local tb, btn, t, inner = newButton(b.tree, "", ctlW, rowH, L.TEXT_PT)
                hb:AddChildToHorizontalBox(tb)
                row.btn, row.val = btn, t
                row.valW = inner                                             -- a plain number on the Lua row table
            end
            b.vbox:AddChildToVerticalBox(hb)
            b.rows[i] = row
        end
        pcall(function() b.root:SetVisibility(COLL) end)
        b.root:AddToViewport(LAYER)
    end)
    if not ok then
        log("box not built: " .. tostring(err))
        if valid(b.root) then pcall(function() b.root:RemoveFromParent() end) end
        return false
    end
    S.box = b
    S.builds = (S.builds or 0) + 1
    S.valsDirty = true
    return true
end

local function setShown(on)
    local b = S.box
    if not b or S.shown == on then return end
    pcall(function() b.root:SetVisibility(on and SELF_INV or COLL) end)
    S.shown = on
end

-- C24 (T2-D2): a row's mod and setting, looked up LIVE through core (MM.modById / MM.setting) every time, never the
-- tables the box was built with: core's discover() replaces them, and the old ones go stale.
local function liveOf(row)
    local m = MM.modById(row.id)
    local st = m and MM.setting(m, row.key)
    return m, st
end

-- 2.0.2: a step's size for "the same value" checks (the slider holds a float32)
local function stepEps(s) return math.max(1e-6, (tonumber(s.step) or 0.01) / 1000) end
local function capturing(sl)
    local c = false
    pcall(function() c = sl:HasMouseCapture() == true end)
    return c
end
-- 2.0.2: the slider shows the kept value. Written only when it shows something else and is not being dragged, so a
-- drag is never fought; row.slShown = what the slider holds after this write (or last read).
local function syncSlider(row, st, v)
    local sl = row.slider
    v = tonumber(v)
    if not (v and valid(sl)) then return end
    if row.slShown ~= nil and math.abs(v - row.slShown) <= stepEps(st) then return end
    if capturing(sl) then return end
    pcall(function() sl:SetValue(v) end)
    row.slShown = v
    setFill(row, st, v)
end

-- The value texts; SetText only where the shown text differs.
local function refresh()
    local b = S.box
    if not b then return end
    for _, row in ipairs(b.rows) do
        local m, st = liveOf(row)
        if not (m and st) then goto continue end
        local v = MM.getValue(m, row.key)
        if row.pill then pillState(row, v == true); goto continue end    -- C50 (3): the pill shows the toggle
        if row.slider then syncSlider(row, st, v) end
        local txt = MM.display(st, v)
        if st.type == "choice" and not (type(st.valueLabels) == "table" and st.valueLabels[tostring(v)] ~= nil) then
            txt = sentence(txt)                                       -- C50 (4)
        end
        txt = fitText(txt, row.valW or px(L.VALUE_W), L.TEXT_PT, "body")         -- C29: never wider than its column
        if txt ~= row.shownText then
            row.shownText = txt
            pcall(function() row.val:SetText(FText(tostring(txt))) end)
        end
        ::continue::
    end
    S.valsDirty = false
end

local function pauseUp()
    local pm = MM.findPauseMenu()
    if not valid(pm) then return false end
    local a = false
    pcall(function() a = pm:IsActivated() end)
    return a == true
end

-- Why the box is not shown now (nil = it is). Cheap reads only: no FindAllOf.
local function hiddenWhy(pc, t, rows)
    if not cfgOn("QuickPanel", true) then return "switched off" end
    if #rows == 0 then return "no pins" end
    if not S.worldAt or t - S.worldAt < WAIT then return "world just loaded" end
    if S.panel or MM.panelOpen() then return "menu open" end
    local pawn = nil
    pcall(function() pawn = pc.Pawn end)
    if not valid(pawn) then return "no character" end
    local cur = false
    pcall(function() cur = pc.bShowMouseCursor end)
    if cur == true and not S.edit then return "cursor shown" end
    if pauseUp() then return "paused" end
    return nil
end

-- ------------------------------------------------------------------ mouse edit (design 6; W2 T2 P1-P3 PASS)
-- 2.0.2: QuickEditKey (default F4) is a TOGGLE: a press enters, the next press leaves ("key"); Esc leaves too.
-- In edit: cursor on, SetInputMode_GameAndUIEx with all 5 params (shorter calls fail silently
-- inside pcall, journal Trap 1), look and move ignored, backdrop + row buttons Visible. Every way out runs exitEdit
-- exactly once (S.edit is cleared first), which undoes only what enterEdit did:
--   the key pressed again, Esc, the box hidden (pins gone, QuickPanel off, no pawn ...), a rebuild, Mod Menu opened, the pause menu,
--   a world change, an error in the tick, the watchdog (60 s with no click) and shutdown().
-- After the menu or the pause menu opened, input mode and cursor belong to them, so only the ignore flags go back.
local WATCHDOG = 60
local ESC_KEY = "Escape"

local function wbl()
    if not valid(S.wbl) then
        S.wbl = nil
        pcall(function() S.wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
    end
    return S.wbl
end
-- 2.0.1 item 4: the cursor's place on the viewport (core reads it the same way, main.lua cursorTick), nil when unreadable.
local function cursorPos()
    if not valid(S.wll) then
        S.wll = nil
        pcall(function() S.wll = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary") end)
    end
    local out = nil
    pcall(function()
        local v = S.wll:GetMousePositionOnViewport(MM.localPC())
        if type(v.X) == "number" and type(v.Y) == "number" then out = { x = v.X, y = v.Y } end
    end)
    return out
end
local function sameSpot(a, b) return a ~= nil and b ~= nil and math.abs(a.x - b.x) <= 3 and math.abs(a.y - b.y) <= 3 end
local function shareQuick(v) pcall(function() ModRef:SetSharedVariable("ModMenu.quick", v) end) end

-- what can be clicked in edit mode: { w, row, dir } (toggle and choice buttons; 2.0.2: slider rows drag instead)
local function clickables()
    local list = {}
    local b = S.box
    if not b then return list end
    for _, row in ipairs(b.rows) do
        if row.btn then list[#list + 1] = { w = row.btn, row = row, dir = 1 } end
    end
    return list
end
local function setEditVis(on)
    local b = S.box
    if not b then return end
    if valid(b.back) then pcall(function() b.back:SetVisibility(on and VIS or COLL) end) end
    for _, c in ipairs(clickables()) do
        local w = c.w
        if valid(w) then pcall(function() w:SetVisibility(on and VIS or SELF_INV) end) end
    end
    for _, row in ipairs(b.rows) do                 -- 2.0.2: the sliders take the mouse only in edit (probe: setting
        local sl = row.slider                       -- one back mid-drag ended the drag, 0 changes after)
        if valid(sl) then pcall(function() sl:SetVisibility(on and VIS or SELF_INV) end) end
    end
end

local function keyDown(pc, name)
    if not name then return false end
    local d = false
    pcall(function() d = pc:IsInputKeyDown({ KeyName = FName(name) }) end)
    return d == true
end
local function editKey()
    local k = editKeyName()
    if not k then return nil end
    local kt = MM.keyTools
    if kt and type(kt.toUnrealKey) == "function" then
        local ok, u = pcall(kt.toUnrealKey, k)
        if ok and type(u) == "string" and u ~= "None" then return u end
    end
    return k
end

-- ------------------------------------------------------------------ pad edit: the swallow context (ruling (o), C14)
-- Probe Q0 (journal 2026-10-20 T0): SetIgnoreLook/MoveInput stop no pad button, but ONE added mapping context at
-- priority 10000 that maps A/B/X/Y/LB/RB/View to a consuming InputAction with no listener silences all of them (no
-- jump, evade, spell panel, radial, attack, no chat or top nav from View) while IsInputKeyDown still reads them and
-- Start still pauses; removing it brings everything back, and the game's own contexts are never touched. So: View
-- held = pad edit. The context is added on the FIRST tick View is seen down (C18; added later, the game's chat hold
-- may already run, T1-D2). View down < 0.3 s (PAD_ARM) is a tap and is simply consumed (ruling t, C23: replaying it
-- into the game opened the top nav only 2 of 10 times, so there is no replay); held 0.3 s or more = edit. The context
-- is removed FIRST in exitEdit, on every way out. LB / RB pick the row, Y / X change it, each on the press edge only
-- (a held Y is one step; held over ~1 s the game would act on it, ruling (q)). All of it only while the own setting
-- QuickPadEdit is on (default OFF, C23); off = View is the game's and pads edit pins on the PINNED page.
local PAD_VIEW = "Gamepad_Special_Left"
local PAD_BTN = { LB = "Gamepad_LeftShoulder", RB = "Gamepad_RightShoulder", X = "Gamepad_FaceButton_Left",
                  Y = "Gamepad_FaceButton_Top" }
local SWALLOW_KEYS = { "Gamepad_FaceButton_Bottom", "Gamepad_FaceButton_Right", "Gamepad_FaceButton_Left",
                       "Gamepad_FaceButton_Top", "Gamepad_LeftShoulder", "Gamepad_RightShoulder", PAD_VIEW }
local SWALLOW_PRIO = 10000
local PAD_ARM = 0.3                                 -- View down this long = edit; released sooner = a tap
local SWALLOW_AT_PRESS = true                       -- C18: the context on the first View tick (false = the C16 bug)
local SW = { imc = nil, ia = nil, sub = nil, subFor = nil, paramsOk = nil, broken = nil, stuck = false }
S.sw = SW

local function hasCtx(sub, imc)
    local o = {}
    local ok, r = pcall(function() return sub:HasMappingContext(imc, o) end)
    if not ok then return nil, nil end
    local p = o.OutFoundPriority                    -- the measured out shape (Q0: {OutFoundPriority = n})
    if type(p) ~= "number" then p = o[1] end
    return r == true, p
end
local function swBroken(why)
    if not SW.broken then SW.broken = why; log("pad editing off: " .. why .. " (pads use the PINNED page in the menu)") end
    M.PAD_EDIT = false
    return false
end
-- MapKey's parameters, read once with ForEachProperty before it is ever called (an arity error kills the chunk).
local function mapKeyOk()
    if SW.paramsOk ~= nil then return SW.paramsOk end
    local fn = nil
    pcall(function() fn = StaticFindObject("/Script/EnhancedInput.InputMappingContext:MapKey") end)
    local names = {}
    local ok = valid(fn) and pcall(function() fn:ForEachProperty(function(p) names[#names + 1] = p:GetFName():ToString() end) end)
    SW.paramsOk = ok and names[1] == "Action" and names[2] == "ToKey" and (names[3] == nil or names[3] == "ReturnValue") and names[4] == nil
    if not SW.paramsOk then swBroken("MapKey takes [" .. table.concat(names, ", ") .. "], not (Action, ToKey)") end
    return SW.paramsOk
end
-- The context and its action. Built again when the engine collected them (they are referenced only while added).
local function swallowBuild()
    if valid(SW.imc) and valid(SW.ia) then return true end
    if SW.broken or not mapKeyOk() then return false end
    if not SW.imcCls then
        pcall(function() SW.imcCls = StaticFindObject("/Script/EnhancedInput.InputMappingContext") end)
        pcall(function() SW.iaCls = StaticFindObject("/Script/EnhancedInput.InputAction") end)
    end
    if not (valid(SW.imcCls) and valid(SW.iaCls)) then return swBroken("Enhanced Input classes not found") end
    local gi = S.gi
    if not valid(gi) then pcall(function() gi = FindFirstOf("GameInstance") end) end
    if not valid(gi) then return false end
    local imc, ia = nil, nil
    pcall(function() imc = StaticConstructObject(SW.imcCls, gi) end)
    pcall(function() ia = StaticConstructObject(SW.iaCls, gi) end)
    if not (valid(imc) and valid(ia)) then return swBroken("the input context could not be built") end
    local consume = false
    pcall(function() ia.bConsumeInput = true end)
    pcall(function() consume = ia.bConsumeInput end)
    if consume ~= true then return swBroken("the input action does not consume") end
    for _, k in ipairs(SWALLOW_KEYS) do
        if not pcall(function() imc:MapKey(ia, { KeyName = FName(k) }) end) then return swBroken("MapKey " .. k .. " failed") end
    end
    SW.imc, SW.ia = imc, ia
    return true
end
-- The local player's input subsystem: one FindAllOf per world, only from core's tick (never the own loop).
local function findSubsystem()
    if valid(SW.sub) and SW.subFor == S.pcName then return SW.sub end
    SW.sub, SW.subFor = nil, S.pcName
    local ok, all = pcall(FindAllOf, "EnhancedInputLocalPlayerSubsystem")
    if ok and all then
        for _, s in ipairs(all) do
            if valid(s) and not tostring(fullName(s) or ""):find("Default__", 1, true) then SW.sub = s; break end
        end
    end
    return SW.sub
end
local function swallowOff()
    local sub, imc = SW.sub, SW.imc
    if not (valid(sub) and valid(imc)) then SW.stuck = false; return true end
    pcall(function() sub:RemoveMappingContext(imc, {}) end)
    local had = hasCtx(sub, imc)
    SW.stuck = had == true                          -- still there: step() tries again every tick
    if SW.stuck then log("the pad input context is still active; removing it again") end
    return not SW.stuck
end
local function swallowOn()
    local sub = SW.sub
    if not (valid(sub) and SW.subFor == S.pcName and swallowBuild()) then return false end
    local okA = pcall(function() sub:AddMappingContext(SW.imc, SWALLOW_PRIO, {}) end)
    local had, p = hasCtx(sub, SW.imc)
    if okA and had and p == SWALLOW_PRIO then return true end
    swallowOff()
    log("pad edit not started: the input context did not take (" .. tostring(had) .. ", " .. tostring(p) .. ")")
    return false
end
-- Own setting QuickPadEdit ("Controller edit (hold View)", modmenu.json), default OFF (C23). Off = no swallow context,
-- View is the game's, pads use the PINNED page. Read from Mod Menu's own values (core's cfg only carries its own keys).
local function padAllowed()
    local own = MM.modById and MM.modById("ModMenu")
    local v = own and MM.getValue(own, "QuickPadEdit")
    if v == nil then v = cfg("QuickPadEdit", false) end
    if type(v) == "string" then v = v:lower(); return v == "true" or v == "1" or v == "yes" or v == "on" end
    return v == true
end

-- From core's tick, before the box is drawn, once the world is past its 45 s gate and nothing is being edited:
-- subsystem + context ready, PAD_EDIT set only when both are. Never in a tick whose pc changed (forgetWorld runs
-- first, in step).
local function padPrepare(t)
    if not padAllowed() then
        if M.PAD_EDIT then M.PAD_EDIT = false end
        return
    end
    if SW.broken or S.edit or not S.pcName or not S.worldAt or t - S.worldAt < WAIT then return end
    if #S.pins == 0 or not cfgOn("QuickPanel", true) then return end
    local pc = MM.localPC()
    if not (valid(pc) and fullName(pc) == S.pcName) then return end
    if findSubsystem() and swallowBuild() then
        if not M.PAD_EDIT then M.PAD_EDIT = true end
    end
end

-- The selected row in pad edit is drawn gold.
local function highlight(sel)
    local b = S.box
    if not b then return end
    local C = MM.ui.COLORS
    for i, row in ipairs(b.rows) do
        local want = (sel == i)
        if row.hl ~= want then
            row.hl = want
            color(row.label, want and C.GOLD or C.CREAM)
        end
    end
end

local function enterEdit(pc, t)
    local e = { kind = "mouse", key = editKey(), pc = pc, pcName = S.pcName, t0 = t, act = t, prev = {} }
    pcall(function() e.cursorWas = pc.bShowMouseCursor == true end)
    S.edit = e                                      -- before any game call: an error from here on still exits
    pcall(function() pc.bShowMouseCursor = true end)
    local lib = wbl()
    e.mode = lib ~= nil and pcall(function() lib:SetInputMode_GameAndUIEx(pc, nil, 0, false, false) end)
    e.look = pcall(function() pc:SetIgnoreLookInput(true) end)
    e.move = pcall(function() pc:SetIgnoreMoveInput(true) end)
    setEditVis(true)
    setHint(true)
    shareQuick("edit")
    S.enters = (S.enters or 0) + 1
end

-- The one way out. keepInput: the menu or the pause menu took input and cursor; leave those to them.
local function exitEdit(why, keepInput)
    local e = S.edit
    if not e then return false end
    S.edit = nil
    if why ~= "key up" and why ~= "tap" then S.latch = true end   -- other ways out: no re-entry until the key is up
    if e.sw then swallowOff() end                   -- pad: the buttons go back to the game before anything else
    local pc = e.pc
    if valid(pc) and fullName(pc) == e.pcName then  -- a dead or new pc took its flags with it
        if e.look then pcall(function() pc:SetIgnoreLookInput(false) end) end
        if e.move then pcall(function() pc:SetIgnoreMoveInput(false) end) end
        if e.kind == "mouse" and not keepInput then
            local lib = wbl()
            if lib then pcall(function() lib:SetInputMode_GameOnly(pc, false) end) end
            pcall(function() pc.bShowMouseCursor = e.cursorWas == true end)
        end
    end
    if e.kind == "mouse" then setEditVis(false); setHint(false) else highlight(nil) end
    shareQuick("")
    S.exits = (S.exits or 0) + 1
    S.lastExit = why
    if why ~= "key up" and why ~= "tap" and why ~= "key" then log("edit ended (" .. tostring(why) .. ")") end
    return true
end

-- C20 (CRASH T1-C1, audit A): the pc changed or went away = the old world is gone or going. Its pc, the box (the
-- travel took it off the screen and the next garbage collection frees it) and anything built for it may already be
-- freed memory, which pcall does not catch. So: Lua state only, NO game call on any of them. The old pc's ignore
-- flags die with it, the new pc starts clean (W2 P3) and the game rebuilds its input contexts on a world load (Q0).
-- The handles are dropped and found or built again in the new world (lazily, after its 45 s wait).
local function forgetWorld()
    local e = S.edit
    S.edit = nil
    if e then
        S.latch = true
        S.exits = (S.exits or 0) + 1
        S.lastExit = "world change"
        shareQuick("")
        log("edit ended (world change)")
    end
    S.box, S.shown = nil, false
    SW.sub, SW.subFor, SW.imc, SW.ia, SW.stuck = nil, nil, nil, nil, false
end

-- A click on a row button: one step for a slider, flip a toggle, next / previous option for a choice.
local function act(row, dir, t, k)
    local m, s = liveOf(row)                        -- C24: live tables, not the ones the box was built with
    if not (m and s) then return end
    local cur = MM.getValue(m, s.key)
    local v = nil
    if s.type == "slider" then
        v = MM.stepFrom(s, tonumber(cur) or s.default, dir, k or 1)
    elseif s.type == "toggle" then
        v = not (cur == true)
    elseif s.type == "choice" and #s.options > 0 then
        local i = 1
        for k, o in ipairs(s.options) do if o == cur then i = k; break end end
        v = s.options[(i - 1 + dir) % #s.options + 1]
    end
    if S.edit then S.edit.act = t end
    if v ~= nil and v ~= cur then MM.setValue(m, s, v, "quick") end
end

-- Mouse clicks are read by polling: pressed on one tick, released while hovered on a later one (qp.lua:262-270).
-- 2.0.1 item 4 (F-4: a click right after F4 with no mouse motion was not counted): Slate sets "hovered" from mouse-move
-- events, so a motionless cursor over a button that just became clickable can press it with IsHovered still false. A
-- press that began on the button (IsPressed) and whose cursor is still where the press began is on that button, so that
-- counts as hovered; a cursor that moved away does not, as before. (2.0.2: the slider - / + and their hold-repeat are
-- gone; slider rows drag, see pollSliders.)
local function pollClicks(t)
    local e = S.edit
    e.pos = e.pos or {}
    for i, c in ipairs(clickables()) do
        local w = c.w
        local p, hv = false, false
        pcall(function() p = w:IsPressed() == true end)
        pcall(function() hv = w:IsHovered() == true end)
        if p and not e.prev[i] then e.pos[i] = cursorPos() end
        if not hv and (p or e.prev[i]) and e.pos[i] then hv = sameSpot(e.pos[i], cursorPos()) end
        if not p then e.pos[i] = nil end
        if e.prev[i] and not p and hv then act(c.row, c.dir, t) end
        e.prev[i] = p
        if not S.edit then return end
    end
end

-- 2.0.2: the drag sliders. Each edit tick reads every slider; one that moved since it was last read or written is
-- snapped to the setting's grid (MM.snapToStep, which also clamps) and written through MM.setValue(.., "quick") when
-- that differs from the kept value. refresh() then puts the snapped value back on the slider once it is not dragged.
local function pollSliders(t)
    local b = S.box
    if not b then return end
    for _, row in ipairs(b.rows) do
        local sl = row.slider
        if sl and valid(sl) then
            local raw = nil
            pcall(function() raw = sl:GetValue() end)
            local m, st = liveOf(row)
            if type(raw) == "number" and m and st then
                local eps = stepEps(st)
                if row.slShown == nil or math.abs(raw - row.slShown) > eps then
                    row.slShown = raw
                    setFill(row, st, raw)                       -- the fill follows the handle during a drag
                    S.edit.act = t
                    local v = MM.snapToStep(st, raw)
                    local cur = tonumber(MM.getValue(m, st.key))
                    if type(v) == "number" and (cur == nil or math.abs(v - cur) > eps) then
                        MM.setValue(m, st, v, "quick")
                        S.drags = (S.drags or 0) + 1
                    end
                end
            end
        end
        if not S.edit then return end
    end
end

-- View seen down: the pad edit starts "armed" (nothing changes in the box yet) with the swallow context added in
-- this same tick. exitEdit is its only way out, like every edit; a release while armed exits as "tap".
local function armPad(pc, t)
    local e = { kind = "pad", armed = true, key = PAD_VIEW, pc = pc, pcName = S.pcName, t0 = t, act = t, prev = {} }
    S.edit = e
    S.enters = (S.enters or 0) + 1
    e.sw = SWALLOW_AT_PRESS and swallowOn()
    if SWALLOW_AT_PRESS and not e.sw then exitEdit("no input context") end
end

-- Held PAD_ARM: edit on. Look/move ignored (the sticks), the selected row in gold. Buttons already down at this tick
-- count as held, so they do nothing until pressed again.
local function enterPad(pc, t)
    local e = S.edit
    if not e.sw then
        e.sw = swallowOn()
        if not e.sw then exitEdit("no input context"); return false end
    end
    e.armed = false
    e.act = t
    e.look = pcall(function() pc:SetIgnoreLookInput(true) end)
    e.move = pcall(function() pc:SetIgnoreMoveInput(true) end)
    for name, k in pairs(PAD_BTN) do e.prev[name] = keyDown(pc, k) end
    local n = S.box and #S.box.rows or 0
    if not S.sel or S.sel > n or S.sel < 1 then S.sel = 1 end
    highlight(S.sel)
    shareQuick("edit")
    return true
end

-- LB / RB = previous / next row (wraps), Y = +1 step / next option / flip, X = -1 step / previous option / flip.
local function pollPad(pc, t)
    local e = S.edit
    local rows = S.box and S.box.rows or {}
    for _, name in ipairs({ "LB", "RB", "Y", "X" }) do
        local d = keyDown(pc, PAD_BTN[name])
        local edge = d and not e.prev[name]
        e.prev[name] = d
        if edge and #rows > 0 then
            e.act = t
            if name == "LB" then S.sel = (S.sel - 2) % #rows + 1
            elseif name == "RB" then S.sel = S.sel % #rows + 1
            else act(rows[S.sel], name == "Y" and 1 or -1, t) end
            if not S.edit then return end
            highlight(S.sel)
        end
    end
end

-- The queued View tap (C19): injected once, on the first tick AFTER a tick that read the context back as gone. While
-- it is still there, wait (the stuck-removal retry runs first in step); after TAP_WAIT ticks, drop it with one log
-- line. Never twice: IA_TopBarMenu toggles the top nav.
-- the mouse edit key (or the pad's View when pad edit is on) is down, while the box is shown: one or two key reads
local function editKeyDown()
    if not S.shown or S.latch then return false end
    local pc = MM.localPC()
    if not valid(pc) then return false end
    if keyDown(pc, editKey()) then return true end
    return M.PAD_EDIT == true and keyDown(pc, PAD_VIEW)
end

-- ------------------------------------------------------------------ the tick (game thread only)
local function step(t)
    local pc = MM.localPC()
    local name = valid(pc) and fullName(pc) or nil
    if name ~= S.pcName then                        -- world change, world gone, or the first sight of a pc
        forgetWorld()                               -- C20: no game calls on old-world objects
        S.pcName = name
        S.worldAt = name and t or nil
    end
    if not name then return end
    if SW.stuck and not S.edit then swallowOff() end
    local down = keyDown(pc, editKey())
    -- 2.0.2: the edit key toggles once per press. Game pass: the 50 / 100 ms IsInputKeyDown poll saw 18-19 of 20 real
    -- 120 ms taps, and mixing it with the key bind double-toggled (the bind's callback can run a tick or more after the
    -- poll saw the press: 9 of 50 presses right). So with the bind registered (ensureKeyBind) the BIND alone is the press
    -- (UE4SS fires it once per press, also for a 1.2 s hold: 50 presses = 50 calls measured); the poll only guards
    -- against a repeat: a recorded press counts when the key was seen up since the last one. Without a bind, the poll edge.
    local edge
    local useBind = KB[tostring(editKeyName() or ""):upper()] == true
    if useBind then
        edge = false
        if (S.taps or 0) ~= (S.tapsSeen or 0) then           -- judged on the ticks BEFORE this one (a repeat that
            S.tapsSeen = S.taps                              -- lands after the release is still a repeat)
            if S.sawUp ~= false then edge = true; S.sawUp = false end
        end
    else
        edge = down and not S.keyWas
    end
    if not down and not edge then S.sawUp = true end
    S.keyWas = down
    local padOn = M.PAD_EDIT == true and padAllowed()
    local vdown = padOn and keyDown(pc, PAD_VIEW)
    if not down and not vdown then S.latch = false end
    if S.edit then
        local e = S.edit
        if e.kind == "pad" and not padOn then exitEdit("controller edit off")
        elseif S.panel or MM.panelOpen() then exitEdit("menu opened", true)
        elseif pauseUp() then exitEdit("paused", true)
        elseif e.kind == "mouse" and edge then exitEdit("key")
        elseif e.kind == "mouse" and keyDown(pc, ESC_KEY) then exitEdit("esc")
        elseif e.kind == "pad" and not keyDown(pc, e.key) then exitEdit(e.armed and "tap" or "key up")
        elseif t - e.act > WATCHDOG then exitEdit("watchdog")
        end
    end
    local rows = liveRows()
    S.why = hiddenWhy(pc, t, rows)
    if S.why then
        exitEdit("hidden: " .. S.why)
        setShown(false)
        return
    end
    local sig = signature(rows)
    local b = S.box
    local inVp = false
    if b and valid(b.root) then pcall(function() inVp = b.root:IsInViewport() end) end
    if not b or b.sig ~= sig or not inVp then
        exitEdit("rebuild")
        if not build(rows, sig) then return end
    end
    refresh()
    setShown(true)
    if S.edit then
        local e = S.edit
        if e.armed then
            if t - e.t0 >= PAD_ARM - 1e-6 then enterPad(pc, t) end
        elseif e.kind == "pad" then pollPad(pc, t)
        else
            pollSliders(t)
            if S.edit then pollClicks(t) end
        end
        refresh()
    elseif not S.latch then
        if edge then enterEdit(pc, t)
        elseif vdown then armPad(pc, t) end
    end
end

local function guarded(t)
    local ok, err = pcall(step, t)
    if not ok then
        S.errors = S.errors + 1
        if S.errors <= 3 then log("tick error: " .. tostring(err)) end
        pcall(exitEdit, "error")
    end
end

-- One own loop per Lua state (LoopInGameThreadWithDelay ignores the callback's return value and its delay cannot
-- change), id-guarded, idle unless the box is shown or edit mode holds input; started from the first core tick, which
-- is on the game thread. It ticks every 50 ms but skips every other tick unless S.edit is on, so the box costs what
-- it did at 100 ms and only edit mode polls clicks and buttons at 50 ms (T1-D1).
local function ensureLoop()
    if S.loopStarted then return end
    S.loopStarted = true
    local id = S.loopId
    local ok = pcall(LoopInGameThreadWithDelay, LOOP_MS, function()
        if S.loopId ~= id or not (S.shown or S.edit) then return end
        local t = now()
        -- on the skipped idle tick, only a key read: an edit key that went down starts the edit now, not up to
        -- 100 ms later (real input: a click right after F4 hit the box before its buttons were clickable, 1 of 18)
        if not S.edit and S.loopAt and t - S.loopAt < IDLE_S - 1e-6 and not editKeyDown() and (S.taps or 0) == (S.tapsSeen or 0) then return end
        S.loopAt = t
        S.loopRuns = (S.loopRuns or 0) + 1
        guarded(t)
    end)
    if not ok then S.loopStarted = false end
end

-- ------------------------------------------------------------------ interface (design 1.4)
function M.init(mm)
    MM = mm
    S.pins = parsePins(cfg("QuickPins", ""))
    return true
end

-- 2.0.2: one UE4SS key bind per edit key name (never removed; it only counts presses while that name is the edit
-- key). Its callback does one Lua assignment, the pattern core uses for its Esc bind (main.lua:1011).
local function ensureKeyBind()
    local k = editKeyName()
    if not k then return end
    local up = k:upper()
    if KB[up] ~= nil then return end
    KB[up] = false
    local kc = nil
    pcall(function() kc = Key[up] end)
    if kc == nil then return end
    KB[up] = pcall(RegisterKeyBind, kc, function()
        local cur = editKeyName()
        if cur and cur:upper() == up then S.taps = (S.taps or 0) + 1 end
    end)
end
M._KB = KB

function M.tick(t)
    if not MM or S.off then return end
    ensureLoop()
    pcall(ensureKeyBind)
    t = tonumber(t) or now()
    -- core tick only (it may run the FindAllOf lookups, once per world), and BEFORE the step, so the first box of a
    -- world is drawn with the right title; a PAD_EDIT flip later rebuilds it (it is in the signature)
    local ok, err = pcall(padPrepare, t)
    if not ok and not SW.prepErr then SW.prepErr = true; log("pad setup error: " .. tostring(err)) end
    guarded(t)
end

-- Pin or unpin a setting (core calls it from a page's pin button or pad Y). Returns the new state (true = pinned)
-- and, when the request was refused, a short reason for the menu to show. The QuickPins line is rewritten through
-- MM.saveOwn, which keeps every other line of Mod Menu's config.txt; pins of mods that are gone stay in it.
local function savePins()
    local parts = {}
    for _, p in ipairs(S.pins) do parts[#parts + 1] = p.id .. "." .. p.key end
    local ok = MM.saveOwn("QuickPins", table.concat(parts, ","))
    if not ok then log("QuickPins could not be saved to config.txt") end
    return ok
end

function M.togglePin(id, key)
    if type(id) ~= "string" or type(key) ~= "string" or id:find(".", 1, true) then return false, "Not a setting." end
    for i, p in ipairs(S.pins) do
        if p.id == id and p.key == key then
            table.remove(S.pins, i)
            savePins()
            return false
        end
    end
    local m = MM.modById(id)
    local s = m and MM.setting(m, key)
    if not (s and M.canPin(m, s)) then return false, "This setting cannot go on the Quick Panel." end
    if #liveRows() >= MAX_PINS then return false, "The Quick Panel holds " .. MAX_PINS .. " settings. Unpin one first." end
    S.pins[#S.pins + 1] = { id = id, key = key }
    savePins()
    return true
end

-- Pad editing (ruling (o)): M.PAD_EDIT turns true once the swallow context is built for this game (core may read it
-- to word its hints). When it cannot be built (logged once, with the step that failed), the box is display-only on a
-- pad and the PINNED page is the pad route: core draws a "PINNED" entry in the docked menu's CHECKS block with these
-- rows, built by core's own row builder; its edits go through MM.setValue(.., "page") and reach the box through
-- onValue. Extra functions, not in the 1.4 table: core calls them through modCall, so the stub means "no PINNED".
M.PAD_EDIT = false

-- The rows of the PINNED page: live pins in pin order (at most 8), each { id, key, m, s }.
function M.pinnedRows()
    if not MM then return {} end
    local out = {}
    for _, r in ipairs(liveRows()) do out[#out + 1] = { id = r.id, key = r.key, m = r.m, s = r.s } end
    return out
end

function M.onValue(id, key, v)
    if M.isPinned(id, key) then S.valsDirty = true end
end

-- Core calls this right after it opened (true) or closed (false) the menu, on the game thread.
function M.onPanel(open)
    S.panel = open == true
    if S.panel then
        exitEdit("menu opened", true)
        setShown(false)
    end
end

function M.shutdown(why)
    S.off = true
    S.loopId = S.loopId + 1
    exitEdit("shutdown: " .. tostring(why))
    dropBox()
    log("off (" .. tostring(why) .. ")")
end

return M
