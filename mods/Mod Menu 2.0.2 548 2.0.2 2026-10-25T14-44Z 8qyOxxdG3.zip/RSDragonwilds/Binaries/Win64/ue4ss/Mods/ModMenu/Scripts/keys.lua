-- Mod Menu 2.0: Keys page (docs/modmenu-2.0-design.md sections 1.4, 3 "Checks pages", 8 Y1/Y2; owner C-keys).
-- Every key a mod uses next to every key the game uses, clashes in red, the game's locked keys marked. Ruling D0
-- 10.3: "locked" = a game key with no player-mappable setting, i.e. what Settings > Controls cannot change and Key
-- Unlocker unlocks. Core calls gameKeys() / clashExtra() / clashCount() for its key rows and the sidebar count, and
-- buildPage() for the page; warm() (optional, safe to call often) refreshes the live keys.
--
-- Where the game keys come from:
--   * GAME_DATA below: the game's own key table for the contexts a player meets in a world (data/imc-table.tsv, built
--     from the game's IMC_* assets by tools/imc_table.py: context, action, key, mappable-setting name, hidden-from-
--     list, mapping index). It gives the default keys before a live read and, always, which mappings are locked.
--   * warm(): the live keys. FindAllOf("InputMappingContext") ONCE per session (87 contexts in 38 ms,
--     journal 2026-09-29), kept; then Mappings[i].Action / .Key.KeyName (Key Unlocker's proven reads) at most every
--     5 s, never in the first 40 s after world entry. So Key Unlocker's moved keys show as they are now.
--   * the player's own Controls changes: the key profile's GetMappingNamesForKey(InKey, OutNames) (3-param UFunction,
--     fills the out table positionally with FNames, journal 2026-09-29), asked once per key at each live read.
-- No game call at load; every UObject call is behind valid() + pcall.

local K = { MM_MODULE = "keys", API = 1 }
local MM = nil

K.READ_GAP = 5          -- seconds between live reads
K.WORLD_WAIT = 40       -- seconds after world entry before any game call

-- context|action|key|mappable name|hidden (1)|mapping index (1-based, the asset's Mappings order); IMC_ / IA_ cut.
-- 189 keyboard and mouse mappings; front end, debug, VR, accessibility, world-create and server dialogs left out.
local GAME_DATA = [[
AgilityCourseUI|Player_Sprint|LeftShift|Sprint||3
BuildMenuPrompt|BuildMenuDummy|B|BuildMenuDummy|1|1
BuildingGeneral|Building_Repair|T|BuildingRepair||1
BuildingMode|Building_QuickInteract|LeftMouseButton|BuildingQuickInteract||1
BuildingMode|Building_InputModifier|LeftControl|BuildingInputModifier|1|12
BuildingMode|Building_InputModifierAlt|LeftAlt|BuildingInputModifierAlt|1|13
BuildingMode|Building_DestroyObject|MiddleMouseButton|BuildingDestroyObject||14
BuildingMode|Building_DestroyHoldObject|MiddleMouseButton|BuildingDestroyObject_Hold|1|16
BuildingMode|Building_Cancel|Escape|BuildingCancel||17
BuildingMode|BuildMenu|B|BuildMenuBuilding|1|19
BuildingMode|Building_FreePlacement|Y|BuildingFreePlacement||21
BuildingMode|Building_GhostPiece_Modifier|F|BuildingGhostPieceModifier||23
BuildingUI|UI_GenericBack|B|CloseBuildMenu|1|1
BuildingUI|UI_GenericTabLeft|Q|BuildingTabLeft||7
BuildingUI|UI_GenericTabRight|E|BuildingTabRight||8
BuildingUI|Building_FavouritePiece|RightMouseButton|||10
BuildingUI|Building_SelectPiece|LeftMouseButton|||11
Chat|UI_GenericBack|Escape|||3
Chat|UI_SendChatMessage|Enter|||5
Combat|PrimaryAction|LeftMouseButton|CombatPrimaryAction||2
Combat|SecondaryAction|RightMouseButton|CombatSecondaryAction||4
Combat|Player_Evade|LeftControl|Evade||6
Combat|SpecialAction|MiddleMouseButton|CombatSpecialAction||7
Combat|ToggleLockOnTargeting|X|CombatToggleLockOn||9
Combat|Mount|LeftAlt|Mount||11
Combat|AmmoSwapLeft|MouseScrollDown|||13
Combat|AmmoSwapRight|MouseScrollUp|||15
ComposterUI|UI_GenericBack|Escape|ProcessingBack|1|1
ComposterUI|Container_TakeIntoInventory|F|||4
ComposterUI|Container_Flush|Q|||6
ContainerUI|UI_GenericBack|Escape|ProcessingBack|1|1
ContainerUI|Container_Flush|Q|||3
ContainerUI|Container_FillFromInventory|R|||4
ContainerUI|Container_TakeIntoInventory|F|||5
Conversation|UI_ContinueConversation|SpaceBar|ContinueConversation||1
Conversation|UI_GenericBack|Escape|CancelConversation||3
Conversation|Conversation_SelectAnswer1|One|ConversationAnswer1||5
Conversation|Conversation_SelectAnswer2|Two|ConversationAnswer2||6
Conversation|Conversation_SelectAnswer3|Three|ConversationAnswer3||7
Conversation|Conversation_SelectAnswer4|Four|ConversationAnswer4||8
CraftingUI|UI_GenericBack|Escape|CraftingBack|1|1
CraftingUI|UI_GenericTabLeft|Q|CraftingTabLeft||5
CraftingUI|UI_GenericTabRight|E|CraftingTabRight||6
DragonkinArtefactWeapon|PilotablePrimaryAction|LeftMouseButton|CombatPrimaryAction||1
DragonkinArtefactWeapon|ExitPilotable|Escape|||7
DragonkinArtefactWeapon|ExitPilotable|E|||8
ExitFreeRoam|ExitFreeRoam|Escape|||1
FishingMiniGame|FishingMiniGame_Exit|RightMouseButton|FishingExit||1
FishingMiniGame|Fishing_Reeling|LeftMouseButton|Reeling||2
FishingMiniGame|FishingMiniGame_MoveRight|D|PullRight||4
FishingMiniGame|FishingMiniGame_MoveLeft|A|PullLeft||5
GameplayUI|TopBarMenu|M|TopBarMenu||1
GameplayUI|OpenJournal|J|OpenJournal||3
GameplayUI|QuickAccessRadialToggle|R|||6
GameplayUI|SkillsMenu|K|SkillsMenu||7
GameplayUI|SpellMenu|Q|SpellMenu||8
GameplayUI|SpellBook|P|SpellBook||10
GameplayUI|BuildMenu|B|BuildMenu||11
GameplayUI|EmotesMenu|H|EmotesMenu||13
GameplayUI|Inventory_QuickAccess_SelectSlot1|One|QuickAccess1||14
GameplayUI|Inventory_QuickAccess_SelectSlot2|Two|QuickAccess2||15
GameplayUI|Inventory_QuickAccess_SelectSlot3|Three|QuickAccess3||16
GameplayUI|Inventory_QuickAccess_SelectSlot4|Four|QuickAccess4||17
GameplayUI|Inventory_QuickAccess_SelectSlot5|Five|QuickAccess5||18
GameplayUI|Inventory_QuickAccess_SelectSlot6|Six|QuickAccess6||19
GameplayUI|Inventory_QuickAccess_SelectSlot7|Seven|QuickAccess7||20
GameplayUI|Inventory_QuickAccess_SelectSlot8|Eight|QuickAccess8||21
GameplayUI|UI_OpenChat|Enter|||22
GameplayUI|Pause|Escape|GameplayPause|1|24
GenericDialog|UI_GenericAccept|LeftMouseButton|||1
InteractionHold|Interact|E|CombatInteract||1
InteractionHold|InteractHold|E|CombatInteract||3
InteractionPrimaryAndSecondary|Interact|E|CombatInteract||1
InteractionPrimaryAndSecondary|SecondaryInteract|F|CombatSecondaryInteract||3
InventoryPrompt|InventoryMenuDummy|Tab|InventoryToggleDummy|1|1
InventoryToggle|InventoryMenu|Tab|InventoryToggle||1
InventoryUI_General|PlayerInventory_Sort|V|InventorySort||1
InventoryUI_SelectItem|Inventory_DestroyObject_Held|X|InventoryDestroyObjectPressed||1
InventoryUI_SelectItem|Inventory_GrantQuickTransfer|LeftControl|InventoryGrantQuickTransfer||3
InventoryUI_SelectItem|Inventory_QuickTransfer|LeftMouseButton|InventoryQuickTransfer|1|5
InventoryUI_SelectItem|Inventory_MoveItemStart|LeftMouseButton|InventoryMoveItemStart|1|7
InventoryUI_SelectItem|Inventory_ModifierChord|LeftShift|InventoryModifierChord|1|8
InventoryUI_SelectItem|Inventory_SplitStack|LeftMouseButton|InvProcSplitStack|1|10
InventoryUI_SelectItem|Inventory_GrantSplitStack|LeftShift|InvProcGrantSplitStack|1|11
InventoryUI_UseItem|Inventory_UseItem|RightMouseButton|InventoryUseItem|1|1
JournalMenu|Journal_MarkAllAsRead|X|JournalMarkAllAsRead||1
JournalPrompt|OpenJournalDummy|J|OpenJournalDummy|1|1
Map|Map_Ping|MiddleMouseButton|MapPing|1|5
Map|Map_MarkerSelectionUI|RightMouseButton|MapMarkerSelectionUI|1|7
Map_MarkerSelection|Map_MarkerPlace|LeftMouseButton|MapPlaceMarker|1|2
Map_QuestList|UI_GenericSubTabLeft|A|||5
Map_QuestList|UI_GenericSubTabRight|D|||6
MountPrompt|MountDummy|LeftAlt|MountDummy|1|1
MountedMovement|Movement|W|MoveForward||1
MountedMovement|Movement|S|MoveBackward||2
MountedMovement|Movement|A|MoveLeft||3
MountedMovement|Movement|D|MoveRight||4
MountedMovement|Player_Jump|SpaceBar|Jump||6
MountedMovement|Player_Sprint|LeftShift|Sprint||7
MountedMovement|Mount|LeftAlt|Mount||10
MountedUI|TopBarMenu|M|TopBarMenu||1
MountedUI|OpenJournal|J|OpenJournal||3
MountedUI|SkillsMenu|K|SkillsMenu||5
MountedUI|UI_OpenChat|Enter|||7
MountedUI|Pause|Escape|GameplayPause|1|9
MountedUI|Inventory_QuickAccess_SelectSlot1|One|QuickAccess1||11
MountedUI|Inventory_QuickAccess_SelectSlot2|Two|QuickAccess2||12
MountedUI|Inventory_QuickAccess_SelectSlot3|Three|QuickAccess3||13
MountedUI|Inventory_QuickAccess_SelectSlot4|Four|QuickAccess4||14
MountedUI|Inventory_QuickAccess_SelectSlot5|Five|QuickAccess5||15
MountedUI|Inventory_QuickAccess_SelectSlot6|Six|QuickAccess6||16
MountedUI|Inventory_QuickAccess_SelectSlot7|Seven|QuickAccess7||17
MountedUI|Inventory_QuickAccess_SelectSlot8|Eight|QuickAccess8||18
MountedUI|QuickAccessRadialToggle|R|||21
Movement|Movement|W|MoveForward||1
Movement|Movement|S|MoveBackward||2
Movement|Movement|A|MoveLeft||3
Movement|Movement|D|MoveRight||4
Movement|Player_Jump|SpaceBar|Jump||6
Movement|Player_Sprint|LeftShift|Sprint||7
Movement|Player_Stealth|C|Stealth||8
Pause|Pause|Escape|Pause|1|1
PauseMenu|UnstuckCharacter_Held|X|||1
PauseMenu|UI_GenericBack|Escape|||3
PlayerList|UI_GenericBack|Escape|||1
PlayerList|UI_EnterAdminPassword|F|||9
PlayerList|UI_GenericTabLeft|Q|||12
PlayerList|UI_GenericTabRight|E|||13
ProcessingUI|UI_GenericBack|Escape|ProcessingBack|1|1
QuickAccessRadialSelection|QuickAccessRadialToggle|R|||3
QuickAccessRadialSelection|QuickAccessRadialToggle|Escape|||4
QuickAccessRadialSelection|UI_GenericAccept_KbmOnly|LeftMouseButton|||5
RadialSelection|SpellsMenu_AcceptSelection|LeftMouseButton|ConfirmSpellSelectionGamepad|1|3
RadialSelection|UI_GenericSelectorLeft|F|SpellRadialTabLeft||5
RadialSelection|UI_GenericSelectorRight|G|SpellRadialTabRight||6
RepairMode|Building_QuickInteract|LeftMouseButton|BuildingQuickInteract||1
RepairMode|Building_DestroyObject|MiddleMouseButton|BuildingDestroyObject||3
RepairMode|Building_DestroyHoldObject|MiddleMouseButton|BuildingDestroyObject_Hold|1|5
RepairMode|BuildMenu|B|BuildMenuBuilding|1|6
RepairMode|Building_Cancel|Escape|BuildingCancel||8
RepairMode|Building_Repair|T|BuildingRepair||10
Resting|Interact|E|CombatInteract||1
RunecraftingUI|SpellsMenu_AcceptSelection|LeftMouseButton|||7
SecondaryActionPrompt|SecondaryActionDummy|RightMouseButton|CombatSecondaryActionDummy|1|1
SignUI|UI_GenericBack|Escape|SignBack|1|1
SignUI|UI_GenericTabLeft|Q|SignTabLeft|1|3
SignUI|UI_GenericTabRight|E|SignTabRight|1|4
SignUI|UI_GenericBack|RightMouseButton|SignBack2|1|5
SkillsMenuPrompt|SkillsMenuDummy|K|SkillsMenuDummy|1|1
SkipNotification|SkipNotification|Escape|SkipNotification|1|1
SpecialActionPrompt|SpecialActionDummy|MiddleMouseButton|CombatSpecialActionDummy|1|1
SpellMenuPrompt|SpellMenuDummy|Q|SpellMenuDummy|1|1
SpellcastingMode|Spellcasting_PlaceSpell|LeftMouseButton|SpellcastingPlaceSpell|1|1
SpellcastingMode|Spellcasting_Cancel|Escape|||3
SpellcastingMode|SpellMenu|Q|||4
SpellcastingModeAdvancedMovement|Player_Evade|LeftControl|||1
SpellsUI|SpellBook|P|SpellBookRadial|1|1
SpellsUI|SpellMenu|Q|SpellMenuRadial|1|3
TopBarMenu|TopBarMap|M|OpenMenu|1|1
TopBarMenu|TopBarSkillsMenu|K|TopBarSkills|1|3
TopBarMenu|TopBarSpellBook|P|TopBarSpellBook|1|4
TopBarMenu|TopBarJournal|J|TopBarOpenJournal|1|5
TopBarMenu|UI_GenericTabLeft|Q|TabLeft|1|7
TopBarMenu|UI_GenericTabRight|E|TabRight|1|9
TopBarMenu|Settings_ResetControls|R|||11
TopBarMenuJournal|Journal_MarkAllAsRead|X|JournalMarkAllAsRead||9
TopBarMenuJournal|UI_GenericSubTabLeft|F|||11
TopBarMenuJournal|UI_GenericSubTabRight|G|||12
TopBarMenuJournal|Journal_ViewEntry|LeftMouseButton|ViewEntryKeyboardMouse|1|14
TopBarMenuPrompt|TopBarMenuDummy|M|TopBarMenuDummy|1|1
TopBarMenuSettings|UI_GenericBack|Escape|||3
TopBarMenuSettings|Settings_Apply|F|||5
TopBarMenuSettings|Settings_ResetControls|R|||7
TopBarMenuSpells|UI_GenericSelectorLeft|F|||6
TopBarMenuSpells|UI_GenericSelectorRight|G|||7
TopBarMenuSpells|SpellsMenu_RemoveSpell|H|RemoveSpell||8
TopBarMenuSpellsRadial|SpellsMenu_AcceptSelection|LeftMouseButton|ConfirmSpellSelectionGamepad|1|4
TopBarMenuSpellsRadial|UI_GenericSelectorLeft|F|SpellRadialTabLeft||7
TopBarMenuSpellsRadial|UI_GenericSelectorRight|G|SpellRadialTabRight||9
UI_Generic|UI_GenericAccept|LeftMouseButton|Accept|1|1
UI_Generic|UI_GenericBack|Escape|Back|1|3
Vehicle|ExitOccupied|E|CombatInteract||1
Vehicle|VehicleMovement|W|MoveForward||3
Vehicle|VehicleMovement|S|MoveBackward||4
Vehicle|VehicleMovement|A|MoveLeft||5
Vehicle|VehicleMovement|D|MoveRight||6
WorldInventory|WorldInventory_Sort|SpaceBar|||1
WorldInventory|WorldInventory_FillStacks|F|||2
WorldInventory|WorldInventory_TakeAll|R|||4
]]

-- Where a context is active, in the words of a mod key's "context" (world / build / chest / menus).
local PLACE = {
    BuildingGeneral = "build", BuildingMode = "build", BuildingUI = "build", RepairMode = "build",
    ContainerUI = "chest", ComposterUI = "chest", WorldInventory = "chest",
    Chat = "menus", Conversation = "menus", CraftingUI = "menus", GenericDialog = "menus", InventoryUI_General = "menus",
    InventoryUI_SelectItem = "menus", InventoryUI_UseItem = "menus", JournalMenu = "menus", Map = "menus",
    Map_MarkerSelection = "menus", Map_QuestList = "menus", PauseMenu = "menus", PlayerList = "menus",
    ProcessingUI = "menus", RunecraftingUI = "menus", SignUI = "menus", SpellsUI = "menus", TopBarMenu = "menus",
    TopBarMenuJournal = "menus", TopBarMenuSettings = "menus", TopBarMenuSpells = "menus",
    TopBarMenuSpellsRadial = "menus", UI_Generic = "menus",
}
for _, c in ipairs({ "AgilityCourseUI", "BuildMenuPrompt", "Combat", "DragonkinArtefactWeapon", "ExitFreeRoam",
    "FishingMiniGame", "GameplayUI", "InteractionHold", "InteractionPrimaryAndSecondary", "InventoryPrompt",
    "InventoryToggle", "JournalPrompt", "MountPrompt", "MountedMovement", "MountedUI", "Movement", "Pause",
    "QuickAccessRadialSelection", "RadialSelection", "Resting", "SecondaryActionPrompt", "SkillsMenuPrompt",
    "SkipNotification", "SpecialActionPrompt", "SpellMenuPrompt", "SpellcastingMode", "SpellcastingModeAdvancedMovement",
    "TopBarMenuPrompt", "Vehicle", "Camera", "LockOnTargeting" }) do PLACE[c] = "world" end   -- the HUD and on-foot contexts
PLACE.SwitchPanel = "menus"
local function placeOf(ctx)
    if PLACE[ctx] then return PLACE[ctx] end
    if ctx:find("UI") or ctx:find("Menu") then return ctx:find("Prompt") and "world" or "menus" end
    return "world"
end
K.placeOf = placeOf

-- Key Unlocker 1.0.3's settings and the game action each one moves (mods/KeyUnlocker/Scripts/main.lua ACTIONS).
-- Those actions are locked (the Controls list leaves them out), and Key Unlocker's own key is no clash with them.
local KU = { QuickWheelKey = "QuickAccessRadialToggle", TargetLockKey = "ToggleLockOnTargeting",
             RepairKey = "Building_Repair", OpenChatKey = "UI_OpenChat", ChestFillKey = "Container_FillFromInventory",
             ChestFlushKey = "Container_Flush", ChestTakeKey = "Container_TakeIntoInventory" }
local KU_ACTION = {}
for _, a in pairs(KU) do KU_ACTION[a] = true end
K.KU = KU

-- Labels: our own words for the ones players know, the action's name in plain words for the rest.
local LABEL = {
    QuickAccessRadialToggle = "Quick access wheel", ToggleLockOnTargeting = "Target lock", Building_Repair = "Repair mode",
    UI_OpenChat = "Open chat", Container_FillFromInventory = "Chest: fill from inventory", Container_Flush = "Chest: quick stack",
    Container_TakeIntoInventory = "Chest: take all", Pause = "Pause menu", Movement = "Move", Player_Sprint = "Sprint",
    Player_Jump = "Jump", Player_Evade = "Evade", Player_Stealth = "Sneak", Interact = "Interact",
    InteractHold = "Interact (hold)", SecondaryInteract = "Second interact", PrimaryAction = "Primary action",
    SecondaryAction = "Secondary action", SpecialAction = "Special action", Mount = "Mount", BuildMenu = "Build menu",
    InventoryMenu = "Inventory", OpenJournal = "Journal", SkillsMenu = "Skills", SpellMenu = "Spell menu",
    SpellBook = "Spell book", EmotesMenu = "Emotes", TopBarMenu = "Top bar menu", TopBarMap = "Map",
    UnstuckCharacter_Held = "Unstuck (hold)", Building_FavouritePiece = "Building: favorite piece",
    Inventory_DestroyObject_Held = "Inventory: destroy item (hold)", Building_DestroyHoldObject = "Building: destroy (hold)",
}
local function words(s)
    s = s:gsub("Dummy$", ""):gsub("_Held$", " (hold)"):gsub("^Player_", ""):gsub("^UI_", "")
    s = s:gsub("Favourite", "Favorite"):gsub("_", " "):gsub("(%l)(%u)", "%1 %2"):gsub("(%a)(%d)", "%1 %2")
    s = s:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    return s:sub(1, 1):upper() .. s:sub(2):lower()
end
function K.labelFor(action)
    action = tostring(action or ""):gsub("^IA_", ""):gsub("Dummy$", "")
    if LABEL[action] then return LABEL[action] end
    local slot = action:match("QuickAccess_SelectSlot(%d+)$")
    if slot then return "Hotbar slot " .. slot end
    return words(action)
end

-- Friendly key text for the page (Unreal name -> what is printed on the key).
local KEY_TEXT = { SpaceBar = "Space", LeftShift = "Left Shift", RightShift = "Right Shift", LeftControl = "Left Ctrl",
    RightControl = "Right Ctrl", LeftAlt = "Left Alt", RightAlt = "Right Alt", Escape = "Esc", BackSpace = "Backspace",
    LeftMouseButton = "Left mouse", RightMouseButton = "Right mouse", MiddleMouseButton = "Middle mouse",
    ThumbMouseButton = "Mouse 4", ThumbMouseButton2 = "Mouse 5", MouseScrollUp = "Wheel up", MouseScrollDown = "Wheel down",
    Zero = "0", One = "1", Two = "2", Three = "3", Four = "4", Five = "5", Six = "6", Seven = "7", Eight = "8", Nine = "9",
    PageUp = "Page Up", PageDown = "Page Down" }
function K.keyText(k)
    k = tostring(k or "")
    if KEY_TEXT[k] then return KEY_TEXT[k] end
    local n = k:match("^NumPad(%a+)$")
    if n and KEY_TEXT[n] then return "Num " .. KEY_TEXT[n] end
    return (k:gsub("(%l)(%u)", "%1 %2"))
end

local NOT_KEY = { [""] = true, AnyKey = true, Mouse2D = true, MouseX = true, MouseY = true, MouseWheelAxis = true, None = true }
local function keyboardKey(k) return type(k) == "string" and not NOT_KEY[k] and not k:find("^Gamepad") and not k:find("^Oculus") end

-- ------------------------------------------------------------------ the built-in table
local META, BY_IDX, BY_ACTION = nil, nil, nil
local function parseData()
    META, BY_IDX, BY_ACTION = {}, {}, {}
    for line in GAME_DATA:gmatch("[^\n]+") do
        local ctx, action, key, name, hidden, idx = line:match("^([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)|(%d+)$")
        if ctx then
            local r = { ctx = ctx, action = action, key = key, name = name, hidden = hidden == "1", idx = tonumber(idx),
                        place = placeOf(ctx) }
            r.locked = r.name == "" or r.hidden or KU_ACTION[action] == true
            META[#META + 1] = r
            BY_IDX[ctx .. "#" .. r.idx] = r
            BY_ACTION[ctx .. "#" .. action] = BY_ACTION[ctx .. "#" .. action] or r
        end
    end
end
function K.data() if not META then parseData() end return META end

-- ------------------------------------------------------------------ the game's controller keys (C36)
-- The gamepad mappings of the same contexts (data/imc-table.tsv, same columns): 231 rows. Key Unlocker is keyboard
-- only, so a pad mapping is locked when it has no mappable name or is hidden from the Controls list.
local PAD_DATA = [[
AgilityCourseUI|AgilityCourse_Banner_Primary|Gamepad_FaceButton_Bottom|||1
AgilityCourseUI|AgilityCourse_Banner_Secondary|Gamepad_FaceButton_Right|||2
AgilityCourseUI|Player_Sprint|Gamepad_LeftThumbstick|SprintGamepad||4
BuildMenuPrompt|BuildMenuDummy|Gamepad_DPad_Down|BuildMenuDummyGamepad||2
BuildingGeneral|Building_Repair|Gamepad_LeftThumbstick|BuildingRepair||2
BuildingMode|Building_QuickInteract|Gamepad_FaceButton_Left|BuildingQuickInteractGamepad||2
BuildingMode|Building_OffsetZ|Gamepad_DPad_Up|||4
BuildingMode|Building_OffsetZ|Gamepad_DPad_Down|||5
BuildingMode|Building_RotateZ|Gamepad_LeftTriggerAxis|||7
BuildingMode|Building_RotateZ|Gamepad_RightTriggerAxis|||8
BuildingMode|Building_OffsetDistance|Gamepad_DPad_Left|||10
BuildingMode|Building_OffsetDistance|Gamepad_DPad_Right|||11
BuildingMode|Building_DestroyObject|Gamepad_FaceButton_Top|BuildingDestroyObjectGamepad||15
BuildingMode|Building_Cancel|Gamepad_FaceButton_Right|BuildingCancelGamepad||18
BuildingMode|BuildMenu|Gamepad_FaceButton_Right|BuildMenuBuildingGamepad|1|20
BuildingMode|Building_FreePlacement|Gamepad_RightThumbstick|BuildingFreePlacementGamepad||22
BuildingMode|Building_GhostPiece_Modifier|Gamepad_Special_Left|BuildingGhostPieceModifierGamepad||24
BuildingMode|Building_RotateZ_Negative|Gamepad_RightTriggerAxis|||25
BuildingMode|Building_OffsetDistance_Negative|Gamepad_DPad_Right|||26
BuildingMode|Building_OffsetZ_Negative|Gamepad_DPad_Down|||27
BuildingMode|Building_DestroyHoldObject|Gamepad_FaceButton_Top|BuildingDestroyObjectGamepad_Hold|1|28
BuildingUI|UI_GenericBack|Gamepad_FaceButton_Right|CloseBuildMenuGamepad||2
BuildingUI|UI_GenericTabLeft|Gamepad_LeftShoulder|BuildingTabLeftGamepad||3
BuildingUI|UI_GenericTabRight|Gamepad_RightShoulder|BuildingTabRightGamepad||4
BuildingUI|Building_SelectPiece|Gamepad_FaceButton_Bottom|BuildingUISelectPieceGamepad||5
BuildingUI|UI_GenericCategoryToggle|Gamepad_RightThumbstick|BuildingToggleCategory||6
BuildingUI|Building_FavouritePiece|Gamepad_FaceButton_Left|||9
Camera|Camera_Rotate|Gamepad_Right2D|||3
Chat|ScrollContent|Gamepad_RightY|||1
Chat|UI_SendChatMessage|Gamepad_FaceButton_Bottom|||2
Chat|UI_GenericBack|Gamepad_FaceButton_Right|||4
Combat|Player_Evade|Gamepad_FaceButton_Right|EvadeGamepad||1
Combat|PrimaryAction|Gamepad_RightShoulder|CombatPrimaryActionGamepad||3
Combat|SecondaryAction|Gamepad_LeftTrigger|CombatSecondaryActionGamepad||5
Combat|SpecialAction|Gamepad_RightTrigger|CombatSpecialActionGamepad||8
Combat|ToggleLockOnTargeting|Gamepad_RightThumbstick|CombatToggleLockOnGamepad||10
Combat|Mount|Gamepad_FaceButton_Top|MountGamepad||12
Combat|AmmoSwapLeft|Gamepad_DPad_Left|||14
Combat|AmmoSwapRight|Gamepad_DPad_Right|||16
ComposterUI|UI_GenericBack|Gamepad_FaceButton_Right|ProcessingBackGamepad||2
ComposterUI|Processing_StartStop|Gamepad_FaceButton_Top|ProcessingStartStopGamepad||3
ComposterUI|Container_TakeIntoInventory|Gamepad_LeftTrigger|||5
ComposterUI|Container_Flush|Gamepad_LeftShoulder|||7
ContainerUI|UI_GenericBack|Gamepad_FaceButton_Right|ProcessingBackGamepad||2
ContainerUI|Container_Flush|Gamepad_LeftShoulder|||6
ContainerUI|Container_FillFromInventory|Gamepad_RightTrigger|||7
ContainerUI|Container_TakeIntoInventory|Gamepad_LeftTrigger|||8
Conversation|UI_ContinueConversation|Gamepad_FaceButton_Bottom|ContinueConversationGamepad||2
Conversation|UI_GenericBack|Gamepad_FaceButton_Right|CancelConversationGamepad||4
CraftingUI|UI_GenericBack|Gamepad_FaceButton_Right|CraftingBackGamepad||2
CraftingUI|UI_GenericTabLeft|Gamepad_LeftShoulder|CraftingTabLeftGamepad||3
CraftingUI|UI_GenericTabRight|Gamepad_RightShoulder|CraftingTabRightGamepad||4
CraftingUI|UI_GenericCategoryToggle|Gamepad_RightThumbstick|CraftingMenuCategoryToggleGamepad||7
CraftingUI|UI_GenericFocusRequirements|Gamepad_FaceButton_Left|||8
CraftingUI|UI_GenericUnFocusRequirements|Gamepad_FaceButton_Left|||9
CraftingUI_Craft|UI_GenericCategoryToggle|Gamepad_RightThumbstick|CraftingCategoryToggleGamepad||1
CraftingUI_Craft|Crafting_CraftItem|Gamepad_FaceButton_Bottom|CraftingCraftGamepad||2
CraftingUI_Craft|ScrollContent|Gamepad_RightY|||3
CraftingUI_Craft|Crafting_AttuneRuneItem|Gamepad_FaceButton_Top|||4
CraftingUI_Masterwork|Crafting_UpgradeMasterwork|Gamepad_FaceButton_Bottom|CraftingUpgradeMasterworkGamepad||1
CraftingUI_Repair|Crafting_RepairItem|Gamepad_FaceButton_Bottom|CraftingRepairGamepad||1
DragonkinArtefactWeapon|PilotablePrimaryAction|Gamepad_RightShoulder|CombatPrimaryActionGamepad||2
DragonkinArtefactWeapon|ExitPilotable|Gamepad_FaceButton_Right|CombatInteractGamepad||3
DragonkinArtefactWeapon|PilotableRotate|Gamepad_Right2D|||6
ExitFreeRoam|ExitFreeRoam|Gamepad_Special_Left|||2
FishingMiniGame|Fishing_Reeling|Gamepad_LeftTrigger|ReelingGamepad||3
FishingMiniGame|FishingMiniGame_Exit|Gamepad_FaceButton_Right|FishingExitGamepad||6
FishingMiniGame|FishingMiniGame_MoveRight|Gamepad_LeftStick_Right|PullRightGamepad||7
FishingMiniGame|FishingMiniGame_MoveLeft|Gamepad_LeftStick_Left|PullLeftGamepad||8
GameplayUI|TopBarMenu|Gamepad_Special_Left|TopBarMenuGamepad||2
GameplayUI|QuickAccessRadial|Gamepad_LeftShoulder|||4
GameplayUI|QuickAccessRadialClose|Gamepad_LeftShoulder|||5
GameplayUI|SpellMenu|Gamepad_FaceButton_Top|SpellMenuGamepad||9
GameplayUI|BuildMenu|Gamepad_DPad_Down|BuildMenuGamepad||12
GameplayUI|UI_OpenChat|Gamepad_Special_Left|||23
GameplayUI|Pause|Gamepad_Special_Right|GamepadGameplayPause||25
GenericDialog|UI_GenericAccept|Gamepad_FaceButton_Bottom|||2
GenericDialog|UI_GenericBack|Gamepad_FaceButton_Right|||3
InteractionHold|Interact|Gamepad_FaceButton_Left|CombatInteractGamepad||2
InteractionHold|InteractHold|Gamepad_FaceButton_Left|CombatInteractGamepad||4
InteractionPrimaryAndSecondary|Interact|Gamepad_FaceButton_Left|CombatInteractGamepad||2
InteractionPrimaryAndSecondary|SecondaryInteract|Gamepad_FaceButton_Left|||4
InventoryPrompt|InventoryMenuDummy|Gamepad_FaceButton_Top|InventoryToggleDummyGamepad|1|2
InventorySplitUI|Inventory_AcceptSplit|Gamepad_FaceButton_Bottom|InventorySplitAcceptGamepad||1
InventoryToggle|InventoryMenu|Gamepad_DPad_Up|InventoryToggleGamepad||2
InventoryUI_General|PlayerInventory_Sort|Gamepad_LeftThumbstick|InventorySortGamepad||2
InventoryUI_General|UI_InventoryTabLeft|Gamepad_LeftShoulder|||3
InventoryUI_General|UI_InventoryTabRight|Gamepad_RightShoulder|||4
InventoryUI_MoveItem|Inventory_MoveItemEnd|Gamepad_FaceButton_Bottom|InventoryMoveItemEndGamepad||1
InventoryUI_MoveItem|Inventory_MoveItemCancel|Gamepad_FaceButton_Right|InventoryMoveItemCancelGamepad||2
InventoryUI_SelectItem|Inventory_DestroyObject_Held|Gamepad_LeftTriggerAxis|InventoryDestroyObjectPressedGamepad||2
InventoryUI_SelectItem|Inventory_QuickTransfer|Gamepad_RightTriggerAxis|InventoryQuickTransferGamepad||4
InventoryUI_SelectItem|Inventory_MoveItemStart|Gamepad_FaceButton_Bottom|InventoryMoveItemStartGamepad||6
InventoryUI_SelectItem|Inventory_SplitStack|Gamepad_FaceButton_Bottom|InvProcSplitStackGamepad||9
InventoryUI_UseItem|Inventory_UseItem|Gamepad_FaceButton_Left|InventoryUseItemGamepad||2
JournalMenu|Journal_MarkAllAsRead|Gamepad_FaceButton_Top|JournalMarkAllAsRead||2
JournalPrompt|OpenJournalDummy|Gamepad_Special_Left|OpenJournalDummytGamepad|1|2
LockOnTargeting|TargetSwitchLockOnTargeting|Gamepad_Right2D|||1
LorePopupUI|ScrollContent|Gamepad_RightY|LoreScrollUpGamepad|1|1
Map|Map_Zoom|Gamepad_RightY|||2
Map|Map_Zoom|Gamepad_RightY|||3
Map|Map_Move|Gamepad_Left2D|||4
Map|Map_Ping|Gamepad_FaceButton_Top|MapPingGamepad||6
Map|Map_MarkerSelectionUI|Gamepad_FaceButton_Bottom|MapMarkerSelectionUIGamepad||8
Map_MarkerSelection|Map_MarkerSelection|Gamepad_Left2D|||1
Map_MarkerSelection|Map_MarkerPlace|Gamepad_FaceButton_Bottom|MapPlaceMarkerGamepad||3
Map_QuestList|Map_TrackQuest|Gamepad_FaceButton_Left|QuestListTrackQuestGamepad||1
Map_QuestList|VerticalMovementUp|Gamepad_DPad_Up|||3
Map_QuestList|VerticalMovementDown|Gamepad_DPad_Down|||4
Map_QuestList|UI_GenericSubTabLeft|Gamepad_LeftTriggerAxis|||7
Map_QuestList|UI_GenericSubTabRight|Gamepad_RightTriggerAxis|||8
MountPrompt|MountDummy|Gamepad_FaceButton_Top|MountDummyGamepad|1|2
MountedMovement|Movement|Gamepad_Left2D|||5
MountedMovement|Player_Jump|Gamepad_FaceButton_Bottom|JumpGamepad||8
MountedMovement|Player_Sprint|Gamepad_LeftThumbstick|SprintGamepad||9
MountedMovement|Mount|Gamepad_FaceButton_Top|MountGamepad||11
MountedUI|TopBarMenu|Gamepad_Special_Left|TopBarMenuGamepad||2
MountedUI|OpenJournal|Gamepad_Special_Left|OpenJournalGamepad||4
MountedUI|SkillsMenu|Gamepad_Special_Left|SkillsMenuGamepad||6
MountedUI|UI_OpenChat|Gamepad_Special_Left|||8
MountedUI|Pause|Gamepad_Special_Right|GamepadGameplayPause||10
MountedUI|QuickAccessRadial|Gamepad_LeftShoulder|||19
MountedUI|QuickAccessRadialClose|Gamepad_LeftShoulder|||20
Movement|Movement|Gamepad_Left2D|||5
Movement|Player_Jump|Gamepad_FaceButton_Bottom|JumpGamepad||9
Movement|Player_Sprint|Gamepad_LeftThumbstick|SprintGamepad||10
Movement|Player_Stealth|Gamepad_FaceButton_Right|StealthGamepad||11
Pause|Pause|Gamepad_Special_Right|PauseGamepad||2
PauseMenu|UnstuckCharacter_Held|Gamepad_FaceButton_Top|||2
PauseMenu|UI_GenericBack|Gamepad_FaceButton_Right|||4
PauseMenu|UI_GenericBack|Gamepad_Special_Right|||5
PauseMenu|UI_GenericAccept|Gamepad_FaceButton_Bottom|||6
PlayerList|UI_GenericBack|Gamepad_FaceButton_Right|||2
PlayerList|UI_GenericBack|Gamepad_Special_Right|||3
PlayerList|UI_GenericAccept|Gamepad_FaceButton_Bottom|||4
PlayerList|UI_GenericNavigationLeftStick|Gamepad_LeftY|||5
PlayerList|UI_ToggleMute|Gamepad_FaceButton_Left|||6
PlayerList|UI_TogglePlayerOptions|Gamepad_FaceButton_Top|||7
PlayerList|UI_EnterAdminPassword|Gamepad_Special_Left|||8
PlayerList|UI_GenericTabLeft|Gamepad_LeftShoulder|||10
PlayerList|UI_GenericTabRight|Gamepad_RightShoulder|||11
ProcessingUI|UI_GenericBack|Gamepad_FaceButton_Right|ProcessingBackGamepad||2
ProcessingUI|Processing_StartStop|Gamepad_FaceButton_Bottom|||3
QuickAccessRadialSelection|SpellsMenu_SelectSlot|Gamepad_Right2D|||1
QuickAccessRadialSelection|QuickAccessRadialClose|Gamepad_LeftShoulder|||2
RadialSelection|RadialSelection_SwitchRadial|Gamepad_FaceButton_Left|||1
RadialSelection|SpellsMenu_SelectSlot|Gamepad_Right2D|||2
RadialSelection|SpellsMenu_AcceptSelection|Gamepad_FaceButton_Bottom|ConfirmSpellSelection||4
RadialSelection|UI_GenericSelectorLeft|Gamepad_LeftTrigger|SpellRadialTabLeftGamepad||7
RadialSelection|UI_GenericSelectorRight|Gamepad_RightTrigger|SpellRadialTabRightGamepad||8
RepairMode|Building_QuickInteract|Gamepad_FaceButton_Left|BuildingQuickInteractGamepad||2
RepairMode|Building_DestroyObject|Gamepad_FaceButton_Top|BuildingDestroyObjectGamepad||4
RepairMode|BuildMenu|Gamepad_FaceButton_Right|BuildMenuBuildingGamepad|1|7
RepairMode|Building_Cancel|Gamepad_FaceButton_Right|BuildingCancelGamepad||9
RepairMode|Building_Repair|Gamepad_LeftThumbstick|BuildingRepair||11
RepairMode|Building_DestroyHoldObject|Gamepad_FaceButton_Top|BuildingDestroyObjectGamepad_Hold|1|12
Resting|Interact|Gamepad_FaceButton_Left|CombatInteractGamepad||2
RunecraftingUI|SpellsMenu_SelectSlot|Gamepad_Left2D|||1
RunecraftingUI|SpellsMenu_AcceptSelection|Gamepad_FaceButton_Bottom|||2
RunecraftingUI|Crafting_AttuneRuneItem|Gamepad_FaceButton_Top|||3
RunecraftingUI|Crafting_AutoCraftRuneItem|Gamepad_FaceButton_Bottom|||4
RunecraftingUI|UI_GenericSelectorLeft|Gamepad_LeftShoulder|||5
RunecraftingUI|UI_GenericSelectorRight|Gamepad_RightShoulder|||6
SecondaryActionPrompt|SecondaryActionDummy|Gamepad_LeftTrigger|CombatSecondaryActionDummyGamepad|1|2
SignUI|UI_GenericBack|Gamepad_FaceButton_Right|SignBackGamepad||2
SignUI|UI_GenericTabLeft|Gamepad_LeftShoulder|SignTabLeftGamepad||6
SignUI|UI_GenericTabRight|Gamepad_RightShoulder|SignTabRightGamepad||7
SkillsMenuPrompt|SkillsMenuDummy|Gamepad_Special_Left|SkillsMenuDummyGamepad|1|2
SkillsMenuPrompt|SkillsMenu|Gamepad_Special_Left|||3
SkipNotification|SkipNotification|Gamepad_RightShoulder|SkipNotificationGamepad|1|2
SpecialActionPrompt|SpecialActionDummy|Gamepad_RightShoulder|CombatSpecialActionDummyGamepad|1|2
SpellMenuPrompt|SpellMenuDummy|Gamepad_FaceButton_Top|SpellMenuDummyGamepad|1|2
SpellcastingMode|Spellcasting_Cancel|Gamepad_LeftTriggerAxis|||5
SpellcastingMode|Spellcasting_PlaceSpell|Gamepad_RightTriggerAxis|||6
SpellcastingMode|Spellcasting_AdjustSpell|Gamepad_LeftShoulder|||7
SpellcastingMode|Spellcasting_AdjustSpell|Gamepad_RightShoulder|||8
SpellcastingMode|SpellMenu|Gamepad_FaceButton_Top|||9
SpellcastingMode|Spellcasting_Adjust_NegativeAxis|Gamepad_RightShoulder|||10
SpellcastingModeAdvancedMovement|Player_Evade|Gamepad_FaceButton_Right|||2
SpellsUI|SpellBook|Gamepad_Special_Left|SpellBookRadialGamepad|1|2
SpellsUI|SpellMenu|Gamepad_FaceButton_Top|SpellMenuRadialGamepad|1|4
SwitchPanel|Inventory_SwitchPanel|Gamepad_RightThumbstick|SwitchPanelRightGamepad||1
TopBarMenu|TopBarMap|Gamepad_Special_Left|OpenMenuGamepad|1|2
TopBarMenu|UI_GenericTabLeft|Gamepad_LeftShoulder|TabLeftGamepad|1|6
TopBarMenu|UI_GenericTabRight|Gamepad_RightShoulder|TabRightGamepad|1|8
TopBarMenu|UI_GenericNavigationLeftStick|Gamepad_Left2D|LeftStickNavigationGamepad|1|10
TopBarMenuJournal|UI_GenericSubTabLeft|Gamepad_LeftTrigger|TabSubLeftGamepad||1
TopBarMenuJournal|UI_GenericSubTabRight|Gamepad_RightTrigger|TabSubRightGamepad||2
TopBarMenuJournal|ScrollContent|Gamepad_RightY|ScrollUpGamepad|1|3
TopBarMenuJournal|UI_GenericFocusRequirements|Gamepad_FaceButton_Left|FocusRequirementGamepad||4
TopBarMenuJournal|UI_GenericUnFocusRequirements|Gamepad_FaceButton_Left|UnFocusRequirementGamepad||5
TopBarMenuJournal|Journal_PageSelectionNext|Gamepad_DPad_Right|PageSelectionNextGamepad||6
TopBarMenuJournal|Journal_PageSelectionPrevious|Gamepad_DPad_Left|PageSelectionPreviousGamepad||7
TopBarMenuJournal|UI_GenericCategoryToggle|Gamepad_RightThumbstick|JournalToggleCategory||8
TopBarMenuJournal|Journal_MarkAllAsRead|Gamepad_FaceButton_Top|JournalMarkAllAsRead||10
TopBarMenuJournal|Journal_ViewEntry|Gamepad_LeftThumbstick|ViewEntryGamepad|1|13
TopBarMenuPrompt|TopBarMenuDummy|Gamepad_Special_Left|TopBarMenuDummyGamepad|1|2
TopBarMenuSettings|UI_GenericSubTabLeft|Gamepad_LeftTrigger|TabSubLeftGamepad||1
TopBarMenuSettings|UI_GenericSubTabRight|Gamepad_RightTrigger|TabSubRightGamepad||2
TopBarMenuSettings|UI_GenericBack|Gamepad_FaceButton_Right|||4
TopBarMenuSettings|Settings_Apply|Gamepad_FaceButton_Left|||6
TopBarMenuSettings_Controls|Settings_ResetControls|Gamepad_FaceButton_Left|RestControlsGamepad||1
TopBarMenuSettings_Updates|ScrollContent|Gamepad_RightY|ScrollUpGamepad|1|1
TopBarMenuSkills|SkillsMenu_Navigation|Gamepad_Left2D|LeftStickNavigationGamepad|1|1
TopBarMenuSkills|SkillsMenu_Back|Gamepad_FaceButton_Right|||2
TopBarMenuSpells|SpellsMenu_AddSpell|Gamepad_FaceButton_Bottom|AddSpellGamepad||1
TopBarMenuSpells|SpellsMenu_EditRadial|Gamepad_FaceButton_Top|EditSpellRadialGamepad||2
TopBarMenuSpells|SpellsMenu_CancelSlotSelection|Gamepad_FaceButton_Right|CancelSpellBookSlotSelectionGamepad||3
TopBarMenuSpells|UI_GenericSelectorLeft|Gamepad_LeftTrigger|TabSubLeftGamepad|1|4
TopBarMenuSpells|UI_GenericSelectorRight|Gamepad_RightTrigger|TabSubRightGamepad|1|5
TopBarMenuSpellsRadial|SpellsMenu_AddSpell|Gamepad_FaceButton_Bottom|AssignSpellGamepad||1
TopBarMenuSpellsRadial|SpellsMenu_RemoveSpell|Gamepad_FaceButton_Top|RemoveSpellGamepad||2
TopBarMenuSpellsRadial|SpellsMenu_SelectSlot|Gamepad_Left2D|SelectSpellGamepad|1|3
TopBarMenuSpellsRadial|SpellsMenu_AcceptSelection|Gamepad_FaceButton_Bottom|ConfirmSpellSelection||5
TopBarMenuSpellsRadial|UI_GenericSelectorLeft|Gamepad_LeftTrigger|TabSubLeftGamepad|1|6
TopBarMenuSpellsRadial|UI_GenericSelectorRight|Gamepad_RightTrigger|TabSubRightGamepad|1|8
UI_Generic|UI_GenericAccept|Gamepad_FaceButton_Bottom|AcceptGamepad||2
UI_Generic|UI_GenericBack|Gamepad_FaceButton_Right|BackGamepad||4
UI_Generic|UI_GenericNavigationLeftStick|Gamepad_LeftX|||5
UI_GenericCheckBox|UI_GenericAccept|Gamepad_FaceButton_Bottom|CheckBoxGamepad|1|1
UI_GenericSelector|UI_GenericSelector|Gamepad_RightX|||1
UI_GenericSelector|UI_GenericAccept|Gamepad_FaceButton_Bottom|||2
UI_GenericSelector|UI_GenericSelector|Gamepad_DPad_Left|||3
UI_GenericSelector|UI_GenericSelector|Gamepad_DPad_Right|||4
UI_GenericSlider|UI_GenericSlider|Gamepad_RightX|||1
UI_GenericSlider|UI_GenericSlider|Gamepad_DPad_Left|||2
UI_GenericSlider|UI_GenericSlider|Gamepad_DPad_Right|||3
Vehicle|ExitOccupied|Gamepad_FaceButton_Left|CombatInteractGamepad||2
Vehicle|VehicleMovement|Gamepad_Left2D|||7
WorldInventory|WorldInventory_FillStacks|Gamepad_FaceButton_Top|||3
WorldInventory|WorldInventory_TakeAll|Gamepad_FaceButton_Top|||5
]]
local PAD_META, PBY_IDX, PBY_ACTION = nil, nil, nil
local function parsePad()
    PAD_META, PBY_IDX, PBY_ACTION = {}, {}, {}
    for line in PAD_DATA:gmatch("[^\n]+") do
        local ctx, action, key, name, hidden, idx = line:match("^([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)|(%d+)$")
        if ctx then
            local r = { ctx = ctx, action = action, key = key, name = name, hidden = hidden == "1", idx = tonumber(idx),
                        place = placeOf(ctx) }
            r.locked = r.name == "" or r.hidden
            PAD_META[#PAD_META + 1] = r
            PBY_IDX[ctx .. "#" .. r.idx] = r
            PBY_ACTION[ctx .. "#" .. action] = PBY_ACTION[ctx .. "#" .. action] or r
        end
    end
end
function K.padData() if not PAD_META then parsePad() end return PAD_META end

-- Every gamepad key name the game uses, by its canonical spelling (a mod row may write it in any case).
local PAD_NAME = {}
for _, n in ipairs({ "Gamepad_DPad_Down", "Gamepad_DPad_Left", "Gamepad_DPad_Right", "Gamepad_DPad_Up",
    "Gamepad_FaceButton_Bottom", "Gamepad_FaceButton_Left", "Gamepad_FaceButton_Right", "Gamepad_FaceButton_Top",
    "Gamepad_Left2D", "Gamepad_LeftShoulder", "Gamepad_LeftStick_Left", "Gamepad_LeftStick_Right", "Gamepad_LeftStick_Up",
    "Gamepad_LeftStick_Down", "Gamepad_LeftThumbstick", "Gamepad_LeftTrigger", "Gamepad_LeftTriggerAxis", "Gamepad_LeftX",
    "Gamepad_LeftY", "Gamepad_Right2D", "Gamepad_RightShoulder", "Gamepad_RightStick_Left", "Gamepad_RightStick_Right",
    "Gamepad_RightStick_Up", "Gamepad_RightStick_Down", "Gamepad_RightThumbstick", "Gamepad_RightTrigger",
    "Gamepad_RightTriggerAxis", "Gamepad_RightX", "Gamepad_RightY", "Gamepad_Special_Left", "Gamepad_Special_Right" }) do
    PAD_NAME[n:lower()] = n
end
function K.padName(v) return type(v) == "string" and PAD_NAME[v:lower()] or nil end

local PADGAME = nil
local function finishPad(rows)
    local seen, out = {}, {}
    for _, r in ipairs(rows) do
        local label = K.labelFor(r.action)
        local id = label .. "|" .. r.key .. "|" .. r.place
        if not seen[id] then
            seen[id] = true
            out[#out + 1] = { key = r.key, action = "IA_" .. r.action, label = label, context = r.place, locked = r.locked,
                              ctx = "IMC_" .. r.ctx }
        end
    end
    table.sort(out, function(a, b)
        if a.key ~= b.key then return a.key < b.key end
        if a.context ~= b.context then return a.context < b.context end
        return a.label < b.label
    end)
    PADGAME = out
    return out
end
function K.padKeys()
    if not PADGAME then
        local rows = {}
        for _, r in ipairs(K.padData()) do
            rows[#rows + 1] = { ctx = r.ctx, action = r.action, key = r.key, place = r.place, locked = r.locked }
        end
        finishPad(rows)
    end
    return PADGAME
end

-- ------------------------------------------------------------------ the game key list (gameKeys)
local GAME, SOURCE, VERSION = nil, "table", 0
local LIVE = { imcs = nil, prof = nil, profTried = false, lastRead = nil, why = "not read yet", findMs = 0, readMs = 0,
               pcName = nil, pcSince = nil, remapped = 0 }

-- one entry per (action, key, place): the IMC contexts repeat actions (wheel in three, chat in two)
local function finish(rows)
    local seen, out = {}, {}
    for _, r in ipairs(rows) do
        local label = K.labelFor(r.action)
        local id = label .. "|" .. r.key .. "|" .. r.place
        if not seen[id] then
            seen[id] = true
            out[#out + 1] = { key = r.key, action = "IA_" .. r.action, label = label, context = r.place, locked = r.locked,
                              ctx = "IMC_" .. r.ctx, default = r.default or r.key, remapped = r.remapped or nil }
        end
    end
    table.sort(out, function(a, b)
        if a.context ~= b.context then return a.context < b.context end
        if a.label ~= b.label then return a.label < b.label end
        return a.key < b.key
    end)
    GAME, VERSION = out, VERSION + 1
    return out
end

local function fromTable()
    local rows = {}
    for _, r in ipairs(K.data()) do
        rows[#rows + 1] = { ctx = r.ctx, action = r.action, key = r.key, place = r.place, locked = r.locked, default = r.key }
    end
    SOURCE = "table"
    return finish(rows)
end

function K.gameKeys()
    if not GAME then fromTable() end
    return GAME
end
function K.source() return SOURCE, LIVE end

local function valid(o) return MM.valid and MM.valid(o) or false end
local function now() return MM.now and MM.now() or os.clock() end
local function nameOf(o)
    local ok, n = pcall(function() return o:GetFName():ToString() end)
    return ok and tostring(n) or nil
end

-- Seconds since the local player controller (the world) appeared; core's MM.worldAge when it has one.
function K.worldAge()
    if type(MM.worldAge) == "function" then
        local ok, a = pcall(MM.worldAge)
        if ok then return a end
    end
    local pc = MM.localPC and MM.localPC() or nil
    if not valid(pc) then LIVE.pcName = nil; return nil end
    local ok, n = pcall(function() return pc:GetFullName() end)
    n = ok and tostring(n) or "?"
    if n ~= LIVE.pcName then LIVE.pcName, LIVE.pcSince = n, now() end
    return now() - LIVE.pcSince
end

local function findContexts()
    local t0 = os.clock()
    local ok, all = pcall(FindAllOf, "InputMappingContext")
    LIVE.findMs = (os.clock() - t0) * 1000
    if not ok or type(all) ~= "table" then return nil end
    local list = {}
    local known = {}
    for _, r in ipairs(K.data()) do known[r.ctx] = true end
    for _, r in ipairs(K.padData()) do known[r.ctx] = true end
    for _, o in ipairs(all) do
        local n = valid(o) and nameOf(o) or nil
        local ctx = n and n:match("^IMC_(.+)$")
        if ctx and known[ctx] then list[#list + 1] = { ctx = ctx, obj = o } end
    end
    return list
end

local function findProfile()
    LIVE.profTried = true
    local ok, all = pcall(FindAllOf, "EnhancedPlayerMappableKeyProfile")
    if not ok or type(all) ~= "table" then return nil end
    for _, p in ipairs(all) do
        local n = valid(p) and nameOf(p) or nil
        if n and not n:find("^Default__") then return p end
    end
    return nil
end

-- The player's Controls changes: mapping name -> { keys it is on now } (nil when the profile cannot be read).
local function profileKeys(prof, keys)
    local byName, any = {}, false
    for k in pairs(keys) do
        local out = {}
        local ok = pcall(function() prof:GetMappingNamesForKey({ KeyName = FName(k) }, out) end)
        if ok then
            for _, fn in ipairs(out) do
                local okN, n = pcall(function() return fn:ToString() end)
                if okN and n and n ~= "" then
                    any = true
                    byName[n] = byName[n] or {}
                    byName[n][#byName[n] + 1] = k
                end
            end
        end
    end
    return any and byName or nil
end

-- The live read. Returns true when GAME holds live keys. Safe to call often (cached, throttled, world-age gated).
function K.warm(force)
    if not MM then return false end
    local age = K.worldAge()
    if not age then LIVE.why = "not in a world"; return SOURCE == "live" end
    if age < K.WORLD_WAIT then LIVE.why = "world loaded under " .. K.WORLD_WAIT .. " s ago"; return SOURCE == "live" end
    if not force and LIVE.lastRead and now() - LIVE.lastRead < K.READ_GAP then return SOURCE == "live" end
    LIVE.lastRead = now()
    local t0 = os.clock()
    if LIVE.imcs then
        for _, c in ipairs(LIVE.imcs) do if not valid(c.obj) then LIVE.imcs = nil; break end end
    end
    if not LIVE.imcs then LIVE.imcs = findContexts() end
    if not LIVE.imcs or #LIVE.imcs == 0 then LIVE.imcs = nil; LIVE.why = "no input contexts found"; return false end
    local rows, keys, padRows = {}, {}, {}
    for _, c in ipairs(LIVE.imcs) do
        local okM, maps = pcall(function() return c.obj.Mappings end)
        local n = 0
        if okM and maps then pcall(function() n = #maps end) end
        for i = 1, n do
            local m = maps[i]
            local okA, action = pcall(function() return m.Action:GetFName():ToString() end)
            local okK, key = pcall(function() return m.Key.KeyName:ToString() end)
            action = okA and tostring(action):gsub("^IA_", "") or nil
            if action and okK and keyboardKey(key) then
                local meta = BY_IDX[c.ctx .. "#" .. i]
                if not meta or meta.action ~= action then meta = BY_ACTION[c.ctx .. "#" .. action] end
                local r = { ctx = c.ctx, action = action, key = key, place = placeOf(c.ctx),
                            locked = meta and meta.locked or false, default = meta and meta.key or key,
                            name = meta and meta.name or "" }
                rows[#rows + 1] = r
                keys[key] = true
            elseif action and okK and PAD_NAME[tostring(key):lower()] then   -- C36: the controller's mappings
                local meta = PBY_IDX[c.ctx .. "#" .. i]
                if not meta or meta.action ~= action then meta = PBY_ACTION[c.ctx .. "#" .. action] end
                padRows[#padRows + 1] = { ctx = c.ctx, action = action, key = key, place = placeOf(c.ctx),
                                          locked = meta and meta.locked or false }
            end
        end
    end
    if #padRows > 0 then finishPad(padRows) end
    -- the player's own Controls changes (mappable rows only)
    if not LIVE.profTried or (LIVE.prof and not valid(LIVE.prof)) then LIVE.prof = findProfile() end
    LIVE.remapped = 0
    if LIVE.prof then
        for _, r in ipairs(K.data()) do keys[r.key] = true end
        for _, s in ipairs(K.modKeys()) do keys[s.unreal] = true end
        local byName = profileKeys(LIVE.prof, keys)
        if byName then
            for _, r in ipairs(rows) do
                local now_ = r.name ~= "" and not r.locked and byName[r.name]
                if now_ then
                    local on = false
                    for _, k in ipairs(now_) do if k == r.key then on = true end end
                    if not on then r.key, r.remapped = now_[1], true; LIVE.remapped = LIVE.remapped + 1 end
                end
            end
        end
    end
    LIVE.readMs = (os.clock() - t0) * 1000
    if #rows == 0 then LIVE.why = "the input contexts had no keyboard keys"; return false end
    SOURCE, LIVE.why = "live", nil
    finish(rows)
    return true
end

-- ------------------------------------------------------------------ mod keys and clashes
-- Every key a switched-on mod uses now: { m, s, value, unreal, place(s) }. Combos (ALT+F) and "none" are left out.
function K.modKeys()
    local out = {}
    for _, m in ipairs(MM.mods() or {}) do
        if not m.off then
            for _, s in ipairs(m.settings or {}) do
                local isKey = s.key and not s.locked and MM.keyTools and MM.keyTools.isKeySetting(s)
                local v = isKey and m.values and m.values[s.key]
                if type(v) == "string" and v:lower() == "default" then v = s.default end
                if type(v) == "string" and v ~= "" and v:upper() ~= "NONE" and not v:find("+", 1, true) then
                    local u = K.padName(v) or MM.keyTools.toUnrealKey(v)          -- C36: a row may name a Gamepad_ key
                    if u and u ~= "None" then
                        out[#out + 1] = { m = m, s = s, value = v, unreal = u, context = s.context or "anywhere" }
                    end
                end
            end
        end
    end
    return out
end

-- Game rows a mod key collides with (same key, places overlap; Key Unlocker vs the action it moves is no clash).
local function gameHits(mk)
    local hits = {}
    local kuAction = mk.m.id == "KeyUnlocker" and KU[mk.s.key] or nil
    local kuPlaces = nil
    if kuAction then
        kuPlaces = {}
        for _, r in ipairs(K.data()) do
            if r.action == kuAction then
                kuPlaces[r.place] = true
                if r.key == mk.unreal then return hits end      -- the game's own key: Key Unlocker moves nothing
            end
        end
    end
    for _, g in ipairs(K.padName(mk.unreal) and K.padKeys() or K.gameKeys()) do
        if g.key == mk.unreal and g.action ~= "IA_" .. tostring(kuAction) then
            local overlap
            if kuPlaces then overlap = kuPlaces[g.context] == true
            else overlap = mk.context == "anywhere" or mk.context == g.context end
            if overlap then hits[#hits + 1] = g end
        end
    end
    return hits
end
K.gameHits = gameHits

function K.clashExtra(m, s)
    if not (m and s) then return nil end
    for _, mk in ipairs(K.modKeys()) do
        if mk.m == m and mk.s == s then
            local hits = gameHits(mk)
            if #hits == 0 then return nil end
            local names, seen = {}, {}
            for _, g in ipairs(hits) do
                if not seen[g.label] then seen[g.label] = true; names[#names + 1] = g.label end
            end
            local more = #names > 3 and (#names - 3) or 0
            while #names > 3 do table.remove(names) end
            return "! " .. mk.value:upper() .. " is also the game's key for " .. table.concat(names, ", ")
                .. (more > 0 and (" and " .. more .. " more") or "") .. "."
        end
    end
    return nil
end

-- Number of mod key rows with any clash (another mod's key, F10/F11, or a game key). Cached until a value changes.
local countCache = { sig = nil, n = 0 }
function K.clashCount()
    local sig = { tostring(VERSION) }
    for _, m in ipairs(MM.mods() or {}) do sig[#sig + 1] = tostring(m.id) .. (m.off and "x" or "") .. tostring(m.rev or 0) end
    sig = table.concat(sig, ",")
    if sig == countCache.sig then return countCache.n end
    local n = 0
    for _, mk in ipairs(K.modKeys()) do
        local modClash = MM.keyTools.keyClash and MM.keyTools.keyClash(mk.m, mk.s)
        if modClash or #gameHits(mk) > 0 then n = n + 1 end
    end
    countCache.sig, countCache.n = sig, n
    return n
end

function K.init(ctx)
    MM = ctx
    parseData()
    GAME, SOURCE, PADGAME = nil, "table", nil
    parsePad()
    LIVE = { imcs = nil, prof = nil, profTried = false, lastRead = nil, why = "not read yet", findMs = 0, readMs = 0,
             pcName = nil, pcSince = nil, remapped = 0 }
    countCache = { sig = nil, n = 0 }
    return true
end

-- ------------------------------------------------------------------ the Keys page (Y2, C35, C36)
-- Three parts: MOD KEYS (a button per key row of every switched-on mod, opens its page at the row), GAME KEYS (the
-- game's keyboard keys per place), and two pictures: a real full-size ANSI keyboard (function row with its gaps, main
-- block with true key widths, nav cluster, inverted-T arrows, numpad block, mouse row) and a controller (shoulders,
-- View / Start, face diamond, D-pad, both sticks and their clicks). Every cap says its key on top and its owner's
-- 4-letter tag (C30) below; gold = a mod's key, red = one key does two things, light gray = the game's key, dark =
-- free; "lock" = a game key Settings > Controls cannot change. Under each picture: a color legend, the tag legend and
-- the full owners of every key in use. Each cap's full owner list is also returned as a hint for core's footer line.
-- Each picture is placed on a CanvasPanel from its own unit grid and scaled as one unit to the page width.
K.CELL_W, K.CELL_H = 52, 44      -- the old map's cap (cellFonts keeps it as the default cap)
K.GAP = 2                        -- one gap between all caps (C52: 2, so names stay 10 pt while the block fits MM.ui.PH)
K.UNIT_MAX_W, K.UNIT_H = 52, 56  -- a unit's width shrinks to fit the page; its height fits the page, min the text's need

-- The keyboard: { Unreal key name (false = a key Unreal has no name for), label (<= 4 characters), x, y, w, h } in
-- key units. Full-size ANSI: 22.5 units wide, function row, 0.5 gap, 5 main rows, 0.5 gap, mouse row.
local BOARD = {}
local function keyRow(y, x, list)
    for _, k in ipairs(list) do
        BOARD[#BOARD + 1] = { key = k[1] or false, label = k[2] or k[1], x = x, y = y, w = k[3] or 1, h = k[4] or 1 }
        x = x + (k[3] or 1)
    end
end
keyRow(0, 0, { { "Escape", "Esc" } })
keyRow(0, 2, { { "F1" }, { "F2" }, { "F3" }, { "F4" } })
keyRow(0, 6.5, { { "F5" }, { "F6" }, { "F7" }, { "F8" } })
keyRow(0, 11, { { "F9" }, { "F10" }, { "F11" }, { "F12" } })
keyRow(0, 15.25, { { false, "Prt" }, { "ScrollLock", "ScL" }, { "Pause", "Pau" } })   -- C47: 3 letters fit a 1-unit cap at 10 pt
keyRow(1.25, 0, { { "Tilde", "`" }, { "One", "1" }, { "Two", "2" }, { "Three", "3" }, { "Four", "4" }, { "Five", "5" },
    { "Six", "6" }, { "Seven", "7" }, { "Eight", "8" }, { "Nine", "9" }, { "Zero", "0" }, { "Hyphen", "-" },
    { "Equals", "=" }, { "BackSpace", "Bksp", 2 } })
keyRow(2.25, 0, { { "Tab", "Tab", 1.5 }, { "Q" }, { "W" }, { "E" }, { "R" }, { "T" }, { "Y" }, { "U" }, { "I" }, { "O" },
    { "P" }, { "LeftBracket", "[" }, { "RightBracket", "]" }, { "Backslash", "\\", 1.5 } })
keyRow(3.25, 0, { { "CapsLock", "Caps", 1.75 }, { "A" }, { "S" }, { "D" }, { "F" }, { "G" }, { "H" }, { "J" }, { "K" },
    { "L" }, { "Semicolon", ";" }, { "Apostrophe", "'" }, { "Enter", "Entr", 2.25 } })
keyRow(4.25, 0, { { "LeftShift", "Shft", 2.25 }, { "Z" }, { "X" }, { "C" }, { "V" }, { "B" }, { "N" }, { "M" },
    { "Comma", "," }, { "Period", "." }, { "Slash", "/" }, { "RightShift", "Shft", 2.75 } })
keyRow(5.25, 0, { { "LeftControl", "Ctrl", 1.25 }, { false, "Win", 1.25 }, { "LeftAlt", "Alt", 1.25 },
    { "SpaceBar", "Spc", 6.25 }, { "RightAlt", "Alt", 1.25 }, { false, "Win", 1.25 }, { false, "Menu", 1.25 },
    { "RightControl", "Ctrl", 1.25 } })
keyRow(1.25, 15.25, { { "Insert", "Ins" }, { "Home", "Hom" }, { "PageUp", "PgU" } })
keyRow(2.25, 15.25, { { "Delete", "Del" }, { "End", "End" }, { "PageDown", "PgD" } })
keyRow(4.25, 16.25, { { "Up", "Up" } })
keyRow(5.25, 15.25, { { "Left", "Lft" }, { "Down", "Dn" }, { "Right", "Rt" } })
keyRow(1.25, 18.5, { { "NumLock", "Num" }, { "Divide", "/" }, { "Multiply", "*" }, { "Subtract", "-" } })
keyRow(2.25, 18.5, { { "NumPadSeven", "7" }, { "NumPadEight", "8" }, { "NumPadNine", "9" }, { "Add", "+", 1, 2 } })
keyRow(3.25, 18.5, { { "NumPadFour", "4" }, { "NumPadFive", "5" }, { "NumPadSix", "6" } })
keyRow(4.25, 18.5, { { "NumPadOne", "1" }, { "NumPadTwo", "2" }, { "NumPadThree", "3" }, { false, "Ent", 1, 2 } })
keyRow(5.25, 18.5, { { "NumPadZero", "0", 2 }, { "Decimal", "." } })
keyRow(6.5, 0, { { "LeftMouseButton", "LMB", 1.5 }, { "RightMouseButton", "RMB", 1.5 }, { "MiddleMouseButton", "MMB", 1.5 },
    { "ThumbMouseButton", "M4", 1.5 }, { "ThumbMouseButton2", "M5", 1.5 }, { "MouseScrollUp", "WhUp", 1.5 },
    { "MouseScrollDown", "WhDn", 1.5 } })
K.BOARD, K.BOARD_W, K.BOARD_H = BOARD, 22.5, 7.5   -- C52: 0.25 gaps above and below the main block
K.KEY_NAMES = { Prt = "Print Screen", Win = "Windows", Menu = "Menu", Ent = "Numpad Enter" }

-- The controller (Xbox layout, C47): a silhouette of a body and two grips (a gold 1 px edge around the union), LT/RT
-- above LB/RB on the top edge, View / Start pills in the center, round A/B/X/Y in a diamond, a D-pad cross, round
-- sticks with their click as a pill inside. Square units (x = y), 18 x 9. shape: "box" | "pill" | "circle".
local PADB = {
    { id = "LT", label = "LT", keys = { "Gamepad_LeftTrigger", "Gamepad_LeftTriggerAxis" }, x = 2.5, y = 0, w = 3, h = 1.25, shape = "pill" },
    { id = "RT", label = "RT", keys = { "Gamepad_RightTrigger", "Gamepad_RightTriggerAxis" }, x = 12.5, y = 0, w = 3, h = 1.25, shape = "pill" },
    { id = "LB", label = "LB", keys = { "Gamepad_LeftShoulder" }, x = 2, y = 1.3, w = 4, h = 1.25, shape = "pill" },
    { id = "RB", label = "RB", keys = { "Gamepad_RightShoulder" }, x = 12, y = 1.3, w = 4, h = 1.25, shape = "pill" },
    { id = "View", label = "View", keys = { "Gamepad_Special_Left" }, x = 6.8, y = 2.7, w = 1.9, h = 1.25, shape = "pill" },
    { id = "Start", label = "Start", keys = { "Gamepad_Special_Right" }, x = 9.3, y = 2.7, w = 1.9, h = 1.25, shape = "pill" },
    { id = "LStick", label = "LS", keys = { "Gamepad_Left2D", "Gamepad_LeftX", "Gamepad_LeftY", "Gamepad_LeftStick_Left",
        "Gamepad_LeftStick_Right", "Gamepad_LeftStick_Up", "Gamepad_LeftStick_Down" }, x = 2.6, y = 2.65, w = 2.9, h = 2.9,
        shape = "circle", click = "LClick" },
    { id = "LClick", label = "L3", keys = { "Gamepad_LeftThumbstick" }, inside = "LStick", shape = "pill" },
    { id = "Y", label = "Y", keys = { "Gamepad_FaceButton_Top" }, x = 13.85, y = 2.6, w = 1.3, h = 1.3, shape = "circle" },
    { id = "X", label = "X", keys = { "Gamepad_FaceButton_Left" }, x = 12.5, y = 3.95, w = 1.3, h = 1.3, shape = "circle" },
    { id = "B", label = "B", keys = { "Gamepad_FaceButton_Right" }, x = 15.2, y = 3.95, w = 1.3, h = 1.3, shape = "circle" },
    { id = "A", label = "A", keys = { "Gamepad_FaceButton_Bottom" }, x = 13.85, y = 5.3, w = 1.3, h = 1.3, shape = "circle" },
    { id = "DUp", label = "Up", keys = { "Gamepad_DPad_Up" }, x = 6.0, y = 5.25, w = 1.25, h = 1.25, shape = "box" },
    { id = "DLeft", label = "Lt", keys = { "Gamepad_DPad_Left" }, x = 4.75, y = 6.5, w = 1.25, h = 1.25, shape = "box" },
    { id = "DRight", label = "Rt", keys = { "Gamepad_DPad_Right" }, x = 7.25, y = 6.5, w = 1.25, h = 1.25, shape = "box" },
    { id = "DDown", label = "Dn", keys = { "Gamepad_DPad_Down" }, x = 6.0, y = 7.75, w = 1.25, h = 1.25, shape = "box" },
    { id = "RStick", label = "RS", keys = { "Gamepad_Right2D", "Gamepad_RightX", "Gamepad_RightY", "Gamepad_RightStick_Left",
        "Gamepad_RightStick_Right", "Gamepad_RightStick_Up", "Gamepad_RightStick_Down" }, x = 10.7, y = 5.65, w = 2.9, h = 2.9,
        shape = "circle", click = "RClick" },
    { id = "RClick", label = "R3", keys = { "Gamepad_RightThumbstick" }, inside = "RStick", shape = "pill" },
}
-- the silhouette: body + two grips (their union gets the gold edge), and the D-pad's middle square (no owner).
-- Buttons are >= 1.25 units tall so a 10 pt key name and a 10 pt tag fit at the ~42 px unit one screen allows.
K.PAD_SHAPES = {
    { x = 1, y = 1.95, w = 16, h = 5.85, r = 1.6 },      -- body
    { x = 1.2, y = 4.6, w = 6.2, h = 4.6, r = 2.3 },     -- left grip
    { x = 10.6, y = 4.6, w = 6.2, h = 4.6, r = 2.3 },    -- right grip
}
K.PAD_DPAD_MID = { x = 6.0, y = 6.5, w = 1.25, h = 1.25 }
K.PAD_BUTTONS, K.PAD_W, K.PAD_H = PADB, 18, 9.2   -- C52: 9.2 tall, so the block fits MM.ui.PH
K.PAD_BODY = K.PAD_SHAPES[1]
K.PAD_NAMES = { LT = "Left trigger", LB = "Left bumper", RT = "Right trigger", RB = "Right bumper", View = "View",
    Start = "Start (Menu)", LStick = "Left stick", LClick = "Left stick click", Y = "Y", X = "X", B = "B", A = "A",
    DUp = "D-pad up", DLeft = "D-pad left", DRight = "D-pad right", DDown = "D-pad down", RStick = "Right stick",
    RClick = "Right stick click" }

-- Mod Menu's own pad controls (design 4, rulings D0 10.1/10.4, C13, C14, C26): they work in Mod Menu's docked panel
-- (pause menu up); the Quick Panel's are on only while its pad edit is on.
K.MM_PAD = {
    Gamepad_Special_Right = { "Start then RB opens Mod Menu" },
    Gamepad_RightShoulder = { "next mod (docked menu)", "after Start: opens Mod Menu" },
    Gamepad_LeftShoulder = { "previous mod (docked menu)" },
    Gamepad_FaceButton_Left = { "reset the row (docked menu)" },
    Gamepad_FaceButton_Top = { "pin the row for the Quick Panel (docked menu)" },
    Gamepad_FaceButton_Bottom = { "press the focused button (docked menu)" },
    Gamepad_FaceButton_Right = { "closes the menu with the pause menu, the place is kept" },
    Gamepad_DPad_Up = { "move between rows (docked menu)" }, Gamepad_DPad_Down = { "move between rows (docked menu)" },
    Gamepad_DPad_Left = { "back to the mod list (docked menu)" }, Gamepad_DPad_Right = { "into the page (docked menu)" },
}
K.QP_PAD = {
    Gamepad_Special_Left = { "Quick Panel: hold to edit the pinned rows" },
    Gamepad_LeftShoulder = { "Quick Panel (View held): previous pinned row" },
    Gamepad_RightShoulder = { "Quick Panel (View held): next pinned row" },
    Gamepad_FaceButton_Left = { "Quick Panel (View held): one step down" },
    Gamepad_FaceButton_Top = { "Quick Panel (View held): one step up" },
    Gamepad_FaceButton_Bottom = { "Quick Panel (View held): switch the toggle" },
}
local function quickPadEdit()
    local v = MM.cfg and MM.cfg.QuickPadEdit
    return v == true or tostring(v):lower() == "true"
end

-- C44: brush colors are LINEAR (FLinearColor, C28 step 4 note); the colors below are sRGB bytes from the mockup's
-- palette (runs/2026-10-19-modmenu-2/mod-menu-2.html), converted here. Passing sRGB numbers straight drew them far
-- lighter in game (C43: the Quick Panel card came out light gray).
local function lin(byte)
    local c = byte / 255
    return c <= 0.04045 and c / 12.92 or ((c + 0.055) / 1.055) ^ 2.4
end
local function srgb(r, g, b, a) return { R = lin(r), G = lin(g), B = lin(b), A = a or 1.0 } end
K.srgb = srgb
-- C49: measured on screen in c48-kb-mouse-165306 / c48-pad-mouse-165310 (pixel samples), our cap fills came out
-- darker than their sRGB bytes: gold #a87c27 drew #804d04, gray #55524c drew #26241f, the free fill and the body
-- drew black. On these (rounded) cap brushes the screen byte is about value ^ 0.75, so a fill is given as the byte
-- we want ON SCREEN raised to 4/3 (K.onScreen). C-core: resample after the reshoot; tune K.SCREEN_GAMMA if needed.
K.SCREEN_GAMMA = 4 / 3
local function onScreen(r, g, b, a)
    local function v(c) return (c / 255) ^ K.SCREEN_GAMMA end
    return { R = v(r), G = v(g), B = v(b), A = a or 1.0 }
end
K.onScreen = onScreen
local CELL_BG = { free = onScreen(29, 26, 21),      -- on screen #1d1a15: dark, free
                  game = onScreen(92, 87, 78),      -- on screen #5c574e: a clearly lighter gray, the game's key
                  mod = onScreen(168, 124, 39),     -- on screen #a87c27 (--gold): a mod's key
                  clash = onScreen(180, 73, 47) }   -- on screen #b4492f (--red): one key does two things
local BODY_BG = onScreen(60, 55, 45)                -- C52: ~10 levels lighter than the card (50,45,36) on screen
local EDGE_GOLD = onScreen(217, 178, 92)            -- on screen #d9b25c (--g-gold): the edges and the shown toggle
local OUTLINE = onScreen(169, 157, 132)             -- on screen #a99d84 (--g-dim): every controller button's outline
local HUB = onScreen(58, 50, 38)                    -- on screen #3a3226 (--g-sel): the D-pad's middle
local INK_DARK = onScreen(29, 26, 21)               -- dark text on the gold toggle
K.HUB = HUB
K.EDGE_GOLD, K.OUTLINE = EDGE_GOLD, OUTLINE
K.CAP_PAD = { Left = 2, Top = 2, Right = 2, Bottom = 2 }
K.CELL_BG, K.BODY_BG = CELL_BG, BODY_BG
local PLACE_TITLE = { world = "In the world", build = "Building", chest = "Chests and storage", menus = "Menus" }

-- A readable tag of at most 4 letters for a mod, from the starts of its words (T3-D3: 6-letter tags were clipped to
-- "etRoc" / "utToo" in a 1-unit cap): "Pet Rock" -> "PeRo", "Auto Tool" -> "AuTo", "XP Tracker" -> "XPTr",
-- "Slayer" -> "Slay", "RuneScape Bags" -> "RSB" (3+ words: initials). The legend under the map gives the full names.
local function nameWords(name)
    local w = {}
    local s = tostring(name or ""):gsub("'", ""):gsub("\226\128\153", "")    -- "Builder's" is one word
    for part in s:gsub("(%l)(%u)", "%1 %2"):gsub("[^%w ]", " "):gmatch("%S+") do w[#w + 1] = part end
    return w
end
function K.tag(name)
    local w = nameWords(name)
    if #w == 0 then return "" end
    if #w == 1 then return w[1]:sub(1, 4) end
    if #w == 2 then return w[1]:sub(1, 2) .. w[2]:sub(1, 2) end
    local t = ""
    for i = 1, math.min(4, #w) do t = t .. w[i]:sub(1, 1) end
    return t
end
-- Tags for a list of names, one each, unique: a clash ("Movement Sliders" / "Morph Sliders" -> MoSl) tries
-- 3+1, 1+3 and the initials before a digit is put on the end.
function K.tags(names)
    local out, used = {}, {}
    local sorted = {}
    for _, n in ipairs(names) do sorted[#sorted + 1] = n end
    table.sort(sorted, function(a, b) return tostring(a):lower() < tostring(b):lower() end)
    for _, n in ipairs(sorted) do
        if not out[n] then
            local w = nameWords(n)
            local cands = { K.tag(n) }
            if #w >= 2 then
                cands[#cands + 1] = w[1]:sub(1, 3) .. w[2]:sub(1, 1)
                cands[#cands + 1] = w[1]:sub(1, 1) .. w[2]:sub(1, 3)
                cands[#cands + 1] = (w[1]:sub(1, 1) .. w[2]:sub(1, 1) .. (w[3] or ""):sub(1, 1) .. (w[4] or ""):sub(1, 1))
            else
                cands[#cands + 1] = (w[1] or ""):sub(1, 3) .. (w[1] or ""):sub(-1)
            end
            local pick = nil
            for _, c in ipairs(cands) do if c ~= "" and not used[c:lower()] then pick = c; break end end
            if not pick then
                local base = K.tag(n):sub(1, 3)
                for d = 2, 9 do if not used[(base .. d):lower()] then pick = base .. d; break end end
            end
            pick = pick or K.tag(n)
            used[pick:lower()] = true
            out[n] = pick
        end
    end
    return out
end
-- Text metrics: core's (MM.ui.metric, C31: the measured Poppins / title fonts, or the game font when they did not
-- load), else the game font measured in L0 / T3 (1.03 em per char, 2.05 lines per point, the widest case). A cap's
-- text uses the wider of "medium" (the key) and "body" (the tag).
K.METRIC = { em = 1.03, line = 2.05 }
function K.metric(kind)
    local m = nil
    if MM and MM.ui and type(MM.ui.metric) == "function" then
        local ok, r = pcall(MM.ui.metric, kind or "body")
        if ok and type(r) == "table" and tonumber(r.em) and tonumber(r.line) then m = r end
    end
    return m or K.METRIC
end
-- C47: in the T3 / keys-m shots core's Poppins average (0.78 em) was too narrow for short cap words: "game" at 9 pt
-- was cut after about 3.5 letters in a 31 px box (~0.98 em). Cap text is sized with at least 1.0 em and 2.1 lines.
K.CAP_EM_MIN, K.CAP_LINE_MIN = 1.0, 2.1
function K.capMetric()
    local a, b = K.metric("medium"), K.metric("body")
    return { em = math.max(a.em, b.em, K.CAP_EM_MIN), line = math.max(a.line, b.line, K.CAP_LINE_MIN) }
end
-- C47 / C49: px rendered = pt x 4/3 x render scale (mouse ~0.97, docked 0.8). The key NAME is the main text:
-- 11 pt (14 px mouse, 11.7 px docked); the tag second: 10 pt (12.9 px mouse, 10.7 px docked). A 3-letter name or tag
-- fits a 1-unit cap (39 px wide, 33 px inside) at 1.0 em; the unit HEIGHT is what the two lines need (K.capNeedH).
K.TAG_PT, K.NAME_PT, K.NAME_MAX = 10, 11, 13
K.NAME_MIN, K.TAG_MIN = 10, 9   -- C52: names >= 10 pt (10.7 px docked); tags drop to 9 pt first
-- Font sizes for a cap wPx x hPx so its key (top) and tag (below) fit inside the cap minus 8 wide and minus 4 high.
-- The tag line's room is kept on every cap, so a key's letter is the same size used or free.
function K.capFonts(wPx, hPx, label, tag, metric)
    metric = metric or K.capMetric()
    local w, h = wPx - 6, hPx - 4                               -- 2 px padding a side + 1 px slack a side
    local function widest(n) return n > 0 and math.floor(w / (n * metric.em)) or 99 end
    local room = math.floor((h - 2) / metric.line)              -- both lines, in pt (2 px for the rounding up)
    local tagPt = K.TAG_PT
    if room - tagPt < K.NAME_MIN then tagPt = math.max(K.TAG_MIN, room - K.NAME_MIN) end   -- C52: the tag gives way first
    local tagSize = math.min(tagPt, widest(#(tag or "")))
    local labelSize = math.min(K.NAME_MAX, widest(#(label or "")), room - tagPt)
    labelSize = math.max(4, labelSize)                          -- fit first
    if tagSize > labelSize then tagSize = labelSize end         -- a name is never smaller than its tag
    return labelSize, tagSize, w, h
end
-- The cap height (px) a name of K.NAME_PT over a tag of K.TAG_PT needs (padding 4 + rounding 2).
function K.capNeedH(metric)
    metric = metric or K.capMetric()
    return math.ceil((K.NAME_PT + K.TAG_PT) * metric.line + 6)
end
-- The old map's 52 x 44 cap of `units` width (kept for callers and tests).
function K.cellFonts(units, label, tag, metric)
    local lS, tS, w, h = K.capFonts(math.floor((units or 1) * K.CELL_W) - K.GAP, K.CELL_H, label, tag, metric or K.capMetric())
    return lS, tS, w, h
end
function K.textWidth(s, size, metric) metric = metric or K.capMetric(); return #(s or "") * size * metric.em end

-- Unit -> pixels for a picture wUnits x hUnits in availW x availH px (C47: the toggle, the picture and its legend fit
-- one screen; availH = core's page height minus the toggle and the legend, when core gives it).
-- C49: the unit height never goes below what a 1-unit cap's two lines need (readability wins over one screen; the
-- page then scrolls a little); a taller page gives no more than K.UNIT_H.
function K.unitFor(wUnits, availW, hUnits, availH)
    local U = math.max(24, math.min(K.UNIT_MAX_W, math.floor((availW or 980) / wUnits)))
    local UH = K.UNIT_H
    if hUnits and availH then UH = math.max(24, math.min(K.UNIT_H, math.floor(availH / hUnits))) end
    return U, UH
end
-- C52: the room the picture gets: the page list (MM.ui.PH) minus the toggle (52), the gaps under it and under the
-- picture (8 + 8) and the legend row (its 13 pt line at this text size).
function K.pictureRoom(PH, T, metric)
    local legend = math.ceil(math.floor(13 * (T or 1) + 0.5) * (metric or K.metric("body")).line)
    return PH - 52 - 8 - 8 - legend, legend
end
-- Pixel rect of a unit rect: one gap between all caps (half a gap each side).
function K.capRect(c, U, UH)
    return math.floor(c.x * U + K.GAP / 2 + 0.5), math.floor(c.y * UH + K.GAP / 2 + 0.5),
           math.floor(c.w * U - K.GAP + 0.5), math.floor(c.h * UH - K.GAP + 0.5)
end

-- C47: 3-letter tags for the pictures (a 4-letter tag cannot be 10 pt in a 1-unit cap): "Pet Rock" -> "PRo",
-- "Auto Tool" -> "ATo", "XP Tracker" -> "XPT", "Slayer" -> "Sla", "RuneScape Bags" -> "RSB", "Mod Menu" -> "MMe".
function K.mapTag(name)
    local w = nameWords(name)
    if #w == 0 then return "" end
    if #w == 1 then return w[1]:sub(1, 3) end
    if #w >= 3 then return (w[1]:sub(1, 1) .. w[2]:sub(1, 1) .. w[3]:sub(1, 1)) end
    if w[1]:match("^%u%u+$") then return (w[1] .. w[2]):sub(1, 3) end          -- an acronym first: XP Tracker -> XPT
    return w[1]:sub(1, 1) .. w[2]:sub(1, 2)
end
function K.mapTags(names)
    local out, used, sorted = {}, {}, {}
    for _, n in ipairs(names) do sorted[#sorted + 1] = n end
    table.sort(sorted, function(a, b) return tostring(a):lower() < tostring(b):lower() end)
    for _, n in ipairs(sorted) do
        if not out[n] then
            local w = nameWords(n)
            local cands = { K.mapTag(n) }
            if #w >= 2 then
                cands[#cands + 1] = w[1]:sub(1, 2) .. w[2]:sub(1, 1)
                cands[#cands + 1] = w[1]:sub(1, 1) .. w[2]:sub(1, 1) .. w[2]:sub(-1)
            elseif w[1] then
                cands[#cands + 1] = w[1]:sub(1, 2) .. w[1]:sub(-1)
            end
            local pick = nil
            for _, c in ipairs(cands) do if c ~= "" and not used[c:lower()] then pick = c; break end end
            if not pick then
                local base = K.mapTag(n):sub(1, 2)
                for d = 2, 9 do if not used[(base .. d):lower()] then pick = base .. d; break end end
            end
            pick = pick or K.mapTag(n)
            used[pick:lower()] = true
            out[n] = pick
        end
    end
    return out
end

-- C47: rounded shapes. The game's FSlateBrush can draw as RoundedBox (ESlateBrushDrawType 4) with corner radii and a
-- 1 px outline; whether UE4SS lets Lua set that is probed ONCE on the first shape (set, read back) and remembered.
-- Without it, shapes are stepped boxes (two crossing rects) and outlines are an outer Border 1 px larger.
K.ROUND = nil
local function setRound(border, fill, outline, radius, half)
    local ok = pcall(function()
        local b = border.Background
        b.DrawAs = 4
        b.TintColor = { SpecifiedColor = fill, ColorUseRule = 0 }
        local o = b.OutlineSettings
        o.CornerRadii = { X = radius, Y = radius, Z = radius, W = radius }
        o.RoundingType = half and 1 or 0
        o.Width = outline and 1 or 0
        if outline then o.Color = { SpecifiedColor = outline, ColorUseRule = 0 } end
        b.OutlineSettings = o
        border:SetBrush(b)
    end)
    if not ok then return false end
    local back = nil
    pcall(function() back = border.Background.DrawAs end)
    return back == 4 or tostring(back) == "4" or tostring(back):find("RoundedBox", 1, true) ~= nil
end
K.setRound = setRound

-- Who uses each keyboard key now: { [unreal] = { mods = { mk }, game = { rows }, clash = bool } }.
function K.usage()
    local use = {}
    local function at(k) use[k] = use[k] or { mods = {}, game = {}, clash = false } return use[k] end
    for _, g in ipairs(K.gameKeys()) do table.insert(at(g.key).game, g) end
    for _, mk in ipairs(K.modKeys()) do
        if not K.padName(mk.unreal) then
            local u = at(mk.unreal)
            u.mods[#u.mods + 1] = mk
            local modClash = MM.keyTools and MM.keyTools.keyClash and MM.keyTools.keyClash(mk.m, mk.s)
            if modClash or #gameHits(mk) > 0 then u.clash = true end
        end
    end
    return use
end

-- Who uses each controller button now: { [button id] = { mods = { mk }, mm = { text }, game = { rows }, clash } }.
function K.padUsage()
    local use = {}
    local byKey = {}
    for _, b in ipairs(PADB) do
        use[b.id] = { mods = {}, mm = {}, game = {}, clash = false }
        for _, k in ipairs(b.keys) do byKey[k] = b.id end
    end
    for _, g in ipairs(K.padKeys()) do
        local id = byKey[g.key]
        if id then table.insert(use[id].game, g) end
    end
    for k, list in pairs(K.MM_PAD) do
        local id = byKey[k]
        if id then for _, t in ipairs(list) do table.insert(use[id].mm, "Mod Menu: " .. t) end end
    end
    if quickPadEdit() then
        for k, list in pairs(K.QP_PAD) do
            local id = byKey[k]
            if id then for _, t in ipairs(list) do table.insert(use[id].mm, t) end end
        end
    end
    for _, mk in ipairs(K.modKeys()) do
        local id = K.padName(mk.unreal) and byKey[mk.unreal]
        if id then
            local u = use[id]
            u.mods[#u.mods + 1] = mk
            if #gameHits(mk) > 0 or #u.mods > 1 then u.clash = true end
        end
    end
    return use
end

-- Kind, tag and full owner text of one cap (keyboard or controller).
local function gameList(rows, cap)
    local names, seen, more = {}, {}, 0
    for _, g in ipairs(rows) do
        local t = g.label .. " (" .. g.context .. (g.locked and ", locked" or "") .. ")"
        if not seen[t] then
            seen[t] = true
            if #names < cap then names[#names + 1] = t else more = more + 1 end
        end
    end
    return names, more
end
local function capInfo(u, tags, title)
    local kind, tag = "free", ""
    local world, locked = 0, 0
    for _, g in ipairs(u and u.game or {}) do
        if g.context == "world" then world = world + 1; if g.locked then locked = locked + 1 end end
    end
    if u and #u.mods > 0 then
        kind = u.clash and "clash" or "mod"
        tag = tags[tostring(u.mods[1].m.name or u.mods[1].m.id)] or ""
    elseif u and u.mm and #u.mm > 0 then
        kind = "mod"
        tag = tags["Mod Menu"] or "MoMe"
    elseif world > 0 then
        kind = "game"                                    -- C47: no "game" tag, the light-gray fill says it
    end
    local lockedAll = kind == "game" and world > 0 and locked == world
    local parts = {}
    for _, mk in ipairs(u and u.mods or {}) do
        parts[#parts + 1] = tostring(mk.m.name or mk.m.id) .. ": " .. K.rowLabel(mk.m, mk.s)
            .. (mk.context ~= "anywhere" and (" (" .. tostring(mk.context) .. ")") or "")
    end
    for _, t in ipairs(u and u.mm or {}) do parts[#parts + 1] = t end
    local g, more = gameList(u and u.game or {}, 6)
    if #g > 0 then parts[#parts + 1] = "game: " .. table.concat(g, ", ") .. (more > 0 and (" and " .. more .. " more") or "") end
    local hint = title .. ": " .. (#parts > 0 and table.concat(parts, "; ") or "free")
    return kind, tag, hint, #parts > 0, lockedAll
end
K.capInfo = capInfo

-- C46: the picture comes first. Which one is shown: "keyboard" (default) or "controller"; the toggle's two buttons
-- are rows { w = button, view = "keyboard" | "controller" } and core calls K.setView(view) on a click, then fills
-- the Keys page again.
K.view = "keyboard"
function K.setView(v)
    if v == "keyboard" or v == "controller" then K.view = v; return true end
    return false
end

-- C46 (c): what a key row is, in words: its own label, with the section header in front when the label says nothing
-- on its own ("Key", "Hotkey") or repeats inside the mod (Spell Hotkeys: Slot 1..8 > "Key" -> "Slot 1 key").
local GENERIC = { key = true, hotkey = true, keybind = true, ["key bind"] = true, bind = true, button = true }
function K.rowLabel(m, s)
    local label = tostring(s.label or s.key or "")
    local header, count = nil, {}
    for _, o in ipairs(m.settings or {}) do
        if o.type ~= "header" and o.label then count[tostring(o.label):lower()] = (count[tostring(o.label):lower()] or 0) + 1 end
    end
    for _, o in ipairs(m.settings or {}) do
        if o == s then break end
        if o.type == "header" then header = o.label end
    end
    if header and (GENERIC[label:lower()] or (count[label:lower()] or 0) > 1) then
        return tostring(header) .. " " .. label:lower()
    end
    return label
end

-- C46 (b): one short line per clash: "G: also Spell Hotkeys; game: Generic selector right +2".
local function shortKey(mk) return K.padName(mk.unreal) and K.keyText(mk.unreal) or K.keyText(mk.unreal) end
local function ctxOverlap(c1, c2) return c1 == "anywhere" or c2 == "anywhere" or c1 == c2 end
function K.shortClash(m, s)
    local mine = nil
    local all = K.modKeys()
    for _, mk in ipairs(all) do if mk.m == m and mk.s == s then mine = mk end end
    if not mine then return nil end
    local others, seen = {}, {}
    for _, mk in ipairs(all) do
        if mk ~= mine and mk.unreal == mine.unreal and ctxOverlap(mine.context, mk.context) then
            local n = mk.m == m and K.rowLabel(mk.m, mk.s) or tostring(mk.m.name or mk.m.id)
            if not seen[n] then seen[n] = true; others[#others + 1] = n end
        end
    end
    local reserved = MM.keyTools and MM.keyTools.RESERVED_KEYS and MM.keyTools.RESERVED_KEYS[tostring(mine.value):upper()]
    local hits = gameHits(mine)
    if #others == 0 and #hits == 0 and not reserved then return nil end
    local parts = {}
    if reserved then parts[#parts + 1] = reserved:gsub("^%S+%s*", "", 1) end           -- "opens the UE4SS console"
    if #others > 0 then
        parts[#parts + 1] = "also " .. others[1] .. (#others > 1 and (" +" .. (#others - 1)) or "")
    end
    if #hits > 0 then
        local labels, seenL = {}, {}
        for _, g in ipairs(hits) do if not seenL[g.label] then seenL[g.label] = true; labels[#labels + 1] = g.label end end
        parts[#parts + 1] = "game: " .. labels[1] .. (#labels > 1 and (" +" .. (#labels - 1)) or "")
    end
    return shortKey(mine) .. ": " .. table.concat(parts, "; ")
end

function K.buildPage(ui, scroll)
    pcall(K.warm)
    local rows, hints = {}, {}
    if not (ui and ui.newText and scroll) then return { rows = rows, hints = hints } end
    local valid_ = MM.valid or function(o) return o ~= nil end
    local T = tonumber(ui.T) or 1
    local C = ui.COLORS or {}
    local GRAY = C.GRAY or C.GREY
    local function fs(n) return math.floor(n * T + 0.5) end
    local tree = ui.tree
    if not valid_(tree) then tree = nil end
    local RW = tonumber(ui.RW) or 980
    -- the page list's visible height (core's MM.ui.PH when it gives it): the toggle, the picture and its legend fit it
    local PH = tonumber(ui.PH) or 470                -- C52: ~470 measured in game
    local function add(w) if w then pcall(function() scroll:AddChild(w) end) end end
    -- kind: "title" for captions, "medium" for headings and cap keys, "body" for the rest (core's C28 fonts)
    local function text(s, size, color, fixed, kind)
        return ui.newText(tree, nil, s, fixed and size or fs(size), color, kind or "body")
    end
    -- a text that wraps at `width` (C28: AutoWrapText alone did not wrap in game; WrapTextAt does)
    local function wrapped(s, size, color, width, kind)
        local t = text(s, size, color, false, kind)
        pcall(function() t:SetAutoWrapText(true) end)
        pcall(function() t.WrapTextAt = width end)
        pcall(function() t:SetWrapTextAt(width) end)
        return t
    end
    local function line(s, size, color, kind) add(wrapped(s, size, color, RW, kind)) end
    -- an empty strip of h px (C52: 8 px under the toggle and under the picture)
    local function gap(h)
        if not tree then return end
        local g = ui.construct("SizeBox", tree)
        pcall(function() g:SetHeightOverride(h) end)
        pcall(function() g:SetWidthOverride(RW) end)
        add(g)
    end
    local view = K.view == "controller" and "controller" or "keyboard"

    -- the tags of every mod on either picture (one table, so a mod has the same tag on both)
    local use, puse = K.usage(), K.padUsage()
    local names = { "Mod Menu" }
    for _, u in pairs(use) do for _, mk in ipairs(u.mods) do names[#names + 1] = tostring(mk.m.name or mk.m.id) end end
    for _, u in pairs(puse) do for _, mk in ipairs(u.mods) do names[#names + 1] = tostring(mk.m.name or mk.m.id) end end
    local TAGS = K.mapTags(names)

    -- (1) the toggle (C49): a segmented control, two equal boxes side by side; the shown side gold-filled with dark
    -- text, the other outlined in gold. Each box carries the real game button on top at opacity 0, so core's click
    -- hook and pad A still reach it (rows { w = button, view }).
    local segW, segH = math.min(260, math.floor((RW - 8) / 2)), 52   -- 52: a game button is up to 49 tall
    do
        local segs = {}
        for _, v in ipairs({ "keyboard", "controller" }) do
            local name = v == "keyboard" and "KEYBOARD" or "CONTROLLER"
            local shown = v == view
            local btn = ui.makeGameButton and ui.makeGameButton(ui.pc, name) or nil
            if not valid_(btn) then btn = nil end
            if tree then
                local ov = ui.construct("Overlay", tree)
                local box = ui.construct("Border", tree)
                pcall(function() box:SetBrushColor(shown and EDGE_GOLD or CELL_BG.free) end)
                local face = box
                if not shown then                                    -- outlined: a 1 px gold edge around it
                    face = ui.construct("Border", tree)
                    pcall(function() face:SetBrushColor(EDGE_GOLD) end)
                    pcall(function() face:SetPadding({ Left = 1, Top = 1, Right = 1, Bottom = 1 }) end)
                    pcall(function() face:SetContent(box) end)
                end
                local vb = ui.construct("VerticalBox", tree)
                local t = text(name, 13, shown and INK_DARK or C.GOLD, false, "medium")
                pcall(function() t:SetAutoWrapText(false) end)
                pcall(function() t:SetJustification(1) end)
                local tsl = vb:AddChildToVerticalBox(t)
                pcall(function() tsl:SetHorizontalAlignment(2) end)
                pcall(function() tsl:SetPadding({ Left = 0, Top = 13, Right = 0, Bottom = 0 }) end)
                pcall(function() box:SetContent(vb) end)
                local s1 = ov:AddChildToOverlay(face)
                pcall(function() s1:SetHorizontalAlignment(0) end)   -- Fill
                pcall(function() s1:SetVerticalAlignment(0) end)
                if btn then
                    pcall(function() btn:SetRenderOpacity(0) end)    -- invisible, still hit-testable
                    local s2 = ov:AddChildToOverlay(btn)
                    pcall(function() s2:SetHorizontalAlignment(0) end)
                    pcall(function() s2:SetVerticalAlignment(0) end)
                end
                segs[#segs + 1] = ui.sized(tree, ov, segW, segH)
            elseif btn then
                segs[#segs + 1] = btn
            end
            if btn then rows[#rows + 1] = { w = btn, view = v } end
        end
        if tree then
            local hb = ui.construct("HorizontalBox", tree)
            for i, sg in ipairs(segs) do
                local sl = hb:AddChildToHorizontalBox(sg)
                if i > 1 then pcall(function() sl:SetPadding({ Left = 8, Top = 0, Right = 0, Bottom = 0 }) end) end
            end
            add(hb)
            gap(8)
        else
            for _, sg in ipairs(segs) do add(sg) end
        end
    end

    -- a color legend: swatch + words in a grid of equal columns (C34 lint: entries built alike line up)
    local function legend(items)
        if not tree then
            local parts = {}
            for _, it in ipairs(items) do parts[#parts + 1] = it[2] end
            line(table.concat(parts, ",  "), 13, GRAY)
            return
        end
        local metric = K.metric("body")
        local longest = 0
        for _, it in ipairs(items) do longest = math.max(longest, math.ceil(#it[2] * fs(13) * metric.em)) end
        local perRow = math.max(1, math.min(#items, math.floor(RW / (14 + 8 + longest + 16))))
        local colW = math.floor(RW / perRow)
        local tw = colW - 14 - 8 - 16
        local hb = nil
        for n, it in ipairs(items) do
            if (n - 1) % perRow == 0 then
                if hb then add(hb) end
                hb = ui.construct("HorizontalBox", tree)
            end
            local sw = ui.construct("Border", tree)
            pcall(function() sw:SetBrushColor(it[1]) end)
            if it[3] then                                          -- an edge color: the swatch inside a 2 px edge
                local edge = ui.construct("Border", tree)
                pcall(function() edge:SetBrushColor(it[3]) end)
                local e = it[3] == EDGE_GOLD and 2 or 1
                pcall(function() edge:SetPadding({ Left = e, Top = e, Right = e, Bottom = e }) end)
                pcall(function() edge:SetContent(sw) end)
                sw = edge
            end
            local s1 = hb:AddChildToHorizontalBox(ui.sized(tree, sw, 14, 14))
            pcall(function() s1:SetVerticalAlignment(1) end)
            pcall(function() s1:SetPadding({ Left = 0, Top = 4, Right = 8, Bottom = 0 }) end)
            local lt = wrapped(it[2], 13, GRAY, tw)
            local s2 = hb:AddChildToHorizontalBox(ui.sized(tree, lt, tw, nil))
            pcall(function() s2:SetPadding({ Left = 0, Top = 0, Right = 16, Bottom = 0 }) end)
        end
        if hb then add(hb) end
    end
    -- C47: one short row (fits one line at T 1.0 and 1.4): the fills and the gold edge of a locked game key
    local LEGEND = { { CELL_BG.mod, "Mod key" }, { CELL_BG.clash, "Clash" }, { CELL_BG.game, "Game key" },
                     { CELL_BG.free, "Free", OUTLINE }, { CELL_BG.game, "Locked", EDGE_GOLD } }   -- free: a 1 px edge (C49: it was the card's color)   -- locked: gray with a gold edge

    -- a shape of w x h px with a fill and an optional 1 px outline, as one widget to place; returns that widget and
    -- the Border that takes the content. Rounded (probed once, K.ROUND) or a plain box with an outer outline Border.
    local function shape(w, h, fill, outline, kind, radiusPx)
        local half = kind == "circle" or kind == "pill"
        local border = ui.construct("Border", tree)
        if K.ROUND == nil then
            K.ROUND = setRound(border, fill, outline, radiusPx or 0, half)
            if MM.log then pcall(MM.log, "keys: rounded brushes " .. (K.ROUND and "on (RoundedBox)" or "not available, stepped boxes")) end
        end
        if K.ROUND then
            setRound(border, fill, outline, radiusPx or 0, half)
            pcall(function() border:SetBrushColor(fill) end)
            pcall(function() border:SetPadding(K.CAP_PAD) end)
            return ui.sized(tree, border, w, h), border
        end
        pcall(function() border:SetBrushColor(fill) end)
        pcall(function() border:SetPadding(K.CAP_PAD) end)
        if not outline then return ui.sized(tree, border, w, h), border end
        local edge = ui.construct("Border", tree)
        pcall(function() edge:SetBrushColor(outline) end)
        pcall(function() edge:SetPadding({ Left = 1, Top = 1, Right = 1, Bottom = 1 }) end)
        pcall(function() edge:SetContent(border) end)
        return ui.sized(tree, edge, w, h), border
    end

    -- the text of a cap: its key on top, the owner's tag below, centered
    local function capTexts(vb, label, lS, tag, tS, kind)
        local function one(s, size, color, fkind)
            local t = text(s, size, color, true, fkind)
            pcall(function() t:SetAutoWrapText(false) end)
            pcall(function() t:SetJustification(1) end)          -- ETextJustify::Center
            local sl = vb:AddChildToVerticalBox(t)
            pcall(function() sl:SetHorizontalAlignment(2) end)   -- EHorizontalAlignment::Center
        end
        one(label, lS, kind == "free" and GRAY or C.CREAM, "medium")
        if tag ~= "" then one(tag, tS, kind == "clash" and C.CREAM or GRAY, "body") end
    end

    -- one picture on a CanvasPanel inside a SizeBox of its size
    local capsDrawn = {}
    local function picture(caps, wUnits, hUnits, opts)
        opts = opts or {}
        local availH = K.pictureRoom(PH, T)                              -- C52: toggle + gaps + legend fit MM.ui.PH
        local U, UH = K.unitFor(wUnits, RW, hUnits, availH)
        if opts.square then U = math.min(U, UH); UH = U end
        local W, H = math.ceil(wUnits * U), math.ceil(hUnits * UH)
        local canvas = ui.construct("CanvasPanel", tree)
        local metric = K.capMetric()
        local function place(widget, x, y, w, h)
            local okS, slot = pcall(function() return canvas:AddChildToCanvas(widget) end)
            if okS and slot then
                pcall(function() slot:SetPosition({ X = x, Y = y }) end)
                pcall(function() slot:SetSize({ X = w, Y = h }) end)
            end
        end
        local function px(r) return math.floor(r.x * U + 0.5), math.floor(r.y * UH + 0.5), math.floor(r.w * U + 0.5), math.floor(r.h * UH + 0.5) end
        -- the silhouette: every shape 1 px larger in gold first, then every shape in the body color (one clean edge)
        if opts.shapes then
            for pass = 1, 2 do
                for _, s in ipairs(opts.shapes) do
                    local x, y, w, h = px(s)
                    local grow = pass == 1 and 1 or 0
                    local fill = pass == 1 and EDGE_GOLD or BODY_BG
                    local rr = math.floor(s.r * U + 0.5) + grow
                    if K.ROUND ~= false then
                        local box = shape(w + 2 * grow, h + 2 * grow, fill, nil, "box", rr)
                        if K.ROUND then place(box, x - grow, y - grow, w + 2 * grow, h + 2 * grow) end
                    end
                    if K.ROUND == false then                               -- stepped: two crossing rects
                        local st = math.floor(math.min(s.r * U, w / 4, h / 4) + 0.5)
                        place(shape(w - 2 * st + 2 * grow, h + 2 * grow, fill, nil, "box"), x + st - grow, y - grow, w - 2 * st + 2 * grow, h + 2 * grow)
                        place(shape(w + 2 * grow, h - 2 * st + 2 * grow, fill, nil, "box"), x - grow, y + st - grow, w + 2 * grow, h - 2 * st + 2 * grow)
                    end
                end
            end
            if opts.mid then
                local x, y, w, h = K.capRect(opts.mid, U, UH)
                place((shape(w, h, HUB, OUTLINE, "box", 3)), x, y, w, h)          -- C49: a hub, not a hole
            end
        end
        for _, c in ipairs(caps) do
            if not c.inside then
                local x, y, w, h = K.capRect(c, U, UH)
                local outline = c.locked and EDGE_GOLD or (opts.outlineAll and OUTLINE) or nil
                local box, border = shape(w, h, CELL_BG[c.kind] or CELL_BG.free, outline, c.shape or "box",
                    (c.shape == "box" or not c.shape) and 4 or math.floor(h / 2))
                local vb = ui.construct("VerticalBox", tree)
                local inner = c.click and caps[c.click] or nil
                local pillH = inner and math.floor(0.75 * UH) or 0
                local lS, tS = K.capFonts(w, h - pillH, c.label, c.tag, metric)
                capTexts(vb, c.label, lS, c.tag, tS, c.kind)
                if inner then                                       -- the stick's click, a pill inside the circle
                    local pw = math.floor(w * 0.62)
                    local text1 = inner.label .. (inner.tag ~= "" and (" " .. inner.tag) or "")
                    local pS = math.min(K.TAG_PT, math.floor((pw - 8) / (#text1 * metric.em)))
                    local pbox, pborder = shape(pw, pillH, CELL_BG[inner.kind] or CELL_BG.free, OUTLINE, "pill", math.floor(pillH / 2))
                    local pvb = ui.construct("VerticalBox", tree)
                    local t = text(text1, pS, inner.kind == "free" and GRAY or C.CREAM, true, "body")
                    pcall(function() t:SetAutoWrapText(false) end)
                    pcall(function() t:SetJustification(1) end)
                    local sl = pvb:AddChildToVerticalBox(t)
                    pcall(function() sl:SetHorizontalAlignment(2) end)
                    pcall(function() pborder:SetContent(pvb) end)
                    local ps = vb:AddChildToVerticalBox(pbox)
                    pcall(function() ps:SetHorizontalAlignment(2) end)
                    capsDrawn[#capsDrawn + 1] = { key = inner.key, id = inner.id, label = inner.label, tag = inner.tag,
                        kind = inner.kind, inside = c.id, w = pw, h = pillH, lSize = pS, tSize = pS, picture = inner.picture, text = text1 }
                    if inner.hint then hints[#hints + 1] = { w = pbox, text = inner.hint } end
                end
                pcall(function() border:SetContent(vb) end)
                place(box, x, y, w, h)
                capsDrawn[#capsDrawn + 1] = { key = c.key, id = c.id, label = c.label, tag = c.tag, kind = c.kind,
                    locked = c.locked, shape = c.shape, x = x, y = y, w = w, h = h, pillH = pillH,
                    lSize = lS, tSize = tS, picture = c.picture }
                if c.hint then hints[#hints + 1] = { w = box, text = c.hint } end
            end
        end
        add(ui.sized(tree, canvas, W, H))
        return U, UH, W, H
    end

    -- the caps of both pictures (hints and owner lines for both; drawn: the one shown)
    local kcaps, shownTags, inUse = {}, {}, {}
    for _, b in ipairs(BOARD) do
        local u = b.key and use[b.key] or nil
        local title = K.keyText(b.key or "") ~= "" and K.keyText(b.key) or (K.KEY_NAMES[b.label] or b.label)
        local kind, tag, hint, used, locked = capInfo(u, TAGS, title)
        if not b.key then kind, tag, locked, hint = "free", "", false, title .. ": no key name Unreal has, so nothing can use it" end
        if u and #u.mods > 0 then shownTags[tag] = tostring(u.mods[1].m.name or u.mods[1].m.id) end
        if used and u and #u.mods > 0 then inUse[#inUse + 1] = hint end
        kcaps[#kcaps + 1] = { key = b.key, label = b.label, tag = tag, kind = kind, hint = hint, picture = "keyboard",
                              locked = locked, x = b.x, y = b.y, w = b.w, h = b.h, shape = "box" }
    end
    local pcaps, pTags, pLines = {}, {}, {}
    for _, b in ipairs(PADB) do
        local u = puse[b.id]
        local kind, tag, hint, used, locked = capInfo(u, TAGS, K.PAD_NAMES[b.id] or b.label)
        if #u.mods > 0 then pTags[tag] = tostring(u.mods[1].m.name or u.mods[1].m.id)
        elseif #u.mm > 0 then pTags[tag] = "Mod Menu" end
        pLines[#pLines + 1] = hint
        local c = { key = b.keys[1], id = b.id, label = b.label, tag = tag, kind = kind, hint = hint, picture = "controller",
                    locked = locked, x = b.x, y = b.y, w = b.w, h = b.h, shape = b.shape, inside = b.inside, click = b.click }
        pcaps[#pcaps + 1] = c
        pcaps[b.id] = c
    end

    -- (2) the picture, right under the toggle, then (3) its color legend and tag legend
    local kU, kUH, kW, kH, pU, pUH, pW, pH = nil, nil, nil, nil, nil, nil, nil, nil
    local tagMap = view == "keyboard" and shownTags or pTags
    if not tree then
        line("The keyboard and controller pictures need Mod Menu 2.0's panel; every key in use is listed below.", 13, GRAY)
    elseif view == "keyboard" then
        kU, kUH, kW, kH = picture(kcaps, K.BOARD_W, K.BOARD_H, {})
    else
        pU, pUH, pW, pH = picture(pcaps, K.PAD_W, K.PAD_H, { square = true, shapes = K.PAD_SHAPES, mid = K.PAD_DPAD_MID,
                                                            outlineAll = true })
    end
    gap(8)
    legend(LEGEND)
    local tl = {}
    for tag, owner in pairs(tagMap) do tl[#tl + 1] = tag .. " = " .. owner end
    table.sort(tl, function(a, b) return a:lower() < b:lower() end)
    if #tl > 0 then                                                  -- C49: one text per line, never one tall block
        local em = K.metric("body").em
        local cur = "Tags: "
        for n, item in ipairs(tl) do
            local nextS = cur .. item .. (n < #tl and ",  " or "")
            if #nextS * fs(13) * em > RW and cur ~= "Tags: " and cur ~= "" then
                line(cur, 13, GRAY); cur = item .. (n < #tl and ",  " or "")
            else
                cur = nextS
            end
        end
        if cur ~= "" then line(cur, 13, GRAY) end
    end
    if view == "controller" and not quickPadEdit() then
        line("Quick Panel pad edit is off, so View and the face buttons do nothing extra while you play (Mod Menu's own settings).", 13, GRAY)
    end

    -- (4) the clash summary: one short line per key that does two things
    local list = {}
    for _, m in ipairs(MM.mods() or {}) do
        if not m.off then
            for _, s in ipairs(m.settings or {}) do
                if s.key and not s.locked and MM.keyTools and MM.keyTools.isKeySetting(s) then list[#list + 1] = { m = m, s = s } end
            end
        end
    end
    table.sort(list, function(a, b)
        local na, nb = tostring(a.m.name or a.m.id):lower(), tostring(b.m.name or b.m.id):lower()
        if na ~= nb then return na < nb end
        return K.rowLabel(a.m, a.s):lower() < K.rowLabel(b.m, b.s):lower()
    end)
    local summary, seenKey = {}, {}
    for _, e in ipairs(list) do
        local c = K.shortClash(e.m, e.s)
        if c then
            local mk = nil
            for _, x in ipairs(K.modKeys()) do if x.m == e.m and x.s == e.s then mk = x end end
            local owner = tostring(e.m.name or e.m.id)
            local k = mk and mk.unreal or c
            if not seenKey[k] then seenKey[k] = true; summary[#summary + 1] = owner .. " " .. c end
        end
    end
    if #summary > 0 then
        add(text("CLASHES", 18, C.RED, false, "title"))
        for _, s in ipairs(summary) do line(s, 14, C.RED) end
    end

    -- (5) the list: every key row of every switched-on mod (a button that opens its page at the row), its key, its
    -- context only when it is not "anywhere" (C46 d), and one short red line when it clashes
    add(text("MOD KEYS", 18, C.GOLD, false, "title"))
    if #list == 0 then line("No mod sets a key.", 16, GRAY) end
    local btnW = math.min(600, RW - 300)
    -- a game button's label is the game's font, ~17 px a character plus 26 (C28 step 7, measured), whatever T is
    local maxChars = math.max(10, math.floor((btnW - 26) / 17))
    local keyW = RW - btnW - 16
    for _, e in ipairs(list) do
        pcall(function()
            local m, s = e.m, e.s
            local v = m.values and m.values[s.key]
            if type(v) == "string" and v:lower() == "default" then v = s.default end
            local shownKey = (type(v) ~= "string" or v == "" or v:upper() == "NONE") and "Not set"
                or (v:find("+", 1, true) and v:upper()) or (K.padName(v) and K.keyText(K.padName(v)))
                or K.keyText(MM.keyTools.toUnrealKey(v))
            local label = tostring(m.name or m.id) .. ": " .. K.rowLabel(m, s)
            if #label > maxChars then label = label:sub(1, maxChars - 1) .. "." end
            local btn = ui.makeGameButton and ui.makeGameButton(ui.pc, label) or nil
            if not valid_(btn) then btn = nil end
            local ctx = tostring(s.context or "anywhere")
            local keyLine = shownKey .. (ctx ~= "anywhere" and ("   " .. ctx) or "")
            local clashText = K.shortClash(m, s)
            if tree then
                local hb = ui.construct("HorizontalBox", tree)
                hb:AddChildToHorizontalBox(ui.sized(tree, btn or wrapped(label, 16, C.CREAM, btnW), btnW, 52))
                local kt = wrapped(keyLine, 16, clashText and C.RED or C.GOLD, keyW)
                local sl = hb:AddChildToHorizontalBox(ui.sized(tree, kt, keyW, nil))
                pcall(function() sl:SetPadding({ Left = 16, Top = 10, Right = 0, Bottom = 0 }) end)
                add(hb)
            else
                add(btn or wrapped(label, 16, C.CREAM, RW))
                line(keyLine, 16, clashText and C.RED or C.GOLD)
            end
            if clashText then line(clashText, 14, C.RED) end
            if btn then rows[#rows + 1] = { w = btn, id = m.id, key = s.key } end
        end)
    end

    -- (6) the game's keyboard keys, per place, two columns of plain lines
    add(text("GAME KEYS", 18, C.GOLD, false, "title"))
    line(SOURCE == "live" and string.format("Read from the game (%d), with Key Unlocker's and your own Controls changes.", #K.gameKeys())
        or ("From Mod Menu's built-in list (the game's defaults): " .. tostring(LIVE.why) .. "."), 13, GRAY)
    line("\"locked\" = Settings > Controls cannot change it (Key Unlocker can for the wheel, target lock, repair, chat and chest keys).", 13, GRAY)
    local colW = math.floor(RW / 2) - 10
    for _, place in ipairs({ "world", "build", "chest", "menus" }) do
        local lines = {}
        for _, g in ipairs(K.gameKeys()) do
            if g.context == place then
                lines[#lines + 1] = g.label .. ": " .. K.keyText(g.key) .. (g.locked and "  (locked)" or "")
                    .. (g.remapped and "  (your key)" or "")
            end
        end
        if #lines > 0 then
            add(text(PLACE_TITLE[place], 16, C.CREAM, false, "medium"))
            local half = math.ceil(#lines / 2)
            local a = table.concat(lines, "\n", 1, half)
            local b = half < #lines and table.concat(lines, "\n", half + 1, #lines) or ""
            if tree then
                local hb = ui.construct("HorizontalBox", tree)
                hb:AddChildToHorizontalBox(ui.sized(tree, wrapped(a, 14, GRAY, colW), colW, nil))
                local s2 = hb:AddChildToHorizontalBox(ui.sized(tree, wrapped(b, 14, GRAY, colW), colW, nil))
                pcall(function() s2:SetPadding({ Left = 20, Top = 0, Right = 0, Bottom = 0 }) end)
                add(hb)
            else
                line(a .. (b ~= "" and ("\n" .. b) or ""), 14, GRAY)
            end
        end
    end

    -- (7) the owners in words (the pad route: caps cannot take pad focus)
    if #inUse > 0 then
        add(text("Keys mods use", 16, C.CREAM, false, "medium"))
        for _, h in ipairs(inUse) do line(h, 13, GRAY) end
    end
    add(text("What each controller button does", 16, C.CREAM, false, "medium"))
    for _, h in ipairs(pLines) do line(h, 13, GRAY) end

    K.lastCaps, K.lastBoard = capsDrawn, { kU = kU, kUH = kUH, kW = kW, kH = kH, pU = pU, pUH = pUH, pW = pW, pH = pH }
    K.lastCells = 0
    for _, c in ipairs(capsDrawn) do if c.picture == "keyboard" then K.lastCells = K.lastCells + 1 end end
    K.lastLegend, K.lastView = tl, view
    return { rows = rows, hints = hints }
end

return K
