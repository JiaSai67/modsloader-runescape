-- Ledger Range - settings
-- Changes take effect after restarting the game.

return {
    -- Range (in meters) of the Storage Ledger. The game's default is 30.
    -- This is the game's shared "linked storage" range, so linked chests count for
    -- crafting benches from this far too.
    RangeMeters = 100,

    -- Extra lines in the UE4SS log to check what the ledger does.
    Debug = false,
}
