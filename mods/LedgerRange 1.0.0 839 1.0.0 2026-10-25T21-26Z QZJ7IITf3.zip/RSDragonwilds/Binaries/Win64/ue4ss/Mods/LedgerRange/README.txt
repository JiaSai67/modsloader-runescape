Storage Ledger Range                                                              v1.0.0
RuneScape: Dragonwilds mod (UE4SS)
=====================================================================================

Raises the range of the Storage Ledger from 30 m to 100 m (configurable), so it also
fills linked chests further away from it.

The game uses the same "linked storage" range for crafting benches (e.g. the cauldron),
so those also take materials from linked chests within the new range.


REQUIREMENTS
------------
  * UE4SS for RuneScape: Dragonwilds


INSTALLATION
------------
Vortex: install the archive like any other Dragonwilds mod.

Manual: extract the archive into the game folder, e.g.
  C:\Program Files (x86)\Steam\steamapps\common\RSDragonwilds\
so that this folder ends up in place:
  RSDragonwilds\Binaries\Win64\ue4ss\Mods\LedgerRange\

The mod is enabled by its enabled.txt; no need to edit mods.txt.


SETTINGS
--------
ue4ss\Mods\LedgerRange\Scripts\config.lua

  RangeMeters   range of the Storage Ledger in meters (game default: 30, mod default: 100)
  Debug         extra lines in the UE4SS log

Restart the game after changing it.


CONSOLE (F10, if a console enabler is installed)
-------
  lr_range             show the current range
  lr_range <meters>    change the range until the game restarts
  lr_chests            linked chests near the closest ledger, with distance and
                       whether they are in range


KNOWN LIMITATIONS
-----------------
  * Tested in single player. In multiplayer the host's range counts, so the host needs
    the mod (untested).
  * Made for game version ++dominion+hotfix-CL-254097 with UE4SS 3.0.1. Game updates may
    break it.


UNINSTALL
---------
Delete ue4ss\Mods\LedgerRange
