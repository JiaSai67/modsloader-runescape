-- Ledger Range
-- RuneScape: Dragonwilds, UE4SS Lua mod
--
-- Raises the range of the Storage Ledger by changing the game's linked-storage radius
-- (InventorySettings.LinkedStorageRadius, 30 m by default).
--
-- Console (F10):
--   lr_range           -> show the current range
--   lr_range <meters>  -> change it until the game restarts
--   lr_chests          -> linked chests near the closest ledger, with distance
--
-- Settings: Scripts/config.lua. Output goes to the UE4SS log, prefixed [LedgerRange].

local MOD_VERSION = "1.0.0"

local UEHelpers = require("UEHelpers")

local function LoadConfig()
    local defaults = { RangeMeters = 100, Debug = false }
    local ok, cfg = pcall(function()
        local dir = debug.getinfo(1, "S").source:match("^@?(.*[\\/])")
        return dofile(dir .. "config.lua")
    end)
    if not ok then ok, cfg = pcall(require, "config") end
    if not ok or type(cfg) ~= "table" then
        print("[LedgerRange] config.lua not loaded, using defaults: " .. tostring(cfg) .. "\n")
        return defaults
    end
    cfg.RangeMeters = tonumber(cfg.RangeMeters) or defaults.RangeMeters
    cfg.Debug = cfg.Debug == true
    return cfg
end
local CONFIG = LoadConfig()

local SETTINGS_PATH = "/Script/Dominion.Default__InventorySettings"
local LEDGER_INTERACTION =
    "/Game/Gameplay/World/Misc/BP_InventoryDropOffPointInteractionComponent.BP_InventoryDropOffPointInteractionComponent_C:K2_OnInteraction"

local rangeUnits = CONFIG.RangeMeters * 100.0
local originalUnits = nil

local function Log(fmt, ...)
    print("[LedgerRange] " .. string.format(fmt, ...) .. "\n")
end

local function Debug(fmt, ...)
    if CONFIG.Debug then Log(fmt, ...) end
end

local function Valid(obj)
    return obj ~= nil and obj.IsValid ~= nil and obj:IsValid()
end

-- Same reasoning as Station Recipe Book: only ever call back on the game thread.
local function Later(ms, fn)
    ExecuteInGameThreadWithDelay(ms, function()
        local ok, err = pcall(fn)
        if not ok then Log("error: %s", tostring(err)) end
    end)
end

local function ResetCache()
    local pc = UEHelpers.GetPlayerController()
    local lib = StaticFindObject("/Script/Dominion.Default__CraftingFunctionLibrary")
    if Valid(pc) and Valid(lib) then
        pcall(function() lib:ResetLinkedInventoryCache(pc) end)
    end
end

-- Returns true once the settings object exists and holds our range.
local function Apply()
    local settings = StaticFindObject(SETTINGS_PATH)
    if not Valid(settings) then return false end
    local current = settings.LinkedStorageRadius
    if originalUnits == nil then
        originalUnits = current
        Log("v%s: game range %.1f m", MOD_VERSION, current / 100.0)
    end
    if current ~= rangeUnits then
        settings.LinkedStorageRadius = rangeUnits
        Log("range set to %.1f m", rangeUnits / 100.0)
        ResetCache()
    end
    return true
end

local function ApplyWhenReady(triesLeft)
    if Apply() or triesLeft <= 0 then
        if triesLeft <= 0 then Log("InventorySettings not found, range unchanged") end
        return
    end
    Later(1000, function() ApplyWhenReady(triesLeft - 1) end)
end

ApplyWhenReady(60)

-- Re-apply after every map load (main menu -> world), in case the settings were reloaded.
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    Later(500, Apply)
end)

---------------------------------------------------------------------------
-- Debug: show which lookups the ledger runs (to confirm it uses this radius)
---------------------------------------------------------------------------

if CONFIG.Debug then
    local hookedLedger = false
    local function HookLedger()
        if hookedLedger then return end
        local ok = pcall(function()
            RegisterHook(LEDGER_INTERACTION, function()
                local settings = StaticFindObject(SETTINGS_PATH)
                Debug("ledger used (radius now %.1f m)",
                    Valid(settings) and settings.LinkedStorageRadius / 100.0 or -1)
            end)
        end)
        hookedLedger = ok
        if ok then Debug("hooked ledger interaction") end
    end
    -- The ledger blueprint only exists once a world with one is loaded.
    RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
        Later(2000, HookLedger)
    end)

    pcall(function()
        RegisterHook("/Script/Dominion.CraftingFunctionLibrary:GetLinkedInventories", function()
            -- Out-param arrays are freed in UE4SS 3.0.1; only log that it ran.
            Debug("GetLinkedInventories called")
        end)
    end)
end

local function Distance(a, b)
    local dx, dy, dz = a.X - b.X, a.Y - b.Y, a.Z - b.Z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

-- Linked chests with their distance to the ledger nearest to the player.
RegisterConsoleCommandHandler("lr_chests", function(_, _, ar)
    local function Out(fmt, ...)
        local msg = "[LedgerRange] " .. string.format(fmt, ...)
        ar:Log(msg)
        print(msg .. "\n")
    end
    local pawn = UEHelpers.GetPlayerController().Pawn
    if not Valid(pawn) then Out("no player") return true end
    local here = pawn:K2_GetActorLocation()

    local ledger, best = nil, math.huge
    for _, l in ipairs(FindAllOf("BP_InventoryDropoffPoint_C") or {}) do
        if Valid(l) then
            local d = Distance(l:K2_GetActorLocation(), here)
            if d < best then ledger, best = l, d end
        end
    end
    if not ledger then Out("no Storage Ledger found") return true end
    local from = ledger:K2_GetActorLocation()
    Out("nearest ledger is %.1f m from you", best / 100.0)

    local settings = StaticFindObject(SETTINGS_PATH)
    local radius = Valid(settings) and settings.LinkedStorageRadius or 0
    for _, link in ipairs(FindAllOf("LinkedInventoryComponent") or {}) do
        if Valid(link) and Valid(link:GetOwner()) then
            local d = Distance(link:GetOwner():K2_GetActorLocation(), from)
            if d < 20000 then
                Out("  %-40s %6.1f m  linked=%s  %s", link:GetOwner():GetFName():ToString(), d / 100.0,
                    tostring(link.bIsLinkable), d <= radius and "in range" or "OUT of range")
            end
        end
    end
    return true
end)

RegisterConsoleCommandHandler("lr_range", function(_, params, ar)
    local meters = tonumber(params[1] or "")
    if meters and meters > 0 then
        rangeUnits = meters * 100.0
        Apply()
    end
    local settings = StaticFindObject(SETTINGS_PATH)
    local msg = string.format("[LedgerRange] range %.1f m (game default %.1f m)",
        Valid(settings) and settings.LinkedStorageRadius / 100.0 or -1,
        (originalUnits or 0) / 100.0)
    ar:Log(msg)
    print(msg .. "\n")
    return true
end)
