-- ue4ss/Mods/FastTomes/Scripts/main.lua

----------------------------------------------------------------
-- REQUIRES
----------------------------------------------------------------

local fastTomesConfig = require("fastTomesConfig")

----------------------------------------------------------------
-- CONFIGURATION
----------------------------------------------------------------

local tomeClassPath = "/Game/Gameplay/Items/Consumables/BP_Consumables_SkillTome.BP_Consumables_SkillTome_C"
local itemUsageDelaySeconds = fastTomesConfig.itemUsageDelaySeconds
local loadRetryLimit = 12
local scanDelayMilliseconds = 250
local excludedObjectFlags = EObjectFlags.RF_ClassDefaultObject | EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_BeginDestroyed | EObjectFlags.RF_FinishDestroyed
local loadingObjectFlags = EObjectFlags.RF_NeedInitialization | EObjectFlags.RF_NeedLoad | EObjectFlags.RF_NeedPostLoad | EObjectFlags.RF_NeedPostLoadSubobjects

----------------------------------------------------------------
-- STATE
----------------------------------------------------------------

local scanScheduled = false
local remainingLoadRetries = 0
local patchedObjectCount = 0
local failureReported = false
local queueTomeScan

----------------------------------------------------------------
-- FUNCTIONS
----------------------------------------------------------------

-- Registra o resultado do mod no log central do UE4SS
local function logMessage(message)
    print("[FastTomes] " .. message .. "\n")
end

-- Altera somente a propriedade refletida de um exemplar de dados de tomo já carregado
local function applyTomeDelay(tomeData)
    if not tomeData:IsValid() or tomeData:HasAnyFlags(excludedObjectFlags) then
        return false, false
    end
    if tomeData:HasAnyFlags(loadingObjectFlags) then
        return false, true
    end
    if not tomeData:IsA(tomeClassPath) then
        return false, false
    end
    local previousDelay = tomeData.ItemUsageDelay
    if type(previousDelay) ~= "number" then
        error("ItemUsageDelay is not a reflected numeric property")
    end
    if math.abs(previousDelay - itemUsageDelaySeconds) < 0.00001 then
        return false, false
    end
    tomeData.ItemUsageDelay = itemUsageDelaySeconds
    if math.abs(tomeData.ItemUsageDelay - itemUsageDelaySeconds) >= 0.00001 then
        error("ItemUsageDelay did not retain the configured value")
    end
    if fastTomesConfig.verboseLogging then
        logMessage(string.format("%s: %.3f -> %.3f seconds", tomeData:GetFullName(), previousDelay, itemUsageDelaySeconds))
    end
    return true, false
end

-- Consulta somente os dados de tomos existentes e aguarda carregamentos ainda incompletos
local function scanLoadedTomes()
    scanScheduled = false
    local changedObjectCount = 0
    local waitingForLoad = false
    local tomeObjects = FindAllOf("BP_Consumables_SkillTome_C") or {}
    for _, tomeData in ipairs(tomeObjects) do
        local updateSucceeded, wasChanged, isLoading = pcall(applyTomeDelay, tomeData)
        if updateSucceeded then
            if wasChanged then
                changedObjectCount = changedObjectCount + 1
            end
            waitingForLoad = waitingForLoad or isLoading
        elseif not failureReported then
            failureReported = true
            logMessage("Could not update a tome: " .. tostring(wasChanged))
        end
    end
    if changedObjectCount > 0 then
        patchedObjectCount = patchedObjectCount + changedObjectCount
        logMessage(string.format("Updated %d tome data assets; delay %.3f seconds; total %d", changedObjectCount, itemUsageDelaySeconds, patchedObjectCount))
    end
    if waitingForLoad and remainingLoadRetries > 0 then
        remainingLoadRetries = remainingLoadRetries - 1
        queueTomeScan()
    end
end

-- Agrupa notificações de carregamento sem manter referências atrasadas a UObjects
queueTomeScan = function()
    if scanScheduled then
        return
    end
    scanScheduled = true
    -- O temporizador apenas encaminha a consulta para a thread do jogo
    ExecuteWithDelay(scanDelayMilliseconds, function()
        ExecuteInGameThread(scanLoadedTomes)
    end)
end

-- Agenda a consulta pela thread do jogo sem acessar objetos em construção
local function handleConsumableConstructed()
    -- Todo estado compartilhado é alterado somente pela thread do jogo
    ExecuteInGameThread(function()
        remainingLoadRetries = loadRetryLimit
        queueTomeScan()
    end)
end

-- Instala um único observador e inclui os tomos carregados antes do mod
local function initializeMod()
    if type(itemUsageDelaySeconds) ~= "number" or itemUsageDelaySeconds ~= itemUsageDelaySeconds or itemUsageDelaySeconds < 0 or itemUsageDelaySeconds > 30 then
        logMessage("Invalid itemUsageDelaySeconds; expected a number from 0 to 30")
        return
    end
    local observerRegistered, registrationError = pcall(NotifyOnNewObject, "/Script/Dominion.ConsumableItemData", handleConsumableConstructed)
    if not observerRegistered then
        logMessage("Could not register the consumable observer: " .. tostring(registrationError))
        return
    end
    remainingLoadRetries = loadRetryLimit
    queueTomeScan()
    logMessage(string.format("Version 1.0.0 loaded; configured delay %.3f seconds", itemUsageDelaySeconds))
end

----------------------------------------------------------------
-- INITIALIZATION
----------------------------------------------------------------

ExecuteInGameThread(initializeMod)
