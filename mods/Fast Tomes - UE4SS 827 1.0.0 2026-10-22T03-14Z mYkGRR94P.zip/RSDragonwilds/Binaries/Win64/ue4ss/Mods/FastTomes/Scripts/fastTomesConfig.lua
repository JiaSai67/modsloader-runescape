-- ue4ss/Mods/FastTomes/Scripts/fastTomesConfig.lua

----------------------------------------------------------------
-- CONFIGURATION
----------------------------------------------------------------

return {
    itemUsageDelaySeconds = 0.0,
    verboseLogging = false,
}
