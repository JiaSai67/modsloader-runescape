-- Fast Eating & Sleeping - RuneScape: Dragonwilds
--
-- Eat and drink back to back, and sleep through the night in about half a second.
--
-- EATING / DRINKING. The wait between two bites is not an animation or a use delay (ItemUsageDelay
-- is already 0.01 s on every food, drink and potion). It is a 2.0 s cooldown effect the game applies
-- after each use: ConsumableItemData.ConsumeCooldownEffectToApply.Effect, an INSTANCED copy per item
-- (e.g. ITEM_Consumable_Farm_Steak:GE_Cooldown_Eat_C_0) with Data.Duration 2.0. Setting that
-- Duration to 0 removes the wait and the food still fills you up. The class defaults
-- (Default__GE_Cooldown_Eat_C) do NOT work: the per-item copies never read them again, so every item
-- is set one by one. New stacks picked up later use the same item data, so they are covered too.
--
-- SLEEPING. Default__PlayerSleepSettings holds SleepTransitionTime 5.0 and DelayBeforeAdvancingWorldTime
-- 2.5. The player's rest component points at that same object, so a live write takes effect on the
-- next sleep. At 0.5 / 0.5 you lie down and are up at dawn about 0.5 s later.
--
-- NAPPING (1.1.0). Resting in a bed in the daytime is a nap: endurance refills at +1.0 per second (60 per
-- in-game hour, 1 game hour = 60 real seconds). The rate is GE_RestingEnduranceRegen_C, the only entry of
-- the rest component's RestingGEs, Data.AmountToModify.Value -60. Writing the class default object
-- (RestingGEs[1]:GetCDO()) makes the NEXT rest read the new number: -300 measured +5.0/s, 50 to 100 in 9.5 s
-- (docs/probe-results-2026-10-20-todo.md Batch 4a). NapSpeed multiplies that number, live from Mod Menu;
-- 1 puts the game's own value back. The sleep settings above are not touched.
--
-- Verified in game 2026-09-29 on a test character (docs/journal.md, "PROBE: Fast Eating & Sleeping").
-- Nothing here runs per frame: one pass after each world load, and one late pass to catch anything
-- loaded afterwards.

local TAG = "[FastEatSleep] "
local VERSION = "1.1.0"
local MODMENU_ID = "FastEatSleep"
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

local cfg = {
    Enabled = true,      -- false leaves the game exactly as it shipped
    FastEating = true,   -- no 2 s wait between foods / between drinks
    Potions = true,      -- potions count as drinks here
    FastSleep = true,    -- sleep through the night in about half a second
    NapSpeed = 3,        -- nap (daytime rest) endurance refill speed, 1 = the game's own, up to 5
    Verbose = false,
}

local NAP_MIN, NAP_MAX = 1, 5
local VANILLA_NAP = -60.0   -- GE_RestingEnduranceRegen AmountToModify (per in-game hour), measured 2026-10-20

local SLEEP_TIME = 0.5   -- SleepTransitionTime (vanilla 5.0)
local SLEEP_DELAY = 0.5  -- DelayBeforeAdvancingWorldTime (vanilla 2.5)

local function valid(o)
    if not o then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v
end

local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    local dir = src:match("^(.*)[/\\][^/\\]*$")
    if not dir then return nil end
    return (dir:match("^(.*)[/\\][^/\\]*$"))
end

-- Config ------------------------------------------------------------------------------------------
local function loadConfig()
    local root = modRoot()
    if not root then return end
    local f = io.open(root .. "\\config.txt", "r")
    if not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if k and v and cfg[k] ~= nil then
            v = v:gsub("%s+[#;].*$", "")
            local l = v:lower()
            if type(cfg[k]) == "number" then
                local n = tonumber(v)
                if n then cfg[k] = n end
            elseif l == "true" or l == "false" then cfg[k] = (l == "true") end
        end
    end
    f:close()
end

local function clampNap()
    local n = tonumber(cfg.NapSpeed) or 1
    if n ~= n then n = 1 end                                -- NaN
    cfg.NapSpeed = math.max(NAP_MIN, math.min(NAP_MAX, n))
end

-- Mod Menu: NapSpeed is the one live setting here (the others read the game's items once per world load).
local mmRev = nil
local function shared(key)
    local ok, v = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. "." .. key) end)
    if ok then return v end
    return nil
end
local function modMenuSync()
    local rev = shared("rev")
    if type(rev) ~= "number" or rev == mmRev then return end
    mmRev = rev
    local v = shared("NapSpeed")
    if type(v) == "number" then cfg.NapSpeed = v; clampNap() end
end

-- Eating / drinking -------------------------------------------------------------------------------
local function fullName(o)
    local n = "?"
    pcall(function() n = o:GetFullName() end)
    return n
end

-- Returns changed, already, failed for one item class. FindAllOf costs 35-50 ms, so this only runs
-- in the two passes after a world load, never on a timer.
local function zeroCooldowns(className)
    local changed, already, failed = 0, 0, 0
    local ok, all = pcall(FindAllOf, className)
    if not ok or not all then return 0, 0, 0 end
    for _, item in ipairs(all) do
        if valid(item) and not fullName(item):find("Default__", 1, true) then
            local eff = nil
            pcall(function() eff = item.ConsumeCooldownEffectToApply.Effect end)
            if valid(eff) then
                local before = nil
                pcall(function() before = eff.Data.Duration end)
                if type(before) == "number" then
                    if before <= 0 then
                        already = already + 1
                    else
                        pcall(function() eff.Data.Duration = 0 end)
                        local after = nil
                        pcall(function() after = eff.Data.Duration end)
                        if after == 0 then
                            changed = changed + 1
                            if cfg.Verbose then log(fullName(eff) .. ": " .. before .. " s -> 0") end
                        else
                            failed = failed + 1
                            log("WRITE DID NOT STICK on " .. fullName(eff) .. " (still " .. tostring(after) .. ")")
                        end
                    end
                end
            end
        end
    end
    return changed, already, failed
end

local function applyEating()
    local classes = { "FoodItemData", "DrinkItemData" }
    if cfg.Potions then classes[#classes + 1] = "PotionItemData" end
    local c, a, f = 0, 0, 0
    for _, cls in ipairs(classes) do
        local c1, a1, f1 = zeroCooldowns(cls)
        c, a, f = c + c1, a + a1, f + f1
    end
    return c, a, f
end

-- Sleeping ----------------------------------------------------------------------------------------
local function applySleep()
    local s = nil
    pcall(function() s = StaticFindObject("/Script/Dominion.Default__PlayerSleepSettings") end)
    if not valid(s) then return false end
    local t, d = nil, nil
    pcall(function() t = s.SleepTransitionTime end)
    pcall(function() d = s.DelayBeforeAdvancingWorldTime end)
    if t == SLEEP_TIME and d == SLEEP_DELAY then return true end
    pcall(function() s.SleepTransitionTime = SLEEP_TIME end)
    pcall(function() s.DelayBeforeAdvancingWorldTime = SLEEP_DELAY end)
    local t2, d2 = nil, nil
    pcall(function() t2 = s.SleepTransitionTime end)
    pcall(function() d2 = s.DelayBeforeAdvancingWorldTime end)
    if t2 == SLEEP_TIME and d2 == SLEEP_DELAY then
        log(string.format("sleep: transition %s -> %s s, delay %s -> %s s", tostring(t), t2, tostring(d), d2))
        return true
    end
    log("sleep write did not stick (transition " .. tostring(t2) .. ", delay " .. tostring(d2) .. ")")
    return false
end

-- Napping -----------------------------------------------------------------------------------------
-- napOrig = the game's own AmountToModify, kept so 1x puts exactly that back. A value that is neither the
-- measured -60 nor one of our own multiples of it (-60 to -300) means the game changed: leave it alone.
local napOrig, napApplied, napWarned = nil, nil, false

local function napGE()
    local rc = nil
    pcall(function() rc = FindFirstOf("PlayerRestComponent") end)
    if not valid(rc) or fullName(rc):find("Default__", 1, true) then return nil end
    local cdo = nil
    pcall(function() cdo = rc.RestingGEs[1]:GetCDO() end)
    if not valid(cdo) then return nil end
    return cdo
end

-- Returns true when the number now matches NapSpeed (or there is nothing to do).
local function applyNap()
    clampNap()
    if napApplied == nil and cfg.NapSpeed == 1 then return true end   -- never touched, nothing to restore
    local cdo = napGE()
    if not cdo then return false end
    local cur = nil
    pcall(function() cur = cdo.Data.AmountToModify.Value end)
    if type(cur) ~= "number" then return false end
    if napOrig == nil then
        if cur <= VANILLA_NAP + 0.5 and cur >= VANILLA_NAP * NAP_MAX - 0.5 then
            napOrig = VANILLA_NAP   -- the game's number (a hot reload may find our own earlier write)
        else
            if not napWarned then napWarned = true; log("nap rate is " .. tostring(cur) .. ", not the expected -60 (a game update?); leaving it alone") end
            napApplied = cfg.NapSpeed
            return true
        end
    end
    local want = napOrig * cfg.NapSpeed
    if math.abs(cur - want) > 0.01 then
        pcall(function() cdo.Data.AmountToModify.Value = want end)
        local after = nil
        pcall(function() after = cdo.Data.AmountToModify.Value end)
        if type(after) ~= "number" or math.abs(after - want) > 0.01 then
            log("nap write did not stick (still " .. tostring(after) .. ")")
            return false
        end
        log(string.format("nap: endurance refill %s -> %s per in-game hour (%sx, %s per second)", tostring(cur), tostring(after), tostring(cfg.NapSpeed), tostring(-after / 60)))
    end
    napApplied = cfg.NapSpeed
    return true
end

-- Passes ------------------------------------------------------------------------------------------
local sleepDone = false

local function pass(label)
    if cfg.FastSleep and not sleepDone then sleepDone = applySleep() end
    if cfg.FastEating then
        local c, a, f = applyEating()
        if c > 0 or f > 0 or cfg.Verbose then
            log(string.format("%s: %d item cooldown(s) removed, %d already off, %d failed", label, c, a, f))
        end
    end
end

-- Startup -----------------------------------------------------------------------------------------
loadConfig()
clampNap()
log("loaded v" .. VERSION)

if not cfg.Enabled then
    log("disabled in config, leaving the game as it shipped")
    return
end

-- A new PlayerRestComponent means a player pawn was just built, i.e. a world is loading. The item
-- passes wait 40 s after that: reads during the world-load stall have aborted UE4SS before.
local worldAt = nil
local passesDone = 0
local PASS_AT = { 40, 120 }   -- seconds after world load: main pass, then a late catch-all

-- A template copy (Default__ / _GEN_VARIABLE) is also announced ~3 s after launch, at the main menu.
-- Only a component on a pawn in a loaded level counts (…L_World:PersistentLevel.BP_PlayerCharacter_C_n
-- .BP_Components_Sleep, verified 2026-09-29); otherwise the pass can land inside the world-load stall
-- of a player who picks a world ~40 s after launch.
local function inMenu(o) return fullName(o):find(":PersistentLevel.", 1, true) == nil end

pcall(NotifyOnNewObject, "/Script/Dominion.PlayerRestComponent", function(o)
    if inMenu(o) then return end
    worldAt = os.clock()
    passesDone = 0
end)

local napNext = 0
local firstTick = true
local okLoop = pcall(LoopInGameThreadWithDelay, 1000, function()
    if firstTick then
        firstTick = false
        -- Hot reload inside a world: no new component will be announced, so treat it as loaded now.
        local rc = nil
        pcall(function() rc = FindFirstOf("PlayerRestComponent") end)
        if valid(rc) and not inMenu(rc) and not worldAt then worldAt = os.clock() - PASS_AT[1] + 5 end
    end
    if cfg.FastSleep and not sleepDone then
        local ok, done = pcall(applySleep)
        sleepDone = ok and done
    end
    pcall(modMenuSync)
    -- Nap rate: only inside a loaded world, 40 s after it loaded (no reads during the load stall), and
    -- only while the number differs from the setting; a failed try waits 5 s.
    if worldAt and os.clock() - worldAt >= PASS_AT[1] and napApplied ~= cfg.NapSpeed and os.clock() >= napNext then
        local ok, done = pcall(applyNap)
        if not (ok and done) then napNext = os.clock() + 5 end
    end
    if worldAt and passesDone < #PASS_AT and os.clock() - worldAt >= PASS_AT[passesDone + 1] then
        passesDone = passesDone + 1
        local ok, err = pcall(pass, passesDone == 1 and "world pass" or "late pass")
        if not ok then log("pass error: " .. tostring(err)) end
    end
    return false
end)
if not okLoop then log("LoopInGameThreadWithDelay missing: this UE4SS build is too old") end
