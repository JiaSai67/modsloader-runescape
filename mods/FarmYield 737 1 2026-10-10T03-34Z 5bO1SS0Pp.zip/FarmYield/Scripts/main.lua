local TAG = "[FarmYield] "

local function log(msg)
    print(TAG .. tostring(msg) .. "\n")
end

local cfg = {
    Enabled = true,
    Multiplier = 3
}

-- Read config.txt
local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    return src:match("^(.*)[/\\]Scripts[/\\][^/\\]*$")
end

local function loadConfig()
    local root = modRoot()
    local f = root and io.open(root .. "\\config.txt", "r")
    if not f then
        log("Could not open config.txt; using defaults.")
        return
    end

    for line in f:lines() do
        local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if k and cfg[k] ~= nil then
            v = v:gsub("%s+[#;].*$", "")
            if type(cfg[k]) == "boolean" then
                cfg[k] = v:lower() == "true"
            elseif type(cfg[k]) == "number" then
                cfg[k] = tonumber(v) or cfg[k]
            end
        end
    end

    f:close()
end

loadConfig()

-- Live settings from Mod Menu
local MODMENU_ID = "FarmYield"
local mmRev = nil

local function modMenuSync(apply)
    local ok, rev = pcall(function()
        return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".rev")
    end)

    if not ok or type(rev) ~= "number" or rev == mmRev then
        return
    end

    mmRev = rev

    apply(function(key)
        local okV, v = pcall(function()
            return ModRef:GetSharedVariable(
                "ModMenu." .. MODMENU_ID .. "." .. key
            )
        end)

        if okV then return v end
    end)
end

local function syncSettings()
    modMenuSync(function(get)
        for k, old in pairs(cfg) do
            local v = get(k)
            if v ~= nil and type(v) == type(old) then
                cfg[k] = v
            end
        end

        log("Settings updated: Enabled=" .. tostring(cfg.Enabled)
            .. ", Multiplier=" .. tostring(cfg.Multiplier) .. "x")
    end)
end

-- Farm plot harvest hook
local target =
    "/Script/Dominion.FarmCommandComponent:Server_TryHarvestPlot"

local Pre, Post = RegisterHook(
    target,
    function(Context, PlotID, YieldMultiplier, Instigator,
             IsManual, Tool, CondenseYield)

        if not cfg.Enabled then
            return
        end

        local ok, original = pcall(function()
            return tonumber(YieldMultiplier:get())
        end)

        if not ok or original == nil then
            log("Could not read YieldMultiplier.")
            return
        end

        local factor = tonumber(cfg.Multiplier) or 3
        local modified = original * factor

        YieldMultiplier:set(modified)

        log("Harvest: original=" .. tostring(original)
            .. ", factor=" .. tostring(factor)
            .. "x, applied=" .. tostring(modified))
    end
)

-- Use the game thread for live settings updates.
local function loop()
    syncSettings()
end

if not pcall(LoopInGameThreadWithDelay, 500, function()
    pcall(loop)
end) then
    log("Could not start settings update loop.")
end

log("Loaded. Default multiplier: " .. tostring(cfg.Multiplier) .. "x")