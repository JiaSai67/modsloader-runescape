# Stashlink 1.1.6

## New in 1.1.6: choose your ledger opening key

Open **Options**, enter a free key such as **G** or **F9** in **Opening key**, then click **Apply** or press Enter. Use **F6 only** to disable E/F opening while keeping F6 available at the ledger. This allows alternate movement layouts such as ESDF to pass the ledger without opening the bank. The existing **Swap F / E** checkbox restores the original choices.

Your opening-key choice is saved between launches, and the ledger prompt follows it. Supported choices are letters, numbers and unreserved function keys. Modifier combinations and reserved Stashlink shortcuts are rejected. Choose a key that is free in your game layout.

Close Dragonwilds before updating and replace the complete Stashlink folder, including its updated native input reader. Saved tabs, quantities and preferences are preserved. Inventory transfer safeguards and item/save handling are unchanged.

## New in 1.1.5: reduced background overhead

Stashlink now uses a lighter ledger-focus event registration, rejects unrelated focus events earlier, and avoids repeated searches for unavailable input, HUD and panel objects. Input and slot reads create fewer temporary objects, and background checks reuse validated context within the same call.

Slow item badges load separately from their primary icons. Opening the bank also avoids repeated searches for an optional armour template removed from the current game. Inventory transfer safeguards, save handling and the native input reader are unchanged.

Close Dragonwilds before updating, then replace the existing Stashlink installation. Saved tabs, quantities and preferences are preserved.

## New in 1.1.4: controller input fixes

RT / R2 transfers no longer activate the equipped weapon skill while banking. Controller capture now starts during bank opening, closing a gap where Y could also open the spell menu. Closing the bank restores normal gameplay controls; a failed opening also releases its input capture.

Includes the 1.1.3 combat-freeze fix, capacity display, saved tabs, placeholders, quantities and crossplay-friendly Windows client banking.

## 1.1.3 combat freeze hotfix

Fixes a combat freeze and background stutter introduced in 1.1.2. Ledger focus detection now checks the actor's already-loaded class hierarchy, without forcing the Storage Ledger Blueprint to load while you play. Users of 1.1.2 should update to 1.1.3.

The fix was accepted after a fresh launch: the user reported the lag gone, and the native log confirmed bank opening, seven completed deposits and guarded ledger focus. Inventory transfer, item/save handling and the native input DLL are unchanged. The capacity display, tabs, controls and prompt polish from 1.1.2 remain included.

## New in 1.1.2

**See your bank space at a glance:** used / total slots, a native gold capacity bar, and a free-slot count stay visible below the storage grid. These count physical spaces across accessible linked storage, independently of search, categories, custom tabs and placeholders. Free slots exclude spare room within partial stacks; an item must still meet a container's normal rules. Counts follow the latest observed inventory snapshot.

The ledger prompt now matches the native key-first layout, spacing, shadow and text brightness. This update also improves E/F protection when approaching a ledger, fixes the controller Options key-swap checkbox and keyboard Enter inside quantity dialogs, preserves unreadable preference files, and keeps incompatible item variants in separate rows across containers.

The bank-space layout was accepted in game on Steam client build 25994193. Nintendo Switch-hosted crossplay is now recorded as user-reported compatibility; the controlled transfer/save results below retain their original PC dedicated-server scope.

## Ledger controls and tab scrolling

- Click **Options** beside the **STASHLINK** heading to open settings. On controller, tap Menu/Options while the bank is open.
- **Swap F / E** is on by default for new installs: **E opens Stashlink; F performs the native ledger deposit**. Turn it off to use F to open and E to deposit. Existing saved choices are preserved.
- Keyboard hints follow the active layout. Away from ledgers the normal game bindings remain. **F still fills stacks while Stashlink is open**; controller bindings are unchanged.
- Assigning an item to an existing custom tab preserves the bank scroll position. New tabs and explicit tab switches begin at the top; shorter views clamp to a valid row.
- The key preference is stored independently from custom tabs, placeholders and bank layouts. Interrupted or unreadable saves retain the guarded fallback and do not overwrite valid settings.

The Options button, both keyboard layouts and custom-tab scroll retention were physically accepted on Steam client build 25994193. The earlier dedicated-server save and contention validation below remains the 1.1.0 baseline; those broader tests were not repeated for this UI and input update.

## Co-op

Join a **PC dedicated server** from the Windows Steam client, stand beside a Storage Ledger, and open Stashlink with **E** (new installs), your saved ledger key, or **F6**, or hold **Menu / Options** for at least **0.75 seconds**, then release while still targeting the ledger. Install Stashlink and the matching UE4SS loader on each client that wants the bank; the dedicated server does not need Stashlink. Nearby accessible storage remains on the server, and transfers use the game's existing inventory requests.

**Nintendo Switch-hosted crossplay:** on October 17, 2026, the user reported Stashlink working when joining a session hosted on a Nintendo Switch. Stashlink runs on the Windows client; this does not require installing the mod on the console host. The report did not specify a full transfer/save matrix, exact host build or console model.

The transfer core passed two-client shared-stack withdrawals, shared-stack deposits, contention for one unique item under simulated delay, an in-flight disconnect, and exact inventory persistence after a server restart. The tests used two isolated local clients with emulated service identities and the unmodified native inventory RPCs. The feedback panel and co-op tooltip changes were checked in-game. Controller opening and keyboard/controller hint switching were accepted in the normal Steam client. The controlled validation remains PC dedicated-server testing; the Switch-host result is user-reported compatibility evidence. Other crossplay combinations, real WAN contention and Game Pass co-op have not completed that controlled matrix. The source validation record keeps the exact test scope and save-validation status.

On the published 1.1.0 baseline (Steam build 25812671), the four-row backpack, six equipment slots, Options and controller interactions passed the user's physical checks. A one-Stone withdrawal and return restored the exact 1,612-record / 276,428-unit baseline with no new duplicate or negative records. Native autosaves and the subsequent normal logout save succeeded with genuine service SDKs under steady 250 ms delay in each direction. After a same-build dedicated-server restart and native-menu rejoin, every inventory slot, item GUID, quantity and observed state matched the saved baseline exactly.

**Co-op controls:** open with **E** (new installs), your saved ledger key, or **F6**, or hold **Menu / Options** for at least **0.75 seconds** and release at the ledger. A short Menu tap retains the game's Pause action. **Y / Triangle** keeps its native spell action in co-op; solo ledger opening still uses Y / Triangle. Use the vanilla inventory to equip, consume or use items and to sort the backpack in co-op. Bank-view sorting and tab arrangement remain available.

Pending and uncertain transfer notices stay visible while you browse tabs or search. An uncertain server result pauses further inventory actions. Let the game finish disconnecting before reconnecting, then inspect both backpack and storage before trying that move again: a delayed server result may have moved some items. Stashlink never retries an uncertain request or creates replacement items. Very severe connection delay can make the game itself disconnect.

## Bank tabs

Custom tabs run across the top, as in the OSRS bank: **∞** shows all storage, followed by up to nine of your own tabs. Create one with **+**, or drag a stored item onto **+**. Drag stored items onto a custom tab to assign their item type; drag onto **∞** to remove that assignment. Drag within a custom tab to reorder its item types. Right-click a custom tab, or focus it and press **X / Square**, to rename or remove it. With a controller, tap **A / Cross** to pick up a stored item and again on a custom tab to assign it. Tab edits organize the view; your items stay in their physical containers.

The rail beside the grid filters by category: All, Equipment, Tools, Food and potions, Materials and seeds, Runes, Ammunition, Plans and tomes, Quest items and Other. Category icons are fixed; a custom tab's icon follows its first item, including its placeholder. Drag any item into a tab's first slot to use that item's icon. Search applies within the selected tab and category.

Scroll the storage grid with the mouse wheel or its scrollbar. In **∞**, drag one stored item onto another to arrange them by hand. **Sort** shows the current order (A–Z, Qty or Custom); it sorts once, and asks for a second press before replacing a hand-arranged order. Arranging and sorting change only the view.

Custom tabs and arrangements are saved locally across restarts in the game's Saved folder. Drag tabs left or right to reorder them, or use **Move tab left/right** in the editor.

**Placeholders** keep a dimmed, zero-count item slot when its last item is withdrawn. The slot survives closing and reopening the bank and returns to a normal item when restocked. Toggle them with the **Placeholders** checkbox below the grid; right-click an empty placeholder, or press **X / Square**, to release that saved slot. Placeholders contain no items and cannot be transferred.

The **Amount** row below the grid shows what double-click, Enter and Withdraw move: 1, 10, Half, Stack, All, or **X** for an exact amount. Half, Stack and All adapt to the selected item; cancelling a quantity popup leaves your previous choice intact.

Stashlink remembers the selected tab, category, order and scroll position for your character at each ledger, together with your amount. Search clears when you reopen. **LB/RB** steps through your custom tabs (or the categories, if you have none) while bank focus is active, and inventory categories while inventory focus is active.

## Your nearby storage. One inventory.

**PC mod. Crossplay friendly.**

Use Stashlink on your Windows PC in solo or multiplayer, including crossplay sessions hosted by a console player. Personally tested as a PC client joining a Nintendo Switch host.

Install Stashlink and its required UE4SS setup on the PC running the mod. Console players do not install Stashlink; this is not a console mod release.

Your supplies are spread across the base. Getting ready should take one stop.

Stashlink brings the contents of accessible nearby storage into one searchable inventory. Find materials, withdraw supplies, deposit loot, and arrange your backpack without opening every chest separately.

**Look at the game's Storage Ledger and press F to open Stashlink.** The Storage Ledger is the in-game object you interact with; Stashlink is the mod's inventory interface.

Your items stay in physical containers. Transfers use the game's inventory system, and existing storage and backpack capacity limits still apply.

### Find it. Move it. Get back to the adventure.

- **Search and sort your storage.** Browse combined quantities for compatible stacks across accessible nearby containers.
- **Move the amount you need.** Drag items or Ctrl-click a stack. Shift-drag half, or choose 1, 10, Half, Stack, All, or a custom amount.
- **Put matching loot away.** Fill Stacks deposits matching backpack items into storage that already contains them.
- **Prepare your backpack here.** Rearrange slots, inspect detailed hover cards, and right-click supported items to eat, equip, or use them.
- **Use more than ordinary chests.** Compatible nearby storage includes Tackle Boxes and Fishing Barrels reported by the game's storage system.

### Familiar game detail

Stashlink uses the installed game's panels, native tooltip widgets, item artwork, typography, gold particles, and opening animations. Durability, fill levels, equipped borders, burnt-food visuals, and upgrade indicators help you see what you are handling.

Transfers check item counts, identity, and supported state, including equipment upgrades and container contents. Hotbar stacks can be moved explicitly with Ctrl-click, RT, drag, or a chosen quantity. Fill Stacks leaves the hotbar in place; equipped armour remains protected from storage transfers. If an inventory action has an uncertain result, further transfers, item actions, and backpack sorting pause for that session.

### Controls

| Action | Control |
| --- | --- |
| Open Stashlink | Look at a Storage Ledger and press **E** (new installs) or your saved ledger key; **F6** also opens nearby |
| Transfer a stack | **Ctrl-click** |
| Withdraw, deposit, or rearrange | **Drag and drop** |
| Move half a stack | **Shift-drag** |
| Open quantity controls at Half | **Shift-click** |
| Options | **Options** beside the **STASHLINK** heading |
| Choose a custom amount | **X** in the Amount row, or **F4** |
| Scroll storage | Mouse wheel, scrollbar, or **Page Up / Page Down** |
| Arrange **∞** by hand | Drag a stored item onto another |
| Search | Search field or **F8** |
| Deposit matching items | **Fill Stacks / F** once the bank is open |
| Sort storage / backpack | **Space / V**; use vanilla backpack sorting in co-op |
| Eat, equip, or use a supported item | Solo: **Right-click**; use the vanilla inventory in co-op |
| Close and cancel pending bulk moves | **Escape / F6** |

### Controller

Controller input uses the same guarded inventory actions. Ledger hints follow the game's current input device, so a connected controller does not hide the F hint during keyboard play. Bank controls use native Xbox or PlayStation glyphs while a controller is active; moving the mouse restores mouse controls.

| Action | Controller |
| --- | --- |
| Open Stashlink at the ledger | Solo: **Y / Triangle**. Co-op: hold **Menu / Options** at least **0.75 seconds**, then release |
| Navigate | Left stick or D-pad |
| Scroll the active bank | Tilt the **right stick up/down**; stronger tilt scrolls faster |
| Switch inventory / bank | **RS / R3** |
| Reach equipment | Down from the bottom backpack row; up returns to backpack |
| Change bank tab / inventory category | **LB / RB**, or **L1 / R1** |
| Move / place a stack | **A / Cross** |
| Choose a split amount | Hold **A / Cross** |
| Transfer a stack | **RT / R2** |
| Use, equip, eat, or read | Solo: **X / Square**; use the vanilla inventory in co-op |
| Fill matching stacks | **Y / Triangle** while open |
| Sort active bank / inventory panel | **LS / L3**; backpack sorting stays in the vanilla inventory in co-op |
| Search | **View / Touchpad** |
| Open the full Options drawer | **Menu / Options**; press again to close |
| Cancel or close | **B / Circle** |

The gold border shows the active panel. Directional navigation stays inside that panel; RS switches between inventory and bank and remembers the last slot in each. Tilt the right stick to scroll while the bank is active; pressing the stick still switches panels. Scrolling stops in popups and while moving a carried item. Return the stick to centre after switching panels or changing a filter. Equipment is part of the inventory panel and remains protected from storage moves. Escape and B dismiss an active popup before closing the inventory. Unavailable quantity transfers show a reason beside the disabled button.

In Options, navigate the presets, transfer button, Refresh and Close with the stick or D-pad. **LB/RB** cycles withdrawal presets. Press **A / Cross** on Withdraw or Deposit to transfer the chosen amount. **B / Circle** closes the drawer; hold **A / Cross** on an inventory stack to open the native split popup.

### Install

**With the CurseForge app:** click **Install** to install Stashlink. A compatible, complete UE4SS installation is also required. The CurseForge app does not fetch this external loader for Stashlink.

**First UE4SS mod? Complete this one-time setup:**

1. Close Dragonwilds. Choose the complete [UE4SS package for your storefront](https://www.nexusmods.com/runescapedragonwilds/mods/4?tab=files): **Steam (latest)** for Steam or **UE4SS 5.6 Xbox** for PC Game Pass. Both list version **3.0.1-gf6d5f942**.
2. Steam: right-click Dragonwilds → **Manage → Browse local files**, then open `RSDragonwilds/Binaries/Win64`. PC Game Pass: follow the Xbox loader package's README to locate the game's binaries.
3. Match the selected loader archive's folder structure to your game installation. Keep its supplied settings and `ue4ss/Mods/shared/UEHelpers`: Stashlink requires the shared helpers. The Steam package uses `dwmapi.dll` beside `RSDragonwilds-Win64-Shipping.exe`; follow the Xbox package's README for Game Pass.
4. Preserve your other mods when updating the loader. Use the package for your storefront rather than mixing loader files.

Then enter a world, look at a Storage Ledger, and press **E** (new installs) or your saved ledger key. **F6** remains available nearby. For co-op, join the multiplayer session using the game's normal connection flow. Log out through Pause > Exit to Main Menu and rejoin through the native menus.

**With Vortex (Steam workflow tested):** install the Steam loader above as Stashlink's Nexus requirement, then install and deploy Stashlink through Vortex. PC Game Pass users should follow the manual instructions and Xbox loader README. The loader is a separate, one-time installation; it is not bundled in Stashlink.

**Manual install:** extract the `Stashlink` folder into your loader's `ue4ss/Mods/` directory (Steam example: `RSDragonwilds/Binaries/Win64/ue4ss/Mods/`).

UE4SS and the game's artwork are not bundled. Stashlink checks required loader functions, input constants, and UEHelpers before attaching its controls. An incomplete or incompatible installation is reported in `ue4ss/UE4SS.log`. A loader's date alone does not establish compatibility. See [Dependencies](DEPENDENCIES.md) for the exact archive, checks, and validation status.

### Compatibility and limits

- Current co-op save checks use Steam client build **25812671**, dedicated server build **25811348** (both **CL248854**) and the complete Nexus Steam loader **3.0.1-gf6d5f942**. Earlier two-client contention checks on client **25741633** / server **25808123** (**CL247725**) conserved 263,214 enumerated units with no new duplicate item GUIDs. Each validation result retains its original build and scope; see [Validation](VALIDATION.md).
- Stashlink checks recorded native function signatures and selected item fields on every game build. A detected mismatch disables inventory writes and names the problem in the log. Matching signatures do not prove that every future game or loader update preserves the same behavior.
- **Windows PC mod for solo and multiplayer, including console-hosted crossplay.** Install the matching UE4SS setup on the PC running Stashlink. Game Pass loading and Nintendo Switch-hosted crossplay are user-reported; the controlled transfer/save matrix retains its original PC dedicated-server scope and has not been repeated for every crossplay combination or real WAN contention.
- Access covers storage reported by the game around the nearby Storage Ledger. Map-wide access and unloaded remote containers are not supported.
- Storage capacity is unchanged. Items that do not fit stay at their source.
- Game updates may change native inventory categories and available item definitions. The current update moved existing rune slots and made four older catalog definitions unavailable; these changes are outside Stashlink's transfer-preservation claim. Current-build checks use a fresh baseline after the game update.
- Audited native item classes cover ordinary items, equipment, ammunition, and held containers. Unknown classes introduced by other mods or future updates remain read-only, including backpack rearrangement. Backpack sorting is unavailable while it contains an unsupported item type.

Back up saves before trying a new inventory mod. For a problem report, include the mod version, Steam build, UE4SS archive/version, item name, action used, and any on-screen error. Share only the relevant error excerpt after checking it for personal paths.

To disable or uninstall, close the game and disable Stashlink in your mod manager or remove its folder. Items remain in the game's physical containers.

---

Unofficial RuneScape: Dragonwilds mod. Not affiliated with or endorsed by Jagex. Runtime artwork belongs to the game; the Stashlink project icon is original. See the included third-party notices for reference attribution.

## Optional Easy Setup

The separate Stashlink Easy Setup ZIP provides Enable, Disable, and Update / Repair controls for an existing CurseForge game installation. Extract the complete setup folder before running `Stashlink Setup.cmd`. Close Dragonwilds first.

Setup verifies its payload, stages complete updates before replacing the installed scripts, and backs up an existing installation under `%LOCALAPPDATA%/Stashlink/Backups`. It preserves notes and the enabled/disabled state during Update. Enable also repairs missing Lua files. A compatible UE4SS loader must already be installed.

If you used the earlier private development build, Easy Setup disables that old installation when Stashlink is enabled. For a manual migration, disable the old mod before installing Stashlink so only one copy runs.

You can also disable Stashlink by setting `disabled=true` in `Scripts/stashlink/profile.lua`. Developer commands and polling are disabled in this release.

## License

All rights reserved for original Stashlink code and branding. You may download, install, and use the distributed mod for gameplay. Third-party components and references retain their own licenses; see `THIRD_PARTY_NOTICES.txt`.
