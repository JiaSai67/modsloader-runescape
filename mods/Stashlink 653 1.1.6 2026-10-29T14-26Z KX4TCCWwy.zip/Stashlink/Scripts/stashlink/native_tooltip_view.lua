-- Native presentation only. No source inventory, slot, or InventoryAPI is bound.
local M={}
local function valid(o) return o and o:IsValid() end
local function text(o,value) if valid(o) then o:SetText(FText(value or '')) end end
local function visible(o,show) if valid(o) then o:SetVisibility(show and 3 or 1) end end
local function trace(s) if require('stashlink.settings').development then print('[Stashlink] tooltip '..s..'\n') end end
local function create(P,cls)
    local lib=StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary')
    local o=lib:Create(P.pc,cls,P.pc);assert(valid(o),'Native tooltip component unavailable')
    o.bAutomaticallyRegisterInputOnConstruction=false
    o:StopListeningForAllInputActions();o:UnregisterInputComponent()
    return o
end
-- Optional BindWidget pointers in InputLabelBase are not safe to read on
-- templates that omit them. UE4SS casts the pointer before IsValid can run.
-- Walk the owned tree instead: only widgets actually present are returned.
local function child_named(widget,name)
    local panel=StaticFindObject('/Script/UMG.PanelWidget')
    local function visit(o)
        if not valid(o) then return nil end
        if o:GetFName():ToString()==name then return o end
        if o:IsA(panel) then
            for i=0,o:GetChildrenCount()-1 do
                local found=visit(o:GetChildAt(i));if found then return found end
            end
        end
    end
    return visit(widget.WidgetTree.RootWidget)
end
local function input(P,template,parent)
    local o=create(P,template:GetClass())
    for _,key in ipairs({'InputLabel','bRightAlignText','bScrollText','LabelTextWidth'}) do o[key]=template[key] end
    o.bShouldHandleVisibilityChanges=false
    local style=template.TextStyle;if valid(style) then o.TextStyle=style end
    parent:AddChildToVerticalBox(o):SetPadding({Left=4,Top=4,Right=4,Bottom=4})
    return o
end
function M.bind(P,H)
    trace('bind start')
    local cls=H.asset('/Game/UI/Inventory/Tooltip/WBP_Inventory_Tooltip.WBP_Inventory_Tooltip_C')
    local widget=create(P,cls)
    trace('native frame created')
    -- Remove the game's input receiver; replace it with passive native labels.
    local original=widget.InputsDisplay
    local parent=original:GetParent()
    original:StopListeningForAllInputActions();original:UnregisterInputComponent();original:SetVisibility(1);original:RemoveFromParent()
    local inputs=H.make('VerticalBox',H.tree);parent:AddChildToVerticalBox(inputs)
    local view={widget=widget,stats={},perks={},inputs={},root=widget.WidgetTree.RootWidget,
        stat_class=H.asset('/Game/UI/Inventory/Tooltip/Stats/WBP_Inventory_Tooltip_StatsEntry.WBP_Inventory_Tooltip_StatsEntry_C'),
        perk_class=widget.PerkList:GetChildAt(0):GetClass()}
    view.inputs.move=input(P,original.MoveInput,inputs)
    trace('move label created')
    view.inputs.use=input(P,original.UseInput,inputs)
    trace('use label created')
    view.inputs.transfer=input(P,original.DropInput,inputs)
    trace('transfer label created')
    -- Passive native labels use texture glyphs and never bind inventory actions.
    local transfer=view.inputs.transfer
    transfer.InputLabel=FText('Transfer')
    widget.StatList.StatsVerticalBox:ClearChildren();widget.PerkList:ClearChildren()
    for _,key in ipairs({'EquippedBorder','BrokenWarningBorder','ConsumeWarningBorder','MagicalEffectBorder','PhysicalEffectBorder','SetBonusBorder','SetBonusStatList','SetBonusTextBlock'}) do visible(widget[key],false) end
    local slot=H.place(H.canvas,widget,0,0,450,440);slot:SetAutoSize(true);slot:SetZOrder(100)
    widget:SetVisibility(1)
    trace('bind complete')
    view.P=P;view.H=H;view.slot=slot
    return view
end
function M.draw(view,model)
    local widget,P=view.widget,view.P
    widget:SetVisibility(3);widget:ForceLayoutPrepass()
    if not view.initialized then
        widget.StatList.StatsVerticalBox:ClearChildren();widget.PerkList:ClearChildren()
        -- Construction populates the tree. Do not read optional native
        -- BindWidget fields, including the single-label secondary icon.
        local function glyph(parent,path,width)
            if not valid(parent) then return end
            local H=view.H;local image=H.make('Image',H.tree)
            image:SetBrushFromTexture(H.asset(path),false)
            -- This is a 32px layout with native scale fitting disabled below.
            -- Render at the reserved size instead of doubling its footprint.
            image:SetRenderTransformPivot({X=.5,Y=.5});image:SetRenderScale({X=1,Y=1})
            local size=H.make('SizeBox',H.tree);size:SetWidthOverride(width or 32);size:SetHeightOverride(32);size:SetContent(image)
            parent:SetContent(size)
            -- The native action widget is 64px high and its ScaleBox halves
            -- its layout. Our replacement is already a 32px layout: keep the
            -- reserved width intact rather than shrinking it under the glyph.
            local scale_box=StaticFindObject('/Script/UMG.ScaleBox')
            if valid(scale_box) and parent:IsA(scale_box) then parent:SetStretch(0) end
            return {image=image,size=size,parent=parent}
        end
        local left='/Game/Art/UI/Inputs/Mouse/T_Mouse-Buttons-Left.T_Mouse-Buttons-Left'
        local right='/Game/Art/UI/Inputs/Mouse/T_Mouse-Buttons-Right.T_Mouse-Buttons-Right'
        view.glyphs={}
        view.glyphs.move=glyph(child_named(view.inputs.move,'InputImageBox'),left)
        view.glyphs.use=glyph(child_named(view.inputs.use,'InputImageBox'),right)
        local primary=child_named(view.inputs.transfer,'InputImageBox')
        view.glyphs.transfer=glyph(primary,'/Game/Art/UI/Inputs/Keyboard/T_Keys-Special-Ctrl.T_Keys-Special-Ctrl',44.5)
        local secondary=child_named(view.inputs.transfer,'SecondaryInputActionWidget')
        if valid(secondary) then
            local secondary_box=secondary:GetParent()
            view.glyphs.secondary=glyph(secondary_box,left)
            -- Select the separator by its owned-tree name. The same box also
            -- contains a text SizeBox and Spacer, which have no text receiver.
            local separator=child_named(view.inputs.transfer,'InputSeparator')
            visible(separator,true);widget:ForceLayoutPrepass();text(separator,'+')
            view.separator=separator
        end
        view.use_label=child_named(view.inputs.use,'LabelText')
        view.transfer_label=child_named(view.inputs.transfer,'LabelText')
        view.initialized=true
    end
    local mode=model.controller and (model.controller_family or 'Xbox') or 'keyboard'
    if view.glyph_mode~=mode then
        local paths
        if model.controller then
            local G=require('stashlink.controller_glyph')
            paths={move=G.path('A',mode),use=G.path('X',mode),transfer=G.path('RT',mode)}
        else
            paths={move='/Game/Art/UI/Inputs/Mouse/T_Mouse-Buttons-Left.T_Mouse-Buttons-Left',
                use='/Game/Art/UI/Inputs/Mouse/T_Mouse-Buttons-Right.T_Mouse-Buttons-Right',
                transfer='/Game/Art/UI/Inputs/Keyboard/T_Keys-Special-Ctrl.T_Keys-Special-Ctrl'}
        end
        for key,path in pairs(paths)do local g=view.glyphs[key];if g then g.image:SetBrushFromTexture(view.H.asset(path),false)end end
        if view.glyphs.transfer then view.glyphs.transfer.size:SetWidthOverride(model.controller and 32 or 44.5)end
        if view.glyphs.secondary then visible(view.glyphs.secondary.parent,not model.controller)end
        visible(view.separator,not model.controller);view.glyph_mode=mode
    end
    text(widget.TooltipTitleTextBlock,model.name);text(widget.ItemTypeTextBlock,model.category)
    local power=type(model.power)=='number' and model.power>=0
    visible(widget.PowerLevelBox,power);if power then text(widget.PowerLevelTextBlock,tostring(model.power)) end
    for i,stat in ipairs(model.stats) do
        local row=view.stats[i]
        if not row then row=create(P,view.stat_class);widget.StatList.StatsVerticalBox:AddChildToVerticalBox(row);view.stats[i]=row end
        row.StatText:SetStyle(stat.primary and row.PrimaryStatNameStyle or row.DefaultStatNameStyle)
        row.StatValueText:SetStyle(stat.primary and row.PrimaryStatValueStyle or row.DefaultStatValueStyle)
        text(row.PrefixTextBlock,stat.prefix or '')
        text(row.StatValueText,stat.native_value or stat.value)
        text(row.StatText,stat.raw_name or stat.name)
        row:UpdateStatDifferenceImage(stat.status or 0);visible(row,true)
    end
    for i=#model.stats+1,#view.stats do visible(view.stats[i],false) end
    visible(widget.StatListBorder,#model.stats>0)
    visible(widget.DurabilityBox,model.max_durability~=nil)
    if model.max_durability then
        local function number(n) local s=tostring(math.floor(n));return s:reverse():gsub('(%d%d%d)','%1,'):reverse():gsub('^,','') end
        text(widget.DurabilityTextBlock,number(model.durability)..'/'..number(model.max_durability))
    end
    for i,detail in ipairs(model.details or {}) do
        local row=view.perks[i]
        if not row then
            row=create(P,view.perk_class);widget.PerkList:AddChildToVerticalBox(row)
            row.PerkImage:SetVisibility(1)
            row.PerkDescription.Slot:SetPadding({Left=0,Top=0,Right=0,Bottom=0})
            view.perks[i]=row
        end
        text(row.PerkTitle,detail.title);text(row.PerkDescription,detail.description);visible(row,true)
    end
    for i=#(model.details or {})+1,#view.perks do visible(view.perks[i],false) end
    visible(widget.PerkInfoBox,#(model.details or {})>0)
    widget.ItemDescriptionTextBlock:SetScrollingEnabled(false)
    widget.ItemDescriptionTextBlock:SetWrapTextWidth(390)
    widget.ItemDescriptionTextBlock:SetAutoWrapText(true)
    text(widget.ItemDescriptionTextBlock,model.description);visible(widget.ItemDescriptionSeparator,model.description~='')
    text(widget.WeightTextBlock,string.format('%.3g',model.weight))
    visible(view.inputs.move,model.can_move);visible(view.inputs.transfer,model.can_transfer);visible(view.inputs.use,model.use_verb~=nil)
    if model.use_verb then text(view.use_label,model.use_verb) end
    text(view.transfer_label,'Transfer')
    widget:ForceLayoutPrepass();local size=widget:GetDesiredSize()
    return math.max(280,size.X),math.max(100,size.Y)
end
return M
