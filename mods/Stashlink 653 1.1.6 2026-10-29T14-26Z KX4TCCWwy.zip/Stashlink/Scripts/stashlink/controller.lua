-- Controller gestures produce the same guarded intents as mouse/keyboard input.
local State=require('stashlink.controller_state')
local UI=require('stashlink.controller_ui')
local Drag=require('stashlink.drag')
local Split=require('stashlink.controller_split')
local Scroll=require('stashlink.controller_scroll')
local Hardware=require('stashlink.hardware_input')
local EntryHold=require('stashlink.controller_entry_hold')
local M={state=State.new(),scroll_state=Scroll.new(),entry_hold=EntryHold.new()}
local names={A='Gamepad_FaceButton_Bottom',B='Gamepad_FaceButton_Right',X='Gamepad_FaceButton_Left',Y='Gamepad_FaceButton_Top',
 RT='Gamepad_RightTriggerAxis',SEARCH='Gamepad_Special_Left',LB='Gamepad_LeftShoulder',RB='Gamepad_RightShoulder',LS='Gamepad_LeftThumbstick',RS='Gamepad_RightThumbstick',
 MENU='Gamepad_Special_Right',UP='Gamepad_DPad_Up',DOWN='Gamepad_DPad_Down',LEFT='Gamepad_DPad_Left',RIGHT='Gamepad_DPad_Right'}
local function valid(o) return o and o:IsValid() end
local function invoke(o,name,...)return o[name](o,...)end
local function call(o,name,...)
    if not valid(o) then return false end
    return pcall(invoke,o,name,...)
end
local function first(class)
    for _,o in ipairs(FindAllOf(class) or {}) do
        if valid(o) and not o:GetFullName():find('Default__',1,true) then return o end
    end
end
local function refresh_subsystems()
    if valid(M.common)and valid(M.enhanced)then return end
    local now=os.clock()
    if M.subsystems_retry_at and now<M.subsystems_retry_at then return end
    M.subsystems_retry_at=now+1
    if not valid(M.common) then M.common=first('CommonInputSubsystem') end
    if not valid(M.enhanced) then M.enhanced=first('EnhancedInputLocalPlayerSubsystem') end
    if valid(M.common)and valid(M.enhanced)then M.subsystems_retry_at=nil end
end
function M.active()
    if M.disabled then return false end
    if M.simulation then return true end
    refresh_subsystems()
    local ok,value=call(M.common,'GetCurrentInputType');return ok and tonumber(value)==1
end
local mapping_options={bIgnoreAllPressedKeysUntilRelease=true,bForceImmediately=true,bNotifyUserSettings=false}
local function unmap()
    if M.mapping then call(M.enhanced,'RemoveMappingContext',M.mapping.context,mapping_options) end
    M.mapping=nil
end
function M.map(scope)
    -- Gameplay owns its input mappings. Rebuilding them on reticle changes
    -- can suppress held movement inputs, including on a remote client.
    -- The closed-bank Y gesture is observed directly through the controller.
    scope=scope=='menu' and 'menu' or nil
    if M.mapping and M.mapping.scope==scope then return end
    unmap();if not scope then return end
    refresh_subsystems();if not valid(M.enhanced) then return end
    local ctx_cls=StaticFindObject('/Script/EnhancedInput.InputMappingContext')
    local action_cls=StaticFindObject('/Script/EnhancedInput.InputAction')
    -- The live local-player subsystem is a valid owner on both tested loaders.
    local outer=M.enhanced
    if not (valid(ctx_cls) and valid(action_cls) and valid(outer)) then return end
    local ok,ctx=pcall(StaticConstructObject,ctx_cls,outer)
    if not ok or not valid(ctx) then return end
    local actions={}
    for key,name in pairs(names) do
        if scope=='menu' or key=='Y' then
            local made,action=pcall(StaticConstructObject,action_cls,outer)
            if made and valid(action) then
                pcall(function() action.bConsumeInput=true end)
                local mapped=call(ctx,'MapKey',action,{KeyName=FName(name)})
                -- The native weapon skill uses the digital trigger, while
                -- transfer polling also reads its analogue axis. Capture both
                -- with one menu action so R2 cannot reach IA_SpecialAction.
                if mapped and key=='RT' then
                    mapped=call(ctx,'MapKey',action,{KeyName=FName('Gamepad_RightTrigger')})
                end
                if mapped then actions[key]=action end
            end
        end
    end
    if scope=='menu' then
        local made,action=pcall(StaticConstructObject,action_cls,outer)
        if made and valid(action)then
            local configured=pcall(function()action.ValueType=1;action.bConsumeInput=true end)
            if configured and call(ctx,'MapKey',action,{KeyName=FName('Gamepad_RightY')})then actions.SCROLL=action end
        end
    end
    local applied=call(M.enhanced,'AddMappingContext',ctx,100010,mapping_options)
    if applied then M.mapping={context=ctx,actions=actions,scope=scope} end
end
local input_keys={}
local empty_keys={}
local function input_key(name)
    if not input_keys[name] then input_keys[name]={KeyName=FName(name)} end
    return input_keys[name]
end
function M.read(pc,world)
    if M.simulation then return M.simulation.keys end
    local keys={}
    if world then
        local ok,value=call(pc,'IsInputKeyDown',input_key(names.Y));keys.Y=ok and value==true
        return keys
    end
    for key,name in pairs(names) do
        local ok,value=call(pc,'IsInputKeyDown',input_key(name));keys[key]=ok and value==true
    end
    local _,x=call(pc,'GetInputAnalogKeyState',input_key('Gamepad_LeftX'))
    local _,y=call(pc,'GetInputAnalogKeyState',input_key('Gamepad_LeftY'))
    x,y=tonumber(x) or 0,tonumber(y) or 0
    local _,right_y=call(pc,'GetInputAnalogKeyState',input_key('Gamepad_RightY'))
    -- Move the list with the stick: positive Y moves content upward by
    -- advancing the bank row (the user's preferred scrolling direction).
    keys.SCROLL=tonumber(right_y)or 0
    local _,trigger=call(pc,'GetInputAnalogKeyState',input_key('Gamepad_RightTriggerAxis'))
    local _,digital=call(pc,'IsInputKeyDown',input_key('Gamepad_RightTrigger'))
    keys.RT=keys.RT or (tonumber(trigger) or 0)>=.5 or digital==true
    keys.LEFT=keys.LEFT or x<-.55;keys.RIGHT=keys.RIGHT or x>.55
    keys.UP=keys.UP or y>.55;keys.DOWN=keys.DOWN or y<-.55
    local c=M.focused
    if M.P and M.V.open and c and valid(c.object) then
        local ok,pressed=call(c.object,'IsPressed');keys.A=keys.A or (ok and pressed==true)
    end
    return keys
end
function M.input_mode(pc,library)
    if M.active() then
        -- The opening Y also releases the native spell menu. Install capture
        -- in this opening call, before enabling game input, not next tick.
        M.map('menu')
        local ok=call(library,'SetInputMode_GameAndUIEx',pc,M.P.root,0,false,false)
        if not ok then library:SetInputMode_UIOnlyEx(pc,M.P.root,0,false) end
        if M.ignored_pc~=pc then
            if M.ignored_pc then call(M.ignored_pc,'SetIgnoreMoveInput',false);call(M.ignored_pc,'SetIgnoreLookInput',false) end
            call(pc,'SetIgnoreMoveInput',true);call(pc,'SetIgnoreLookInput',true);M.ignored_pc=pc
        end
        pc.bShowMouseCursor=false
    else
        M.map(nil)
        library:SetInputMode_UIOnlyEx(pc,M.P.root,0,false);pc.bShowMouseCursor=true
        if M.ignored_pc then call(M.ignored_pc,'SetIgnoreMoveInput',false);call(M.ignored_pc,'SetIgnoreLookInput',false);M.ignored_pc=nil end
    end
end
function M.reset(world_changed)
    M.focus_binding=nil
    M.subsystems_retry_at=nil
    EntryHold.reset(M.entry_hold);M.remote_entry_scope=nil;M.solo_glyph_family=nil
    if M.quantity_previous and M.V then M.V.amount_index=M.quantity_previous.index;M.V.custom_amount=M.quantity_previous.amount end
    M.quantity_previous=nil
    if not world_changed then
        if M.P then Split.close(M.P) end
        if M.P and M.modal=='options' then M.P.set_drawer(false) end
        unmap()
        if M.ignored_pc then call(M.ignored_pc,'SetIgnoreMoveInput',false);call(M.ignored_pc,'SetIgnoreLookInput',false) end
        if M.P and M.P.controller_ui then
            if M.P.controller_ui.keyboard_open then UI.keyboard(M.P,M.V,false) end
            UI.update(M.P,M.V,false,nil,nil,nil)
        end
        for _,entry in ipairs(M.hidden_legends or {}) do call(entry.widget,'SetVisibility',entry.visibility) end
    else M.pending_unmap=M.mapping end
    M.mapping=nil;M.ignored_pc=nil;M.hidden_legends=nil;M.carry=nil;M.modal=nil;M.focused=nil;M.last_item=nil;M.device=nil;M.state=State.new();M.scroll_state=Scroll.new();M.graph_key=nil;M.panel=nil;M.panel_focus={};M.options_return=nil;M.options_selection=nil;M.world_poll_active=nil;M.remote_world_session=nil;M.remote_pad_slot=nil
    if M.P then M.P.controller_active=false;M.P.controller_focus=nil;M.P.controller_carry=false end
end
function M.forget_world()
    M.reset(true)
    -- Pretravel reset removes old mappings; post-travel cleanup cannot use
    -- old mapping or subsystem wrappers through the new player session.
    M.pending_unmap=nil;M.common=nil;M.enhanced=nil
end
function M.bind(service,P,V,context)
    M.service,M.P,M.V,M.context=service,P,V,context
end
local function available(c)
    return c and not c.invalid_cell and (not M.P.cell_available or M.P.cell_available(c))
end
local function nodes()
    local P=M.P;local result={}
    if M.modal=='quantity' then return {P.controller_split and P.controller_split.control or P.transfer_button} end
    for _,c in ipairs(P.controls) do
        local include=M.modal=='tab_editor'and c.tab_editor or M.modal=='keyboard' and c.controller_keyboard
            or M.modal=='options'and c.drawer and not c.controller_keyboard
            or not M.modal and not c.controller_keyboard and not c.tab_editor and not c.bank_hidden
        if include and not M.modal then
            local pane=c.pane=='stored' and 'stored' or c.pane and 'held' or c.bounds and c.bounds.x>=692 and 'stored' or 'held'
            include=pane==(M.panel or 'stored')
        end
        if include and available(c)and (not c.drawer or P.extras_open) and c.bounds and valid(c.object) then
            local ok,visible=call(c.object,'IsVisible');local _,enabled=call(c.object,'GetIsEnabled')
            if (not ok or visible) and enabled~=false then result[#result+1]=c end
        end
    end
    return result
end
function M.focus(c)
    if not available(c)or not valid(c.object) then return end
    M.focused=c;M.P.controller_focus=c
    M.focus_binding=c.bag_binding
    if not M.modal then M.panel=c.pane=='stored' and 'stored' or c.pane and 'held' or c.bounds and c.bounds.x>=692 and 'stored' or 'held' end
    call(c.object,'SetUserFocus',M.P.pc)
    if c.pane then M.P.select_control(c);M.last_item=c end
    if c.pane=='armour' then M.V.mode='stored';M.V.player_slot=nil;M.V.selection=0 end
    if M.carry and c.bounds then M.P.ghost_slot:SetPosition({X=c.bounds.x+26,Y=c.bounds.y+26}) end
    if M.V.open then M.P.render() end
    if not M.modal then
        M.panel_focus=M.panel_focus or {}
        M.panel_focus[M.panel]={control=c,serial=M.P.serial,tab=M.P.player_tab,bag_page=M.P.bag_page,bank_row=M.P.bank_row,
            category=M.V.bank_category,custom=M.V.bank and M.V.bank.selected}
    end
end
local function switch_panel()
    local pane=M.panel=='stored' and 'held' or 'stored'
    local remembered=M.panel_focus and M.panel_focus[pane]
    local c=remembered and remembered.control
    local present=false;for _,node in ipairs(M.P.controls)do if node==c then present=true;break end end
    local context=remembered and remembered.serial==M.P.serial
        and (pane=='stored' and remembered.bank_row==M.P.bank_row and remembered.category==M.V.bank_category
                and remembered.custom==(M.V.bank and M.V.bank.selected)
            or pane=='held' and (c.pane~='held' or (remembered.tab==M.P.player_tab and remembered.bag_page==M.P.bag_page)))
    local visible,shown=call(c and c.object,'IsVisible');local _,enabled=call(c and c.object,'GetIsEnabled')
    if not (present and context and available(c)and valid(c.object) and (not visible or shown) and enabled~=false)then
        c=pane=='held' and M.P.backpack[1] or M.P.stored[1]
    end
    M.focus(c)
end
local function graph()
    local key=tostring(M.modal)..':'..tostring(M.panel)..':'..tostring(M.P.serial)..':'..tostring(M.P.updates)
    if M.graph_key==key then return M.graph_nodes end
    local list=nodes();local directions={'left','right','up','down'}
    for _,c in ipairs(list) do
        for i,d in ipairs(directions) do
            local next=c.pane=='armour' and d=='down' and c or State.neighbour(list,c,d)
            if next then call(c.object,'SetNavigationRuleExplicit',i-1,next.object) end
        end
    end
    M.graph_key=key;M.graph_nodes=list;return list
end
local function cancel_carry()
    M.carry=nil;if M.P then M.P.controller_carry=false;if valid(M.P.ghost) then M.P.ghost:SetVisibility(1) end end
end
function M.repair_focus()
    local c=M.focused
    if c and available(c)and M.focus_binding==c.bag_binding then return false end
    local list=nodes();local replacement
    for _,node in ipairs(list)do if node.pane=='held'then replacement=node;break end end
    replacement=replacement or list[1]
    cancel_carry();M.focused=nil;M.P.controller_focus=nil;M.focus_binding=nil;M.state=State.new()
    if replacement then M.focus(replacement)end
    return true
end
function M.backpack_bottom()
    local result,y={},nil
    for _,c in ipairs(M.P.backpack or{})do
        if available(c)and c.bounds then
            if not y or c.bounds.y>y then result={};y=c.bounds.y end
            if c.bounds.y==y then result[#result+1]=c end
        end
    end
    return result
end
local function grid_return(cancelled)
    Split.close(M.P)
    if cancelled and M.quantity_previous then M.V.amount_index=M.quantity_previous.index;M.V.custom_amount=M.quantity_previous.amount end
    M.quantity_previous=nil
    local returning=M.options_return or M.last_item or M.P.stored[1]
    M.options_return=nil;M.options_selection=nil
    M.modal=nil;M.V.entry=nil;M.P.set_drawer(false)
    M.focus(returning);M.P.render()
end
function M.keyboard_key(key)
    local ui=M.P.controller_ui
    if key=='done'and ui.keyboard_mode=='tab_name'then
        local ok,why
        if ui.rename_id then ok,why=M.V.bank:rename(ui.rename_id,ui.keyboard_value)
        else ok,why=M.V.bank:add(ui.keyboard_value,nil,ui.rename_icon);if ok then M.V.select_bank_tab(ok)end end
        if not ok then
            M.V.status=require('stashlink.feedback').text(why);ui.keyboard_hint.value=M.V.status;ui.keyboard_hint.object:SetText(FText(M.V.status));return
        end
        M.V.repack();M.V.status='Custom tab renamed'
    end
    if not UI.key(M.P,M.V,key) then
        UI.keyboard(M.P,M.V,false);M.modal=nil;M.P.render();M.focus(M.P.stored[1])
    end
end
function M.rename_tab(id,icon)
    local tab=id and M.V.bank:get(id)or{name='Tab '..(#M.V.bank.state.tabs+1)};if not tab then return end
    cancel_carry();UI.keyboard(M.P,M.V,true,{kind='tab_name',id=id,value=tab.name,icon=icon})
    M.modal='keyboard';M.focus(M.P.keyboard_controls[1])
end
function M.search()
    cancel_carry();if M.modal=='keyboard' then M.keyboard_key('done');return end
    UI.keyboard(M.P,M.V,true);M.modal='keyboard';M.focus(M.P.keyboard_controls[1])
end
local function quantity(half)
    cancel_carry()
    local focus=M.focused
    if focus and not focus.pane and focus.action~='extras'then M.V.status='Select a stack to choose its quantity';return end
    local row=M.V.selected()
    if not row or not row.writable or row.available<=0 then M.V.status='Choose an unprotected, supported stack';return end
    if M.modal=='keyboard' then UI.keyboard(M.P,M.V,false) end
    M.quantity_row=row;M.quantity_token=M.V.snapshot.token;M.quantity_mode=M.V.mode
    M.quantity_previous={index=M.V.amount_index,amount=M.V.custom_amount}
    M.modal='quantity';if half then M.V.custom_amount=nil;M.V.amount_index=5 end
    M.V.entry='controller_amount';M.P.render()
    local shown=Split.show(M.P,row,M.V.amount(row),M.last_item)
    M.P.set_drawer(not shown)
    M.focus(M.P.controller_split and M.P.controller_split.control or M.P.transfer_button)
end
local function options_selection()
    local V=M.V;local row=V.selected()
    return {token=V.snapshot.token,key=row and row.key,mode=V.mode,slot=V.player_slot,identity=row and row.source and row.source.identity}
end
local function same_selection(a,b)
    return a and b and a.key==b.key and a.mode==b.mode and a.slot==b.slot and a.identity==b.identity
end
local function refresh_options_selection()
    local current=options_selection()
    M.options_selection=same_selection(M.options_selection,current)and current or nil
end
local function focus_preset()
    for _,control in ipairs(M.P.amount_buttons or{})do
        if control.data==M.V.amount_index then
            local ok,enabled=call(control.object,'GetIsEnabled')
            local row=M.V.selected()
            if row and row.writable and row.available>0 and(not ok or enabled~=false)then M.focus(control);return true end
        end
    end
end
local function options()
    if M.modal=='options'then grid_return();return end
    if M.modal then return end
    cancel_carry();Split.close(M.P)
    M.options_return=M.focused;M.options_selection=options_selection()
    M.modal='options';M.V.entry='controller_options';M.P.set_drawer(true);M.P.render()
    if not focus_preset()then M.focus(M.P.drawer_close or nodes()[1])end
end
local function options_accept()
    local control=M.focused
    if not control or not control.drawer or control.controller_keyboard then return end
    local ok,enabled=call(control.object,'GetIsEnabled')
    if ok and enabled==false then M.V.status=M.P.transfer_unavailable or'This option is unavailable';return end
    if control.action=='drawer_close'or control.action=='close'then grid_return()
    elseif control.action=='amount'then M.P.click(control)
    elseif control.action=='refresh'then M.service.ui_action('refresh');refresh_options_selection()
    elseif control.action=='ledger_swap'or control.action=='ledger_key_apply'or control.action=='ledger_key_none'then M.service.ui_action(control.action)
    elseif control.action=='transfer'then
        local current=options_selection();local row=M.V.selected()
        assert(M.options_selection and M.options_selection.token==current.token and same_selection(M.options_selection,current),'Inventory or selection changed; reopen Options')
        assert(row and row.writable and row.available>0,'Choose an unprotected, supported stack')
        M.service.ui_action('transfer');refresh_options_selection()
    end
end
local function move()
    local c=M.focused
    if not c then return end
    if M.carry and M.P.drop_bank_tab and M.P.drop_bank_tab(M.carry,c)then cancel_carry();M.P.render();return end
    if not c.pane then
        if c.action=='extras' or c.action=='amount_custom' then options()
        elseif c.action=='controller_key' then M.keyboard_key(c.data)
        else M.P.click(c) end
        return
    end
    if M.carry then
        local carry=M.carry;cancel_carry()
        assert(carry.token==M.V.snapshot.token,'Inventory changed; pick up the stack again')
        local intent,why=Drag.resolve(carry,c)
        if intent then
            if carry.quantity then intent.quantity=math.min(intent.quantity,carry.quantity) end
            M.service.ui_action('drag',intent)
        else M.V.status=why end
    elseif c.row and c.pane~='armour' and (c.pane=='stored' or c.row.writable and c.row.available>0) then
        M.carry={row=c.row,pane=c.pane,token=M.V.snapshot.token,control=c,binding=c.bag_binding,metadata_only=not c.row.writable or c.row.available<=0}
        M.P.controller_carry=true
        local entry=M.P.icon_cache[c.row.definition]
        if entry and valid(entry.texture) then M.P.ghost:SetBrushFromTexture(entry.texture,false);M.P.ghost:SetVisibility(3) end
        M.V.status=M.carry.metadata_only and 'Choose a custom tab; this item cannot be transferred' or 'Choose a destination and press A; B cancels';M.focus(c)
    else M.V.status='This slot is protected, empty, or read-only' end
end
local function quick()
    if M.carry and not Drag.source_valid(M.carry)then cancel_carry();M.V.status='Inventory changed; pick up the stack again';return end
    local quantity=M.carry and M.carry.quantity
    local c=M.carry and M.carry.control or M.focused
    local row=M.carry and M.carry.row or c and c.row
    local token=M.carry and M.carry.token or M.V.snapshot.token
    cancel_carry()
    if c and row and row.writable and row.available>0 and (c.pane=='held' or c.pane=='hotbar' or c.pane=='stored') then
        M.service.ui_action('quick_transfer',{pane=c.pane,row=row,slot=c.slot,snapshot_token=token,quantity=quantity})
    else M.V.status='This slot is protected, empty, or read-only' end
end
local function page(delta)
    local P,V=M.P,M.V
    if M.modal=='quantity' then
        V.custom_amount=nil;V.amount_index=((V.amount_index-1+delta)%5)+1
        Split.set(P,V.amount(M.quantity_row));P.render();return
    end
    if M.modal=='options'then
        local row=V.selected()
        if row and row.writable and row.available>0 then
            V.custom_amount=nil;V.amount_index=((V.amount_index-1+delta)%5)+1
            if V.remember_amount then V.remember_amount()end
            focus_preset();P.render()
        end
        return
    end
    if M.modal then return end
    -- Bumpers step through the top tab row (All + custom tabs); with no custom
    -- tabs they step through the category rail instead.
    local tabs=V.bank and V.bank.state and V.bank.state.tabs or {}
    if M.panel=='stored'and #tabs>0 then
        local ids={'all'};for _,tab in ipairs(tabs)do ids[#ids+1]=tab.id end
        local index=1;for i,id in ipairs(ids)do if id==V.bank.selected then index=i;break end end
        cancel_carry();P.bank_action('bank_tab',ids[((index-1+delta)%#ids)+1]);P.render();M.focus(P.stored[1]);return
    end
    if M.panel=='stored'and P.category_buttons and #P.category_buttons>0 then
        local index=1;for i,b in ipairs(P.category_buttons)do if b.data==V.bank_category then index=i;break end end
        local next=P.category_buttons[((index-1+delta)%#P.category_buttons)+1]
        cancel_carry();P.bank_action('bank_category',next.data);P.render();M.focus(P.stored[1]);return
    end
    P.player_tab=((P.player_tab-1+delta)%#P.tab_buttons)+1;P.bag_page=0;V.player_slot=nil
    P.render();if M.focused and M.focused.pane~='stored' then M.focus(P.backpack[1]) end
end
function M.action(event,native_changed)
    local kind=event.kind;local P,V=M.P,M.V
    if M.focused and (not available(M.focused)or M.focus_binding~=M.focused.bag_binding)then
        M.repair_focus()
        if kind~='back'and kind~='navigate'and kind~='switch_panel'then return end
    end
    if kind=='back' then
        if M.carry then cancel_carry();V.status='Move cancelled'
        elseif M.modal=='tab_editor'then P.close_tab_editor()
        elseif M.modal=='keyboard' then UI.keyboard(P,V,false);M.modal=nil;M.focus(P.stored[1])
        elseif M.modal=='quantity' or P.extras_open then grid_return(true)
        else M.service.close() end
    elseif kind=='navigate' then
        if M.modal=='quantity' then
            if event.direction=='left' or event.direction=='right' then
                local row=M.quantity_row
                V.custom_amount=math.max(1,math.min(row.available,Split.amount(P,V.amount(row))+(event.direction=='left' and -1 or 1)))
                V.custom_amount=Split.set(P,V.custom_amount)
            end
        elseif not native_changed then
            local current=M.focused;local target
            local group
            if current and current.pane=='armour' and event.direction=='down' then target=current
            elseif M.panel=='held' and current and current.pane=='held' and event.direction=='down' then
                for _,c in ipairs(M.backpack_bottom())do if c==current then group=P.armour;break end end
            elseif M.panel=='held' and current and current.pane=='armour' and event.direction=='up' then
                group=M.backpack_bottom()
            end
            if group then
                local distance;local x=current.bounds.x+current.bounds.w/2
                for _,c in ipairs(group)do local d=math.abs(c.bounds.x+c.bounds.w/2-x)
                    if available(c)and(not distance or d<distance)then target,distance=c,d end
                end
            end
            M.focus(target or State.neighbour(nodes(),current,event.direction))
        end
    elseif kind=='accept' then
        if M.modal=='keyboard' then M.keyboard_key(M.focused.data)
        elseif M.modal=='options'then options_accept()
        elseif M.modal=='quantity' then
            assert(M.quantity_token==V.snapshot.token,'Inventory changed; choose the quantity again')
            assert(V.selected() and V.selected().key==M.quantity_row.key and V.mode==M.quantity_mode,'Selected stack changed')
            local row=M.quantity_row;local amount=math.max(1,math.min(row.available,Split.amount(P,V.amount(row))));local source=M.last_item
            assert(source and source.row and source.row.key==row.key,'Selected stack changed')
            if V.remember_amount then
                local expected=math.max(1,math.min(row.available,V.amount(row)))
                if amount==expected then V.remember_amount()else V.remember_amount(amount)end
            end
            grid_return()
            M.carry={row=row,pane=source.pane,token=M.quantity_token,control=source,binding=source.bag_binding,quantity=amount}
            P.controller_carry=true;V.status='Choose a destination for '..amount..' items; A places, B cancels'
            local entry=P.icon_cache[row.definition]
            if entry and valid(entry.texture) then P.ghost:SetBrushFromTexture(entry.texture,false);P.ghost:SetVisibility(3) end
        else move() end
    elseif kind=='search' then if not M.modal or M.modal=='keyboard'and P.controller_ui.keyboard_mode~='tab_name' then M.search() end
    elseif kind=='hold' then if not M.modal then quantity(true)end
    elseif kind=='options' then options()
    elseif kind=='quick' then if not M.modal then quick() end
    elseif kind=='use' then
        if M.modal=='keyboard' then M.keyboard_key('delete')
        elseif not M.modal and not M.carry and M.focused and M.focused.action=='bank_tab'and M.focused.data~='all'then P.open_tab_editor(M.focused.data)
        elseif not M.modal and not M.carry and M.focused and M.focused.row then M.service.ui_action('use',M.focused) end
    elseif kind=='matching' then
        if M.modal=='keyboard' then M.keyboard_key('clear')
        elseif not M.modal and not M.carry then M.service.ui_action('matching') end
    elseif kind=='previous' then page(-1)
    elseif kind=='next' then page(1)
    elseif kind=='switch_panel' then if not M.modal then switch_panel() end
    elseif kind=='bag_sort' then if not M.modal and not M.carry then M.service.ui_action(M.panel=='stored' and 'sort' or 'bag_sort');M.focus(M.focused) end
    elseif kind=='sort' then if not M.modal and not M.carry then M.service.ui_action('sort');M.focus(M.focused) end end
    if V.open then P.render() end
end
function M.scroll_bank(keys,now)
    local P,V=M.P,M.V
    local eligible=V.open and P.controller_active and M.panel=='stored'and not M.modal and not M.carry
        and not V.entry and not P.pointer and not P.tab_editor_open and not P.extras_open and P.scroll_to_row~=nil
    -- Button gestures retain their exact target; scroll cannot rebind a cell
    -- beneath a pending pickup, transfer, split, or panel-switch press.
    for key in pairs(names)do if keys[key]then eligible=false;break end end
    local context=table.concat({tostring(P.serial),tostring(M.panel),tostring(M.modal),tostring(V.bank_category),
        tostring(V.bank and V.bank.selected),tostring(V.bank and V.bank.revision),tostring(V.query),tostring(V.sort_mode)},'|')
    local delta=Scroll.step(M.scroll_state,keys.SCROLL,eligible,context,now)
    if not delta then return false end
    local rows=P.bank_rows();local before=P.bank_row or 0
    local cols=P.bank_layout and P.bank_layout.cols or 8
    local relative,column=0,0
    if M.focused and M.focused.pane=='stored'and M.focused.row_index then
        relative=math.max(0,math.min((P.visible_rows or 8)-1,math.floor((M.focused.row_index-1)/cols)-before))
        column=(M.focused.row_index-1)%cols
    end
    P.scroll_to_row(before+delta,#rows)
    if P.bank_row==before then return false end
    local target=math.min(#rows,(P.bank_row+relative)*cols+column+1)
    V.mode='stored';V.selection=target;P.reveal_selection=false;P.last_click=nil;M.graph_key=nil
    P.render()
    for _,control in ipairs(P.stored)do
        if control.row_index==target and control.row and not control.clipped and not control.bank_hidden then
            M.focus(control);break
        end
    end
    return true
end
function M.tick_remote_world(actor,c)
    M.remote_entry_scope=true
    if require('stashlink.profile').remote_controller_entry~=true then
        EntryHold.reset(M.entry_hold)
        if M.world_poll_active then M.state=State.new()end
        M.world_poll_active=false;M.remote_pad_slot=nil;M.remote_world_session=nil
        if M.context.set_controller then M.context.set_controller(false)end
        return
    end
    -- Native Unreal key-state queries caused first-join movement/collision
    -- regressions. Closed remote entry only observes the hardware reader.
    if not M.hardware_load_attempted and not M.simulation then
        M.hardware_load_attempted=true
        local ok,why=Hardware.load()
        if not ok then print('[Stashlink] Remote controller entry unavailable: '..tostring(why)..'. Keyboard F remains available.\n')end
    end
    local keys=M.simulation and M.simulation.keys or Hardware.read()
    if not keys then
        EntryHold.reset(M.entry_hold)
        if M.state.scope~=nil or M.world_poll_active then M.state=State.new()end
        M.world_poll_active=false;M.remote_pad_slot=nil
        if M.context.set_controller then M.context.set_controller(false)end
        return
    end
    -- Target identity is the engine address, not a short-lived Lua wrapper.
    local ok,target=pcall(function()return actor:GetAddress()end)
    if not ok or not target then EntryHold.reset(M.entry_hold);return end
    local now=M.simulation and M.simulation.time or os.clock()
    local released=EntryHold.step(M.entry_hold,keys,target,c.session,now)
    local family=M.P and M.P.controller_ui and M.P.controller_ui.family or 'Xbox'
    if M.context.set_controller then M.context.set_controller(true,'MENU',family)end
    M.world_poll_active=true
    if released then
        -- Revalidate the complete focus at release; a cached reticle alone
        -- cannot authorize entry into a different ledger or world session.
        local fresh,current,context=pcall(M.context.focused,M.service.adapter,M.V)
        local same,identity=pcall(function()return current:GetAddress()end)
        EntryHold.reset(M.entry_hold)
        if fresh and same and identity==target and context and context.networked
            and context.session==c.session and require('stashlink.profile').remote_controller_entry==true then
            -- The first bank frame primes its own input edges, so Menu cannot
            -- flow through this release into the in-bank Options action.
            M.state=State.new();M.service.open(current)
        end
    end
end
function M.tick()
    if M.disabled or not M.service or M.service.stopped then EntryHold.reset(M.entry_hold);return end
    local V,P=M.V,M.P
    local actor,c
    if V.open then
        EntryHold.reset(M.entry_hold)
        local ok;ok,c=pcall(M.service.adapter.context,M.service.adapter);if not ok then return end
    elseif M.context.current then actor,c=M.context.current()
    else actor,c=M.context.focused(M.service.adapter,V) end
    if not V.open and actor and c and c.networked then
        M.tick_remote_world(actor,c);return
    end
    EntryHold.reset(M.entry_hold)
    -- Missing context cannot establish solo scope, including the first tick
    -- after a post-travel-only reset. Defer native cleanup until a positively
    -- observed bank or solo ledger scope, regardless of previous scope flags.
    if not V.open and (not actor or not c) then
        if M.state.scope~=nil or M.world_poll_active then M.state=State.new()end
        M.world_poll_active=false;return
    end
    M.remote_entry_scope=nil
    if M.pending_unmap then
        refresh_subsystems();call(M.enhanced,'RemoveMappingContext',M.pending_unmap.context,mapping_options);M.pending_unmap=nil
    end
    local active=M.active()
    if M.simulation then
        -- Physical keyboard/mouse activity can change CommonInput during an
        -- automated run. Keep the preview's native glyphs on the tested device.
        local got,input=call(M.common,'GetCurrentInputType')
        if got and tonumber(input)~=1 then call(M.common,'SetCurrentInputType',1) end
    end
    M.map(V.open and active and 'menu' or nil)
    if not V.open then
        -- Solo already owns CommonInput discovery. Resolve the real family
        -- here, then give the passive prompt a value instead of letting it
        -- scan. The remote hardware-only path returns before this branch.
        if not active then M.solo_glyph_family=nil
        elseif not M.solo_glyph_family then M.solo_glyph_family=require('stashlink.controller_glyph').family()end
        if M.context.set_controller then M.context.set_controller(active,'Y',M.solo_glyph_family) end
        if not active then
            if M.world_poll_active then M.state=State.new();M.world_poll_active=false end
            -- Prime the opening gesture without native key polling or a
            -- gameplay mapping. The first Y press after mouse mode stays fresh.
            if M.state.scope~='world'then State.step(M.state,empty_keys,'ledger','world',os.clock())end
            return
        end
        M.world_poll_active=true
    end
    -- Mouse mode does not need nineteen gamepad queries every frame.
    local keys=active and M.read(c.pc,not V.open) or {};local now=os.clock()
    if P.time_lib then local success,t=call(P.time_lib,'GetRealTimeSeconds',c.pc);if success then now=t end end
    if M.simulation then now=M.simulation.time end
    if not V.open then
        local events=State.step(M.state,keys,'ledger','world',now)
        for _,e in ipairs(events) do if e.kind=='matching' and actor and active then
            local current=M.context.focused(M.service.adapter,V)
            if current then M.service.open(current) end
            break
        end end
        return
    end
    -- Gameplay legends do not belong behind either input mode's inventory UI.
    -- Preserve their original visibility until the inventory closes.
    if not M.hidden_legends then
        M.hidden_legends={}
        for _,class in ipairs({'WBP_InputLegend_World_C','WBP_HUD_InteractionPrompt_C'})do
        for _,legend in ipairs(FindAllOf(class) or {}) do
            local got,pawn=call(legend,'GetOwningPlayerPawn')
            if got and valid(pawn) and valid(c.pawn) and pawn:GetAddress()==c.pawn:GetAddress() then
                local captured,visibility=call(legend,'GetVisibility')
                if captured then
                    M.hidden_legends[#M.hidden_legends+1]={widget=legend,visibility=visibility}
                    call(legend,'SetVisibility',1)
                end
            end
        end end
    end
    if active~=M.device then
        cancel_carry();P.pointer=nil;P.last_click=nil;M.device=active;P.controller_active=active
        if P.tab_editor_open and P.close_tab_editor then P.close_tab_editor() end
        for _,control in ipairs(P.controls) do if control.material then control.material:SetScalarParameterValue(FName('Controller on/off'),active and 1 or 0) end end
        if not active and M.modal then
            if M.modal=='keyboard' then UI.keyboard(P,V,false)
            elseif M.modal=='quantity'then grid_return(true)
            elseif M.modal=='options'then grid_return()
            else Split.close(P);P.set_drawer(false) end
            M.modal=nil;V.entry=nil
        end
        local library=StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary');M.input_mode(c.pc,library)
        if active then M.focus(M.focused or P.stored[1]) end
    end
    if not active then
        if next(M.scroll_state)then M.scroll_state=Scroll.new()end
        UI.update(P,V,false,nil,nil,nil);return
    end
    M.repair_focus()
    local list=graph();local native_changed=false
    for _,node in ipairs(list) do
        local success,focused=call(node.object,'HasUserFocus',c.pc)
        if success and focused and node~=M.focused then M.focus(node);native_changed=true;break end
    end
    if not M.focused then M.focus(list[1]) end
    local events=State.step(M.state,keys,State.token(M.focused),M.modal or 'grid',now)
    local handled=false
    for _,event in ipairs(events) do
        if event.kind=='navigate' or not handled then
            local applied,why=pcall(M.action,event,native_changed)
            if not applied then cancel_carry();V.status=tostring(why);if V.open then P.render() end end
            if event.kind~='navigate' then handled=true end
            if not V.open then break end
        end
    end
    if V.open then M.scroll_bank(keys,now);UI.update(P,V,true,M.focused,M.carry,M.mapping) end
end
-- Session-bound development input only; shipped settings never enable this path.
function M.debug(args)
    assert(require('stashlink.settings').development,'Controller simulation requires development mode')
    local verb,value=args:match('^(%S+)%s*(.*)$')
    if verb=='on' then
        M.simulation={keys={},time=0};M.state=State.new()
        refresh_subsystems();call(M.common,'SetCurrentInputType',1);return 'Controller simulation enabled'
    elseif verb=='off' then
        M.simulation=nil;M.state=State.new();call(M.common,'SetCurrentInputType',0);return 'Controller simulation disabled'
    elseif verb=='keys' then
        assert(M.simulation,'Enable controller simulation first')
        local keys={};for key in value:gmatch('%u+') do assert(names[key],'Unknown controller key');keys[key]=true end
        M.simulation.keys=keys;M.simulation.time=M.simulation.time+.016;M.tick();return 'Controller frame applied'
    elseif verb=='wait' then
        assert(M.simulation,'Enable controller simulation first')
        local t=assert(tonumber(value),'Use wait milliseconds');assert(t>=0 and t<=5000,'Delay out of range')
        M.simulation.time=M.simulation.time+t/1000;M.tick();return 'Controller time advanced'
    elseif verb=='focus' then
        local pane,index=value:match('^(%a+)%s+(%d+)$');index=tonumber(index)
        local group=({stored=M.P.stored,held=M.P.backpack,hotbar=M.P.hotbar,armour=M.P.armour,keyboard=M.P.keyboard_controls})[pane]
        assert(group and group[index],'Use focus stored|held|hotbar|armour|keyboard INDEX');M.focus(group[index]);M.P.render();return 'Controller focus set'
    elseif verb=='search' then M.search();return 'Controller search opened'
    elseif verb=='status' then
        local c=M.focused;local _,focus=call(c and c.object,'HasUserFocus',M.P.pc)
        return 'active='..tostring(M.active())..' focused='..tostring(c and c.pane or c and c.action)..
            ' index='..tostring(c and c.index)..' native_focus='..tostring(focus)..' modal='..tostring(M.modal)..
            ' carrying='..tostring(M.carry~=nil)..' mapping='..tostring(M.mapping and M.mapping.scope)..' simulation='..tostring(M.simulation~=nil)
    end
    error('Use controller on|off|keys KEYS|wait MS|focus PANE INDEX|search|status')
end
return M
