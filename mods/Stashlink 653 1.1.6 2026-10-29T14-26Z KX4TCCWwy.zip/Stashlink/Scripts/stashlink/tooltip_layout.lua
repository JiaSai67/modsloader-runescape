-- Wrap measured text segments without allowing adjacent stat labels to overlap.
local M={}
function M.flow(width,parts,gap)
    gap=gap or 8
    local x,y,line_height=0,0,0
    local positions={}
    for i,part in ipairs(parts) do
        local w=math.min(width,math.max(0,part.width))
        local h=math.max(1,part.height)
        if x>0 and x+w>width then y=y+line_height+4;x=0;line_height=0 end
        positions[i]={x=x,y=y,width=w,height=h}
        x=x+w+gap;line_height=math.max(line_height,h)
    end
    return positions,y+line_height
end
return M
