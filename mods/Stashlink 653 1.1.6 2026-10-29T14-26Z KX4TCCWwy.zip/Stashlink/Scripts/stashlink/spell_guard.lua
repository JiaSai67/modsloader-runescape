-- The game's input policy already has a spell-menu permission. Lease only
-- that flag while Stashlink owns the ledger gesture; keep movement untouched.
local M={}
local function valid(o)return o and o:IsValid()end
function M.release()
 if not M.lease then return end
 local saved=M.lease;M.lease=nil
 -- Resolve the persistent data asset again after travel instead of using a
 -- possibly stale UObject wrapper from the preceding world.
 local policy=StaticFindObject(saved.path)
 if valid(policy)and policy.bIsSpellcastingMenuAllowedToOpen==false then
  policy.bIsSpellcastingMenuAllowedToOpen=saved.value
 end
end
function M.acquire(c)
 if not c or not c.networked or not valid(c.pc)then return false end
 local policy=c.pc.CurrentInputMode
 if not valid(policy)or policy.bAllowInteraction~=true then return false end
 local path=policy:GetFullName():match('^%S+ (.+)$')
 if not path then return false end
 if M.lease and M.lease.path==path then return true end
 M.release()
 local value=policy.bIsSpellcastingMenuAllowedToOpen
 if type(value)~='boolean'then return false end
 M.lease={path=path,value=value}
 if value then policy.bIsSpellcastingMenuAllowedToOpen=false end
 return true
end
return M
