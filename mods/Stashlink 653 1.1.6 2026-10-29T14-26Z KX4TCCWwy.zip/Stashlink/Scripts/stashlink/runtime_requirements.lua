-- Check loader capabilities before scheduling work or attaching input callbacks.
-- A loader revision alone does not establish that its Lua API is usable.
local M={}
M.repair_hint='Install the complete UE4SS package for your store: Steam (latest) or 5.6 Xbox for PC Game Pass, including ue4ss/Mods/shared/UEHelpers. Keep its supplied folders and settings: https://www.nexusmods.com/runescapedragonwilds/mods/4?tab=files'
local functions={'RegisterKeyBind','LoopInGameThreadWithDelay','StaticFindObject','FindAllOf',
    'StaticConstructObject','LoadAsset','RegisterCustomProperty','CreateInvalidObject'}
local keys={'F6','F7','F8','F4','F3','ESCAPE','UP_ARROW','DOWN_ARROW','LEFT_ARROW','RIGHT_ARROW',
    'PAGE_UP','PAGE_DOWN','LEFT_MOUSE_BUTTON','RIGHT_MOUSE_BUTTON','V','SPACE','F','RETURN'}
local function callable(value)
    if type(value)=='function' then return true end
    -- UE4SS also exports FName/FText as userdata constructors. Their metatables
    -- may be protected, so __call cannot be inspected from ordinary Lua. Do not
    -- invoke a native constructor while preflighting the loader thread.
    if type(value)=='userdata' then return true end
    local meta=getmetatable(value)
    return type(meta)=='table' and type(meta.__call)=='function'
end
function M.check(environment,load_module)
    environment=environment or _G
    load_module=load_module or require
    local missing={}
    for _,name in ipairs(functions) do
        if type(environment[name])~='function' then missing[#missing+1]=name end
    end
    for _,name in ipairs({'FName','FText'}) do
        if not callable(environment[name]) then missing[#missing+1]=name end
    end
    local properties=environment.PropertyTypes
    if type(properties)~='table' or type(properties.NameProperty)~='table' then
        missing[#missing+1]='PropertyTypes.NameProperty'
    end
    local function enum_members(name,members)
        local values=environment[name]
        for _,member in ipairs(members) do
            local value=type(values)=='table' and values[member] or nil
            if type(value)~='number' or value<0 or value~=math.floor(value) or value==math.huge then
                missing[#missing+1]=name..'.'..member
            end
        end
    end
    enum_members('Key',keys)
    enum_members('ModifierKey',{'SHIFT','CONTROL'})
    -- Loading the supplied helper can itself fail if the installation is incomplete.
    if #missing==0 then
        local ok,helpers=pcall(load_module,'UEHelpers')
        if not ok then missing[#missing+1]='UEHelpers ('..tostring(helpers)..')'
        elseif type(helpers)~='table' or type(helpers.GetPlayerController)~='function' then
            missing[#missing+1]='UEHelpers.GetPlayerController'
        end
    end
    if #missing>0 then return false,'Missing or incompatible loader capability: '..table.concat(missing,', ')..'. '..M.repair_hint end
    return true
end
return M
