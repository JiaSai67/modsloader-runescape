-- Pure snapshot logic. Records must be supplied by a verified game adapter.
-- No UObjects, live pointers, inventory mutations, or persisted item copies.
local M = {}
local MAX_COUNT = 2147483647
local fields = {"session", "world", "container_id", "slot", "base_id", "definition_id",
    "signature", "signature_verified", "instance_id", "count", "revision",
    "available", "authorized", "supported"}

local function text(value) return type(value) == "string" and #value > 0 end
local function tuple(...)
    local result = {}
    for _, value in ipairs({...}) do
        value = tostring(value)
        result[#result + 1] = #value .. ":" .. value
    end
    return table.concat(result)
end
local function equal(a, b)
    for _, field in ipairs(fields) do if a[field] ~= b[field] then return false end end
    return true
end
local function copy(record)
    local result = {}
    for _, field in ipairs(fields) do result[field] = record[field] end
    return result
end

function M.build(records, session, world)
    assert(text(session) and text(world), "snapshot requires session and world identity")
    local unique, conflicts, issues = {}, {}, {}
    local function issue(reason, key) issues[#issues + 1] = {reason = reason, source = key} end
    for _, record in ipairs(records) do
        if record.session ~= session or record.world ~= world then
            issue("stale_session_or_world")
        elseif not text(record.container_id) or not text(record.slot) then
            issue("unverified_source_identity")
        else
            local key = tuple(record.container_id, record.slot)
            if unique[key] and not equal(unique[key], record) then
                conflicts[key] = true
            else
                unique[key] = copy(record)
            end
        end
    end
    local groups, instance_sources = {}, {}
    -- An instance appearing at two distinct sources is ambiguous, never two items.
    for key, record in pairs(unique) do
        if text(record.instance_id) then
            local other = instance_sources[record.instance_id]
            if other and other ~= key then conflicts[key], conflicts[other] = true, true end
            instance_sources[record.instance_id] = key
        end
    end
    for key, record in pairs(unique) do
        if conflicts[key] then
            issue("conflicting_source", key)
        elseif record.available ~= true or record.authorized ~= true or record.supported ~= true then
            issue("unavailable_or_unauthorized_or_unsupported", key)
        elseif not text(record.base_id) or not text(record.definition_id) then
            issue("unverified_base_or_item", key)
        elseif type(record.count) ~= "number" or record.count ~= math.floor(record.count)
            or record.count < 0 or record.count > MAX_COUNT then
            issue("invalid_count", key)
        elseif record.count > 0 then
            local group_key
            if not record.instance_id and record.signature_verified == true and text(record.signature) then
                group_key = "stack:" .. tuple(record.definition_id, record.signature)
            else
                group_key = "source:" .. key
            end
            local group = groups[group_key]
            if not group then
                group = {key = group_key, definition_id = record.definition_id, total = 0, bases = {}, sources = {}}
                groups[group_key] = group
            end
            group.total = group.total + record.count
            group.bases[record.base_id] = (group.bases[record.base_id] or 0) + record.count
            group.sources[#group.sources + 1] = record
        end
    end
    local rows = {}
    for _, group in pairs(groups) do
        table.sort(group.sources, function(a, b)
            if a.count ~= b.count then return a.count < b.count end
            return tuple(a.container_id, a.slot) < tuple(b.container_id, b.slot)
        end)
        rows[#rows + 1] = group
    end
    table.sort(rows, function(a, b) return a.key < b.key end)
    return {session = session, world = world, rows = rows, issues = issues,
        complete = #issues == 0, authoritative = false}
end

return M
