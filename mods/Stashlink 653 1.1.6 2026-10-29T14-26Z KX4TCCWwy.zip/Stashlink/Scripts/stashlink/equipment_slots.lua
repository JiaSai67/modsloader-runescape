-- Visible equipment selectors are enum values, not physical Loadout slots.
-- Retain only plain Lua names/numbers; unavailable discovery is retried.
local M={};local cached
local order={'Head','Body','Legs','Cape','Necklace','Trinket'}
local legacy={'Head','Body','Legs','Cape','Trinket'}
local function integer(n)return type(n)=='number'and n==n and n>=0 and n<math.huge and n==math.floor(n)end
local function fallback()
 local specs={};for i,name in ipairs(legacy)do specs[i]={name=name,slot=i-1}end;return specs
end
function M.specs()
 if cached then return cached end
 local ok,values=pcall(function()
  if type(StaticFindObject)~='function'then return nil end
  local enum=StaticFindObject('/Script/Dominion.ELoadoutSlotStrategy')
  if not enum or not enum:IsValid()then return nil end
  local found={}
  enum:ForEachName(function(name,value)
   local text=type(name)=='string'and name or name:ToString()
   local semantic=text:match('::([^:]+)$')or text
   for _,wanted in ipairs(order)do if semantic==wanted then
    assert(integer(value),'Invalid equipment selector value')
    assert(found[semantic]==nil or found[semantic]==value,'Conflicting equipment selector')
    found[semantic]=value;break
   end end
  end)
  return found
 end)
 if not ok or not values then return fallback()end
 local specs,used={},{}
 for _,name in ipairs(order)do
  local slot=values[name]
  assert(slot~=nil or name=='Necklace','Equipment enum missing '..name)
  if slot~=nil then
   assert(not used[slot],'Equipment enum repeats a visible selector value')
   used[slot]=true;specs[#specs+1]={name=name,slot=slot}
  end
 end
 cached=specs;return specs
end
function M.selector(control)
 local slot=control.nativeequipment_slot
 if slot==nil and control.row then slot=control.row.nativeequipment_slot end
 if slot==nil then local spec=M.specs()[control.index];slot=spec and spec.slot end
 if not integer(slot)then return nil end
 if control.row and control.row.nativeequipment_slot~=nil and control.row.nativeequipment_slot~=slot then return nil end
 return slot
end
function M.key(specs)
 local parts={};for _,s in ipairs(specs)do parts[#parts+1]=s.name..':'..s.slot end;return table.concat(parts,'|')
end
function M.layout(specs)
 return {count=#specs,x=37.2,y=71.7,pitch=68.5375,sort_x=410,sort_y=#specs>5 and 32 or 86}
end
return M
