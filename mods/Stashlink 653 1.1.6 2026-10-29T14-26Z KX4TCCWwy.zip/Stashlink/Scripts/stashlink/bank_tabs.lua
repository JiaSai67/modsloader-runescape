-- Custom tabs only describe a view of storage. They never own or move items.
local M={MAX_TABS=9,MAX_ITEMS=8192}
local function copy(state)
    local result={next_id=state.next_id,tabs={}}
    for i,tab in ipairs(state.tabs)do local n={id=tab.id,name=tab.name,icon=tab.icon,items={}};result.tabs[i]=n
        for j,definition in ipairs(tab.items)do n.items[j]=definition end
    end;return result
end
function M.validate(state)
    assert(type(state)=='table'and type(state.tabs)=='table'and #state.tabs<=M.MAX_TABS,'Invalid custom tabs')
    assert(type(state.next_id)=='number'and state.next_id>=1 and state.next_id<=2147483647 and state.next_id==math.floor(state.next_id),'Invalid tab sequence')
    local ids,items,count={},{},0
    for _,tab in ipairs(state.tabs)do
        assert(type(tab.id)=='string'and tab.id:match('^t%d+$')and not ids[tab.id]
            and tonumber(tab.id:sub(2))<state.next_id,'Invalid tab ID');ids[tab.id]=true
        assert(type(tab.name)=='string'and #tab.name>=1 and #tab.name<=80 and tab.name:find('%S')and not tab.name:find('[%z\1-\31\127]'),'Invalid tab name')
        assert(type(tab.items)=='table','Invalid tab items')
        assert(tab.icon==nil or(type(tab.icon)=='string'and #tab.icon>0 and #tab.icon<=2048 and not tab.icon:find('[%z\1-\31\127]')),'Invalid tab icon')
        for _,definition in ipairs(tab.items)do
            count=count+1;assert(count<=M.MAX_ITEMS and type(definition)=='string'and #definition>0 and #definition<=2048
                and not definition:find('[%z\1-\31\127]')and not items[definition],'Invalid or duplicate tab item')
            items[definition]=tab.id
        end
    end
    return true
end
function M.new(store)
    local self={state={next_id=1,tabs={}},revision=0,selected='all',store=store,index={}}
    function self:reindex()
        self.index={};for _,tab in ipairs(self.state.tabs)do for rank,definition in ipairs(tab.items)do self.index[definition]={tab.id,rank}end end
    end
    function self:load()
        if not self.store then return true end
        local state,why=self.store:load()
        if state then self.state=state;self.revision=self.revision+1;self:reindex();return true end
        self.load_error=why;return not why,why
    end
    function self:get(id)for _,tab in ipairs(self.state.tabs)do if tab.id==id then return tab end end end
    function self:membership(definition)
        local value=self.index[definition];if value then return value[1],value[2]end
    end
    function self:commit(state)
        local ok,why=pcall(M.validate,state);if not ok then return nil,why end
        if self.load_error then return nil,'Saved custom tabs could not be read; original files were preserved'end
        if self.store then local saved,problem=self.store:save(state);if not saved then return nil,problem end end
        self.state=state;self.revision=self.revision+1;self:reindex();return true
    end
    function self:add(name,definition,icon)
        if #self.state.tabs>=M.MAX_TABS then return nil,'All nine custom tabs are in use'end
        local next=copy(self.state);local id='t'..next.next_id;next.next_id=next.next_id+1
        local tab={id=id,name=name or ('Tab '..(#next.tabs+1)),icon=icon,items={}};next.tabs[#next.tabs+1]=tab
        if definition then
            for _,old in ipairs(next.tabs)do for i=#old.items,1,-1 do if old.items[i]==definition then table.remove(old.items,i)end end end
            tab.items[1]=definition
        end
        local ok,why=self:commit(next);if ok then return id end;return nil,why
    end
    function self:rename(id,name)
        local next=copy(self.state);for _,tab in ipairs(next.tabs)do if tab.id==id then tab.name=name;return self:commit(next)end end
        return nil,'Choose a custom tab first'
    end
    function self:set_icon(id,definition)
        local next=copy(self.state)
        for _,tab in ipairs(next.tabs)do if tab.id==id then tab.icon=definition;return self:commit(next)end end
        return nil,'Choose a custom tab first'
    end
    function self:move(id,before)
        if before==id then return true end
        local next=copy(self.state);local moving
        for i,tab in ipairs(next.tabs)do if tab.id==id then moving=table.remove(next.tabs,i);break end end
        if not moving then return nil,'Choose a custom tab first'end
        local at=#next.tabs+1
        if before then
            at=nil;for i,tab in ipairs(next.tabs)do if tab.id==before then at=i;break end end
            if not at then return nil,'The destination tab changed'end
        end
        table.insert(next.tabs,at,moving);return self:commit(next)
    end
    function self:shift(id,delta)
        for i,tab in ipairs(self.state.tabs)do if tab.id==id then
            local destination=i+delta
            if destination<1 or destination>#self.state.tabs then return true end
            return self:move(id,delta<0 and self.state.tabs[destination].id or(self.state.tabs[destination+1]and self.state.tabs[destination+1].id))
        end end;return nil,'Choose a custom tab first'
    end
    function self:remove(id)
        local next=copy(self.state);for i,tab in ipairs(next.tabs)do if tab.id==id then
            table.remove(next.tabs,i);local ok,why=self:commit(next);if ok and self.selected==id then self.selected='all'end;return ok,why
        end end;return nil,'Choose a custom tab first'
    end
    function self:assign(id,definition,before)
        if id~='all'and not self:get(id)then return nil,'Choose a custom tab first'end
        if before==definition then return true end
        -- Reordering within a tab: moving right takes the target's place, not the slot before it.
        local same,from,to=self:get(id),nil,nil
        if same then for i,value in ipairs(same.items)do if value==definition then from=i end;if value==before then to=i end end end
        local after=from and to and to>from
        local next=copy(self.state)
        for _,tab in ipairs(next.tabs)do for i=#tab.items,1,-1 do if tab.items[i]==definition then table.remove(tab.items,i)end end end
        if id~='all'then for _,tab in ipairs(next.tabs)do if tab.id==id then
            local at=#tab.items+1;for i,value in ipairs(tab.items)do if value==before then at=after and i+1 or i;break end end
            table.insert(tab.items,at,definition)
        end end end
        return self:commit(next)
    end
    function self:matches(row)return self.selected=='all'or self:membership(row.definition)==self.selected end
    return self
end
return M
