-- Use the installed game's panel Blueprint and its own opening animation.
-- These are new UI instances; the vanilla inventory and its handlers are untouched.
local Scheduler=require('stashlink.scheduler')
local M=package.loaded['stashlink.native_panels'] or {}
-- Layout helpers may be shallow wrapper tables. Their asset closure, shared
-- by every panel in one build, is the stable identity. Weak keys retain no tree.
M.template_misses=M.template_misses or setmetatable({},{__mode='k'})
local function valid(o)return o and o:IsValid()end
function M.create(P,H,parent,width,height,armour)
 local name='WBP_Panel_Inventory';local cls
 if armour then
  local compact='WBP_Panel_Inventory_Armour'
  local path='/Game/UI/Panels/'..compact..'.'..compact..'_C'
  local misses=M.template_misses[H.asset]
  if not misses then misses={};M.template_misses[H.asset]=misses end
  if not misses[path]then
   local ok,asset=pcall(H.asset,path)
   if ok and valid(asset)then name=compact;cls=asset
   else misses[path]=true end
  end
 end
 -- The current game removed the compact class. The existing inventory panel
 -- supports these same explicit size overrides and owns the normal emitter.
 if not cls then cls=H.asset('/Game/UI/Panels/'..name..'.'..name..'_C')end
 local library=StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary')
 local panel=library:Create(P.pc,cls,P.pc)
 assert(valid(panel) and valid(panel.WidgetTree) and valid(panel.InAnimation),'Native panel construction failed')
 local size=panel.WidgetTree.RootWidget
 size:SetWidthOverride(width);size:SetHeightOverride(height)
 H.place(parent,panel,0,0,width,height)
 local particles=panel[name=='WBP_Panel_Inventory_Armour' and 'NS_UI_VFX_InventoryPanel_Armour' or 'NS_UI_VFX_InventoryPanel']
 assert(valid(particles),'Native panel particles unavailable')
 particles.AutoActivate=false
 panel:SetVisibility(1)
 local entry={widget=panel,particles=particles,width=width,height=height,armour=armour}
 P.native_panels[#P.native_panels+1]=entry
 return entry
end
local function sync(entry)
 if not valid(entry.widget) or not valid(entry.content) then return end
 local background=entry.widget.BackgroundPanel
 if not valid(background) then return end
 local scale=background.RenderTransform.Scale
 entry.content:SetRenderOpacity(background.RenderOpacity)
 entry.content:SetRenderScale({X=scale.X,Y=scale.Y})
 return background.RenderOpacity,scale.X,scale.Y
end
local function start(P,entry)
 if not valid(entry.widget) or not valid(entry.content) then return end
 entry.content:SetRenderOpacity(0)
 entry.widget:StopAllAnimations()
 entry.widget:SetVisibility(4)
 entry.started=P.time_lib:GetRealTimeSeconds(P.pc)
 entry.animating=true
 entry.widget:SetPanelVisibility(true)
 sync(entry)
end
function M.tick()
 local P=M.active
 if not P or not valid(P.root) then M.active=nil;return end
 local now=P.time_lib:GetRealTimeSeconds(P.pc)
 local busy=false
 for _,entry in ipairs(P.native_panels or {})do
  if entry.animating then
   if entry.drawer and not P.extras_open then entry.animating=false
   else
    local opacity,sx,sy=sync(entry)
    local elapsed=now-entry.started
    if elapsed>=.75 or (elapsed>=.35 and opacity and opacity>=.995 and math.abs(sx-1)<.005 and math.abs(sy-1)<.005) then
     entry.animating=false
     if valid(entry.content) then entry.content:SetRenderOpacity(1);entry.content:SetRenderScale({X=1,Y=1}) end
    else busy=true end
   end
  end
 end
 local main=P.native_panels and P.native_panels[1]
 if valid(P.close_legend) and main and main.animating then
  local background=main.widget.BackgroundPanel
  if valid(background) then
   local scale=background.RenderTransform.Scale
   P.close_legend:SetRenderOpacity(background.RenderOpacity)
   P.close_legend:SetRenderScale({X=scale.X,Y=scale.Y})
  end
 elseif valid(P.close_legend) then P.close_legend:SetRenderOpacity(1);P.close_legend:SetRenderScale({X=1,Y=1}) end
 if not busy then M.active=nil end
end
local function schedule()
 if M.scheduled then return end
 Scheduler.every(16,function() if M.active then M.tick() end end)
 M.scheduled=true
end
function M.show(P)
 schedule()
 M.active=P
 for _,entry in ipairs(P.native_panels or {})do
  if entry.drawer and not P.extras_open then
   entry.animating=false
   if valid(entry.widget) then entry.widget:SetVisibility(1) end
   if valid(entry.content) then entry.content:SetRenderOpacity(0) end
  else start(P,entry) end
 end
 M.tick()
 if P.effects then P.effects:tick() end
end
function M.show_drawer(P)
 schedule()
 M.active=P
 for _,entry in ipairs(P.native_panels or {})do if entry.drawer then start(P,entry) end end
 M.tick()
 if P.effects then P.effects:tick() end
end
function M.hide(P)
 if M.active==P then M.active=nil end
 if not valid(P.root)then return end
 for _,entry in ipairs(P.native_panels or {})do
  entry.animating=false
  if valid(entry.widget)then entry.widget:StopAllAnimations();entry.widget:SetVisibility(1)end
  if valid(entry.content)then entry.content:SetRenderOpacity(0);entry.content:SetRenderScale({X=1,Y=1})end
 end
 if valid(P.close_legend) then P.close_legend:SetRenderOpacity(0) end
end
return M
