-- One pinned game-thread loop owns all mod work. The loader's async coroutine
-- shares its Lua VM with game-thread callbacks, so no LoopAsync is used.
local M={queue={},pinned={},tasks={},started=false,stopped=false,epoch=0}
function M.pin(fn) M.pinned[fn]=true; return fn end
function M.invalidate()
    M.epoch=M.epoch+1;M.queue={}
end
function M.run(fn)
    assert(type(fn)=="function","Scheduled action must be a function")
    if M.stopped or #M.queue>=64 then return false end
    M.queue[#M.queue+1]=fn
    return true
end
local function call(fn)
    local ok,err=pcall(fn)
    if not ok then print("[Stashlink] Scheduled action failed: "..tostring(err).."\n") end
end
M.tick=M.pin(function()
    if M.stopped then return end
    if M.gate then
        local ok,ready=pcall(M.gate)
        if not ok then
            if M.gate_error~=tostring(ready) then M.gate_error=tostring(ready);print('[Stashlink] Runtime gate: '..M.gate_error..'\n') end
            return
        end
        if ready~=true then return end
    end
    -- A callback may start and finish travel synchronously. Its generation
    -- change still invalidates the remaining work captured by this pulse.
    local epoch=M.epoch
    local queue=M.queue; M.queue={}
    for _,fn in ipairs(queue) do call(fn); if M.stopped or M.epoch~=epoch then return end end
    for _,task in ipairs(M.tasks) do
        task.remaining=task.remaining-1
        if task.remaining<=0 then task.remaining=task.interval; call(task.fn) end
        if M.stopped or M.epoch~=epoch then return end
    end
end)
function M.every(milliseconds,fn)
    local interval=math.max(1,math.ceil(milliseconds/16))
    M.tasks[#M.tasks+1]={interval=interval,remaining=interval,fn=M.pin(fn)}
end
function M.start()
    if M.started then return end
    assert(type(LoopInGameThreadWithDelay)=="function","This build needs game-thread loop support")
    M.started=true
    M.handle=LoopInGameThreadWithDelay(16,M.tick)
end
function M.stop()
    M.stopped=true; M.queue={}; M.tasks={}
    if M.handle and type(CancelDelayedAction)=="function" then CancelDelayedAction(M.handle) end
end
return M
