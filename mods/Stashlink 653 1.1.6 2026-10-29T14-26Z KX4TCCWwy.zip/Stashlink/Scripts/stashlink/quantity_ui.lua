local M={}
function M.bind(P,V)
    if P.click~=P.click_wrapper then P.base_click=P.click end
    if P.pointer_down~=P.pointer_down_wrapper then P.base_pointer_down=P.pointer_down end
    for _,c in ipairs(P.controls) do
        if c.action=='close' then
            local parent=c.object:GetParent()
            local drawer=P.extras_content or P.extras
            if parent and parent:IsValid() and parent:GetAddress()==drawer:GetAddress() then c.action='drawer_close';P.drawer_close=c end
        end
    end
    function P.set_drawer(open)
        local opening=open and not P.extras_open
        P.extras_open=open;P.extras:SetVisibility(open and 0 or 1)
        if P.fit_viewport then P.fit_viewport()end
        if opening and P.animate_drawer then P.animate_drawer() end
        if not open then V.entry=nil end
        if P.refresh_feedback then P.refresh_feedback() end
    end
    local click_wrapper=function(chosen)
        local control=chosen or P.hovered()
        if control and control.action=='drawer_close' then P.set_drawer(false);return end
        if control and control.action=='extras' then P.set_drawer(not P.extras_open);P.render();return end
        return P.base_click(chosen)
    end
    P.click_wrapper=click_wrapper;P.click=click_wrapper
    local pointer_wrapper=function(force_half,force_quick)
        local control=P.hovered()
        if control and (control.action=='drawer_close' or control.action=='extras') then P.click(control);return end
        return P.base_pointer_down(force_half,force_quick)
    end
    P.pointer_down_wrapper=pointer_wrapper;P.pointer_down=pointer_wrapper
end
return M
