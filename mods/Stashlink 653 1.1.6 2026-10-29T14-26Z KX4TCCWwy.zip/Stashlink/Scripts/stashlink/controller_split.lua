-- Presentation only: native split widget, with inventory intents owned by Stashlink.
local M={}
local function valid(o) return o and o:IsValid() end
local function invoke(o,name,...)return o[name](o,...)end
local function call(o,name,...)
    if not valid(o) then return false end
    return pcall(invoke,o,name,...)
end
function M.close(P)
    local split=P.controller_split
    if split and valid(split.widget) then split.widget:RemoveFromParent() end
    P.controller_split=nil
end
function M.show(P,row,amount,source)
    M.close(P)
    local cls
    for _,slot in ipairs(FindAllOf('InventorySlotBase') or {}) do
        local ok,value=pcall(function() return slot.SplitStackWidgetClass end)
        if ok and valid(value) then cls=value;break end
    end
    if not valid(cls) then
        for _,widget in ipairs(FindAllOf('WBP_Inventory_SplitStackUIButton_C') or {}) do
            if valid(widget) and not widget:GetFullName():find('Default__',1,true) then cls=widget:GetClass();break end
        end
    end
    if not valid(cls) then return false end
    local library=StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary')
    local made,widget=call(library,'Create',P.pc,cls,P.pc)
    if not made or not valid(widget) then return false end
    local slider=widget.AmountSlider;local inner=valid(slider) and slider.InputSlider
    if not valid(inner) then widget:RemoveFromParent();return false end
    local max=math.max(1,math.min(row.available,row.stack_size or row.available))
    local canvas=P.controller_canvas or P.tree.RootWidget
    local slot=canvas:AddChildToCanvas(widget);slot:SetAutoSize(true);slot:SetZOrder(500)
    local bounds=source and source.bounds or {x=700,y=200,w=60,h=60}
    local x=math.max(32,math.min(940,bounds.x+bounds.w+18));local y=math.max(32,math.min(540,bounds.y+8))
    slot:SetOffsets({Left=x,Top=y,Right=400,Bottom=150})
    -- Construction applies the designer's 1..1 range. Configure the live
    -- slider after it has joined the viewport, including the Slate range.
    call(widget,'ForceLayoutPrepass')
    pcall(function() slider.NumGamepadSliderIncrements=math.max(1,max-1) end)
    call(slider,'UpdateMaxValue',max)
    call(inner,'SetMinValue',1);call(inner,'SetMaxValue',max);call(inner,'SetStepSize',1)
    call(slider,'SetValue',math.max(1,math.min(max,amount)))
    for _,direction in ipairs({0,1,2,3}) do call(inner,'SetNavigationRuleExplicit',direction,inner) end
    call(inner,'SetUserFocus',P.pc)
    P.controller_split={widget=widget,slider=slider,inner=inner,max=max,value=amount,
        control={id='native-split',action='transfer',object=inner,bounds={x=x,y=y,w=400,h=150}}}
    return true
end
function M.amount(P,amount)
    local split=P.controller_split;if not split then return amount end
    local ok,value=call(split.inner,'GetValue')
    if ok and type(value)=='number' then amount=math.max(1,math.min(split.max,math.floor(value+.5))) end
    return amount
end
function M.set(P,amount)
    local split=P.controller_split
    if split then amount=math.max(1,math.min(split.max,amount));call(split.slider,'SetValue',amount);split.value=amount end
    return amount
end
return M
