-- Read-only live discovery of the installed build. No inventory mutations.
local M = {}
local Helpers = require("UEHelpers")
local function valid(value) return value and value:IsValid() end

function M.run(path)
    local output = assert(io.open(path, "w"))
    local function line(value) output:write(tostring(value), "\n") end
    local done = {}
    local function schema(object)
        if not valid(object) then return end
        local class = object:IsAnyClass() and object or object:GetClass()
        local depth = 0
        while valid(class) and depth < 12 do
            depth = depth + 1
            local name = class:GetFullName()
            if done[name] then break end
            done[name] = true
            line("CLASS " .. name)
            class:ForEachProperty(function(p)
                line("  PROPERTY " .. p:GetFullName())
                local n = p:GetFName():ToString()
                if n == "ItemSlots" then
                    local ok, inner = pcall(function() return p:GetInner() end)
                    if ok and inner then line("    INNER " .. inner:GetFullName()) end
                end
            end)
            class:ForEachFunction(function(fn)
                line("  FUNCTION " .. fn:GetFullName())
                fn:ForEachProperty(function(p) line("    PARAM " .. p:GetFullName()) end)
            end)
            class = class:GetSuperStruct()
        end
    end
    local ok, err = pcall(function()
        local pc = Helpers.GetPlayerController()
        assert(valid(pc), "Local player controller unavailable")
        local pawn, world = pc.Pawn, pc:GetWorld()
        assert(valid(pawn) and valid(world), "Enter a solo world first")
        local world_name = world:GetFullName()
        line("WORLD " .. world_name)
        line("PLAYER " .. pawn:GetFullName())
        schema(pc)
        schema(pawn)
        local hud_ok, hud = pcall(function() return pc:GetHUD() end)
        if hud_ok and valid(hud) then line("HUD " .. hud:GetFullName()); schema(hud) end

        local inventories = FindAllOf("InventoryComponent") or {}
        local count = 0
        for _, inventory in ipairs(inventories) do
            local inv_ok, inv_err = pcall(function()
                local owner = inventory:GetOwner()
                if not valid(owner) or not valid(owner:GetWorld()) or owner:GetWorld():GetFullName() ~= world_name then return end
                local owner_name = owner:GetFullName()
                if owner_name:find("Default__", 1, true) then return end
                local owner_class = owner:GetClass():GetFullName()
                if owner_name ~= pawn:GetFullName() and not owner_class:find("/Game/Gameplay/BaseBuilding/", 1, true)
                    and not owner_class:find("InventoryDrop", 1, true) then return end
                count = count + 1
                if count > 100 then return end
                line("INVENTORY " .. inventory:GetFullName())
                line("  OWNER " .. owner_name)
                schema(owner)
                schema(inventory)
                local slots = inventory.MaxSlotCount
                line("  MAX_SLOTS " .. tostring(slots))
                line("  QUICK_SLOTS " .. tostring(inventory.NumberOfQuickActionSlots))
                line("  LOADED " .. tostring(inventory.bHasLoadedFromSave))
                assert(type(slots) == "number" and slots >= 0 and slots <= 1000, "Unexpected slot count")
                for slot = 0, slots - 1 do
                    local item = inventory:GetItemFromSlot(slot)
                    if valid(item) then
                        line("  SLOT " .. slot .. " COUNT " .. inventory:GetNumItemsInSlot(slot) .. " ITEM " .. item:GetFullName())
                        schema(item)
                        local class = item:GetClass()
                        local inspected = {}
                        for _ = 1, 6 do
                            if not valid(class) then break end
                            class:ForEachProperty(function(p)
                                local n = p:GetFName():ToString()
                                if not inspected[n] and p:GetFullName():match("^ObjectProperty ") then
                                    inspected[n] = true
                                    local value_ok, value = pcall(function() return item[n] end)
                                    if value_ok and valid(value) then
                                        line("    OBJECT_VALUE " .. n .. " " .. value:GetFullName())
                                        if value:GetClass():GetFullName():find("ItemData", 1, true) then schema(value) end
                                    end
                                end
                            end)
                            class = class:GetSuperStruct()
                        end
                    end
                end
            end)
            if not inv_ok then line("INVENTORY_ERROR " .. tostring(inv_err)) end
        end
        ForEachUObject(function(object)
            if not valid(object) then return end
            local name = object:GetFName():ToString()
            if name == "GetLinkedInventories" or name == "FillStacksOnTarget" or name == "GetItemName" then
                line("TARGET " .. object:GetFullName())
                object:ForEachProperty(function(p) line("  PARAM " .. p:GetFullName()) end)
            end
        end)
        local player_inventory = pc.InventoryComponent
        schema(player_inventory)
        schema(pc.LoadoutComponent)
        line("PLAYER_INVENTORY " .. player_inventory:GetFullName())
        line("PLAYER_QUICK " .. tostring(player_inventory.NumberOfQuickActionSlots))
        line("PLAYER_MAX " .. tostring(player_inventory.MaxSlotCount))
        local enums=StaticFindObject("/Script/Dominion.EInventorySlotType")
        player_inventory.InventoryPages:ForEach(function(i,p)
            local page=p:get()
            line("PLAYER_PAGE "..i.." type="..page.SlotType.." name="..enums:GetNameByValue(page.SlotType):ToString().." slots="..page.NumSlots)
        end)
        for slot = 0, player_inventory.MaxSlotCount - 1 do
            local item = player_inventory:GetItemFromSlot(slot)
            if valid(item) then
                line("PLAYER_SLOT " .. slot .. " COUNT " .. player_inventory:GetNumItemsInSlot(slot) .. " ITEM " .. item:GetFullName())
                line("PLAYER_DATA " .. item.ItemData:GetFullName())
                local name_ok, name = pcall(function() return item:GetPlayerFacingName():ToString() end)
                line("PLAYER_NAME " .. tostring(name_ok) .. " " .. tostring(name))
            end
        end
        local library = StaticFindObject("/Script/Dominion.Default__CraftingFunctionLibrary")
        line("LIBRARY " .. (valid(library) and library:GetFullName() or "unavailable"))
        for _, ledger in ipairs(FindAllOf("BP_InventoryDropoffPoint_C") or {}) do
            if valid(ledger) and ledger:GetWorld():GetFullName() == world_name then
                local here, player_pos = ledger:K2_GetActorLocation(), pawn:K2_GetActorLocation()
                line("LEDGER " .. ledger:GetFullName())
                line("LEDGER_DISTANCE " .. math.sqrt((here.X-player_pos.X)^2+(here.Y-player_pos.Y)^2+(here.Z-player_pos.Z)^2))
                local linked = {}
                local call_ok, result = pcall(function() return library:GetLinkedInventories(ledger, here, {}, linked) end)
                line("LINK_RESULT " .. tostring(call_ok) .. " " .. tostring(result) .. " count=" .. #linked)
                for _, wrapped in ipairs(linked) do
                    local unwrap_ok, inventory = pcall(function() return wrapped:get() end)
                    if not unwrap_ok then inventory = wrapped end
                    line("LINKED " .. inventory:GetFullName())
                    for slot=0,inventory.MaxSlotCount-1 do
                        local item=inventory:GetItemFromSlot(slot)
                        if valid(item) and item:GetPlayerFacingName():ToString()=="Stone" then
                            line("ROUTE_STONE source_slot="..slot.." count="..item:GetStackSize().." native_source_lookup="..inventory:GetSlotForItem(item)
                                .." player_lookup="..player_inventory:GetSlotForItem(item).." category_lookup="..player_inventory:GetSlotForItemByCategory(item.ItemData:GetCategory())
                                .." category="..item.ItemData:GetCategory().TagName:ToString().." empty="..player_inventory:GetNumEmptySlots())
                            local taglib=StaticFindObject("/Script/GameplayTags.Default__BlueprintGameplayTagLibrary")
                            schema(taglib)
                            player_inventory.InventoryPages:ForEach(function(page_index,entry)
                                local page=entry:get()
                                local match_ok,matches=pcall(function() return taglib:DoesContainerMatchTagQuery(item.ItemData.ItemFilterTags,page.AllowedItemFilter) end)
                                line("PAGE_MATCH "..page_index.." "..tostring(match_ok).." "..tostring(matches))
                                local detail_ok,detail=pcall(function()
                                    local query=page.AllowedItemFilter
                                    local cat=taglib:MakeGameplayTagContainerFromTag(item.ItemData:GetCategory())
                                    return "empty="..tostring(taglib:IsTagQueryEmpty(query)).." categorymatch="..tostring(taglib:DoesContainerMatchTagQuery(cat,query))
                                        .." tokens="..#query.QueryTokenStream.." description="..query.AutoDescription:ToString()
                                end)
                                line("PAGE_DETAIL "..page_index.." "..tostring(detail_ok).." "..tostring(detail))
                                local bytes,dict,tags={},{},{}
                                page.AllowedItemFilter.QueryTokenStream:ForEach(function(_,v) bytes[#bytes+1]=v:get() end)
                                page.AllowedItemFilter.TagDictionary:ForEach(function(_,v) dict[#dict+1]=v:get().TagName:ToString() end)
                                item.ItemData.ItemFilterTags.GameplayTags:ForEach(function(_,v) tags[#tags+1]=v:get().TagName:ToString() end)
                                line("PAGE_RAW "..page_index.." bytes="..table.concat(bytes,",").." dictionary="..table.concat(dict,",").." itemtags="..table.concat(tags,","))
                            end)
                            break
                        end
                    end
                    local owner = inventory:GetOwner()
                    local own_ok, ownership = pcall(function() return owner.OwnershipComponent end)
                    if own_ok and valid(ownership) then schema(ownership) end
                end
                schema(ledger.Interaction)
            end
        end
        line("END inventories=" .. count)
    end)
    output:close()
    if not ok then error(err) end
    return "Live inspection saved to " .. path
end

M.bindings_run=M.run
function M.run(path)
    package.loaded["stashlink.ui_probe"]=nil
    return require("stashlink.ui_probe").run(path..".ui")
end
return M
