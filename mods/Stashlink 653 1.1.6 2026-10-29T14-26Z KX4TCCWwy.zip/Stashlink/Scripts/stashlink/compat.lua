-- Native write-path compatibility for every game and loader combination.
-- A game update may keep or change the reflected functions the
-- transfer path calls; this compares them with the signatures recorded on the
-- validated build (see BINDINGS.md). Matching bindings permit transfers, which
-- still verify every native result and pause on anything unverifiable.
-- Any mismatch keeps Stashlink read-only and names the changed binding.
local M={}
M.functions={
    ['/Script/Dominion.InventoryComponent:MoveItem']='IntProperty:SlotIndex|ObjectProperty:TargetInventory|IntProperty:TargetSlotIndex|ObjectProperty:Instigator|IntProperty:Amount|BoolProperty:ReturnValue',
    ['/Script/Dominion.InventoryComponent:GetItemFromSlot']='IntProperty:SlotIndex|ObjectProperty:ReturnValue',
    ['/Script/Dominion.InventoryComponent:GetNumItemsInSlot']='IntProperty:Index|IntProperty:ReturnValue',
    ['/Script/Dominion.InventoryComponent:IsItemAllowed']='ObjectProperty:Item|BoolProperty:ReturnValue',
    ['/Script/Dominion.Item:GetGuid']='StructProperty:ReturnValue',
    ['/Script/Dominion.Item:IsSameType']='ObjectProperty:Item|BoolProperty:ReturnValue',
    ['/Script/Dominion.Item:GetStackFreeSpace']='IntProperty:ReturnValue',
    ['/Script/Dominion.CraftingFunctionLibrary:GetLinkedInventories']='ObjectProperty:WorldContextObject|StructProperty:BuildingPieceLocation|ArrayProperty:InDefaultInventories|ArrayProperty:OutAvailableInventories',
    ['/Script/Dominion.OwnershipComponent:IsPrivatelyLockedFromPlayer']='StructProperty:InteractingPlayerGuid|BoolProperty:ReturnValue',
    ['/Script/Dominion.LinkedInventoryComponent:IsLinkable']='BoolProperty:ReturnValue',
    ['/Script/Dominion.InventoryController:SortInventory']='ObjectProperty:Inventory',
    ['/Script/Dominion.InventoryController:UseItemFromInventory']='ObjectProperty:Inventory|IntProperty:SlotIndex',
    ['/Script/GameplayTags.BlueprintGameplayTagLibrary:DoesContainerMatchTagQuery']='StructProperty:TagContainer|StructProperty:TagQuery|BoolProperty:ReturnValue',
    ['/Script/GameplayTags.BlueprintGameplayTagLibrary:IsTagQueryEmpty']='StructProperty:TagQuery|BoolProperty:ReturnValue',
}
M.properties={
    ['/Script/Dominion.Item']={Count='IntProperty',Durability='IntProperty',Guid='StructProperty',NumMasterworkUpgradesApplied='ByteProperty'},
    ['/Script/Dominion.InventoryComponent']={ItemSlots='ArrayProperty',bAllowAdds='BoolProperty',bAllowRemoves='BoolProperty'},
}
M.network_functions={
    ['/Script/Dominion.InventoryController:Server_MoveItemBetweenInventories']='ObjectProperty:SourceInventory|IntProperty:SourceSlotIndex|ObjectProperty:TargetInventory|IntProperty:TargetSlotIndex',
    ['/Script/Dominion.InventoryController:Server_SplitAndPutStack']='ObjectProperty:SourceInventory|IntProperty:SourceSlotIndex|IntProperty:Amount|ObjectProperty:TargetInventory|IntProperty:TargetSlotIndex',
}
local function valid(o) return o and o:IsValid() end
local function field(p)
    local full=p:GetFullName()
    return full:match('^(%S+)'),full:match('([^:]+)$')
end
function M.signature(fn)
    local fields={}
    fn:ForEachProperty(function(p) local kind,name=field(p);fields[#fields+1]=kind..':'..name end)
    return table.concat(fields,'|')
end
function M.check_network(find)
    find=find or StaticFindObject
    for path,expected in pairs(M.network_functions) do
        local fn=find(path)
        if not valid(fn) then return false,'missing '..path end
        if M.signature(fn)~=expected then return false,'changed '..path end
    end
    return true
end
-- Returns true, or false and the first changed binding. Game thread only.
function M.check(find)
    find=find or StaticFindObject
    local names={}
    for name in pairs(M.functions) do names[#names+1]=name end
    table.sort(names)
    for _,name in ipairs(names) do
        local fn=find(name)
        if not valid(fn) then return false,'missing '..name end
        if M.signature(fn)~=M.functions[name] then return false,'changed '..name end
    end
    local classes={}
    for name in pairs(M.properties) do classes[#classes+1]=name end
    table.sort(classes)
    for _,name in ipairs(classes) do
        local class=find(name)
        if not valid(class) then return false,'missing '..name end
        local seen={}
        class:ForEachProperty(function(p) local kind,field_name=field(p);seen[field_name]=kind end)
        for field_name,kind in pairs(M.properties[name]) do
            if seen[field_name]~=kind then return false,'changed '..name..'.'..field_name end
        end
    end
    return true
end
return M
