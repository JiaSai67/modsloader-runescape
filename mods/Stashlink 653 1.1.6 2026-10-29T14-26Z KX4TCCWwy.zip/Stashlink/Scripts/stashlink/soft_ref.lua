-- Soft object references without letting UE4SS copy them into Lua.
-- UE4SS builds since late August 2026 crash in this game whenever Lua reads a
-- SoftObjectProperty (push_softobjectproperty copies an FSoftObjectPath with a
-- runtime layout that does not match). Here a soft pointer is 0x28 bytes:
-- FWeakObjectPtr, then the FTopLevelAssetPath PackageName and AssetName FNames,
-- then SubPathString. Only the two names are read, through custom NameProperty
-- views, and the asset is found or loaded by path. Metadata checks reject
-- unsupported layouts before registering or reading a view. These checks do
-- not independently prove the internal layout of every future soft pointer.
local M={views={},loaded={},fields={},owners={},checked={},failures={}}
local SOFT_SIZE=0x28
local layouts={
    ['/Script/Dominion.ItemData']={
        Icon={'Icon','CategoryClassIcon','SoftObjectProperty'},
        CategoryClassIcon={'CategoryClassIcon','StaticMesh','SoftObjectProperty'},
    },
    ['/Script/Dominion.ContainerContentDataAsset']={
        InventorySlotIcon={'InventorySlotIcon','InventorySlotIconTint','StructProperty'},
    },
    ['/Script/Dominion.MasterworkEquipmentSlotStyling']={
        PartiallyAscendedIcon={'PartiallyAscendedIcon','FullyAscendedIcon','SoftObjectProperty'},
        -- This is the final reflected field: only the preceding pair is
        -- available. The loader exposes no per-property or struct size getter.
        FullyAscendedIcon={'PartiallyAscendedIcon','FullyAscendedIcon','SoftObjectProperty'},
    },
}
local function valid(o) return o and o:IsValid() end
local function check(condition,reason) if not condition then error(reason,0) end end
local function warn(key,reason)
    if M.failures[key] then return end
    M.failures[key]=tostring(reason)
    print('[Stashlink] Icon hidden for '..key..': '..tostring(reason)..'.\n')
end
local function field(struct_path,name)
    local key=struct_path..':'..name
    if not M.owners[struct_path] then
        local owner=StaticFindObject(struct_path)
        check(valid(owner),'Missing reflected owner '..struct_path)
        owner:ForEachProperty(function(p) M.fields[struct_path..':'..p:GetFName():ToString()]=p end)
        M.owners[struct_path]=true
    end
    check(M.fields[key]~=nil,'Missing reflected field '..key)
    return M.fields[key]
end
local function offset(struct_path,name,kind)
    local p=field(struct_path,name)
    local expected=kind..' '..struct_path..':'..name
    local actual=p:GetFullName()
    check(actual==expected,'Expected '..expected..'; found '..tostring(actual))
    local n=p:GetOffset_Internal()
    -- RegisterCustomProperty uses signed 32-bit offsets. Both 8-byte name
    -- views must fit without an offset overflow.
    check(type(n)=='number' and n>=0 and n<=0x7fffffff-24 and n==math.floor(n),
        'Invalid offset for '..struct_path..':'..name..': '..tostring(n))
    return n
end
-- These type sizes are exposed by UE4SS as metadata, not item-value reads.
function M.layout_ok()
    if M.layout==nil then
        local ok,reason=pcall(function()
            for _,name in ipairs({'NameProperty','WeakObjectProperty'}) do
                local property=PropertyTypes and PropertyTypes[name]
                local size=type(property)=='table' and property.Size or nil
                check(size==8,'PropertyTypes.'..name..'.Size must be 8; found '..tostring(size))
            end
        end)
        M.layout=ok
        if not ok then warn('soft-reference layout',reason) end
    end
    return M.layout
end
local function field_ok(struct_path,name)
    local key=struct_path..':'..name
    if M.checked[key]~=nil then return M.checked[key] end
    local ok,reason=pcall(function()
        local layout=layouts[struct_path] and layouts[struct_path][name]
        check(layout~=nil,'No audited soft-reference layout for '..key)
        offset(struct_path,name,'SoftObjectProperty')
        local first=offset(struct_path,layout[1],'SoftObjectProperty')
        local following=offset(struct_path,layout[2],layout[3])
        check(following-first==SOFT_SIZE,
            'Expected 40-byte spacing for '..struct_path..':'..layout[1]..' -> '..layout[2]..'; found '..tostring(following-first))
    end)
    M.checked[key]=ok
    if not ok then warn(key,reason) end
    return ok
end
local function register(key,class_path,offset)
    local names=M.views[key]
    if names then return names end
    local id='Stashlink_Soft_'..key:gsub('%W','_')
    names={package=id..'_Package',asset=id..'_Asset'}
    local function view(name,delta)
        RegisterCustomProperty({Name=name,Type=PropertyTypes.NameProperty,BelongsToClass=class_path,
            OffsetInternal=type(offset)=='table' and {Property=offset.Property,RelativeOffset=delta} or offset+delta})
    end
    view(names.package,8); view(names.asset,16)
    -- Struct field lookups use FNAME_Find, so the view names must exist.
    local add=EFindName and EFindName.FNAME_Add
    for _,name in pairs(names) do if add then FName(name,add) else FName(name) end end
    M.views[key]=names
    return names
end
local function load(object,names)
    local package,asset=object[names.package]:ToString(),object[names.asset]:ToString()
    if package:sub(1,1)~='/' or asset=='' or asset=='None' or asset:find('[/.]') then return nil end
    local path=package..'.'..asset
    local o=M.loaded[path]
    -- Lua UObject wrappers do not keep assets alive. After an icon leaves the
    -- rooted widget cache, Unreal can collect it and reuse its address for a
    -- different texture; IsValid alone then accepts the wrong asset.
    local matches=false
    if valid(o) then
        local ok,full_name=pcall(o.GetFullName,o)
        matches=ok and type(full_name)=='string' and full_name:gsub('^%S+%s+','')==path
    end
    if not matches then
        -- LoadAsset resolves through the asset registry, including assets
        -- already resident. StaticFindObject scans the live object set and
        -- measured 50–68 ms per cold icon in the large catalog test world.
        o=LoadAsset(path)
        M.loaded[path]=o
    end
    return valid(o) and o or nil
end
local function resolve(object,class_path,name)
    if not M.layout_ok() or not field_ok(class_path,name) then return nil end
    local key=class_path..':'..name
    local ok,names=pcall(register,key,class_path,{Property=name})
    if not ok then
        M.checked[key]=false
        warn(key,'Custom name-view registration failed: '..tostring(names))
        return nil
    end
    return load(object,names)
end
-- The asset referenced by the soft property class_path:name on object.
function M.load(object,class_path,name)
    if not valid(object) then return nil end
    return resolve(object,class_path,name)
end
-- The asset referenced by the soft field struct_path:name of a struct value,
-- such as a TMap value. The views belong to the struct type itself.
function M.load_in_struct(value,struct_path,name)
    if not value then return nil end
    return resolve(value,struct_path,name)
end
return M
