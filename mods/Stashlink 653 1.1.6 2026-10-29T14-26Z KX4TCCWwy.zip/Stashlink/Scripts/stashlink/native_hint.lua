-- Passive widgets inside the local interaction HUD; no viewport or input owner.
local M={}
local function valid(o)return o and o:IsValid()end
local function same(a,b)return valid(a)and valid(b)and a:GetAddress()==b:GetAddress()end
function M.hide(keep_primary)
 if not keep_primary then M.restore_primary()end
 if valid(M.row)and M.row:GetVisibility()~=1 then M.row:SetVisibility(1)end
end
function M.forget()
 -- Preserve desired input presentation; discard every owned native wrapper.
 M.hud=nil;M.owner=nil;M.row=nil;M.image=nil;M.key=nil;M.label=nil;M.keyboard_texture=nil
 M.applied_input=nil;M.retry_at=nil;M.disabled=nil
 M.input_hud=nil;M.input_player=nil;M.input_subsystem=nil;M.input_type=nil;M.input_retry_at=nil;M.input_error_until=nil
 M.primary_saved=nil
 M.find_owner=nil;M.find_retry_at=nil
end
function M.reset()
 M.restore_primary()
 local row=M.row;M.forget()
 if valid(row)then row:RemoveFromParent()end
end
function M.restore_primary()
 local saved=M.primary_saved;M.primary_saved=nil
 if saved then pcall(function()
  if valid(saved.widget)and saved.widget:GetText():ToString()=='F'then saved.widget:SetText(FText(saved.original))end
 end)end
end
function M.create(hud)
 local tree=hud.WidgetTree;local parent=hud.PromptInput:GetParent();local title=hud.ItemNameTextBlock
 local texture=hud.SecondaryPromptInput.InputActionWidget.StandardBackgroundImage
 if not(valid(tree)and valid(parent)and valid(title)and valid(texture))then return false end
 M.serial=(M.serial or 0)+1;local n=0
 local function make(kind)
  n=n+1
  local o=StaticConstructObject(StaticFindObject('/Script/UMG.'..kind),tree,FName('StashlinkNativeHint_'..M.serial..'_'..n),0x40)
  assert(valid(o),'Native hint element unavailable');return o
 end
 local row=make('HorizontalBox');M.row=row;row:SetVisibility(1)
 local box=make('SizeBox');box:SetWidthOverride(32);box:SetHeightOverride(32)
 local slot=row:AddChildToHorizontalBox(box);slot:SetVerticalAlignment(2)
 local overlay=make('Overlay');box:SetContent(overlay)
 local image=make('Image');image:SetBrushFromTexture(texture,false);overlay:AddChildToOverlay(image)
 local key=make('TextBlock');key:SetFont(title.Font);key:SetText(FText('F'));key:SetJustification(1)
 key:SetColorAndOpacity({SpecifiedColor={R=.76,G=.76,B=.76,A=1},ColorUseRule=0})
 key:SetShadowOffset({X=1,Y=1});key:SetShadowColorAndOpacity({R=0,G=0,B=0,A=.9})
 slot=overlay:AddChildToOverlay(key);slot:SetHorizontalAlignment(0);slot:SetVerticalAlignment(2)
 local label=make('TextBlock');label:SetFont(title.Font);label:SetText(FText('Open Stashlink'))
 label:SetColorAndOpacity({SpecifiedColor={R=.65,G=.65,B=.65,A=1},ColorUseRule=0})
 label:SetShadowOffset({X=2,Y=2});label:SetShadowColorAndOpacity({R=0,G=0,B=0,A=.9})
 slot=row:AddChildToHorizontalBox(label);slot:SetPadding({Left=6,Top=0,Right=0,Bottom=0});slot:SetVerticalAlignment(2)
 M.image=image;M.key=key;M.keyboard_texture=texture;M.label=label
 slot=parent:AddChildToVerticalBox(row);slot:SetHorizontalAlignment(0)
 return true
end
-- Read the owning player's last input method at the existing prompt cadence.
-- A connected pad remains eligible to open the bank, but is not proof that
-- the player is currently using it. Never select another local player's input.
function M.observe_input(hud)
 if M.input_error_until and os.time()<M.input_error_until then M.input_type=0;return 0 end
 M.input_error_until=nil
 local ok,kind=pcall(function()
  if not valid(hud)then return 0 end
  if not same(M.input_hud,hud)then
   M.input_hud=hud;M.input_player=nil;M.input_subsystem=nil;M.input_retry_at=nil
  end
  if not valid(M.input_player)then
   M.input_player=hud:GetOwningLocalPlayer()
   if not valid(M.input_player)then return 0 end
  end
  local subsystem=M.input_subsystem
  if not valid(subsystem)then
   if M.input_retry_at and os.time()<M.input_retry_at then return 0 end
   M.input_retry_at=os.time()+1
   for _,candidate in ipairs(type(FindAllOf)=='function'and FindAllOf('CommonInputSubsystem')or{})do
    local checked,owned=pcall(function()return valid(candidate)and same(candidate:GetOuter(),M.input_player)end)
    if checked and owned then subsystem=candidate;M.input_subsystem=candidate;M.input_retry_at=nil;break end
   end
   if not valid(subsystem)then return 0 end
  end
  local value=tonumber(subsystem:GetCurrentInputType())
  return (value==0 or value==1 or value==2)and value or 0
 end)
 M.input_type=ok and kind or 0
 if not ok then
  M.input_hud=nil;M.input_player=nil;M.input_subsystem=nil;M.input_retry_at=nil;M.input_error_until=os.time()+1
 end
 return M.input_type
end
function M.set_controller(active,key,family)
 M.controller=active==true
 M.controller_key=key or 'Y';M.controller_family=family or 'Xbox'
 local controller=M.controller and (M.input_type==nil or M.input_type==1)
 local mode=tostring(controller)..':'..M.controller_key..':'..M.controller_family..':'..(M.keyboard_key or 'F')
 if not valid(M.row)or M.applied_input==mode then return end
 if valid(M.label)then M.label:SetText(FText(controller and M.controller_key=='MENU'and 'Open Stashlink (Hold and release Menu)'or 'Open Stashlink'))end
 if controller then
  local G=require('stashlink.controller_glyph');local texture=StaticFindObject(G.path(M.controller_key,M.controller_family))
  if valid(texture)then M.image:SetBrushFromTexture(texture,false);M.key:SetVisibility(1)
  else M.image:SetBrushFromTexture(M.keyboard_texture,false);M.key:SetText(FText(M.controller_key=='MENU'and 'Menu'or M.controller_key));M.key:SetVisibility(3)end
 else
  M.image:SetBrushFromTexture(M.keyboard_texture,false);M.key:SetText(FText(M.keyboard_key or 'F'));M.key:SetVisibility(3)
 end
 M.applied_input=mode
end
function M.set_keyboard_key(key)
 assert(require('stashlink.ledger_keys').info(key),'Invalid ledger keyboard hint')
 if M.keyboard_key==key then return end
 M.keyboard_key=key;M.applied_input=nil
 M.set_controller(M.controller,M.controller_key,M.controller_family)
end
local function find(pc)
 if same(M.owner,pc)and valid(M.hud)and same(M.hud:GetOwningPlayer(),pc)then return M.hud end
 local owner=valid(pc)and pc:GetAddress()or nil;local now=os.clock()
 if M.find_owner==owner and M.find_retry_at and now<M.find_retry_at then return end
 M.reset()
 M.find_owner=owner;M.find_retry_at=now+1
 if type(FindAllOf)~='function'then return end
 for _,hud in ipairs(FindAllOf('WBP_HUD_InteractionPrompt_C')or{})do
  if valid(hud)and same(hud:GetOwningPlayer(),pc)then M.hud=hud;M.owner=pc;M.find_retry_at=nil;return hud end
 end
end
-- Change only this HUD instance's keyboard letter; never a shared action asset.
-- Native input-method changes still own controller glyphs and visibility.
function M.primary(pc,actor,key)
 if not key then M.restore_primary();return end
 local ok=pcall(function()
  local hud=find(pc)
  if not hud or not same(hud.CurrentWorldActor,actor)then M.restore_primary();return end
  if M.observe_input(hud)==1 then M.restore_primary();return end
  local label=hud.PromptInput.InputActionWidget.KeyText
  if not valid(label)then return end
  if not(M.primary_saved and same(M.primary_saved.widget,label))then
   M.restore_primary();M.primary_saved={widget=label,original=label:GetText():ToString()}
  end
  if label:GetText():ToString()~=key then label:SetText(FText(key))end
 end)
 return ok
end
function M.show(pc,actor)
 if not valid(pc)or not valid(actor)then M.hide();return false end
 if not valid(M.hud)and M.retry_at and os.time()<M.retry_at then return false end
 local hud=find(pc)
 if not hud then M.retry_at=os.time()+1;return false end
 if not same(hud.CurrentWorldActor,actor)or hud:GetVisibility()==1 or hud:GetVisibility()==2 then M.hide();return false end
 M.observe_input(hud)
 if not valid(M.row)and not M.create(hud)then return false end
 M.set_controller(M.controller,M.controller_key,M.controller_family)
 if M.row:GetVisibility()~=4 then M.row:SetVisibility(4)end
 return true
end
return M
