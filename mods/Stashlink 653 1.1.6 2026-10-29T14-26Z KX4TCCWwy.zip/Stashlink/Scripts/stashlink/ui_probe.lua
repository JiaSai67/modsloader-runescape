local M={}
local function valid(o) return o and o:IsValid() end
local function name(o) return valid(o) and o:GetFullName() or "none" end
function M.run(path)
 local f=assert(io.open(path,"w"));local function line(s) f:write(s,"\n");f:flush() end
 local classes={};local function isa(o,n)
  if not valid(o) then return false end
  local c=classes[n];if not c then c=StaticFindObject("/Script/UMG."..n);classes[n]=c end
  return valid(c) and o:IsA(c)
 end
 local function brush(b) line("BRUSH "..name(b.ResourceObject).." draw="..b.DrawAs) end
 local seen={};local walk
 walk=function(w,depth)
  if not valid(w) or depth>20 or seen[w:GetAddress()] then return end
  seen[w:GetAddress()]=true
  local cls=w:GetClass();if not valid(cls) then return end
  local c=cls:GetFName():ToString(); local n=w:GetFName():ToString()
  line(c.." "..n)
  if isa(w,"Image") then brush(w.Brush) end
  if isa(w,"CheckBox") then for _,k in ipairs({"UncheckedImage","CheckedImage"}) do brush(w.WidgetStyle[k]) end end
  if isa(w,"ProgressBar") then brush(w.WidgetStyle.BackgroundImage);brush(w.WidgetStyle.FillImage) end
  if isa(w,"PanelWidget") then for i=0,w:GetChildrenCount()-1 do walk(w:GetChildAt(i),depth+1) end
  elseif isa(w,"UserWidget") and valid(w.WidgetTree) then walk(w.WidgetTree.RootWidget,depth+1) end
 end
 local ok,err=pcall(function()
  local pc=require("stashlink.service").adapter:context().pc
  local hud=pc:GetHUD();assert(valid(hud),"HUD not ready")
  local panel=hud:GetInventoryWidget();assert(valid(panel),"Native inventory not ready")
  local content=panel.InventoryContent;assert(valid(content),"Native content unavailable")
  local group=content.CategoryButtonGroup;assert(valid(group),"Native tabs unavailable")
  walk(group,0)
  walk(content.WeightBar,0)
  walk(content.EquipmentBar,0)
  local power=StaticFindObject("/Game/UI/Inventory/EquipmentBar/WBP_InventoryPowerLevelDisplay.WBP_InventoryPowerLevelDisplay_C:WidgetTree.PowerLevelIcon")
  if valid(power) then brush(power.Brush) end
  local cls=StaticFindObject("/Script/Dominion.SelectableItemButton")
  if valid(cls) then
   cls:ForEachProperty(function(p) line("PROP "..p:GetFullName()) end)
  end
  local slotclass=StaticFindObject("/Script/Dominion.InventorySlotBase")
  local found=false
  local seek
  seek=function(w,depth)
   if found or not valid(w) or depth>20 then return end
   if w:IsA(slotclass) then
    found=true
    line("SLOT "..name(w))
    local image=w.ItemImage
    if valid(image) then
     local material=image.Brush.ResourceObject
     line("SLOT_MATERIAL "..name(material))
     if valid(material) then
      line("PARENT "..name(material.Parent))
      for _,kind in ipairs({"ScalarParameterValues","TextureParameterValues"}) do
       material[kind]:ForEach(function(_,v)
        local p=v:get();local value=p.ParameterValue
        if kind=="TextureParameterValues" then value=name(value) end
        line(kind.." "..p.ParameterInfo.Name:ToString().."="..tostring(value))
       end)
      end
     end
    end
    return
   end
   if isa(w,"PanelWidget") then for i=0,w:GetChildrenCount()-1 do seek(w:GetChildAt(i),depth+1) end
   elseif isa(w,"UserWidget") and valid(w.WidgetTree) then seek(w.WidgetTree.RootWidget,depth+1) end
  end
  seek(hud:GetWorldActorInventory(),0)
 end)
 f:close();if not ok then error(err) end;return "Targeted native style fields read"
end
return M
