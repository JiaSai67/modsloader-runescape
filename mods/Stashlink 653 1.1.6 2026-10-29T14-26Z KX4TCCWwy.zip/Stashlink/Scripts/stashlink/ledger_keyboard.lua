-- Owned, ledger-only keyboard contexts. The game's native Interact action is
-- reused unchanged. Bank input consumes E/F before GameAndUI can expose it.
local Prefs=require('stashlink.ledger_key_preferences')
local Hardware=require('stashlink.hardware_input')
local M={mode='off'}
local primary_path='/Game/Gameplay/Inputs/Actions/Basic/IA_Interact.IA_Interact'
local deferred={bIgnoreAllPressedKeysUntilRelease=false,bForceImmediately=false,bNotifyUserSettings=false}
local immediate={bIgnoreAllPressedKeysUntilRelease=false,bForceImmediately=true,bNotifyUserSettings=false}
local function valid(o)return o and o:IsValid()end
local function same(a,b)return valid(a)and valid(b)and a:GetAddress()==b:GetAddress()end
local function method(o,name,...)return o[name](o,...)end
local function invoke(o,name,...)
 if not valid(o)then return false,'Keyboard input owner unavailable'end
 return pcall(method,o,name,...)
end
local function held(keys)return not keys or keys.E or keys.F end
function M.forget()
 -- Post-travel: no calls on wrappers from the old player/world.
 M.mode='off';M.pc=nil;M.world=nil;M.local_player=nil;M.subsystem=nil;M.hud=nil
 M.primary=nil;M.world_context=nil;M.bank_context=nil;M.world_e=nil;M.bank_e=nil;M.bank_f=nil
 M.world_added=nil;M.bank_added=nil;M.pending_since=nil;M.error=nil;M.last_context=nil
end
local function remove(which,force)
 if not M[which..'_added']then return true end
 local ok,why=invoke(M.subsystem,'RemoveMappingContext',M[which..'_context'],force and immediate or deferred)
 if ok then M[which..'_added']=nil end
 return ok,why
end
function M.reset()
 -- Called while the old world still exists, before the pure forget phase.
 local a,why=remove('world',true);local b,error=remove('bank',true)
 if a and b then M.forget();return true end
 return nil,tostring(why or error)
end
local function owner(c)
 if not(c and valid(c.pc)and valid(c.world))then return nil,'Keyboard player context unavailable'end
 if same(M.pc,c.pc)and same(M.world,c.world)and valid(M.subsystem)then M.last_context=c;return true end
 if M.pc then
  -- Travel's pre hook owns detachment; never inspect old objects after travel.
  if M.world and not same(M.world,c.world)then M.forget()
  else local ok,why=M.reset();if not ok then return nil,why end end
 end
 if type(RegisterLoadMapPreHook)~='function'then return nil,'Ledger key swap requires pre-travel cleanup support'end
 local keys,why=Hardware.keyboard_state();if not keys then return nil,why end
 if type(FindAllOf)~='function'then return nil,'Keyboard subsystem discovery unavailable'end
 local hud,player,subsystem
 for _,candidate in ipairs(FindAllOf('WBP_HUD_InteractionPrompt_C')or{})do
  if valid(candidate)and same(candidate:GetOwningPlayer(),c.pc)then hud=candidate;player=candidate:GetOwningLocalPlayer();break end
 end
 if not valid(player)then return nil,'Local keyboard player unavailable'end
 for _,candidate in ipairs(FindAllOf('EnhancedInputLocalPlayerSubsystem')or{})do
  if valid(candidate)and same(candidate:GetOuter(),player)then subsystem=candidate;break end
 end
 if not valid(subsystem)then return nil,'Owned keyboard subsystem unavailable'end
 local primary=StaticFindObject(primary_path)
 if not valid(primary)then return nil,'Native ledger interaction action unavailable'end
 M.pc,M.world,M.local_player,M.subsystem,M.hud,M.primary=c.pc,c.world,player,subsystem,hud,primary
 M.last_context=c;return true,nil,keys
end
local function construct(which)
 if valid(M[which..'_context'])then return true end
 local context_class=StaticFindObject('/Script/EnhancedInput.InputMappingContext')
 local action_class=StaticFindObject('/Script/EnhancedInput.InputAction')
 if not(valid(context_class)and valid(action_class))then return nil,'Keyboard mapping classes unavailable'end
 local context=StaticConstructObject(context_class,M.subsystem)
 if not valid(context)then return nil,'Keyboard mapping unavailable'end
 local function action(key)
  local result=StaticConstructObject(action_class,M.subsystem)
  assert(valid(result),'Keyboard action unavailable')
  result.bConsumeInput=true;result.ValueType=0
  context:MapKey(result,{KeyName=FName(key)})
  return result
 end
 if which=='world'then
  M.world_e=action('E');context:MapKey(M.primary,{KeyName=FName('F')})
 else M.bank_e=action('E');M.bank_f=action('F')end
 M[which..'_context']=context;return true
end
local function add(which,force)
 if M[which..'_added']then return true end
 local ok,why=construct(which);if not ok then return nil,why end
 ok,why=invoke(M.subsystem,'AddMappingContext',M[which..'_context'],which=='bank'and 100021 or 100020,force and immediate or deferred)
 if ok then M[which..'_added']=true;M.pending_since=os.clock()end
 return ok,why
end
local function mapped(which)
 local ok,result=pcall(function()
  local input=M.pc.PlayerInput
  if not valid(input)or not same(input:GetOuter(),M.pc)then return false end
  local found={};local unexpected=false;local primary=M.primary:GetAddress()
  local we=valid(M.world_e)and M.world_e:GetAddress()
  local be=valid(M.bank_e)and M.bank_e:GetAddress()
  local bf=valid(M.bank_f)and M.bank_f:GetAddress()
  input.EnhancedActionMappings:ForEach(function(_,wrapped)
   local row=wrapped:get();local key=row.Key.KeyName
   local name=type(key)=='string'and key or key:ToString()
   if(name=='E'or name=='F')and valid(row.Action)then
    local address=row.Action:GetAddress()
    if which=='world'and not((name=='E'and address==we)or(name=='F'and address==primary))then unexpected=true end
    if which=='bank'and not((name=='E'and address==be)or(name=='F'and address==bf))then unexpected=true end
    if address==primary then found['native'..name]=true
    elseif address==we then found['world'..name]=true
    elseif address==be then found['bankE'..name]=true
    elseif address==bf then found['bankF'..name]=true
    else unexpected=true end
   elseif name=='E'or name=='F'then unexpected=true end
  end)
  if which=='world'then return not unexpected and found.worldE and found.nativeF and not found.nativeE and not found.bankEE and not found.bankFF end
  if which=='bank'then return not unexpected and found.bankEE and found.bankFF and not found.nativeE and not found.nativeF end
  return not(found.worldE or found.bankEE or found.bankFF)
 end)
 return ok and result==true
end
local function bank(c)
 local ok,why=owner(c);if not ok then return nil,why end
 ok,why=add('bank',true);if not ok then return nil,why end
 if not mapped('bank')then return nil,'Keyboard protection could not be verified; swap remains unavailable'end
 M.mode='bank';M.pending_since=nil;return true
end
function M.before_open(c)
 if not Prefs.enabled()and not(M.world_added or M.bank_added)then return true end
 if M.error and M.mode=='off'and not(M.world_added or M.bank_added)then return true end
 -- Add the higher-priority E/F mask before hiding the world hint or entering
 -- GameAndUI. It is retained across close until the physical keys are up.
 local ok,why=bank(c)
 if not ok then M.error=tostring(why);return nil,why end
 return true
end
-- Earlier native focus notifications may consume E/F immediately, but never
-- arm the native F action. Normal routing owns the later physical release.
function M.protect(c)
 if not Prefs.enabled()then return nil,'Ledger swap disabled'end
 local keys,why=Hardware.keyboard_state()
 if not keys or not keys.focused then return nil,why or 'Keyboard focus unavailable'end
 local ok,error=bank(c)
 if not ok then M.error=tostring(error);return nil,error end
 return true
end
function M.set_enabled(enabled,c)
 assert(type(enabled)=='boolean','Invalid ledger key option')
 if enabled then local ok,why=bank(c);if not ok then return nil,why end end
 local ok,why=Prefs.set(enabled)
 if not ok then return nil,why end
 M.error=nil;return true
end
local function leave()
 if not(M.world_added or M.bank_added)then
  if M.mode=='off_pending'and not mapped('off')then return false end
  M.mode='off';return true
 end
 local keys=Hardware.keyboard_state()
 if held(keys)then
  local ok,why=bank(M.last_context)
  if not ok then M.error=tostring(why);return nil,why end
  M.mode='release';return false
 end
 local a,why=remove('world',true);local b,error=remove('bank',true)
 if not(a and b)then M.error=tostring(why or error);return nil,M.error end
 M.mode=mapped('off')and'off'or'off_pending';return M.mode=='off'
end
function M.tick(actor,c,open)
 if open then return true end
 if not Prefs.enabled()or not actor or not c then return leave()end
 local keys,why=Hardware.keyboard_state()
 if not keys then M.error=tostring(why);return leave()end
 if not keys.focused then return leave()end
 local ok,error,owned_keys=owner(c);if not ok then M.error=tostring(error);return leave()end
 -- Discovery can outlast the first hardware sample. Use its newer observation
 -- so an F press while acquiring ownership cannot become a native deposit.
 if owned_keys then keys=owned_keys end
 if not keys.focused then return leave()end
 if M.bank_added and held(keys)then M.mode='release';return false end
 if not M.world_added and held(keys)then
  -- Observing a held approach must suppress native E now. Merely waiting for
  -- release leaves a spammed key bound to the game's deposit action forever.
  ok,error=bank(c);if not ok then M.error=tostring(error);return nil,error end
  M.mode='release';return false
 end
 -- A released approach installs one immediate, verified graph. When a mask is
 -- already present, queue world first and let its removal rebuild once. Never
 -- expose native F until both physical keys are up; held movement is preserved.
 ok,error=add('world',not M.bank_added);if not ok then M.error=tostring(error);return leave()end
 ok,error=remove('bank',true);if not ok then M.error=tostring(error);return nil,error end
 if M.mode=='world'or mapped('world')then M.mode='world';M.pending_since=nil;M.error=nil;return true end
 M.mode='world_pending'
 if M.pending_since and os.clock()-M.pending_since>1 then
  M.error='Ledger keyboard mapping unavailable; default keys restored';return leave()
 end
 return false
end
function M.entry_key()
 if M.error and M.mode~='off'then return nil end
 if M.mode=='world'then return 'E'end
 if M.mode=='off'then return 'F'end
end
function M.allow_entry(key)
 if M.entry_key()~=key then return false end
 if M.mode~='world'then return true end
 local keys=Hardware.keyboard_state()
 if not(Prefs.enabled()and keys~=nil and keys.focused==true)then return false end
 if not mapped('world')then
  M.mode='world_pending';M.pending_since=os.clock();M.error='Ledger keys changed; waiting for keyboard protection'
  return false
 end
 return true
end
-- Custom mode owns only its chosen key. E/F world remapping stays in the
-- legacy path above; F6-only mode installs no world mapping at all.
local function custom_key()return Prefs.custom and Prefs.custom()end
local function custom_remove()
 if M.custom_added then
  local ok,why=invoke(M.subsystem,'RemoveMappingContext',M.custom_context,immediate)
  if not ok then return nil,why end
 end
 M.custom_added=nil;M.custom_ready=nil;M.custom_armed=nil;M.custom_activated_at=nil
 M.custom_context=nil;M.custom_action=nil;M.custom_key=nil;M.custom_native_key=nil;M.custom_actor=nil;M.custom_c=nil;M.custom_last=nil
 return true
end
local function custom_mapped()
 local ok,result=pcall(function()
  local input=M.pc.PlayerInput
  if not valid(input)or not same(input:GetOuter(),M.pc)then return false end
  local found=0;local wrong=false;local address=M.custom_action:GetAddress()
  input.EnhancedActionMappings:ForEach(function(_,wrapped)
   local row=wrapped:get();local key=row.Key.KeyName
   local name=type(key)=='string'and key or key:ToString()
   if name==M.custom_native_key then
    if valid(row.Action)and row.Action:GetAddress()==address then found=found+1 else wrong=true end
   end
  end)
  return found==1 and not wrong
 end)
 return ok and result==true
end
local function custom_mask(c,key)
 local ok,why=owner(c);if not ok then return nil,why end
 if M.custom_added and M.custom_key==key and M.custom_ready then return true end
 if M.custom_context then ok,why=custom_remove();if not ok then return nil,why end end
 local context_class=StaticFindObject('/Script/EnhancedInput.InputMappingContext')
 local action_class=StaticFindObject('/Script/EnhancedInput.InputAction')
 if not(valid(context_class)and valid(action_class))then return nil,'Custom-key mapping classes unavailable'end
 local context=StaticConstructObject(context_class,M.subsystem)
 local action=StaticConstructObject(action_class,M.subsystem)
 if not(valid(context)and valid(action))then return nil,'Custom-key mapping unavailable'end
 action.bConsumeInput=true;action.ValueType=0
 local native_key=assert(require('stashlink.ledger_keys').info(key)).unreal
 context:MapKey(action,{KeyName=FName(native_key)})
 M.custom_context=context;M.custom_action=action;M.custom_key=key;M.custom_native_key=native_key
 ok,why=invoke(M.subsystem,'AddMappingContext',context,100022,immediate)
 if not ok then return nil,why end
 M.custom_added=true
 if not custom_mapped()then return nil,'Custom-key protection could not be verified'end
 M.custom_ready=true;M.custom_armed=false;M.custom_activated_at=os.clock();return true
end
local function custom_observe(actor,c,state)
 if not same(actor,M.custom_actor)then
  M.custom_activated_at=os.clock();M.custom_armed=not state.down
 end
 M.custom_actor=actor;M.custom_c=c
 if not state.down then M.custom_armed=true end
end
local old_forget,old_reset=M.forget,M.reset
function M.forget()
 -- Post-travel: discard only; native detach belongs to reset before travel.
 M.custom_added=nil;M.custom_ready=nil;M.custom_armed=nil;M.custom_activated_at=nil
 M.custom_context=nil;M.custom_action=nil;M.custom_key=nil;M.custom_native_key=nil;M.custom_actor=nil;M.custom_c=nil
 old_forget()
end
function M.reset()
 local ok,why=custom_remove();if not ok then return nil,why end
 return old_reset()
end
local old_before_open,old_protect=M.before_open,M.protect
function M.before_open(c,fallback)
 local key=custom_key()
 if not key then return old_before_open(c)end
 M.custom_armed=false
 if key=='F6'then return true end
 local state,why=Hardware.key_state(key)
 if not state or not state.focused then
  M.error=why or 'Keyboard focus unavailable'
  if fallback then return true end
  return nil,M.error
 end
 local ok,error=custom_mask(c,key)
 if not ok and fallback then M.error=tostring(error);return true end
 return ok,error
end
function M.protect(c,actor)
 local key=custom_key()
 if not key then return old_protect(c)end
 if key=='F6'then return true end
 local state,why=Hardware.key_state(key)
 if not state or not state.focused then return nil,why or 'Keyboard focus unavailable'end
 local ok,error=custom_mask(c,key)
 if ok and actor then custom_observe(actor,c,state)end
 return ok,error
end
local old_set_enabled=M.set_enabled
function M.set_enabled(value,c)
 if M.custom_added then
  local state=Hardware.key_state(M.custom_key)
  if not state or state.down then return nil,'Release the current opening key before changing it'end
 end
 local ok,why=custom_remove();if not ok then return nil,why end
 local saved,error=old_set_enabled(value,c)
 if not saved and custom_key()then M.before_open(c)end
 return saved,error
end
function M.set_open_key(value,c)
 local info,why=require('stashlink.ledger_keys').info(value)
 if not info then return nil,why end
 local key=info.name
 if key=='E'or key=='F'then return M.set_enabled(key=='E',c)end
 if key~='F6'then
  local state,error=Hardware.key_state(key)
  if not state or not state.focused then return nil,error or 'Keyboard focus unavailable'end
 end
 if M.world_added or M.bank_added then
  local state=Hardware.keyboard_state()
  if not state or held(state)then return nil,'Release E and F before changing the opening key'end
 end
 if M.custom_added then
  local state=Hardware.key_state(M.custom_key)
  if not state or state.down then return nil,'Release the current opening key before changing it'end
 end
 local ok,error=M.reset();if not ok then return nil,error end
 if key~='F6'then
  ok,error=custom_mask(c,key)
  if not ok then custom_remove();M.before_open(c);return nil,error end
 end
 ok,error=Prefs.set_key(key)
 if not ok then custom_remove();M.before_open(c);return nil,error end
 M.error=nil;M.custom_armed=false;return true
end
local old_tick,old_entry_key,old_allow_entry=M.tick,M.entry_key,M.allow_entry
function M.tick(actor,c,open)
 local key=custom_key()
 if not key then
  if M.custom_context then local ok,why=custom_remove();if not ok then M.error=tostring(why);return nil,why end end
  return old_tick(actor,c,open)
 end
 if open then M.custom_armed=false;return true end
 -- Detach the former legacy graph before custom/F6-only world input resumes.
 if M.world_added or M.bank_added then
  local a,why=remove('world',true);local b,error=remove('bank',true)
  if not(a and b)then M.error=tostring(why or error);return nil,M.error end
  M.mode='off'
 end
 if key=='F6'then
  if M.custom_context then return custom_remove()end
  return true
 end
 if not actor or not c then
  M.custom_actor=nil;M.custom_c=nil;M.custom_armed=false;M.custom_activated_at=nil
  if M.custom_context then
   local state=Hardware.key_state(key)
   if state and state.down then return false end
   return custom_remove()
  end
  return true
 end
 local state,why=Hardware.key_state(key)
 if not state or not state.focused then M.custom_actor=nil;M.custom_c=nil;M.custom_armed=false;return false end
 local ok,error=custom_mask(c,key)
 if not ok then M.error=tostring(error);M.custom_actor=nil;M.custom_c=nil;return nil,error end
 custom_observe(actor,c,state)
 M.error=nil;return true
end
function M.entry_key()
 local key=custom_key()
 if key=='F6'then return key end
 if key then return M.custom_ready and key or M.error and 'F6'or nil end
 return old_entry_key()
end
function M.allow_entry(key)
 if custom_key()then return false end
 return old_allow_entry(key)
end
-- UE4SS's real key edge also handles taps shorter than one rendered frame.
-- The arrival timestamp rejects queued presses from before ledger focus.
function M.allow_custom_entry(key,pressed,actor,c)
 if custom_key()~=key or key=='F6'or not M.custom_ready or type(pressed)~='number'then return false end
 if not M.custom_armed then return false end
 if not actor or not c or not same(actor,M.custom_actor)or not same(c.pc,M.pc)or not same(c.world,M.world)then return false end
 if not M.custom_activated_at or pressed<M.custom_activated_at then return false end
 if M.custom_last and pressed<=M.custom_last+.35 then return false end
 local state=Hardware.key_state(key)
 if not state or not state.focused then return false end
 if not custom_mapped()then M.custom_ready=false;return false end
 M.custom_last=os.clock();M.custom_armed=false;return true
end
function M.custom_pulse(service,view,context)
 local key=custom_key()
 if not key or key=='F6'or view.open or not M.custom_actor or not M.custom_ready then return end
 local state=Hardware.key_state(key)
 if not state or not state.focused then M.custom_armed=false;return end
 if not state.down then M.custom_armed=true;return end
 if not M.custom_armed then return end
 M.custom_armed=false
 local now=os.clock();if M.custom_last and now-M.custom_last<.35 then return end
 if not custom_mapped()then M.custom_ready=false;return end
 local actor,c=context.focused(service.adapter,view)
 if not actor or not same(actor,M.custom_actor)or not same(c.pc,M.pc)or not same(c.world,M.world)then return end
 M.custom_last=now;service.open(actor)
end
return M
