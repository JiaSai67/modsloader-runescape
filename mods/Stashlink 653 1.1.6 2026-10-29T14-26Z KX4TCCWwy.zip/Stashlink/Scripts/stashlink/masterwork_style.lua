local M={}
local none={opacity=0,color={R=1,G=1,B=1,A=0}}
function M.select(catalog,is_masterwork,kind)
 if not is_masterwork then return catalog[2] or none end
 return catalog[kind] or catalog[2] or none
end
return M
