-- Lightweight in-game inventory panel. Widgets contain no inventory state.
local M={open=false,lines={},selection=1,mode="stored",query="",entry=nil,amount_index=3,frames=0,draw_errors=0,status=""}
local Categories=require('stashlink.bank_categories')
M.bank=require('stashlink.bank_tabs').new();M.bank_category='all'
local filtered_cache={}
local layouts,layout_order={},{}
function M.begin_session()
    layouts={};layout_order={};filtered_cache={};M.keep_slots=true;M.restore_view=true;M.query=''
    if M.memory then local p=M.memory.state.prefs;M.amount_index=p.amount_index;M.custom_amount=p.custom_amount end
end
function M.end_session()layouts={};layout_order={};filtered_cache={};M.keep_slots=false end
function M.configure_tabs()
    if M.tabs_loaded then return end;M.tabs_loaded=true
    local Store=require('stashlink.bank_tab_store');local path=Store.default_path()
    if path then M.bank.store=Store.new(path);local ok,why=M.bank:load();if not ok then M.status=why end end
    local Memory=require('stashlink.bank_memory');local memory_path=Memory.default_path()
    M.memory=Memory.new(memory_path and Store.new(memory_path,nil,Memory)or nil)
    local ok,why=M.memory:load();if not ok then M.preferences_error=why end
    M.amount_index=M.memory.state.prefs.amount_index;M.custom_amount=M.memory.state.prefs.custom_amount
end
local function view_key(query)
    return #query..':'..query..'|'..tostring(M.sort_mode)..'|'..M.bank_category..'|'..M.bank.selected..'|'..M.bank.revision..'|'..tostring(M.memory and M.memory.revision)
end
local function presentation_key(row)
    if row.stack_size and row.stack_size<=1 and row.sources and #row.sources==1 then
        return row.sources[1].signature..'|guid:'..row.sources[1].identity
    end
    return row.key
end
function M.filtered_rows(mode)
    local result={}
    if not M.snapshot then return result end
    local query=M.query:lower()
    local cached=filtered_cache[mode]
    local key=view_key(query)
    if cached and cached.snapshot==M.snapshot and cached.key==key then return cached.rows end
    local rows=M.snapshot[mode]
    if mode=='stored'and M.memory_active then rows=M.memory:rows(rows)end
    for _,row in ipairs(rows) do
        if (query=="" or row.name:lower():find(query,1,true))and (mode~='stored'
            or ((M.bank_category=='all'or Categories.classify(row)==M.bank_category)and M.bank:matches(row)))then result[#result+1]=row end
    end
    if mode=="stored" and M.sort_mode=="amount"and not M.memory_active then
        table.sort(result,function(a,b) if a.total~=b.total then return a.total>b.total end; return a.key<b.key end)
    end
    if mode=='stored'and M.bank.selected~='all'and M.sort_mode~='amount'then
        table.sort(result,function(a,b)
            local _,x=M.bank:membership(a.definition);local _,y=M.bank:membership(b.definition)
            if x~=y then return x<y end
            if M.memory_active then local ax,by=M.memory:rank(a),M.memory:rank(b);if ax~=by then return ax<by end end
            if a.name~=b.name then return a.name<b.name end;return a.key<b.key
        end)
    end
    local count,placeholders=0,0
    for _,row in ipairs(result)do if row.placeholder then placeholders=placeholders+1 else count=count+1 end end
    if mode=='stored'and M.keep_slots and not M.memory_active then
        local layout=layouts[key]
        if not layout then
            if #layout_order>=24 then layouts[table.remove(layout_order,1)]=nil end
            layout={order={},seen={}};layouts[key]=layout;layout_order[#layout_order+1]=key
        end
        local current={}
        for _,row in ipairs(result)do local id=presentation_key(row);current[id]=row
            if not layout.seen[id]then layout.order[#layout.order+1]=id;layout.seen[id]=true end
        end
        result={};for i,id in ipairs(layout.order)do result[i]=current[id]or false end
    end
    -- Native snapshots are replaced wholesale. Never mutate the source rows here.
    filtered_cache[mode]={snapshot=M.snapshot,key=key,rows=result,count=count,placeholders=placeholders}
    return result
end
function M.result_count(mode)M.filtered_rows(mode);return filtered_cache[mode]and filtered_cache[mode].count or 0 end
function M.placeholder_count()M.filtered_rows('stored');return filtered_cache.stored and filtered_cache.stored.placeholders or 0 end
function M.remember_amount(amount)
    if M.memory then M.memory:set_amount(M.amount_index,amount or M.custom_amount)end
end
function M.remember_view(panel)
    if not M.memory then return end
    local p=M.memory.state.prefs
    M.memory:remember({amount_index=p.amount_index,custom_amount=p.custom_amount,
        selected_tab=M.bank.selected,category=M.bank_category,sort_mode=M.sort_mode or 'name',page=panel.bank_row or 0})
end
function M.flush_preferences(force)
    if not M.memory then return true end
    local ok,why=M.memory:flush(force)
    if not ok then M.preferences_error=why end
    return ok,why
end
-- Sorting is a one-shot arrangement; the saved order then stays put until the next sort or drag.
function M.set_sort(mode)
    assert(mode=='name'or mode=='amount');M.sort_mode=mode
    if M.memory_active then M.memory:sort(mode)end
    M.repack()
end
function M.next_sort()return M.sort_mode=='name'and 'amount'or 'name'end
function M.sort_label()return ({name='A–Z',amount='Qty',custom='Custom'})[M.sort_mode]or 'A–Z'end
-- Shows a custom tab's own order without re-sorting the saved All arrangement.
function M.use_custom_order()
    if M.sort_mode=='custom'then return end
    M.sort_mode='custom';if M.memory_active then M.memory:set_order('custom')end;M.repack()
end
-- Drag-arrange All: presentation only, the stored items never move.
function M.arrange(row,target)
    if not(M.memory_active and M.memory.move)then return nil,'Arranging needs saved bank layouts'end
    local ok,why=M.memory:move(row,target)
    if ok then M.sort_mode='custom';M.repack()end
    return ok,why
end
function M.toggle_placeholders()
    if not M.memory then return end
    M.memory:set_placeholders(not M.memory.state.prefs.placeholders);M.repack();M.selection=0
end
function M.release_placeholder(row)
    if not M.memory or not row or not row.placeholder then return nil,'Select an empty placeholder'end
    local ok,why=M.memory:release(row.placeholder_id)
    if ok then M.repack();M.selection=0;M.status='Placeholder released; stored items are unchanged'else M.status=tostring(why)end
    return ok,why
end
function M.icon_row(definition)
    for _,row in ipairs(M.snapshot and M.snapshot.stored or{})do if row.definition==definition then return row end end
    return M.memory_active and M.memory:definition_row(definition)or nil
end
function M.select_bank_tab(id)
    assert(id=='all'or M.bank:get(id),'Unknown custom tab');M.bank.selected=id;M.mode='stored';M.player_slot=nil;M.selection=0
end
function M.select_category(id)
    assert(Categories.by_id[id],'Unknown bank category');M.bank_category=id;M.mode='stored';M.player_slot=nil;M.selection=0
end
function M.repack()layouts={};layout_order={};filtered_cache={}end
function M.empty_text()
    if M.query~=''then return 'No matching items\nClear Search to see this tab again'end
    if M.bank_category~='all'then return 'No items in this category\nChoose All to see the rest of this tab'end
    if M.bank.selected~='all'then return 'This custom tab is empty\nDrag a stored item onto its icon'end
    return 'Your linked storage is empty'
end
function M.rows() return M.filtered_rows(M.mode) end
function M.selected()
    if M.mode=="held" and M.player_slot~=nil and M.snapshot and M.snapshot.player_slots then return M.snapshot.player_slots[M.player_slot] end
    return M.rows()[M.selection]or nil
end
function M.amount(row)
    if M.custom_amount then return M.custom_amount end
    return ({math.min(1,row.available),math.min(10,row.available),math.min(row.stack_size or 1,row.available),row.available,math.max(1,math.floor(math.min(row.stack_size or 1,row.available)/2))})[M.amount_index] or 1
end
-- Drawer summary line, e.g. "Available: 39 / 39    1 source stack".
function M.source_info(row)
    if not row then return "" end
    if row.placeholder then return 'Placeholder — no stored items'end
    local where=row.source and "Backpack slot "..(row.source.slot+1)
        or #row.sources..(#row.sources==1 and " source stack" or " source stacks")
    return "Available: "..row.available.." / "..row.total.."    "..where
end
-- A preset stays lit only while the amount field agrees with it. typed is nil when the field is
-- not being edited, false when it holds no number, else the number being typed.
function M.preset_selected(index,row,typed)
    if M.custom_amount~=nil or M.amount_index~=index then return false end
    return typed==nil or (row~=nil and typed==M.amount(row))
end
function M.update(snapshot)
    local old=M.selected()
    M.snapshot=snapshot
    if M.memory then
        local persistent=snapshot.bank_scope~=nil
        local key=snapshot.bank_scope or tostring(snapshot.session)..'|'..tostring(snapshot.anchor)
        local changed=M.memory:activate(key,persistent);M.memory_active=true
        M.memory:observe(snapshot.stored)
        if changed or M.restore_view then
            local s=M.memory.current
            M.bank.selected=M.bank:get(s.selected_tab)and s.selected_tab or 'all'
            M.bank_category=s.category;M.sort_mode=s.sort_mode;M.preferred_bank_row=s.page
            M.mode='stored';M.player_slot=nil;M.selection=0;old=nil;M.restore_view=false
            M.repack()
        end
    end
    if M.mode=="held" and M.player_slot~=nil then
        local current=M.selected()
        if not old or not current or current.key~=old.key or current.source.identity~=old.source.identity then
            M.player_slot=nil; M.selection=0
        end
        return
    end
    if old then
        M.selection=0
        for i,row in ipairs(M.rows()) do if row and row.key==old.key then M.selection=i; break end end
    elseif M.selection>0 then M.selection=math.min(M.selection,#M.rows()) end
end
return M
