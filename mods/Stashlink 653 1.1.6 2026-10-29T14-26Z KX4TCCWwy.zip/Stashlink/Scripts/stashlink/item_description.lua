local M={}
local function text(value)
 if value==nil then return '' end
 return type(value)=='string' and value or value:ToString()
end
local function expand(template,values)
 return text(template):gsub('{([^{}]+)}',function(key) return values[key] or ('{'..key..'}') end)
end
function M.read(data,contents)
 local raw=text(data.FlavourText)
 if contents and raw:find('{HeldContainerDescription}',1,true) then
  local key=contents.quantity<=0 and 'ContainerEmptyContentsDescription'
   or contents.quantity>=contents.capacity and 'ContainerFullContentsDescription' or 'ContainerSomeContentsDescription'
  local values={['HeldContainer.Quantity']=tostring(contents.quantity),['HeldContainer.Capacity']=tostring(contents.capacity),['HeldContainer.ContentName']=contents.name}
  values.HeldContainerDescription=expand(data[key],values)
  raw=expand(raw,values)
 end
 return raw:gsub('\r\n','\n'):gsub('[ \t]+\n','\n'):gsub('\n\n\n+','\n\n')
end
function M.lines(value,width)
 local lines=0
 for part in (value..'\n'):gmatch('(.-)\n') do lines=lines+math.max(1,math.ceil(#part/width)) end
 return lines
end
return M
