-- Device-independent gestures. State changes cannot replay a held button.
local M={}
local edges={{'RT','quick'},{'X','use'},{'Y','matching'},{'SEARCH','search'},{'LB','previous'},{'RB','next'},{'LS','bag_sort'},{'RS','switch_panel'},{'MENU','options'}}
function M.new()
    return {scope=nil,previous={},repeat_at=0}
end
function M.step(s,keys,target,scope,now)
    local events={}
    if scope~=s.scope then
        s.scope=scope;s.previous={};s.a_start=nil;s.a_target=nil;s.a_blocked=keys.A==true;s.direction=nil
        for key,value in pairs(keys) do s.previous[key]=value==true end
        return events
    end
    if keys.B and not s.previous.B then
        s.a_start=nil;s.a_target=nil;s.a_blocked=keys.A==true
        events[1]={kind='back'}
    else
        if s.a_blocked then
            if not keys.A then s.a_blocked=false end
        elseif keys.A then
            if s.a_start==nil then s.a_start=now;s.a_target=target end
            if target~=s.a_target then s.a_start=nil;s.a_target=nil;s.a_blocked=true
            elseif target and now-s.a_start>=.5 then
                events[#events+1]={kind='hold',target=target};s.a_start=nil;s.a_target=nil;s.a_blocked=true
            end
        elseif s.a_start~=nil then
            if target and target==s.a_target then events[#events+1]={kind='accept',target=target} end
            s.a_start=nil;s.a_target=nil
        end
        for _,edge in ipairs(edges) do
            local key,kind=edge[1],edge[2]
            if keys[key] and not s.previous[key] then events[#events+1]={kind=kind} end
        end
        local direction=keys.UP and 'up' or keys.DOWN and 'down' or keys.LEFT and 'left' or keys.RIGHT and 'right'
        if direction then
            if direction~=s.direction or now>=s.repeat_at then
                events[#events+1]={kind='navigate',direction=direction}
                s.repeat_at=now+(direction~=s.direction and .32 or .095)
            end
        else s.repeat_at=0 end
        s.direction=direction
    end
    for key,value in pairs(keys) do s.previous[key]=value==true end
    for key in pairs(s.previous) do if keys[key]==nil then s.previous[key]=false end end
    return events
end
-- A focus graph is rebuilt from visible controls, never from inventory contents.
function M.neighbour(nodes,current,direction)
    if not current or not current.bounds then return nodes[1] end
    local r=current.bounds;local x,y=r.x+r.w/2,r.y+r.h/2
    local best,score
    for _,node in ipairs(nodes) do
        if node~=current and node.bounds then
            local b=node.bounds;local dx,dy=b.x+b.w/2-x,b.y+b.h/2-y
            local forward,cross
            if direction=='right' then forward,cross=dx,math.abs(dy)
            elseif direction=='left' then forward,cross=-dx,math.abs(dy)
            elseif direction=='down' then forward,cross=dy,math.abs(dx)
            else forward,cross=-dy,math.abs(dx) end
            if forward>1 then
                local n=forward+cross*3+cross*cross/math.max(forward,1)
                if not score or n<score then best,score=node,n end
            end
        end
    end
    return best or current
end
function M.token(control)
    if not control then return nil end
    local row=control.row
    return tostring(control.id or control)..'|'..tostring(row and row.key or '')..'|'..
        tostring(row and row.source and row.source.identity or '')
end
return M
