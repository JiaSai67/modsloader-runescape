local Data=require('stashlink.tooltip_data')
local Scheduler=require('stashlink.scheduler')
local M={}
local function valid(o) return o and o:IsValid() end
local function identity(control)
    local row=control and control.row
    if not row then return nil end
    local source=row.source
    return table.concat({control.pane,tostring(row.key or row.definition or row.name),
        tostring(row.definition),source and tostring(source.identity) or ''},'|')
end
local gold={R=.78,G=.64,B=.36,A=1}
local white={R=.86,G=.85,B=.8,A=1}
local function set(label,value)
    value=tostring(value or '')
    if label.value~=value then label.object:SetText(FText(value));label.value=value end
end
local function position(widget,x,y,w,h)
    widget.Slot:SetOffsets({Left=x,Top=y,Right=w,Bottom=h})
end
function M.schedule()
    for _,task in ipairs(Scheduler.tasks) do
        if task.key=='stashlink.hover' or (task.fn==M.previous_pulse) then
            Scheduler.pinned[task.fn]=nil
            task.fn=Scheduler.pin(M.pulse);task.key='stashlink.hover';task.interval=1;task.remaining=1
            return
        end
    end
    Scheduler.every(16,M.pulse);Scheduler.tasks[#Scheduler.tasks].key='stashlink.hover'
end
function M.hide()
    if M.visible and valid(M.card) then M.card:SetVisibility(1) end
    if M.highlight and M.P then
        local c=M.highlight
        if valid(c.material) then c.material:SetScalarParameterValue(M.P.params.selected,c.selected and 1 or 0) end
    end
    if M.P and M.P.effects then M.P.effects:highlight(nil) end
    M.visible=false;M.highlight=nil
end
-- Post-travel release must not even query validity on old native wrappers.
function M.release(P,native_allowed)
    if P and M.P and P~=M.P then return false end
    local owner=M.P
    local ok,why=true,nil
    if native_allowed==true then ok,why=pcall(M.hide) end
    local binding=M.binding
    if binding then
        binding.active=false
        if owner then
            if owner.render==binding.render then owner.render=binding.base_render end
            if owner.hide==binding.hide then owner.hide=binding.base_hide end
            if owner.render_wrapper==binding.render then owner.render_wrapper=nil end
            if owner.hide_wrapper==binding.hide then owner.hide_wrapper=nil end
        end
    end
    for _,key in ipairs({'P','V','H','binding','card','slot','native_view','highlight','target','force',
        'bound_row','snapshot','model','model_key','stats','details','hints','visible','rendered',
        'layout_pending','mouse_x','mouse_y','controller_mode','bank_empty','ready_at','force_until'}) do
        M[key]=nil
    end
    return ok,why
end
function M.bind(P,V,H)
    M.release(M.P,true);M.P=P;M.V=V;M.H=H;M.target=nil;M.model_key=nil;M.mouse_x=nil;M.force=nil;M.stats={};M.details={};M.hints={}
    if P.render~=P.render_wrapper then P.base_render=P.render end
    if P.hide~=P.hide_wrapper then P.base_hide=P.hide end
    local binding={active=true,base_render=P.base_render,base_hide=P.base_hide};M.binding=binding
    local render_wrapper=function()
        binding.base_render()
        if not binding.active then return end
        if P.refresh_quantity_ui then P.refresh_quantity_ui() end
        if P.refresh_feedback then P.refresh_feedback() end
        for _,c in ipairs(P.controls) do
            if c.pane and c.tooltip~=c.cleared_tooltip then c.object:SetToolTipText(FText(''));c.cleared_tooltip=c.tooltip end
        end
        -- A virtual cell can display another item before the next hover pulse.
        -- Dismiss its old card immediately; same-item refreshes stay visible.
        if M.target and identity(M.target)~=M.model_key then
            M.hide();M.target=nil;M.bound_row=nil;M.model_key=nil;M.model=nil
            M.rendered=false;M.layout_pending=false;M.mouse_x=nil
        elseif M.target and M.target.row~=M.bound_row then M.mouse_x=nil end
    end
    binding.render=render_wrapper;P.render_wrapper=render_wrapper;P.render=render_wrapper
    local hide_wrapper=function()
        if binding.active then M.hide();if P.effects then P.effects:stop() end;M.target=nil;M.mouse_x=nil end
        binding.base_hide()
    end
    binding.hide=hide_wrapper
    P.hide_wrapper=hide_wrapper;P.hide=hide_wrapper
    M.native_view=require('stashlink.native_tooltip_view').bind(P,H)
    M.card=M.native_view.widget;M.slot=M.native_view.slot;M.width=450;M.height=440
    M.schedule()
end
function M.draw(model)
    M.width,M.height=require('stashlink.native_tooltip_view').draw(M.native_view,model)
end
function M.pulse()
    local P,V=M.P,M.V
    if not P or not V.open or not valid(P.root) or P.pointer or P.controller_carry or P.tab_editor_open
        or P.controller_ui and P.controller_ui.keyboard_open then M.hide();M.target=nil;M.mouse_x=nil;return end
    local x,y=P.pointer_position()
    if P.controller_active then
        local control=P.controller_focus
        if not control or not control.bounds or not control.pane then M.hide();M.target=nil;M.mouse_x=nil;return end
        x,y=control.bounds.x+control.bounds.w/2,control.bounds.y+control.bounds.h/2
    end
    local refreshed=M.snapshot~=V.snapshot
    local device_changed=M.controller_mode~=(P.controller_active==true)
    local changed=M.mouse_x~=x or M.mouse_y~=y or refreshed
        or (M.target and (M.target.row~=M.bound_row or identity(M.target)~=M.model_key))
        or device_changed or M.bank_empty~=P.bank_empty
    M.bank_empty=P.bank_empty
    M.controller_mode=P.controller_active==true
    local now=P.time_lib:GetRealTimeSeconds(P.pc)
    if P.feedback_tick then P.feedback_tick(now) end
    if M.force and now>(M.force_until or 0) then M.force=nil;M.hide();M.target=nil;M.model_key=nil;changed=true end
    if changed or M.force then
        M.mouse_x,M.mouse_y,M.snapshot=x,y,V.snapshot
        local groups={P.hotbar,P.backpack,P.armour,P.stored}
        local target=M.force or Data.hit_test(groups,x,y)
        if not target or not target.pane or not target.row then
            local empty=Data.slot_at(groups,x,y)
            if empty and empty.pane and not empty.row and not(empty.pane=='stored'and P.bank_empty)then
                if M.highlight~=empty or M.visible then
                    M.hide();M.highlight=empty
                    empty.material:SetScalarParameterValue(P.params.selected,1)
                    if P.effects then P.effects:highlight(empty) end
                end
            else M.hide() end
            M.target=nil;return
        end
        local key=identity(target)
        if target~=M.target or key~=M.model_key then
            M.hide();M.target=target;M.bound_row=target.row;M.model_key=key;M.ready_at=now+(M.force and 0 or .12);M.rendered=false
            M.highlight=target;target.material:SetScalarParameterValue(P.params.selected,1)
            if P.effects then P.effects:highlight(target) end
        elseif refreshed or target.row~=M.bound_row or device_changed then
            -- Refresh stats in place. Only a different item starts a new delay.
            M.bound_row=target.row;M.rendered=false
        end
    end
    if not M.target or now<M.ready_at then return end
    -- Remain anchored to the item. Mouse movement inside its slot does not
    -- rebuild or reposition the card, so there is no low-frequency cursor chase.
    if M.rendered and M.visible then
        if not M.layout_pending then return end
        M.layout_pending=false;M.draw(M.model)
    end
    if not M.rendered then
        local started=os.clock()
        local ok,model=pcall(Data.read,P,M.target)
        if not ok or not model then M.hide();M.target=nil;return end
        M.draw(model);M.model=model;M.layout_pending=model.details and #model.details>0;M.rendered=true;M.last_read_ms=(os.clock()-started)*1000
    end
    local size=P.layout_lib:GetViewportSize(P.pc)
    local scale=P.layout_lib:GetViewportScale(P.pc)
    local content_scale=P.content_scale or 1
    local left,top,factor=Data.place(x,y,M.width or 450,M.height,size.X/scale/content_scale,size.Y/scale/content_scale,M.target.bounds)
    M.card:SetRenderTransformPivot({X=0,Y=0});M.card:SetRenderScale({X=factor,Y=factor});M.slot:SetPosition({X=left,Y=top})
    M.card:SetVisibility(3);M.visible=true;M.highlight=M.target
    M.target.material:SetScalarParameterValue(P.params.selected,1)
end
function M.preview(name)
    for _,c in ipairs(M.P.controls) do
        if c.row and c.row.name:lower():find(name:lower(),1,true) then
            M.force=c;M.force_until=M.P.time_lib:GetRealTimeSeconds(M.P.pc)+8;M.model_key=nil;M.pulse()
            return 'Previewing '..c.row.name..'; read_ms='..tostring(M.last_read_ms)
        end
    end
    return 'No visible matching item'
end
return M
