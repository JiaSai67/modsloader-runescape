local Native=require("stashlink.native")
local Coordinator=require("stashlink.coordinator")
local View=require("stashlink.view")
local Panel=require("stashlink.grid_panel")
local Scheduler=require("stashlink.scheduler")
local Helpers=require("UEHelpers")
local Context=require("stashlink.context_entry")
local MenuGuard=require('stashlink.menu_guard')
local Controller=require('stashlink.controller')
local LedgerKeyboard=require('stashlink.ledger_keyboard')
local EarlyEntry=require('stashlink.ledger_early_entry')
local M=package.loaded['stashlink.service'] or {adapter=Native.new(),attached=false,sequence=0,hooks={},stopped=false,dirty=true}
M.lifecycle=M.lifecycle or require('stashlink.world_lifecycle').new()
M.coordinator=M.coordinator or Coordinator.new(M.adapter,4096)
function M.transfer_notice()
    -- This is a read-only projection of coordinator state, never an unlock or
    -- retry path. A sent move remains pending even if its ledger was closed.
    local feedback=require('stashlink.feedback')
    if M.coordinator.busy then
        local result=M.coordinator.active_result
        local pending=M.pending_transfer
        if result and pending and pending.id==result.request_id then
            return feedback.transfer(pending.direction,pending.row,result)
        end
        return feedback.text('transfer_in_progress')
    end
    local snapshot=M.adapter.snapshot
    if snapshot and M.coordinator.blocked and M.coordinator.session==snapshot.session then
        return feedback.text('uncertain_previous_transfer')
    end
end
View.transfer_notice=M.transfer_notice
local input_owner,input_mode,previous_cursor,input_library
local function valid(o) return o and o:IsValid() end
local function log(message) print("[Stashlink] "..tostring(message).."\n") end
local function stop_early_entry()
    local observer=M.early_entry
    if not observer then return true end
    local called,stopped,why=pcall(observer.stop,observer)
    if called and stopped and not observer.registered then
        M.early_entry=nil;M.early_entry_cleanup_retry=nil;M.early_entry_cleanup_error=nil
        return true
    end
    -- Loading or failed detachment leaves an inert registration. Keep its
    -- scalar IDs and suppress replacement until a ready-session retry detaches.
    M.early_entry_cleanup_retry=os.clock()+1
    if not called or not stopped then
        local error=tostring(called and why or stopped)
        if M.early_entry_cleanup_error~=error then
            M.early_entry_cleanup_error=error;log('Early ledger observation cleanup: '..error)
        end
    end
    return false
end
function M.poll_early_entry()
    if M.stopped or M.lifecycle.loading or not M.lifecycle.ready then return end
    if M.early_entry and M.early_entry.stopped then
        if M.early_entry_cleanup_retry and os.clock()<M.early_entry_cleanup_retry then return end
        if not stop_early_entry()then return end
    end
    if not M.early_entry then M.early_entry=EarlyEntry.new(M,View)end
    M.early_entry:poll()
end
local function mode(open)
    if not valid(input_library) then input_library=StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end
    local library=input_library
    assert(valid(library),"UI input bridge unavailable")
    if open then
        local c=M.adapter:context()
        input_owner=c.pc
        previous_cursor=c.pc.bShowMouseCursor
        input_mode=valid(c.pc.CurrentInputMode) and c.pc.CurrentInputMode:GetFullName() or ""
        Controller.input_mode(c.pc,library)
    elseif valid(input_owner) then
        local current=valid(input_owner.CurrentInputMode) and input_owner.CurrentInputMode:GetFullName() or ""
        if current==input_mode then
            library:SetInputMode_GameOnly(input_owner,true)
            input_owner.bShowMouseCursor=previous_cursor
            -- The game restores its own mode on focus; avoid a re-entrant
            -- UpdateInputMode call while closing a custom Slate tree.
        end
        input_owner=nil
    end
end
function M.close(reason,world_changed,preserve_native_input)
    -- Bulk cancellation may render a still-open view. After travel no old UI
    -- callback is allowed to run, even when pretravel cleanup was interrupted.
    if world_changed then View.open=false end
    if M.coordinator.cancel then M.coordinator:cancel(reason or 'Transfer cancelled') end
    if View.open and not world_changed then
        local saved,why=pcall(function()View.remember_view(Panel);local ok,error=View.flush_preferences(true);if not ok then log('Bank preferences: '..tostring(error))end end)
        if not saved then log('Bank preferences: '..tostring(why))end
    end
    if world_changed then pcall(Controller.forget_world or Controller.reset,true)
    else pcall(Controller.reset,false)end
    require("stashlink.bulk").cancel("Transfer cancelled")
    if world_changed then
        if Context.forget then Context.forget()end
        if Panel.forget then Panel.forget()end
        input_owner=nil;input_library=nil;input_mode=nil;previous_cursor=nil
    else Context.hide()end
    log("close begin: "..tostring(reason or "user"))
    View.open=false
    View.end_session()
    if not world_changed then pcall(Panel.hide)end
    if not world_changed and not preserve_native_input then pcall(mode,false) else input_owner=nil end
    View.entry=nil
    View.status=reason or "Closed"
    M.adapter.cached_pc=nil
    M.adapter.anchor_object=nil
    log("close complete")
end
function M.shutdown()
    M.stopped=true
    stop_early_entry()
    Scheduler.stop()
    M.close("Mod stopping")
    pcall(Panel.destroy)
    for _,hook in ipairs(M.hooks) do pcall(UnregisterHook,hook[1],hook[2],hook[3]) end
    M.hooks={}
end
local function retain_changed_inventories()
    if M.dirty~=true and type(M.dirty)~='table' then M.dirty={} end
    local changed=false
    for address in pairs(M.adapter.changed or {}) do
        if M.dirty~=true then M.dirty[address]=true end
        changed=true
    end
    return changed
end
function M.refresh(incremental)
    -- Replication observers can mark inventories after the initial dispatch.
    -- Import their markers before deciding which cached slot arrays to reuse.
    if incremental then retain_changed_inventories() end
    local changes=incremental and M.dirty or nil
    if changes==true then changes=nil end
    local previous_session=M.adapter.snapshot and M.adapter.snapshot.session
    local snapshot=M.adapter:refresh(changes)
    -- Old status text must not reappear beneath a notice from the previous
    -- connection. Coordinator history and its session lock remain untouched.
    if previous_session and previous_session~=snapshot.session then View.status='' end
    M.dirty={}; M.adapter.changed={}
    View.update(snapshot)
    if View.open then Panel.render() end
    return snapshot
end
function M.open(preferred,opening_key)
    if View.open then return "Already open" end
    View.begin_session()
    log("open begin")
    local snapshot=M.adapter:open(preferred)
    M.dirty={}; M.adapter.changed={}
    local c=M.adapter:context()
    assert(not MenuGuard.blocked(c.pc),"Close the current game menu first")
    local keyboard_ready,keyboard_error=LedgerKeyboard.before_open(c,opening_key=='F6')
    assert(keyboard_ready,keyboard_error)
    -- Tooltip presentation uses the verified opening context. Native guards
    -- still decide whether any requested inventory action may be dispatched.
    Panel.networked=c.networked==true
    View.update(snapshot)
    Context.hide()
    View.selection=0
    Panel.pending_row=View.preferred_bank_row or 0
    -- Create and show a real widget before capturing input. A failed widget build
    -- must never leave the player with only a cursor and blocked game controls.
    log("open snapshot ready")
    local shown,show_error=pcall(Panel.show)
    if not shown then pcall(Panel.destroy); error(show_error) end
    local ok,err=pcall(mode,true)
    if not ok then
        pcall(Controller.reset,false)
        pcall(Panel.hide)
        pcall(mode,false)
        error(err)
    end
    View.status=View.preferences_error or LedgerKeyboard.error or "Drag a stack to withdraw, deposit, or rearrange. Fill Stacks leaves your hotbar in place."
    if not M.transfer_notice() and c.networked and not M.adapter.network_validated then
        View.status=M.adapter:network_write_ready(c)
            and 'TEST SESSION: multiplayer transfers enabled for this connection only'
            or 'Multiplayer preview: transfers are read-only until dedicated-server validation passes'
    end
    Panel.render()
    M.opened_at=os.clock()
    log("open complete")
    return "Opened "..snapshot.containers.." linked containers"
end
local function describe(result)
    return string.format("%s: moved %d of %d%s",result.status,result.moved,result.requested or 0,
        result.reason and (" - "..result.reason) or "")
end
function M.transfer(direction,row,amount,destination,options)
    assert(row,"Select an item first")
    assert(not row.placeholder,'Placeholder: no items are stored here')
    local transfer_started=os.clock()
    M.sequence=M.sequence+1
    local snapshot=M.adapter.snapshot
    local request={id="ui-"..M.sequence,session=snapshot.session,direction=direction,row_key=row.key,
        quantity=amount,snapshot_token=snapshot.token,destination_id=destination}
    if options then
        request.destination_slot=options.destination_slot; request.target_identity=options.target_identity
        request.snapshot_token=options.snapshot_token or request.snapshot_token
    end
    if (direction=="deposit" or direction=="rearrange") and row.source then request.source_slot=row.source.slot; request.source_identity=row.source.identity end
    log("transfer begin "..direction.." quantity="..amount)
    local result=M.coordinator:execute(request)
    if result.status=='pending' and not M.pending_transfer then
        M.pending_transfer={id=request.id,direction=direction,row={name=row.name},moved=result.moved,status=result.status}
    end
    View.status=require("stashlink.feedback").transfer(direction,row,result)
    View.status_version=(View.status_version or 0)+1
    if type(M.dirty)~="table" then M.dirty={} end
    for address in pairs(M.adapter.changed) do M.dirty[address]=true end
    local ok,why=true,nil
    if result.status~='pending' then ok,why=pcall(M.refresh,true) end
    M.transfer_ms=(os.clock()-transfer_started)*1000
    log("transfer "..result.status.." "..View.status.." cpu_ms="..string.format("%.2f",M.transfer_ms))
    if not ok then M.close("Refresh failed: "..tostring(why)) end
    return result
end
function M.poll_transfer()
    if not M.coordinator.active then return end
    local result=M.coordinator:poll()
    if not result then return end
    M.last_transfer_result=result
    local changed_inventories=retain_changed_inventories()
    local pending=M.pending_transfer
    if pending and pending.id==result.request_id then
        local changed=pending.moved~=result.moved or pending.status~=result.status
        pending.moved,pending.status=result.moved,result.status
        if changed and not require('stashlink.bulk').job then
            View.status=require('stashlink.feedback').transfer(pending.direction,pending.row,result)
            View.status_version=(View.status_version or 0)+1
            if View.open and result.status=='pending' and not changed_inventories then Panel.render() end
        end
    end
    if result.status~='pending' then
        M.pending_transfer=nil
        log('Server transfer '..describe(result))
    end
    if View.open and (result.status~='pending' or changed_inventories) then
        local ok,why=pcall(M.refresh,true)
        if not ok then M.coordinator:block(M.coordinator.session);M.close('Refresh after server result failed: '..tostring(why)) end
    end
    return result
end
function M.render() if View.open then Panel.render() end end
function M.back()
    if not View.open then return end
    if Panel.tab_editor_open then Panel.close_tab_editor()
    elseif Controller.carry or Controller.modal then Controller.action({kind='back'})
    elseif Panel.extras_open then
        Panel.set_drawer(false);if valid(Panel.root)then Panel.root:SetKeyboardFocus()end
    elseif View.entry then
        Panel.sync_inputs(false);View.entry=nil
        if valid(Panel.root)then Panel.root:SetKeyboardFocus()end;Panel.render()
    else M.close() end
end
local function writable_session()
    local session=M.adapter:session_id()
    assert(session,'Player inventory session unavailable')
    assert(not M.coordinator.busy,'An inventory transfer is in progress')
    assert(not (M.coordinator.blocked and M.coordinator.session==session),'Inventory actions are paused after an uncertain result')
    return session
end
function M.use_item(control)
    require('stashlink.bulk').cancel('New action')
    local session=writable_session()
    if not M.item_uses or M.item_use_session~=session then
        M.item_uses=require('stashlink.item_use').new(M.adapter);M.item_use_session=session
    end
    local request=M.adapter:capture_use(control)
    assert(request.session==session,'Inventory session changed; select the item again')
    M.use_sequence=(M.use_sequence or 0)+1;request.id='use-'..M.use_sequence
    local result=M.item_uses:execute(request)
    if result.status=='unknown' then M.coordinator:block(session);View.status='Item action result needs inspection; further actions are paused'
    elseif result.status=='rejected' then View.status=require('stashlink.feedback').text(result.reason)
    else View.status=(request.verb=='Unequip' and 'Unequipping ' or request.verb=='Equip' and 'Equipping ' or 'Using ')..request.name end
    View.status_version=(View.status_version or 0)+1
    if result.status=='rejected' then return result end
    local observed,observation_error=pcall(function()
        M.dirty={};for address in pairs(M.adapter.changed) do M.dirty[address]=true end
        assert(M.adapter:session_id()==session,'Inventory session changed after item action')
        local c=M.adapter:context()
        if MenuGuard.blocked(c.pc) then M.close('Opened game menu',false,true)
        elseif View.open then
            -- Native equipment changes may update its input mode. Preserve the
            -- original cursor restoration value while retaining this custom panel.
            input_mode=valid(c.pc.CurrentInputMode) and c.pc.CurrentInputMode:GetFullName() or ''
            if valid(input_library) then input_library:SetInputMode_UIOnlyEx(c.pc,Panel.root,0,false);c.pc.bShowMouseCursor=true end
            M.refresh(true)
        end
    end)
    if not observed then
        M.coordinator:block(session)
        error('Item action result requires inspection: '..tostring(observation_error))
    end
    return result
end
function M.matching() return require("stashlink.bulk").start(M,View,"matching") end
-- F both opens the ledger and fills stacks. A press made while the panel was
-- still opening, or just after, repeats the opening gesture; it never deposits.
M.fill_guard=.6
function M.fill_ready(pressed)
    return View.open and M.opened_at~=nil and (pressed or os.clock())>=M.opened_at+M.fill_guard
end
-- A hand-arranged All order is replaced only by a second Sort press.
M.sort_confirm_window=4
function M.sort()
    local now=os.clock()
    if View.sort_mode=='custom'and now-(M.sort_requested or -math.huge)>M.sort_confirm_window then
        M.sort_requested=now;View.status='Press Sort again to replace your arranged order';return View.status
    end
    M.sort_requested=nil
    View.set_sort(View.next_sort());View.selection=0;View.mode='stored'
    Panel.scroll_to_row(0);Panel.render()
    return View.status
end
function M.take_all() View.status='Take All was removed; Ctrl-click a stack to transfer it';return View.status end
function M.sort_backpack()
    local session=writable_session()
    assert(M.adapter.validated and M.adapter:build_supported(),"Inventory writes unavailable")
    local c=M.adapter:check_access()
    assert(not c.networked,'In co-op, sort your backpack in the game inventory')
    assert(valid(c.pc.InventoryController),"Native inventory controller unavailable")
    local function totals(snapshot)
        local rows={}
        for _,cell in pairs(snapshot.player_slots) do
            local key=cell.source.signature
            if cell.stack_size<=1 then key=key.."|"..cell.source.identity end
            rows[key]=(rows[key] or 0)+cell.total
        end
        return rows
    end
    local snapshot=M.refresh()
    for _,cell in pairs(snapshot.player_slots) do
        assert(cell.writable,'Sorting is unavailable while the backpack contains an unsupported item type')
    end
    local before=totals(snapshot)
    assert(M.adapter:session_id()==session,'Inventory session changed; sort again after refreshing')
    M.dirty={[c.inventory:GetAddress()]=true}
    local verified,verification_error=pcall(function()
        c.pc.InventoryController:SortInventory(c.inventory)
        assert(M.adapter:session_id()==session,'Inventory session changed after sorting')
        local after=totals(M.refresh(true))
        for key,count in pairs(before) do assert(after[key]==count,'Native sort changed item state or quantities') end
        for key,count in pairs(after) do assert(before[key]==count,'Native sort changed item state or quantities') end
    end)
    if not verified then
        M.coordinator:block(session)
        error('Native sort result requires inspection: '..tostring(verification_error))
    end
    View.status="Backpack sorted"
    return View.status
end

function M.prove()
    assert(M.adapter:build_supported(),"Unsupported game build")
    local before=M.adapter:open()
    local selected
    for _,row in ipairs(before.stored) do if row.name=="Stone" and row.writable and row.available>=2 then selected=row; break end end
    assert(selected,"Proof needs a linked chest containing at least two Stone")
    local source=selected.sources[1].container_id
    local key=selected.key
    local function quantity(snapshot,where)
        for _,row in ipairs(snapshot[where]) do if row.key==key then return row.total end end
        return 0
    end
    local stored_before,held_before=quantity(before,"stored"),quantity(before,"held")
    M.adapter.validated=true
    local withdrawal=M.transfer("withdraw",selected,1)
    if withdrawal.status~="completed" then M.adapter.validated=false; return "Proof stopped: "..describe(withdrawal) end
    local middle=M.adapter.snapshot
    if quantity(middle,"stored")~=stored_before-1 or quantity(middle,"held")~=held_before+1 then
        M.adapter.validated=false; error("Proof conservation failed after withdrawal")
    end
    local held
    for _,row in ipairs(middle.held) do if row.key==key then held=row; break end end
    local deposit=M.transfer("deposit",held,1,source)
    if deposit.status~="completed" then M.adapter.validated=false; return "Return step stopped: "..describe(deposit) end
    local after=M.adapter.snapshot
    if quantity(after,"stored")~=stored_before or quantity(after,"held")~=held_before then
        M.adapter.validated=false; error("Proof conservation failed after return")
    end
    return string.format("PASS native round trip: Stone storage %d -> %d -> %d; backpack %d -> %d -> %d",stored_before,stored_before-1,quantity(after,"stored"),held_before,held_before+1,quantity(after,"held"))
end

function M.drag_proof()
    local before=M.adapter:open(); View.update(before)
    local stone
    for _,row in ipairs(before.stored) do if row.name=="Stone" and row.writable and row.available>=1 then stone=row; break end end
    assert(stone,"Proof needs Stone in linked storage")
    local source=stone.sources[1]
    local c=M.adapter:scope()
    local item=M.adapter.lookup[source.container_id]:GetItemFromSlot(source.slot)
    local empty={}
    for _,slot in ipairs(M.adapter:destination_slots(c.inventory,item,c.inventory)) do
        if not valid(c.inventory:GetItemFromSlot(slot)) then empty[#empty+1]=slot end
        if #empty==2 then break end
    end
    assert(#empty==2,"Proof needs two empty normal backpack slots")
    M.adapter.validated=true
    local a,b=empty[1],empty[2]
    local result=M.transfer("withdraw",stone,1,nil,{destination_slot=a,target_identity=""})
    assert(result.status=="completed","Exact-slot withdrawal stopped: "..describe(result))
    local cell=M.adapter.snapshot.player_slots[a]
    assert(cell and cell.total==1,"Unexpected proof stack after withdrawal")
    local identity=cell.source.identity
    result=M.transfer("rearrange",cell,1,nil,{destination_slot=b,target_identity=""})
    assert(result.status=="completed","Backpack rearrangement stopped: "..describe(result))
    cell=M.adapter.snapshot.player_slots[b]
    assert(cell and cell.total==1 and cell.source.identity==identity and not M.adapter.snapshot.player_slots[a],"Rearrangement did not preserve the item instance")
    result=M.transfer("deposit",cell,1,source.container_id)
    assert(result.status=="completed","Proof return stopped: "..describe(result))
    local after=M.adapter.snapshot
    local total=0
    for _,row in ipairs(after.stored) do if row.key==stone.key then total=row.total end end
    assert(total==stone.total and not after.player_slots[a] and not after.player_slots[b],"Drag proof conservation failed")
    return "PASS exact-slot withdrawal -> backpack move -> original storage; Stone "..total.." unchanged; slots "..a.." and "..b.." empty again"
end

local function safe(action)
    local ok,err=pcall(action)
    if not ok then View.status=tostring(err); log(err) end
end
function M.ui_action(action,data)
    if action=='controller_key' then return Controller.keyboard_key(data) end
    if action~='close' and (Panel.tab_editor_open or Controller.modal=='keyboard' or Controller.modal=='tab_editor') then return end
    if action=="drag" or action=="transfer" or action=="quick_transfer" or action=="bag_sort" then require("stashlink.bulk").cancel("New action") end
    if action=="drag" then
        return M.transfer(data.direction,data.row,data.quantity,nil,data)
    elseif action=='use' then
        if data and data.row and data.row.placeholder then local result=View.release_placeholder(data.row);Panel.render();return result end
        return M.use_item(data)
    elseif action=="close" then M.close()
    elseif action=="refresh" then M.refresh(); View.status="Inventory refreshed"
    elseif action=='ledger_swap'or action=='ledger_key_apply'or action=='ledger_key_none' then
        if M.coordinator.busy or Panel.pointer or Controller.carry or require('stashlink.bulk').job then
            View.status='Finish the current move before changing ledger keys';return
        end
        Panel.ledger_key_quarantine_until=os.clock()+.5
        local preferences=require('stashlink.ledger_key_preferences')
        local ok,why
        if action=='ledger_swap'then
            ok,why=LedgerKeyboard.set_enabled(not preferences.enabled(),M.adapter:context())
        else
            local value=action=='ledger_key_none'and'F6'or Panel.ledger_open_input:GetText():ToString()
            ok,why=LedgerKeyboard.set_open_key(value,M.adapter:context())
        end
        if ok then
            if M.ensure_open_key_binding then M.ensure_open_key_binding()end
            local chosen=preferences.key()
            View.status=preferences.custom()and('Opening key: '..chosen..'; E/F opening disabled')or('Ledger keys: '..chosen..' opens Stashlink')
            View.entry=nil
            if valid(Panel.root)then Panel.root:SetKeyboardFocus()end
        else View.status=tostring(why)end
    elseif action=="matching" then
        if not M.fill_ready(type(data)=='number' and data or nil) then return end
        M.matching()
    elseif action=="take_all" then M.take_all()
    elseif action=="quick_transfer" then
        assert(data and data.snapshot_token==M.adapter.snapshot.token,'Inventory changed; click the stack again')
        assert(data.pane=='stored' or data.pane=='held' or data.pane=='hotbar','Choose a storage, backpack or hotbar stack')
        local row=data.row
        assert(row and row.writable and row.available>0,'This stack cannot be transferred')
        if data.pane~='stored' then
            local current=M.adapter.snapshot.player_slots[data.slot]
            assert(current and current.key==row.key and current.source.identity==row.source.identity,'Backpack stack changed; click it again')
        end
        local quantity=data.pane=='stored' and math.min(row.available,row.stack_size or 1) or row.available
        if data.quantity~=nil then
            assert(type(data.quantity)=='number' and data.quantity>=1 and data.quantity==math.floor(data.quantity) and data.quantity<=quantity,'Invalid selected quantity')
            quantity=data.quantity
        end
        M.transfer(data.pane=='stored' and 'withdraw' or 'deposit',row,quantity,nil,{snapshot_token=data.snapshot_token})
    elseif action=="bag_sort" then M.sort_backpack()
    elseif action=="sort" then M.sort()
    elseif action=="transfer" then
        local row=View.selected()
        assert(row,"Select an item first")
        assert(row.writable,"This item type is read-only in Stashlink")
        assert(row.available>0,"This item is protected")
        Panel.sync_inputs(true)
        M.transfer(View.mode=="stored" and "withdraw" or "deposit",row,View.amount(row))
    end
end
function M.begin_world_change()
    M.lifecycle:begin_load();M.lifecycle_poll=0;M.lifecycle_retry_at=nil;M.world_cleanup_pending=true
    -- Post-only loaders must make old callbacks inert without native queries.
    stop_early_entry()
    if Scheduler.invalidate then Scheduler.invalidate()else Scheduler.queue={}end
    -- Cancellation only stops unissued work. The sent RPC stays in the
    -- coordinator and will fail its session check after the world changes.
    M.coordinator:cancel('World changing')
    M.adapter:invalidate()
end
function M.prepare_world_change()
    -- LoadMap's pre hook still has the old world. Detach its UI there;
    -- native wrappers retained until after travel can reference freed widgets.
    -- In the pre hook the old Blueprint function still exists. Detach before
    -- loading begins; a new ready session gets a fresh observer/registration.
    stop_early_entry()
    M.begin_world_change()
    -- Release each owner even if another owner's native detachment fails.
    local function cleanup(fn,...)
        if not fn then return end
        local ok,why=pcall(fn,...)
        if not ok then log('Old-world UI cleanup failed: '..tostring(why))end
    end
    cleanup(M.close,'Leaving old world',false,true)
    cleanup(Context.destroy);cleanup(Panel.destroy)
    cleanup(Controller.forget_world);cleanup(Context.forget);cleanup(Panel.forget)
    input_owner=nil;input_library=nil;input_mode=nil;previous_cursor=nil
end
function M.end_world_change()
    M.lifecycle:end_load();M.lifecycle_poll=0;M.lifecycle_retry_at=nil;M.world_cleanup_pending=true
end
local function defer_runtime(now)
    M.lifecycle:observe(nil);M.lifecycle_poll=0;M.lifecycle_retry_at=now+1
    return false
end
function M.runtime_ready()
    if M.lifecycle.loading then return false end
    if M.lifecycle.ready then return true end
    local retry_clock=os.clock()
    if M.lifecycle_retry_at and retry_clock<M.lifecycle_retry_at then return false end
    M.lifecycle_poll=(M.lifecycle_poll or 0)-1
    if M.lifecycle_poll>0 then return false end
    M.lifecycle_poll=6
    local ok,c=pcall(M.adapter.context,M.adapter,true)
    if not ok or MenuGuard.blocked(c.pc) then return defer_runtime(retry_clock)end
    local checked,ready=pcall(require('stashlink.session_readiness').check,c)
    if not checked or ready~=true then return defer_runtime(retry_clock)end
    local got,now=pcall(function()
        local clock=M.adapter:binding('lifecycle_clock','/Script/Engine.Default__GameplayStatics')
        return clock:GetRealTimeSeconds(c.pc)
    end)
    if not got then M.lifecycle_poll=0;M.lifecycle_retry_at=retry_clock+1;return false end
    M.lifecycle_retry_at=nil
    if not M.lifecycle:observe(c.session,now) then return false end
    if M.world_cleanup_pending then
        M.world_cleanup_pending=false
        -- Old-world native detachment belongs to the pre hook. After travel,
        -- close(true) only forgets wrappers and cannot touch their methods.
        M.close('World changed',true);M.adapter:invalidate()
    end
    log('Player session ready; background work resumed')
    M.poll_early_entry()
    return true
end
local function key(name,action,allow_closed,modifiers,redraw)
    local on_game_thread=Scheduler.pin(function(pressed,was_open)
        if M.stopped then return end
        if not View.open and name~="F6" and not allow_closed then return end
        if Panel.ledger_key_quarantine_until and pressed and pressed<=Panel.ledger_key_quarantine_until
            and name~='F6'and name~='ESCAPE'and name~='LEFT_MOUSE_BUTTON'and name~='RIGHT_MOUSE_BUTTON'
            and not(name=='RETURN'and View.open and Panel.extras_open)then return end
        -- Check native focus immediately: typing F/V/etc must never issue an
        -- inventory action before the next ordinary input-sync pulse.
        if View.open and valid(Panel.ledger_open_input)and Panel.ledger_open_input:HasKeyboardFocus()
            and name~='LEFT_MOUSE_BUTTON'and name~='RIGHT_MOUSE_BUTTON'then
            Panel.ledger_key_quarantine_until=os.clock()+.5
            if name=='RETURN'then safe(function()M.ui_action('ledger_key_apply')end);safe(Panel.render);return end
            if name~='ESCAPE'and name~='F6'then return end
        end
        M.input_actions=(M.input_actions or 0)+1
        M.last_key=name
        safe(function() action(pressed,was_open) end)
        if View.open and name~="LEFT_MOUSE_BUTTON"and redraw~=false then safe(Panel.render) end
    end)
    -- Stamp the press on arrival: the game thread may run it after a slow open.
    local callback=Scheduler.pin(function()
        if not M.lifecycle.ready then return end
        local pressed=os.clock();local was_open=View.open
        Scheduler.run(function() on_game_thread(pressed,was_open) end)
    end)
    local code=not name:match('^%d$')and Key[name]or nil
    if not code then code=assert(require('stashlink.ledger_keys').info(name)).vk end
    if modifiers then RegisterKeyBind(code,modifiers,callback) else RegisterKeyBind(code,callback) end
end
function M.ensure_open_key_binding()
    local preferences=require('stashlink.ledger_key_preferences')
    local selected=preferences.custom and preferences.custom()
    if not selected or selected=='F6'then return end
    M.custom_key_bindings=M.custom_key_bindings or{}
    if M.custom_key_bindings[selected]then return end
    -- At most one callback per reviewed key for this process. Old callbacks
    -- become inert when another key is selected; travel adds none.
    key(selected,function(pressed,was_open)
        if was_open or View.open or require('stashlink.ledger_key_preferences').custom()~=selected then return end
        local target,c=Context.focused(M.adapter,View)
        if target and LedgerKeyboard.allow_custom_entry(selected,pressed,target,c)then M.open(target,selected)end
    end,true,nil,false)
    M.custom_key_bindings[selected]=true
end
function M.attach()
    if M.attached then return end
    M.attached=true
    -- Map callbacks only change Lua state. Native widget cleanup, reticle
    -- queries and controller polling wait for a stable gameplay session.
    Scheduler.gate=M.runtime_ready
    View.configure_tabs()
    Panel.bind(M.adapter,M.ui_action)
    Context.bind(M,View)
    Controller.bind(M,Panel,View,Context)
    M.ensure_open_key_binding()
    -- Bounded registration retries only. After initialization the observer
    -- reads no reticle state here; native focus notifications own that work.
    Scheduler.every(80,M.poll_early_entry)
    Scheduler.every(16,function()
        if LedgerKeyboard.custom_pulse then LedgerKeyboard.custom_pulse(M,View,Context)end
    end)
    -- Keep observing a sent request after menu close; closing cannot retract it.
    Scheduler.every(32,function() if not M.stopped then M.poll_transfer() end end)
    -- External inventory changes are observed with read-only array fingerprints.
    -- No native inventory hook re-enters this mod while MoveItem is executing.
    local last_toggle=-1
    key("F6",function()
        local now=os.clock(); if now-last_toggle<0.3 then return end; last_toggle=now
        if View.open then M.close() else M.open(nil,'F6') end
    end)
    key("F7",function()
        if not View.open or View.entry then return end
        View.mode=View.mode=="stored" and "held" or "stored"; View.selection=1; View.player_slot=nil
        if View.mode=="held" then Panel.navigate(0) end
    end)
    key("F8",function() if View.open then Panel.focus_search() end end)
    key("F4",function() if View.open then Panel.focus_amount() end end)
    key("F3",function() if View.open then M.refresh(); View.status="Inventory refreshed" end end)
    key("ESCAPE",function() M.back() end)
    key("UP_ARROW",function() if View.open and not View.entry then Panel.navigate(-8) end end)
    key("DOWN_ARROW",function() if View.open and not View.entry then Panel.navigate(8) end end)
    key("LEFT_ARROW",function() if View.open and not View.entry then Panel.navigate(-1) end end)
    key("RIGHT_ARROW",function() if View.open and not View.entry then Panel.navigate(1) end end)
    key("PAGE_UP",function() if View.open and not View.entry then Panel.navigate(View.mode=="stored" and -Panel.page_size or -Panel.bag_capacity()) end end)
    key("PAGE_DOWN",function() if View.open and not View.entry then Panel.navigate(View.mode=="stored" and Panel.page_size or Panel.bag_capacity()) end end)
    key("LEFT_MOUSE_BUTTON",function(pressed) if View.open then Panel.pointer_down(false,false,pressed) end end)
    key("LEFT_MOUSE_BUTTON",function(pressed) if View.open then Panel.pointer_down(true,false,pressed) end end,false,{ModifierKey.SHIFT})
    key("LEFT_MOUSE_BUTTON",function(pressed) if View.open then Panel.pointer_down(false,true,pressed) end end,false,{ModifierKey.CONTROL})
    M.shift_drag_registered=true
    M.shift_force_registered=true
    key('RIGHT_MOUSE_BUTTON',function() if View.open then Panel.right_click() end end)
    M.use_key_registered=true
    for name,action in pairs({V="bag_sort",SPACE="sort"}) do
        key(name,function() if View.open and not View.entry then M.ui_action(action) end end)
    end
    local last_context_f=-1
    key("F",function(pressed)
        pressed=pressed or os.clock()
        if pressed-last_context_f<.35 then return end;last_context_f=pressed
        if View.open then
            if View.entry then return end
            if M.fill_ready(pressed) then M.ui_action("matching",pressed)
            elseif M.opened_at and pressed>=M.opened_at then View.status='Press F again to fill stacks' end
        else
            local target=LedgerKeyboard.allow_entry('F')and Context.focused(M.adapter,View)
            if target then M.open(target) end
        end
    end,true)
    local last_context_e=-1
    key('E',function(pressed)
        if View.open or not LedgerKeyboard.allow_entry('E')then return end
        pressed=pressed or os.clock()
        if pressed-last_context_e<.35 then return end;last_context_e=pressed
        local target=Context.focused(M.adapter,View)
        if target then M.open(target)end
    end,true,nil,false)
    key("RETURN",function()
        if not View.open then return end
        if View.entry=='bank_tab_name'then Panel.bank_action('bank_save');Panel.render();return end
        if View.entry=="native_search" then Panel.sync_inputs(false); View.entry=nil; return end
        if View.entry=="native_amount" then
            Panel.sync_inputs(true); return
        end
        -- Slate may clear textbox focus on Enter before this queued callback.
        -- In Options, Enter commits a changed key or does nothing; it never
        -- falls through from an editor into an inventory transfer.
        if Panel.extras_open and valid(Panel.ledger_open_input)then
            local typed=Panel.ledger_open_input:GetText():ToString()
            if View.entry=='native_ledger_key'or typed~=require('stashlink.ledger_key_preferences').key()then
                M.ui_action('ledger_key_apply')
            end
            return
        end
        if Controller.modal or View.entry then return end
        M.ui_action("transfer")
    end)
    -- Native EditableTextBox owns typing; do not schedule a grid redraw for every letter.
    local refresh_action=Scheduler.pin(function()
        M.refresh_pending=false
        if not View.open then return end
        local ok,err=pcall(function()
            local checked_context=M.adapter:check_access()
            Panel.sync_inputs(false)
            if M.dirty~=true then
                M.dirty=M.dirty or {}
                for address in pairs(M.adapter:detect_changes(nil,checked_context)) do M.dirty[address]=true end
            end
            if M.adapter:membership_changed(checked_context) then M.dirty=true end
            if M.dirty==true or (type(M.dirty)=="table" and next(M.dirty)) then M.refresh(true) end
        end)
        if not ok then M.close(tostring(err)) end
    end)
    Scheduler.every(32,refresh_action)
    Scheduler.every(1000,function()
        if View.open then View.remember_view(Panel)end
    end)
    Scheduler.every(16,function()
        if View.memory and View.memory.dirty and not M.stopped then
            if not Panel.pointer and not Controller.carry and not M.coordinator.busy and not require('stashlink.bulk').job then
                local ok,why=View.flush_preferences(false)
                if not ok and M.preference_error~=tostring(why)then M.preference_error=tostring(why);View.status='Could not save bank preferences: '..tostring(why);log(View.status)end
            end
        end
    end)
    Scheduler.every(16,function()
        if M.stopped or not View.open then return end
        if Panel.has_work() then safe(function() Panel.pointer_tick(); Panel.pump_icons(2) end) end
        -- The native ScrollBox owns wheel and scrollbar input; follow its offset.
        safe(Panel.scroll_tick)
    end)
    Scheduler.every(16,function()
        if M.stopped then return end
        local ok,why=pcall(Controller.tick)
        if not ok then
            Controller.disabled=true;pcall(Controller.reset,false)
            if View.open then pcall(mode,true);View.status='Controller input unavailable; mouse controls remain active' end
            if M.controller_error~=tostring(why) then M.controller_error=tostring(why);log(M.controller_error) end
        end
    end)
    if type(RegisterLoadMapPreHook)=='function' and type(RegisterLoadMapPostHook)=='function' then
        RegisterLoadMapPreHook(Scheduler.pin(M.prepare_world_change))
        RegisterLoadMapPostHook(Scheduler.pin(M.end_world_change))
    elseif type(RegisterLoadMapPostHook)=='function' then
        RegisterLoadMapPostHook(Scheduler.pin(function()
            M.begin_world_change();M.end_world_change()
        end))
    end
    log("Local panel attached. F6 opens Stashlink near a Storage Ledger.")
    log("Runtime revision: sol-review-20261017.1")
end

function M.command(input)
    M.attach()
    local verb,args=input:match("^(%S+)%s*(.*)$")
    if verb=='network_test_arm' then
        assert(require('stashlink.settings').development,'Test interface is disabled')
        assert(not M.coordinator.busy and not M.coordinator.blocked,'An unfinished or uncertain transfer cannot be unlocked')
        local c=M.adapter:context()
        assert(c.networked and not c.pawn:HasAuthority(),'Join the remote test server first')
        local expected=args:upper()
        assert(#expected==32 and expected:match('^[0-9A-F]+$'),'Expected the disposable character GUID')
        local g=c.pc:GetCharacterGuid().InnerGuid
        assert(type(g)=='table' and type(g.A)=='number' and type(g.B)=='number' and type(g.C)=='number' and type(g.D)=='number','Character GUID binding changed')
        local actual=string.format('%08X%08X%08X%08X',g.A%4294967296,g.B%4294967296,g.C%4294967296,g.D%4294967296)
        assert(actual==expected,'The disposable test character is not selected')
        assert(M.adapter:build_supported(),'Inventory bindings changed')
        local checked,matched,note=pcall(require('stashlink.compat').check_network)
        assert(checked and matched==true,'Network inventory bindings changed: '..tostring(note or matched))
        -- Normal opening and every dispatched move still perform the ledger
        -- range and ownership checks; arming does not override either guard.
        M.adapter.network_ok=true
        M.adapter.network_test_session=c.session
        if View.open then View.status='TEST SESSION: multiplayer transfers enabled for this connection only';Panel.render() end
        return 'Disposable-character test transfers enabled; reconnecting locks them again'
    elseif verb=='network_identity' then
        assert(require('stashlink.settings').development,'Test interface is disabled')
        local pc=Helpers.GetPlayerController()
        assert(valid(pc) and pc:IsLocalPlayerController(),'Local player unavailable')
        local fn=StaticFindObject('/Script/Dominion.DominionPlayerControllerBase:GetPlayerId')
        assert(valid(fn) and require('stashlink.compat').signature(fn)=='StrProperty:ReturnValue','Player-ID getter changed')
        local value=pc:GetPlayerId();if type(value)~='string' then value=value:ToString() end
        -- The game may serialize its online identity as JSON. Preserve that
        -- exact value for DedicatedServer.ini rather than guessing a raw GUID.
        assert(type(value)=='string' and #value>=16 and #value<=1024 and not value:find('[%c]'),'Player ID is not ready')
        local here=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
        local scripts=assert(here:match('^(.*)/stashlink/[^/]+$'),'Test path unavailable')
        local file=assert(io.open(scripts..'/../diagnostics/network-owner-id.txt','w'))
        file:write(value);file:close()
        return 'Player ID recorded locally for the test server'
    elseif verb=="open" then return M.open()
    elseif verb=='controller' then return Controller.debug(args)
    elseif verb=="close" then M.close(); return "Closed"
    elseif verb=="rebuild" then
        M.close("Rebuilding layout");Panel.destroy();package.loaded["stashlink.chest_layout"]=nil
        return M.open()
    elseif verb=="bag_sort" then return M.sort_backpack()
    elseif verb=="context" then
        local actor=Context.focused(M.adapter,View)
        return "focused_ledger="..tostring(actor~=nil).." prompt="..tostring(Context.visible)
    elseif verb=="near" then
        local actor,d=M.adapter:nearest(100000)
        return valid(actor) and (actor:GetFullName().." distance="..d) or "No loaded ledger"
    elseif verb=="status" then return "open="..tostring(View.open).." widget="..tostring(valid(Panel.root))
        .." in_viewport="..tostring(valid(Panel.root) and Panel.root:IsInViewport())
        .." transient="..tostring(valid(Panel.root) and Panel.root:HasAnyFlags(0x40))
        .." updates="..Panel.updates.." keys="..tostring(M.input_actions or 0).." last="..tostring(M.last_key)
        .." scans="..tostring(M.adapter.refresh_count or 0).." last_scan_cpu_ms="..string.format("%.2f",M.adapter.refresh_ms or 0)
        .." transfer_ms="..string.format("%.2f",M.transfer_ms or 0)
        .." inventories_read="..tostring(M.adapter.last_inventory_reads or 0)
        .." render_ms="..string.format("%.2f",Panel.render_ms or 0).." icons_pending="..tostring(Panel.icons_pending or 0)
        .." scope_ms="..tostring(M.adapter.scope_ms).." query_ms="..tostring(M.adapter.query_ms).." read_ms="..tostring(M.adapter.read_ms).." tail_ms="..tostring(M.adapter.tail_ms)
        .." writes="..tostring(M.adapter.validated).." "..View.status
    elseif verb=="prove" then return M.prove()
    elseif verb=="dragproof" then
        local ok,result=pcall(M.drag_proof)
        if not ok then M.adapter.validated=false; error(result) end
        return result
    elseif verb=="page" then
        local n=tonumber(args); assert(n and n>=1 and n==math.floor(n),"Use page N")
        View.mode="stored"; Panel.scroll_to_row((n-1)*Panel.visible_rows); Panel.render()
        return "Scrolled; render_ms="..string.format("%.2f",Panel.render_ms or 0)
    elseif verb=="slotmove" then
        local from,to=args:match("^(%d+)%s+(%d+)$"); assert(from and to,"Use slotmove FROM TO")
        from,to=tonumber(from),tonumber(to)
        local s=M.adapter.snapshot; local target=s.player_slots[to]
        return describe(M.transfer("rearrange",s.player_slots[from],s.player_slots[from].total,nil,{destination_slot=to,target_identity=target and target.source.identity or ""}))
    elseif verb=="snapshot" then
        local s=M.adapter.anchor and M.refresh() or M.adapter:open()
        local lines={"Linked containers="..s.containers.." occupied="..s.occupied.." capacity="..s.capacity}
        for _,where in ipairs({"stored","held"}) do
            for i,row in ipairs(s[where]) do lines[#lines+1]=where.." "..i.." | "..row.name.." | "..row.total.." | available="..row.available end
        end
        return table.concat(lines,"\n")
    elseif verb=="find" then View.query=args; View.selection=1; return "Search: "..args
    elseif verb=="panel" then assert(args=="held" or args=="stored","Use held or stored"); View.mode=args; View.selection=1; return args
    elseif verb=="amount" then local n=tonumber(args); assert(n and n>0 and n==math.floor(n),"Invalid quantity"); View.custom_amount=n; return "Amount "..n
    elseif verb=="withdraw" or verb=="deposit" then
        local index,amount=args:match("^(%d+)%s+(%d+)$")
        assert(index and amount,"Use bank "..verb.." row-number amount")
        local s=M.adapter.snapshot or M.adapter:open()
        local row=(verb=="withdraw" and s.stored or s.held)[tonumber(index)]
        return describe(M.transfer(verb,row,tonumber(amount)))
    elseif verb=="matching" then return M.matching()
    elseif verb=="inputmeta" then
        local lines={}
        for _,name in ipairs({"SetInputMode_UIOnlyEx","SetInputMode_GameOnly"}) do
            local fn=StaticFindObject("/Script/UMG.WidgetBlueprintLibrary:"..name)
            fn:ForEachProperty(function(p) lines[#lines+1]=p:GetFullName() end)
        end
        return table.concat(lines,"\n")
    elseif verb=="capture" then
        local pc=M.adapter:context().pc
        StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):ExecuteConsoleCommand(pc,"Shot showui",pc)
        return "Requested an in-game UI screenshot"
    end
    return "bank open / close / snapshot / find text / panel held|stored / amount N / withdraw ROW N / deposit ROW N / matching"
end

return M
