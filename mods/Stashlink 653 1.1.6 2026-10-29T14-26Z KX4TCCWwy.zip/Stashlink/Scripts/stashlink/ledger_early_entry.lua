-- Observe the game's existing bound event without activating the loader's
-- full-path script-hook lookup on every unrelated Blueprint execution.
-- This remains synchronous observation, never event cancellation.
local M={dispatcher={}}
M.path='/Game/Gameplay/Character/Player/BP_PlayerCharacter.BP_PlayerCharacter_C:BndEvt__BP_PlayerCharacter_BP_Components_InteractionDetector_K2Node_ComponentBoundEvent_4_OnCurrentInteractableActorChanged__DelegateSignature'
M.event_name=assert(M.path:match(':([^:]+)$'))
local function valid(o)return o and o:IsValid()end
local function same(a,b)return valid(a)and valid(b)and a:GetAddress()==b:GetAddress()end
local function parameter(w)return w and w:get()end
local function integer(n)return type(n)=='number'and n>=0 and n%1==0 end
function M.new(service,view,options)
 options=options or {}
 local Keyboard=options.keyboard or require('stashlink.ledger_keyboard')
 local Context=options.context or require('stashlink.context_entry')
 local Prefs=options.preferences or require('stashlink.ledger_key_preferences')
 local dispatcher=options.dispatcher or M.dispatcher
 local self={needs_initial=true,attempts=0,stats={events=0,not_ready=0,foreign=0,stale=0,
  no_ledger=0,armed=0,armed_event=0,armed_initial=0,failures=0,reentrant=0},logs=0}
 local function ready()
  return not self.stopped and not service.stopped and service.lifecycle
   and service.lifecycle.ready==true and service.lifecycle.loading~=true
 end
 local function note(message)
  if self.logs>=8 then return end
  self.logs=self.logs+1
  (options.log or print)('[Stashlink private early focus] '..tostring(message):sub(1,240))
 end
 local function fail(why)
  self.stats.failures=self.stats.failures+1;self.last_error=tostring(why):sub(1,240)
  note(self.last_error)
 end
 local function scan(event_context,event_component,origin)
  -- Check before unwrapping callback params or reading ANY world/native object.
  if not ready()then self.stats.not_ready=self.stats.not_ready+1;return end
  local protection=Prefs.protected and Prefs.protected()or Prefs.enabled()
  if not protection or view.open then return end
  local component,pawn
  if origin=='event'then
   pawn=parameter(event_context);component=parameter(event_component)
   if not valid(pawn)or not valid(pawn.InteractableDetector)then self.stats.foreign=self.stats.foreign+1;return end
   if not valid(component)then self.stats.no_ledger=self.stats.no_ledger+1;return end
   if not same(component,pawn.InteractableDetector.CurrentInteractable)then self.stats.stale=self.stats.stale+1;return end
   -- Ordinary stations/resources need no player lookup or session strings.
   -- This is rejection only; a real ledger still passes every check below.
   if not Context.is_ledger(component:GetOwner())then self.stats.no_ledger=self.stats.no_ledger+1;return end
  end
  local c=service.adapter:context(origin~='event')
  if not ready()then self.stats.not_ready=self.stats.not_ready+1;return end
  if not(c and valid(c.pc)and valid(c.pawn)and valid(c.world)
   and type(c.session)=='string'and c.session~=''
   and c.pc:IsLocalPlayerController()and same(c.pc.Pawn,c.pawn)
   and same(c.pc:GetWorld(),c.world)and same(c.pawn:GetWorld(),c.world))then
   self.stats.foreign=self.stats.foreign+1;return
  end
  if origin=='event'then
   if not same(pawn,c.pawn)then self.stats.foreign=self.stats.foreign+1;return end
   local detector=c.pawn.InteractableDetector
   if not valid(detector)or not same(component,detector.CurrentInteractable)then
    self.stats.stale=self.stats.stale+1;return
   end
  end
  -- Recheck all existing reticle/menu/range/world constraints. The event alone
  -- cannot authorize a ledger, and a previously remembered actor is never used.
  local actor,current=Context.focused(service.adapter,view,c)
  if not ready()then self.stats.not_ready=self.stats.not_ready+1;return end
  if not actor or not current then self.stats.no_ledger=self.stats.no_ledger+1;return end
  if not(same(current.pc,c.pc)and same(current.pawn,c.pawn)and same(current.world,c.world)
   and current.session==c.session
   and same(actor:GetWorld(),c.world))then self.stats.foreign=self.stats.foreign+1;return end
  if component and not same(component,actor.Interaction)then self.stats.stale=self.stats.stale+1;return end
  if not ready()then self.stats.not_ready=self.stats.not_ready+1;return end
  local protected,why=Keyboard.protect(c,actor)
  if not protected then fail(why or 'Bank mask was not verified');return end
  self.stats.armed=self.stats.armed+1;self.last_origin=origin
  self.stats['armed_'..origin]=self.stats['armed_'..origin]+1
  self.last_session=tostring(c.session);self.last_target=tostring(actor:GetAddress())
  self.last_at=os.clock()
  if self.stats.armed<=3 then note('verified bank mask from '..origin..'; no native F armed')end
 end
 function self:observe(event_context,event_component)
  if not self.registered or not ready()then self.stats.not_ready=self.stats.not_ready+1;return end
  self.stats.events=self.stats.events+1
  if self.busy then self.stats.reentrant=self.stats.reentrant+1;return end
  self.busy=true
  local ok,why=pcall(scan,event_context,event_component,'event')
  self.busy=nil;if not ok then fail(why)end
  -- A nil result leaves this void Blueprint event unchanged. Returning false
  -- would not cancel the body, which has already completed before this hook.
 end
 function self:register()
  if self.registered then return true end
  if not ready()then return nil,'Waiting for a ready player session'end
  if self.attempts>=3 then return nil,'Registration attempts exhausted'end
  if self.retry_at and os.clock()<self.retry_at then return nil,'Registration retry deferred'end
  self.attempts=self.attempts+1;self.retry_at=os.clock()+1
  local ok,why=pcall(function()
   assert(type(Keyboard.protect)=='function','Reviewed bank-mask protect API unavailable')
   assert(type(RegisterCustomEvent)=='function','Short-name event API unavailable')
   local fn=StaticFindObject(M.path)
   assert(valid(fn),'Recorded bound event is not loaded')
   local class=fn:GetClass()
   assert(valid(class)and class:GetFullName()=='Class /Script/CoreUObject.Function',
    'Recorded name is not an ordinary UFunction; delegate hooks are unsupported')
   local flags=fn:GetFunctionFlags();assert(integer(flags),'Function flags unavailable')
   self.function_flags=flags
   assert((flags&0x400)==0,'Expected Blueprint function is native; hook timing differs') -- FUNC_Native
   local fields={}
   fn:ForEachProperty(function(p)
    local full=p:GetFullName();fields[#fields+1]=(full:match('^(%S+)')or'?')..':'..(full:match('([^:]+)$')or'?')
   end)
   self.signature=table.concat(fields,'|')
   assert(self.signature=='ObjectProperty:CurrentInteractableComponent','Recorded bound-event signature changed')
   if not dispatcher.registered then
    dispatcher.callback=dispatcher.callback or function(...)
     local active=dispatcher.active
     if active then return active:observe(...)end
    end
    RegisterCustomEvent(M.event_name,dispatcher.callback)
    dispatcher.registered=true
   end
   -- The short-name registry has one owner per name and returns no token.
   -- Keep one owned dispatcher through travel and replace only this receiver
   -- after the complete function/session checks pass.
   dispatcher.active=self
   self.registered=true;self.retry_at=nil
   note('registered short-name post-Blueprint focus observation; flags='..flags)
  end)
  if not ok then fail(why);return nil,why end
  return true
 end
 function self:poll()
  -- Intended at the existing ready scheduler cadence. Once registered and
  -- initialized, this path performs no context, reticle, or native reads.
  if not ready()then return end
  if not self:register()then return end
  if not self.needs_initial then return end
  if self.busy then self.stats.reentrant=self.stats.reentrant+1;return end
  self.needs_initial=nil
  self.busy=true
  local ok,why=pcall(scan,nil,nil,'initial')
  self.busy=nil;if not ok then fail(why)end
 end
 function self:forget_world()
  -- The regular keyboard owner detaches pre-travel and forgets post-travel.
  -- This experiment retains no pawn, actor, world, function or widget wrappers.
  self.needs_initial=true;self.last_session=nil;self.last_target=nil;self.last_at=nil;self.last_origin=nil
 end
 function self:stop()
  self.stopped=true;self.needs_initial=nil
  -- Pure Lua retirement is safe even after travel has started. Never touch
  -- an old UFunction or accumulate another native callback on the next join.
  if dispatcher.active==self then dispatcher.active=nil end
  self.registered=nil
  return true
 end
 function self:diagnostics()
  local result={registered=self.registered==true,stopped=self.stopped==true,attempts=self.attempts,
   flags=self.function_flags,signature=self.signature,error=self.last_error,
   last_session=self.last_session,last_target=self.last_target,last_origin=self.last_origin,last_at=self.last_at,
   dispatcher_registered=dispatcher.registered==true,active_receiver=dispatcher.active==self}
  for key,value in pairs(self.stats)do result[key]=value end
  return result
 end
 return self
end
return M
