-- Pure Menu hold/release recognizer. No engine or hardware calls.
local M={hold_seconds=.75,max_gap=.25}
function M.new()return {}end
function M.reset(s)
 s.target=nil;s.session=nil;s.slot=nil;s.last=nil;s.started=nil;s.primed=false
end
local function finite(n)return type(n)=='number'and n==n and n>-math.huge and n<math.huge end
function M.step(s,keys,target,session,now)
 if type(keys)~='table'or type(keys.MENU)~='boolean'or target==nil
  or type(session)~='string'or session==''or not finite(now)or now<0
  or type(keys.slot)~='number'or keys.slot%1~=0 or keys.slot<0 or keys.slot>3 then
  M.reset(s);return false
 end
 if s.last and(now<s.last or now-s.last>M.max_gap)then
  -- A discontinuity needs a later, separately observed released sample.
  M.reset(s);return false
 end
 if s.target~=target or s.session~=session or s.slot~=keys.slot then
  M.reset(s);s.target=target;s.session=session;s.slot=keys.slot
 end
 s.last=now
 if not s.primed then
  if not keys.MENU then s.primed=true end
  return false
 end
 if keys.MENU then
  if s.started==nil then s.started=now end
  return false
 end
 local opened=s.started~=nil and now-s.started>=M.hold_seconds
 s.started=nil
 return opened
end
return M
