-- Ledger interaction keys are presentation preferences, independent of bank
-- tabs and saved item layouts. The shared store verifies alternating copies.
local Store=require('stashlink.bank_tab_store')
local Keys=require('stashlink.ledger_keys')
local M={LIMIT=1024}
local function sequence_valid(n)
    return type(n)=='number' and n==math.floor(n) and n>=1 and n<=2147483647
end
function M.pack(state,sequence)
    assert(type(state)=='table' and type(state.swap_ledger_keys)=='boolean','Invalid ledger key preference')
    assert(sequence_valid(sequence),'Invalid ledger key save sequence')
    local body
    if state.open_key~=nil then
        local key=assert(Keys.normalize(state.open_key));assert(key==state.open_key and key~='E' and key~='F','Invalid custom opening key')
        body='STASHLINK_LEDGER_KEYS\t2\t'..sequence..'\nS\t'..(state.swap_ledger_keys and '1' or '0')..'\nK\t'..key..'\n'
    else body='STASHLINK_LEDGER_KEYS\t1\t'..sequence..'\nS\t'..(state.swap_ledger_keys and '1' or '0')..'\n'end
    return body..'END\t'..Store.checksum(body)..'\n'
end
function M.unpack(value)
    assert(type(value)=='string' and #value<=M.LIMIT,'Invalid ledger key settings size')
    local body,hash=value:match('^(.*\n)END\t(%x+)\n$')
    assert(body and Store.checksum(body)==hash,'Incomplete ledger key settings')
    local sequence,flag=body:match('^STASHLINK_LEDGER_KEYS\t1\t(%d+)\nS\t([01])\n$')
    local key
    if not sequence then sequence,flag,key=body:match('^STASHLINK_LEDGER_KEYS\t2\t(%d+)\nS\t([01])\nK\t([A-Z0-9]+)\n$')end
    if key then local canonical=Keys.normalize(key);assert(canonical==key and key~='E' and key~='F','Invalid saved opening key')end
    sequence=tonumber(sequence)
    assert(sequence_valid(sequence),'Invalid ledger key settings version or record')
    return {swap_ledger_keys=flag=='1',open_key=key},sequence
end
function M.new(store)
    local self={store=store,state={swap_ledger_keys=false},loaded=false}
    function self:load()
        if self.loaded then return not self.load_error,self.load_error end
        self.loaded=true
        if not self.store then return true end
        local ok,state,why=pcall(self.store.load,self.store)
        if not ok then self.load_error='Could not read ledger key settings: '..tostring(state);return nil,self.load_error end
        if state then self.state=state
        elseif not why then
            -- Apply the new-install default only after a successful empty read.
            -- Explicit saved choices win; unreadable settings stay disabled.
            self.state={swap_ledger_keys=true}
        end
        self.load_error=why
        return not why,why
    end
    function self:swapped()return self.state.swap_ledger_keys end
    function self:set(value)
        if type(value)~='boolean' then return nil,'Choose whether to swap the ledger keys' end
        self:load()
        if self.load_error then return nil,'Saved ledger key settings could not be read; original files were preserved' end
        if value==self:swapped() and not self.state.open_key then return true end
        if not self.store then return nil,'Ledger key settings storage is unavailable' end
        local next_state={swap_ledger_keys=value}
        local called,ok,why=pcall(self.store.save,self.store,next_state)
        if not called or not ok then return nil,'Could not save ledger keys: '..tostring(called and why or ok) end
        self.state=next_state
        return true
    end
    function self:set_key(value)
        local key,why=Keys.normalize(value);if not key then return nil,why end
        if key=='E' or key=='F'then return self:set(key=='E')end
        self:load()
        if self.load_error then return nil,'Saved ledger key settings could not be read; original files were preserved'end
        if self.state.open_key==key then return true end
        if not self.store then return nil,'Ledger key settings storage is unavailable'end
        local state={swap_ledger_keys=self:swapped(),open_key=key}
        local called,ok,error=pcall(self.store.save,self.store,state)
        if not called or not ok then return nil,'Could not save ledger keys: '..tostring(called and error or ok)end
        self.state=state;return true
    end
    return self
end
local current
function M.current()
    if not current then
        local base=os.getenv('LOCALAPPDATA')
        local prefix=base and (base:gsub('\\','/')..'/RSDragonwilds/Saved/Stashlink-ledger-keys')
        current=M.new(prefix and Store.new(prefix,nil,M) or nil)
        current:load()
    end
    return current
end
function M.enabled()local p=M.current();return not p.state.open_key and p:swapped()end
function M.set(value)return M.current():set(value)end
function M.custom()return M.current().state.open_key end
function M.key()return M.custom()or(M.enabled()and'E'or'F')end
function M.set_key(value)return M.current():set_key(value)end
function M.protected()local key=M.custom();return key and key~='F6' or M.enabled()end
return M
