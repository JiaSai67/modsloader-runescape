-- Optional native input reader. Missing/invalid input never authorizes opening.
local M={}
local function integer(value,lo,hi)
 return type(value)=='number'and value==math.floor(value)and value>=lo and value<=hi
end
function M.load(path)
 if M.available then return true end
 if not path then
  local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
  local directory=source:match('^(.*)/[^/]+$')
  if not directory then return false,'Native input module path unavailable'end
  path=directory..'/../../native/stashlink_input.dll'
 end
 if not package or type(package.loadlib)~='function'then return false,'Native Lua modules unavailable'end
 local loaded,init,why=pcall(package.loadlib,path,'luaopen_stashlink_input')
 if not loaded or type(init)~='function'then return false,tostring(why or init)end
 local ok,err=pcall(init)
 if not ok then return false,tostring(err)end
 if type(StashlinkPadApiVersion)~='function'or type(StashlinkReadPadState)~='function'then
  return false,'Native input exports unavailable'
 end
 local versioned,version=pcall(StashlinkPadApiVersion)
 if not versioned or version~=1 then return false,'Native input API mismatch'end
 M.poll=StashlinkReadPadState;M.available=true;M.error=nil
 return true
end
function M.read()
 if not M.available or not M.poll then return nil end
 local ok,focused,connected,buttons,packet,slot=pcall(M.poll)
 if not ok then M.available=false;M.error=tostring(focused);return nil end
 if focused~=true or connected~=true then return nil end
 if not integer(buttons,0,65535)or not integer(packet,0,4294967295)or not integer(slot,0,3)then return nil end
 return {Y=(buttons&0x8000)~=0,MENU=(buttons&0x0010)~=0,slot=slot,packet=packet}
end
-- The keyboard reader does not require a connected controller. Physical held
-- state is kept separate from Unreal's flushed game/UI input state.
function M.keyboard_state()
 if not M.available then local ok,why=M.load();if not ok then return nil,why end end
 if not M.keyboard_poll then
  if type(StashlinkKeyboardApiVersion)~='function'or type(StashlinkReadKeyboardState)~='function'then return nil,'Native keyboard reader unavailable'end
  local ok,version=pcall(StashlinkKeyboardApiVersion)
  if not ok or version~=1 then return nil,'Native keyboard API mismatch'end
  M.keyboard_poll=StashlinkReadKeyboardState
 end
 local ok,focused,e,f=pcall(M.keyboard_poll)
 if not ok or type(focused)~='boolean'or type(e)~='boolean'or type(f)~='boolean'then return nil,'Native keyboard state unavailable'end
 return{focused=focused,E=e,F=f}
end
-- One selected physical key per call; no keyboard-wide scan or game input read.
function M.key_state(key)
 local info,why=require('stashlink.ledger_keys').info(key);if not info then return nil,why end
 if not M.available then local ok,error=M.load();if not ok then return nil,error end end
 if not M.key_poll then
  if type(StashlinkKeyApiVersion)~='function'or type(StashlinkReadKeyState)~='function'then return nil,'Restart with the complete preview to load custom-key support'end
  local ok,version=pcall(StashlinkKeyApiVersion)
  if not ok or version~=1 then return nil,'Native custom-key API mismatch'end
  M.key_poll=StashlinkReadKeyState
 end
 local ok,focused,down=pcall(M.key_poll,info.vk)
 if not ok or type(focused)~='boolean'or type(down)~='boolean'then return nil,'Native custom-key state unavailable'end
 return {focused=focused,down=down}
end
return M
