-- Pure session barrier. No Unreal objects or inventory operations live here.
local M={}
function M.new(settle_seconds)
    local self={loading=false,ready=false,settle_seconds=settle_seconds or 2}
    function self:reset()
        self.ready=false;self.token=nil;self.since=nil;self.last_time=nil
    end
    function self:begin_load()self:reset();self.loading=true end
    function self:end_load()self:reset();self.loading=false end
    function self:observe(token,now)
        if self.loading then return false end
        if type(token)~='string' or token=='' or type(now)~='number' or now~=now or now==math.huge or now==-math.huge then
            self:reset();return false
        end
        if self.token~=token or self.last_time and now<self.last_time then
            self:reset();self.token=token;self.since=now
        end
        self.last_time=now
        self.ready=now-self.since>=self.settle_seconds
        return self.ready
    end
    return self
end
return M
