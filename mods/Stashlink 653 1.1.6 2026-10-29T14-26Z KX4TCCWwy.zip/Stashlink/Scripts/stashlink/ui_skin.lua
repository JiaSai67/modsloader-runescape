-- Passive native-art treatment. This module never owns inventory actions.
local M=package.loaded['stashlink.ui_skin']or{}
local function colour(r,g,b,a)return {R=r,G=g,B=b,A=a or 1}end
local function valid(o)return o and o:IsValid()end
function M.decorate(P,c,H)
    local s={control=c,H=H};c.skin=s
    P.styled_controls=P.styled_controls or {};P.styled_controls[#P.styled_controls+1]=c
    local function line()
        local w=H.make('Border',H.tree);w:SetVisibility(3);H.place(c.canvas,w,0,0,1,1):SetZOrder(3);return w
    end
    s.top=line();s.bottom=line();s.left=line();s.right=line();s.active=line()
    s.grain=H.image(c.canvas,H.grain,2,2,c.bounds.w-4,c.bounds.h-4);s.grain:SetRenderOpacity(.2)
    s.grain.Slot:SetZOrder(1)
    s.underline=H.make('Image',H.tree);s.underline:SetBrushFromMaterial(H.underline);s.underline:SetVisibility(3)
    H.place(c.canvas,s.underline,5,c.bounds.h-8,c.bounds.w-10,8):SetZOrder(3)
    c.label.object.Slot:SetZOrder(10)
    function s:update()
        local w,h=c.bounds.w,c.bounds.h
        if self.w~=w or self.h~=h then
            self.w,self.h=w,h
            c.face.Slot:SetOffsets({Left=2,Top=2,Right=w-4,Bottom=h-4})
            c.outline.Slot:SetOffsets({Left=0,Top=0,Right=w,Bottom=h})
            self.top.Slot:SetOffsets({Left=3,Top=1,Right=w-6,Bottom=2})
            self.bottom.Slot:SetOffsets({Left=3,Top=h-3,Right=w-6,Bottom=2})
            self.left.Slot:SetOffsets({Left=1,Top=3,Right=1,Bottom=h-6})
            self.right.Slot:SetOffsets({Left=w-2,Top=3,Right=1,Bottom=h-6})
            self.grain.Slot:SetOffsets({Left=2,Top=2,Right=w-4,Bottom=h-4})
            self.underline.Slot:SetOffsets({Left=4,Top=h-8,Right=w-8,Bottom=8})
            self.active.Slot:SetOffsets(c.action=='bank_category'and {Left=w-3,Top=3,Right=2,Bottom=h-6}or{Left=3,Top=h-3,Right=w-6,Bottom=2})
        end
        local enabled=c.object:GetIsEnabled()
        local hovered=enabled and c.object:IsHovered()and not(P.tab_editor_open and not c.tab_editor)
        local focused=enabled and P.controller_active and P.controller_focus==c
        local pressed=enabled and c.object:IsPressed()
        local primary=c.action=='transfer'or c.action=='bank_save'
        local state=table.concat({tostring(enabled),tostring(hovered),tostring(focused),tostring(pressed),tostring(c.selected),tostring(primary)},':')
        if self.state==state then return end;self.state=state
        local active=enabled and (c.selected or primary)
        local bright=enabled and (hovered or focused)
        c.outline:SetBrushColor(focused and colour(.95,.83,.57)or bright and colour(.42,.29,.11)or active and colour(.30,.20,.065)or colour(.034,.029,.019))
        c.face:SetBrushColor(pressed and colour(.008,.008,.007)or active and colour(.105,.067,.021)or bright and colour(.018,.016,.011)or colour(.003,.004,.004))
        self.top:SetBrushColor(active and colour(.51,.37,.13)or bright and colour(.32,.25,.13)or colour(.14,.12,.08))
        self.left:SetBrushColor(colour(.13,.105,.065));self.right:SetBrushColor(colour(.018,.013,.008));self.bottom:SetBrushColor(colour(.002,.002,.002))
        self.active:SetBrushColor(colour(.72,.48,.13));self.active:SetVisibility(active and 3 or 1)
        self.underline:SetRenderOpacity(bright and .9 or active and .6 or 0)
        c.label.object:SetColorAndOpacity({SpecifiedColor=not enabled and colour(.28,.27,.24)or active and colour(.98,.80,.43)or bright and colour(1,.95,.79)or c.action=='bank_remove'and colour(.59,.38,.26)or colour(.69,.68,.60),ColorUseRule=0})
        self.grain:SetRenderOpacity(active and .32 or .20)
    end
    return s
end
function M.bind(P,V)
    M.P,M.V=P,V
    P.refresh_skin=function()
        for _,c in ipairs(P.styled_controls or{})do
            if not c.bank_hidden and (not c.tab_editor or P.tab_editor_open)
                and (not c.drawer or P.extras_open)and (not c.controller_keyboard or P.controller_ui.keyboard_open)
                and valid(c.object)and c.skin then c.skin:update()end
        end
    end
    if not M.scheduled then
        require('stashlink.scheduler').every(64,function()
            if M.P and M.V.open and valid(M.P.root)then M.P.refresh_skin()end
        end);M.scheduled=true
    end
end
return M
