-- Read the controller's applied input policy. The HUD Blueprint's
-- IsInputBlockingWidgetOpen calls native IsOpen on unregistered menu entries
-- while Settings is active; a native null dereference bypasses Lua pcall.
local M={}
function M.blocked(pc)
    local ok,allowed=pcall(function()
        if not pc or not pc:IsValid() then return false end
        local mode=pc.CurrentInputMode
        return mode and mode:IsValid() and mode.bAllowInteraction==true
    end)
    -- Missing/unknown policy must never authorize opening over another menu.
    return not ok or allowed~=true
end
return M
