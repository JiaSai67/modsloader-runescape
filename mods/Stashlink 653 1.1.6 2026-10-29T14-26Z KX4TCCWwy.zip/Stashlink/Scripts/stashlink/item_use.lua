-- One native use call for one explicitly identified item. No retry, automatic
-- fallback, or manual emulation of eating/equipping.
local M={}
function M.new(adapter)
 local self={adapter=adapter,seen={},count=0,busy=false,blocked=false}
 function self:execute(request)
  if type(request)~='table' or type(request.id)~='string' then return {status='rejected',reason='Invalid item action'} end
  local key=table.concat({tostring(request.session),tostring(request.source_id),tostring(request.slot),tostring(request.identity),tostring(request.signature)},'|')
  local previous=self.seen[request.id]
  if previous then return previous.key==key and previous.result or {status='rejected',reason='Item action ID was reused'} end
  if self.busy or self.blocked or self.count>=4096 then return {status='rejected',reason='Item actions are unavailable in this session'} end
  local allowed,reason=adapter:can_write(request)
  if not allowed then return {status='rejected',reason=reason} end
  local ok,target,why=pcall(adapter.resolve_use,adapter,request)
  if not ok or not target then return {status='rejected',reason=ok and why or tostring(target)} end
  self.count=self.count+1;self.busy=true
  local result={status='pending'};self.seen[request.id]={key=key,result=result}
  local issued,error_message=pcall(adapter.invoke_use,adapter,target)
  self.busy=false
  if not issued then self.blocked=true;result.status='unknown';result.reason=tostring(error_message)
  else result.status='requested' end
  return result
 end
 return self
end
return M
