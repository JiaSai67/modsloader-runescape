-- Presentation layouts follow the persisted character and ledger, not addresses.
local M={}
local function valid(o)return o and o:IsValid()end
local function guid(g)
    if not g then return end
    -- Character GUIDs wrap an FGuid in InnerGuid; ledger SpudGuid is an FGuid.
    if type(g)=='table'and type(g.InnerGuid)=='table'then g=g.InnerGuid end
    local values={g.A,g.B,g.C,g.D};local nonzero=false
    for _,n in ipairs(values)do
        if type(n)~='number'or n~=math.floor(n)or math.abs(n)>4294967295 then return end
        nonzero=nonzero or n~=0
    end
    if #values~=4 or not nonzero then return end
    return table.concat(values,':')
end
function M.read(c)
    local ok,key=pcall(function()
        local cls=M.class
        if not valid(cls)then cls=StaticFindObject('/Script/Dominion.BaseBuildingActor');M.class=cls end
        if not valid(cls)or not valid(c.anchor)or not c.anchor:IsA(cls)then return end
        local player,ledger=guid(c.pc:GetCharacterGuid()),guid(c.anchor.SpudGuid)
        if player and ledger then return 'character:'..player..'|ledger:'..ledger end
    end)
    return ok and key or nil
end
return M
