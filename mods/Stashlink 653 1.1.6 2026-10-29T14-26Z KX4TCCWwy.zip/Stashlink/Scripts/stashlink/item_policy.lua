-- Exact native classes audited on the supported build. Unknown subclasses do
-- not inherit write permission: their additional state must be understood first.
local M={}
M.base='Class /Script/Dominion.Item'
M.held='Class /Script/Dominion.HeldEquipmentItem'
local kinds={Item='item',Equipment='equipment',Trinket='equipment',HeldEquipmentItem='held',Shield='held',
 WearableEquipment='wearable',HeldContainerEquipmentItem='container',
 Ammo='equipment',MagicAmmo='equipment',RangedAmmo='equipment',FishingBaitAmmo='equipment'}
function M.kind(class_name) return kinds[class_name:match('^Class /Script/Dominion%.([%w_]+)$')] end
function M.writable(class_name) return M.kind(class_name)~=nil end
-- Native ammo use selects ammo; it does not toggle selection off.
function M.use_label(row)
 local source=row.source or (row.sources and row.sources[1])
 local class=source and source.signature and source.signature:match('^([^|]+)') or ''
 local ammo=class:match('^Class /Script/Dominion%.([%w_]+)$')
 ammo=ammo=='Ammo' or ammo=='MagicAmmo' or ammo=='RangedAmmo' or ammo=='FishingBaitAmmo'
 return row.equipped and row.use_verb=='Equip' and not ammo and 'Unequip' or row.use_verb
end
local function unwrap(value)
 local ok,result=pcall(function() return value:get() end);return ok and result or value
end
local function object_name(value) return value and value:IsValid() and value:GetFullName() or '' end
local function string_value(value)
 if value==nil then return '' end
 return type(value)=='string' and value or value:ToString()
end
local function number(value)
 assert(type(value)=='number' and value==value and math.abs(value)<math.huge,'Invalid equipment state')
 return string.format('%.17g',value)
end
local function pack(values)
 local result={}
 for _,v in ipairs(values) do local s=tostring(v);result[#result+1]=#s..':'..s end
 return table.concat(result)
end
-- Read borrowed native properties only; these values are never written back.
function M.effects(item,class_name)
 local kind=M.kind(class_name)
 local persistence=string_value(item.ItemDataPersistenceId)
 local fields={}
 if persistence~='' then fields[#fields+1]='persistence';fields[#fields+1]=persistence end
 if kind and kind~='item' then
  fields[#fields+1]='equipment';fields[#fields+1]=number(item.CurrentVitalShield)
  local enchantments={}
  item.EnchantmentGameplayEffects:ForEach(function(_,value) enchantments[#enchantments+1]=object_name(unwrap(value)) end)
  fields[#fields+1]=pack(enchantments)
 end
 if kind=='held' or kind=='container' then
  fields[#fields+1]='held'
  fields[#fields+1]=object_name(item.CurrentMagicalHeldEquipmentEffectInstance.Data)
  fields[#fields+1]=object_name(item.CurrentPhysicalHeldEquipmentEffectInstance.Data)
 end
 if kind=='wearable' then
  local row=item.CurrentWearableEquipmentDataTableRowHandle
  fields[#fields+1]='wearable';fields[#fields+1]=object_name(row.DataTable);fields[#fields+1]=string_value(row.RowName)
 elseif kind=='container' then
  local contents=item.Contents
  fields[#fields+1]='container';fields[#fields+1]=object_name(contents.ContentData);fields[#fields+1]=number(contents.Quantity)
  fields[#fields+1]=string_value(item.ContentPersistenceID);fields[#fields+1]=number(item.Quantity_Persistence)
 end
 return #fields>0 and ('|state:'..pack(fields)) or ''
end
return M
