-- Steam build 25812671 / CL248854: genuine-service dedicated-server checks, 2026-10-14.
-- Earlier two-client contention used CL247725; see VALIDATION.md for test scope.
-- Every game/loader combination must pass compat.lua before writes are enabled.
return {steam_build="25812671", native_transfers_validated=true, disabled=false,
    multiplayer_preview=true, multiplayer_transfers_validated=true,
    -- Remote entry: hold Menu/Options for 0.75 seconds and release at the ledger.
    -- Solo retains Y/Triangle; remote Y remains reserved for the native spell menu.
    remote_controller_entry=true}
