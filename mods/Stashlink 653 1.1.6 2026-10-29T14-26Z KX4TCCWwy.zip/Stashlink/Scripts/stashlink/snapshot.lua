-- Assemble immutable UI rows from per-inventory native observations.
-- No UObject handles, native calls, or inventory mutations in this module.
local M={}
function M.assemble(records)
    local held,stored,player_slots={},{},{}
    local occupied,capacity=0,0
    for _,record in ipairs(records) do
        if not record.player then capacity=capacity+record.capacity end
        local groups=record.player and held or stored
        for slot,cell in pairs(record.slots) do
            local row=groups[cell.key]
            if not row then
                row={key=cell.key,name=cell.name,definition=cell.definition,class_name=cell.class_name,category=cell.category,stack_size=cell.stack_size,
                    memory_id=cell.memory_id,_presentation=cell,
                    writable=cell.writable,read_only_reason=cell.read_only_reason,contents=cell.contents,use_verb=cell.use_verb,masterwork_style=cell.masterwork_style,burnt=cell.burnt,masterwork_type=cell.masterwork_type,masterwork_upgrades=cell.masterwork_upgrades,total=0,available=0,sources={},durability=cell.durability,max_durability=cell.max_durability}
                groups[cell.key]=row
            end
            row.total=row.total+cell.total
            -- Physical hotbar cells permit explicit moves; aggregate/bulk rows
            -- retain their source protection and cannot consume those cells.
            row.available=row.available+(cell.source.protected and 0 or cell.available)
            row.sources[#row.sources+1]=cell.source
            if record.player then player_slots[slot]=cell else occupied=occupied+1 end
        end
    end
    local function ordered(groups)
        local result={}
        for _,row in pairs(groups) do
            table.sort(row.sources,function(a,b)
                if a.count~=b.count then return a.count<b.count end
                return a.container_id..":"..a.slot<b.container_id..":"..b.slot
            end)
            result[#result+1]=row
        end
        table.sort(result,function(a,b) if a.name~=b.name then return a.name<b.name end; return a.key<b.key end)
        return result
    end
    return {stored=ordered(stored),held=ordered(held),player_slots=player_slots,occupied=occupied,capacity=capacity}
end
return M
