-- Passive controller glyphs and focus decoration. Inventory actions live elsewhere.
local Glyph=require('stashlink.controller_glyph')
local M={}
local function valid(o)return o and o:IsValid()end
local function set(label,value)if label.value~=value then label.object:SetText(FText(value));label.value=value end end
local function show(o,on)if valid(o)then o:SetVisibility(on and 3 or 1)end end
local function texture(ui,key)
    local path=Glyph.path(key,ui.family);if not path then return end
    local o=ui.textures[path]
    if not valid(o)then o=LoadAsset(path);ui.textures[path]=o end
    return valid(o)and o or nil
end
local function prompts(ui,active,entries)
    for i,p in ipairs(ui.prompts)do
        local entry=entries[i]
        if active and entry then
            set(p.label,entry[1])
            if p.key~=entry[2]then
                local t=texture(ui,entry[2]);if t then
                    p.image:SetBrushFromTexture(t,false)
                    for _,shadow in ipairs(p.shadows or {})do shadow:SetBrushFromTexture(t,false)end
                end
                p.key=entry[2]
            end
        end
        show(p.widget,active and entry~=nil)
    end
end
function M.bind(P,V,H)
    local ui={H=H,textures={},family=Glyph.family(),keyboard_widgets={},saved={},prompts={}}
    P.controller_ui=ui;P.keyboard_controls={}
    local row_y=P.bank_layout and P.bank_layout.row_y or 614
    ui.search_image=H.make('Image',H.tree);H.place(P.right_frame,ui.search_image,226,row_y+3,24,28);show(ui.search_image,false)
    local width=(P.drawer_bounds and P.drawer_bounds.w or 672)-48
    ui.keyboard_title=H.label(P.extras,'Search storage',24,22,200,24,12,false)
    ui.keyboard_hint=H.label(P.extras,'',225,25,width-201,22,10,false)
    ui.keyboard_hint.object:SetTextOverflowPolicy(1)
    local keys={};for c in ('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):gmatch('.')do keys[#keys+1]={c,c}end
    for _,key in ipairs({{'Space',' '},{'Delete','delete'},{'Clear','clear'},{'Done','done'}})do keys[#keys+1]=key end
    local pitch=width/10
    for i,key in ipairs(keys)do
        local c=H.tiny(P.extras,key[1],24+((i-1)%10)*pitch,55+math.floor((i-1)/10)*28,pitch-4,'controller_key',key[2],true)
        c.size:SetHeightOverride(26);c.bounds.h=26
        c.object.Slot:SetOffsets({Left=24+((i-1)%10)*pitch,Top=55+math.floor((i-1)/10)*28,Right=pitch-4,Bottom=26})
        c.outline.Slot:SetOffsets({Left=0,Top=0,Right=pitch-4,Bottom=26})
        c.face.Slot:SetOffsets({Left=1,Top=1,Right=pitch-6,Bottom=24})
        c.label.object.Font.Size=11;c.label.object.Slot:SetOffsets({Left=0,Top=0,Right=pitch-4,Bottom=26})
        c.controller_keyboard=true;P.keyboard_controls[i]=c;ui.keyboard_widgets[c.object:GetAddress()]=true;c.object:SetVisibility(1)
    end
    for _,label in ipairs({ui.keyboard_title,ui.keyboard_hint})do ui.keyboard_widgets[label.object:GetAddress()]=true;show(label.object,false)end
    for i=1,7 do
        local row=H.make('CanvasPanel',H.tree);local slot=P.tree.RootWidget:AddChildToCanvas(row)
        slot:SetAnchors({Minimum={X=1,Y=1},Maximum={X=1,Y=1}});slot:SetOffsets({Left=-316,Top=-346+(i-1)*42,Right=288,Bottom=36})
        -- The glyph alpha supplies the silhouette, so the shadow follows every
        -- button shape without placing a solid box behind the prompt.
        local halo=H.make('Image',H.tree);H.place(row,halo,252,-1,34,34)
        halo:SetColorAndOpacity({R=0,G=0,B=0,A=.55})
        local drop=H.make('Image',H.tree);H.place(row,drop,255,2,32,32)
        drop:SetColorAndOpacity({R=0,G=0,B=0,A=.9})
        local icon=H.make('Image',H.tree);H.place(row,icon,201,0,32,32)
        icon.Slot:SetOffsets({Left=253,Top=0,Right=32,Bottom=32})
        local label=H.label(row,'',0,5,241,28,12,false,120);label.object:SetJustification(2)
        label.object:SetShadowOffset({X=2,Y=2})
        label.object:SetShadowColorAndOpacity({R=0,G=0,B=0,A=.9})
        ui.prompts[i]={widget=row,image=icon,label=label,shadows={halo,drop}};show(row,false)
    end
    ui.panel_lines={}
    for name,r in pairs(P.panel_bounds or {held={28,57,613,420},armour={28,470,613,150},stored={692,57,672,758}})do
        local lines={};ui.panel_lines[name]=lines
        for _,b in ipairs({{9,9,r[3]-18,2},{9,r[4]-11,r[3]-18,2},{9,9,2,r[4]-18},{r[3]-11,9,2,r[4]-18}})do
            local line=H.make('Border',H.tree);line:SetBrushColor({R=.94,G=.73,B=.34,A=.95})
            H.place(H.canvas,line,r[1]+b[1],r[2]+b[2],b[3],b[4]):SetZOrder(16);show(line,false);lines[#lines+1]=line
        end
    end
    ui.tab_glyphs={}
    -- Storage bumpers flank the top tab row.
    for _,entry in ipairs({{'LB',195,168,'held'},{'RB',568,168,'held'},{'LB',716,118,'stored'},{'RB',1304,118,'stored'}})do
        local image=H.make('Image',H.tree);H.place(H.canvas,image,entry[2],entry[3],26,24)
        ui.tab_glyphs[#ui.tab_glyphs+1]={image=image,key=entry[1],pane=entry[4]};show(image,false)
    end
end
function M.keyboard(P,V,open,options)
    local ui=P.controller_ui;if not ui or open==ui.keyboard_open then return end
    local parent=P.extras_content or P.extras
    if open then
        ui.keyboard_mode=options and options.kind or 'search';ui.keyboard_value=options and options.value or V.query
        ui.rename_id=options and options.id
        ui.rename_icon=options and options.icon
        set(ui.keyboard_title,ui.keyboard_mode=='tab_name'and 'Rename custom tab'or'Search storage')
        ui.saved={};for i=0,parent:GetChildrenCount()-1 do local w=parent:GetChildAt(i)
            if valid(w)and not ui.keyboard_widgets[w:GetAddress()]then ui.saved[#ui.saved+1]={widget=w,visibility=w:GetVisibility()};w:SetVisibility(1)end
        end;P.set_drawer(true);V.entry='controller_search'
    else
        for _,entry in ipairs(ui.saved)do if valid(entry.widget)then entry.widget:SetVisibility(entry.visibility)end end
        ui.saved={};P.set_drawer(false);V.entry=nil
    end
    ui.keyboard_open=open
    for _,c in ipairs(P.keyboard_controls)do c.object:SetVisibility(open and 0 or 1)end
    show(ui.keyboard_title.object,open);show(ui.keyboard_hint.object,open)
    if open then set(ui.keyboard_hint,(ui.keyboard_mode=='tab_name'and 'Name: 'or'Search: ')..ui.keyboard_value)end
end
function M.key(P,V,key)
    if key=='done'then return false end
    local ui=P.controller_ui
    local query=ui.keyboard_mode=='tab_name'and ui.keyboard_value or V.query
    if key=='delete'then local start=utf8.offset(query,-1);query=start and query:sub(1,start-1)or ''
    elseif key=='clear'then query='' elseif #query<80 then query=query..(ui.keyboard_mode=='tab_name'and key or key:lower())end
    ui.keyboard_value=query
    if ui.keyboard_mode~='tab_name'then V.query=query;V.mode='stored';V.selection=1;if P.scroll_to_row then P.scroll_to_row(0)end;P.search:SetText(FText(query));P.render()end
    set(ui.keyboard_hint,(ui.keyboard_mode=='tab_name'and'Name: 'or'Search: ')..query);return true
end
function M.update(P,V,active,control,carrying)
    local ui=P.controller_ui;if not ui then return end
    local previous=ui.last_update
    if previous and previous.active==active and previous.control==control and previous.carrying==carrying
        and previous.updates==P.updates and previous.entry==V.entry and previous.keyboard==ui.keyboard_open
        and previous.keyboard_mode==ui.keyboard_mode and previous.split==P.controller_split
        and previous.editor==P.tab_editor_open and previous.empty==P.bank_empty then return end
    ui.last_update={active=active,control=control,carrying=carrying,updates=P.updates,entry=V.entry,
        keyboard=ui.keyboard_open,keyboard_mode=ui.keyboard_mode,split=P.controller_split,editor=P.tab_editor_open,empty=P.bank_empty}
    if active and not ui.textures_ready then
        for _,p in ipairs(ui.tab_glyphs)do local t=texture(ui,p.key);if t then p.image:SetBrushFromTexture(t,false)end end
        local search_texture=texture(ui,'SEARCH');if search_texture then ui.search_image:SetBrushFromTexture(search_texture,false)end
        ui.textures_ready=true
    end
    local quantity=V.entry=='controller_amount' or P.controller_split~=nil
    local options=V.entry=='controller_options'
    local modal=ui.keyboard_open or quantity or options or P.tab_editor_open
    local entries=ui.keyboard_open and {{'Select','A'},{'Delete','X'},{'Clear','Y'},{ui.keyboard_mode=='tab_name'and 'Cancel'or 'Done','B'}}
        or quantity and {{'Quantity','AXIS'},{'Previous preset','LB'},{'Next preset','RB'},{'Confirm','A'},{'Cancel','B'}}
        or options and {{'Select','A'},{'Previous preset','LB'},{'Next preset','RB'},{'Close options','MENU'},{'Close options','B'}}
        or P.tab_editor_open and {{'Select','A'},{'Cancel','B'}}
        or carrying and (carrying.metadata_only and {{'Assign to tab','A'},{'Cancel','B'}} or {{'Place / Assign','A'},{'Transfer stack','RT'},{'Switch Panel','RS'},{'Cancel move','B'}})
        or control and control.action=='bank_tab'and control.data~='all'and {{'Open tab','A'},{'Manage tab','X'},{'Switch Panel','RS'},{'Close','B'}}
        or control and control.row and control.row.placeholder and {{'Organize slot','A'},{'Release placeholder','X'},{'Switch Panel','RS'},{'Close','B'}}
        or {{'Split (Hold)','A'},{'Fill Stacks','Y'},{'Search','SEARCH'},{'Options','MENU'},{'Switch Panel','RS'},{'Close','B'}}
    local stored=control and(control.pane=='stored' or (not control.pane and control.bounds and control.bounds.x>=692))
    if stored and not modal and not carrying and P.scroll_to_row then table.insert(entries,#entries,{'Scroll (Tilt)','RS'})end
    prompts(ui,active,entries)
    for _,p in ipairs(ui.tab_glyphs)do show(p.image,active and not modal and ((p.pane=='stored')==(stored==true)))end
    show(ui.search_image,active and not modal)
    if ui.search_active~=active then
        local host=P.search:GetParent()
        if valid(host)then host:SetPadding({Left=7,Top=3,Right=active and 34 or 7,Bottom=3})end
        P.search:SetHintText(FText(active and 'Search storage' or 'Search linked chests'))
        ui.search_active=active
    end
    for name,lines in pairs(ui.panel_lines)do for _,line in ipairs(lines)do show(line,active and not modal and (name=='stored' and stored or name~='stored' and not stored))end end
    if P.move_hint then set(P.move_hint,active and 'RT  Move stack' or 'Ctrl-click  Move stack')end
    show(P.close_legend,not active)
    for _,c in ipairs(P.controls)do
        if c.keyboard_key then
            local key=({matching='Y',sort='LS',bag_sort='LS',close='B'})[c.action]
            show(c.key_image,not active);if c.key_label then show(c.key_label.object,not active)end
            if active and key and not c.gamepad_image then
                local image=ui.H.make('Image',ui.H.tree);local x=(c.keyboard_key=='V' or c.keyboard_key=='ESC')and c.bounds.w-30 or 0
                ui.H.place(c.canvas,image,x,0,30,32);local t=texture(ui,key);if t then image:SetBrushFromTexture(t,false)end;c.gamepad_image=image
            end;show(c.gamepad_image,active and key~=nil)
        end
        local selected=active and c==control and not(c.pane=='stored'and P.bank_empty)
        if c.controller_selected~=selected or selected and c.controller_draw~=P.updates then
            c.controller_selected=selected
            c.controller_draw=P.updates
            if c.material then c.material:SetScalarParameterValue(P.params.selected,selected and 1 or(c.selected and 1 or 0))end
            if c.skin then c.skin:update()
            else
                if c.outline then c.outline:SetBrushColor((selected or c.selected)and {R=.84,G=.66,B=.32,A=1}or{R=.38,G=.33,B=.23,A=1})end
                if c.controller_keyboard and c.face then c.face:SetBrushColor(selected and {R=.25,G=.19,B=.09,A=1}or{R=.055,G=.05,B=.04,A=.95})end
            end
        end
    end
end
return M
