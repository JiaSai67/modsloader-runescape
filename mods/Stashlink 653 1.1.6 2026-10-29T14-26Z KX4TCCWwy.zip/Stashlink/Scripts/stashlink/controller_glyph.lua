-- Passive native artwork; no Enhanced Input pointers are assigned to widgets.
local M={}
local xbox={A='T_Xbox-A',B='T_Xbox-B',X='T_Xbox-X',Y='T_Xbox-Y',RT='T_Xbox-R_Trigger',
 LB='T_Xbox-L_Bumper',RB='T_Xbox-R_Bumper',LS='Xbox-LS_Stick_',RS='Xbox-RS_Stick_',SEARCH='T_Xbox-View_Btn',MENU='T_Xbox-Menu_Btn',AXIS='T_Xbox-L_Stick_L_R'}
local ps={A='T_PS-Cross',B='T_PS-Circle',X='T_PS-Square',Y='T_PS-Triangle',RT='T_PS-R2',
 LB='T_PS-L1',RB='T_PS-R1',LS='T_PS-L3_Stick',RS='T_PS-R3_Stick',SEARCH='T_PS5-Touchpad',MENU='PS-Options',AXIS='T_PS-L_Stick_L_R'}
function M.family()
    for _,o in ipairs(FindAllOf('CommonInputSubsystem')or {})do if o:IsValid()then
        local ok,name=pcall(function()return o:GetCurrentGamepadName():ToString()end)
        if ok then name=name:lower();if name:find('ps',1,true)or name:find('playstation',1,true)or name:find('dual',1,true)then return 'Playstation'end end
    end end
    return 'Xbox'
end
function M.path(key,family)
    family=family or 'Xbox';local name=(family=='Playstation' and ps or xbox)[key]
    if name then return '/Game/Art/UI/Inputs/Controller/'..family..'/'..name..'.'..name end
end
return M
