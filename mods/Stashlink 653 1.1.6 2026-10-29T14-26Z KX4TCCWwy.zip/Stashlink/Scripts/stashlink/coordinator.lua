-- Executes explicit intents through a native adapter. Never creates/restores items.
local M = {}
local MAX_QUANTITY = 2147483647
local function integer(n) return type(n) == "number" and n == math.floor(n) and n > 0 and n <= MAX_QUANTITY end
local function copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for k, v in pairs(value) do result[k] = copy(v) end
    return result
end
local function token(value)
    local s = tostring(value or "")
    return #s .. ":" .. s
end
local function payload(request)
    local parts = {}
    for _, key in ipairs({"session", "direction", "row_key", "quantity", "snapshot_token", "destination_id", "source_slot", "source_identity", "destination_slot", "target_identity"}) do
        parts[#parts + 1] = token(request[key])
    end
    return table.concat(parts)
end

function M.new(adapter, max_requests, existing)
    local self = existing or {adapter = adapter, session = nil, results = {}, count = 0, busy = false,
        blocked = false, max_requests = max_requests or 256}
    assert(not self.busy and not self.active,"Cannot refresh an in-flight transfer coordinator")
    self.adapter=adapter

    -- Item use and sorting share the same uncertainty gate as transfers.
    -- Bind it before a first transfer can initialize this session and clear it.
    function self:block(session)
        assert(type(session)=="string" and #session>0,"A mutation lock needs its inventory session")
        if self.session~=session then self.session,self.results,self.count=session,{},0 end
        self.blocked=true
    end

    -- UE4SS native bindings require the registered Lua state. A Lua coroutine
    -- is a different state even when resumed on the game thread. Keep pending
    -- work as plain data and advance it through ordinary scheduler callbacks.
    -- Closing the UI stops future dispatch; a sent request still needs a result.
    function self:cancel(reason)
        if not self.active then return false end
        self.cancel_reason=reason or "transfer_cancelled"
        return true
    end
    function self:result(request_id)
        local entry=self.results[request_id]
        return entry and copy(entry.result) or nil
    end
    local function finish(state)
        local result=state.result
        if result.status=="pending" then
            result.status=result.remainder==0 and "completed" or (result.moved>0 and "partial" or "rejected")
            if result.remainder>0 then result.reason=result.reason or "insufficient_available_quantity" end
        end
        self.busy,self.active,self.active_result=false,nil,nil
    end
    local function consume(state,outcome)
        local result,fragment=state.result,state.fragment
        if type(outcome)~="table" or outcome.status=="unknown" then
            result.status,result.reason,self.blocked="unknown",type(outcome)=="table" and outcome.reason or "native_outcome_uncertain",true
            finish(state);return false
        end
        if outcome.status=="rejected" then
            result.reason=outcome.reason or "native_rejection";finish(state);return false
        end
        if outcome.status~="confirmed" or type(outcome.moved)~="number"
            or outcome.moved~=math.floor(outcome.moved) or outcome.moved<0 or outcome.moved>fragment.quantity then
            result.status,result.reason,self.blocked="unknown","invalid_native_outcome",true
            finish(state);return false
        end
        result.moved=result.moved+outcome.moved
        result.remainder=state.request.quantity-result.moved
        result.fragments[#result.fragments+1]={moved=outcome.moved,requested=fragment.quantity}
        if state.request.destination_slot~=nil and type(outcome.destination_identity)=="string" then
            state.move_request.target_identity=outcome.destination_identity
        end
        if outcome.moved<fragment.quantity then
            if outcome.moved>0 and outcome.continue==true then fragment.quantity=fragment.quantity-outcome.moved
            else result.reason=outcome.reason or "partial_native_acceptance";finish(state);return false end
        else state.fragment=nil;state.index=state.index+1 end
        return true
    end
    local function advance(state)
        if not state.fragments then
            local fragments,why=adapter:plan(state.request)
            if not fragments then
                state.result.status,state.result.reason="rejected",why;finish(state);return
            end
            local planned=0
            for _,fragment in ipairs(fragments) do
                if not integer(fragment.quantity) then error("Invalid fragment quantity") end
                planned=planned+fragment.quantity
                if planned>state.request.quantity then error("Plan exceeds requested quantity") end
            end
            state.fragments=copy(fragments)
        end
        if state.operation then
            local outcome=adapter:poll_move(state.operation,state.move_request)
            if type(outcome)=="table" and outcome.status=="pending" then return end
            state.operation=nil;state.issued=false
            if not consume(state,outcome) then return end
        end
        while self.active==state do
            if not state.fragment then
                local fragment=state.fragments[state.index]
                if not fragment then finish(state);return end
                state.fragment=copy(fragment)
            end
            if self.cancel_reason then state.result.reason=self.cancel_reason;finish(state);return end
            local allowed,why=adapter:can_write(state.request)
            if not allowed then state.result.reason=why or "access_lost";finish(state);return end
            state.operations=state.operations+1
            if state.operations>512 then state.result.reason="operation_limit_reached";finish(state);return end
            state.issued=true
            local outcome=adapter:move(state.fragment,state.move_request)
            if type(outcome)=="table" and outcome.status=="pending" then
                assert(type(adapter.poll_move)=="function" and outcome.operation~=nil,"Pending native request has no observer")
                state.operation=outcome.operation
                return
            end
            state.issued=false
            if not consume(state,outcome) then return end
        end
    end
    local function run(state)
        local ok,why=pcall(advance,state)
        if not ok then
            if state.issued then
                state.result.status,state.result.reason,self.blocked="unknown",
                    (state.operation and "transfer_observation_failed: " or "native_call_failed: ")..tostring(why),true
            else
                state.result.status=state.result.moved>0 and "partial" or "rejected"
                state.result.reason="request_failed: "..tostring(why)
            end
            finish(state)
        end
        return copy(state.result)
    end
    function self:poll()
        if not self.active then return nil end
        return run(self.active)
    end

    function self:execute(request)
        local function rejected(reason)
            return {status = "rejected", requested = request.quantity, moved = 0, remainder = request.quantity, reason = reason}
        end
        if type(request) ~= "table" then return {status = "rejected", moved = 0, reason = "invalid_request"} end
        if not integer(request.quantity) then return rejected("invalid_quantity") end
        if request.direction ~= "withdraw" and request.direction ~= "deposit" and request.direction ~= "rearrange" then return rejected("invalid_direction") end
        if type(request.id) ~= "string" or #request.id > 80 or not request.id:match("^[%w_-]+$") then return rejected("invalid_request_id") end
        if type(request.row_key) ~= "string" or #request.row_key == 0 or #request.row_key > 4096 then return rejected("invalid_row") end
        local current_session = adapter:session_id()
        if not current_session or request.session ~= current_session then return rejected("stale_session") end
        if self.busy then
            local previous=self.results[request.id]
            if previous and self.session==current_session then
                if previous.identity~=payload(request) then return rejected("request_id_reused") end
                return copy(previous.result)
            end
            return rejected("transfer_in_progress")
        end
        if self.session ~= current_session then
            self.session, self.results, self.count, self.blocked = current_session, {}, 0, false
        end
        local identity = payload(request)
        local previous = self.results[request.id]
        if previous then
            if previous.identity ~= identity then return rejected("request_id_reused") end
            return copy(previous.result)
        end
        if self.blocked then return rejected("uncertain_previous_transfer") end
        if self.count >= self.max_requests then return rejected("request_limit_reached") end
        local capable, reason = adapter:can_write(request)
        if not capable then return rejected(reason or "writes_unavailable") end

        self.busy = true
        self.count = self.count + 1
        request=copy(request)
        local result = {status = "pending", request_id=request.id, requested = request.quantity, moved = 0,
            remainder = request.quantity, fragments = {}}
        self.results[request.id] = {identity = identity, result = result}
        self.cancel_reason=nil
        self.active_result=result
        self.active={request=request,move_request=copy(request),result=result,index=1,operations=0,issued=false}
        return run(self.active)
    end
    return self
end

return M
