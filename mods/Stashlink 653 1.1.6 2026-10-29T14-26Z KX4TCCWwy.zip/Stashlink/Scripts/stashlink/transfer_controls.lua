-- Availability feedback only; the shared coordinator still validates every move.
local M={}
function M.reason(row,quantity)
    if not row then return 'Select an item first' end
    if not row.writable then return row.read_only_reason or 'This item type is read-only in Stashlink' end
    if row.available<=0 then return 'This item is protected' end
    if type(quantity)~='number' or quantity~=quantity or quantity==math.huge
        or quantity<1 or quantity~=math.floor(quantity)then return 'Enter a positive whole quantity' end
    if quantity>row.available then return 'Only '..row.available..' available' end
end
function M.update(P,V)
    local row=V.selected()
    local reason=M.reason(row,tonumber(P.amount:GetText():ToString()))
    if reason~=P.transfer_unavailable or not P.transfer_availability_set then
        P.transfer_unavailable=reason;P.transfer_availability_set=true
        P.transfer_button.object:SetIsEnabled(reason==nil)
        P.transfer_button.object:SetRenderOpacity(reason and .45 or 1)
        P.transfer_button.object:SetToolTipText(FText(reason or 'Transfer the chosen quantity'))
        if P.transfer_help then P.transfer_help.object:SetText(FText(reason or ''));P.transfer_help.value=reason or '' end
    end
end
return M
