-- Normal play does not register developer commands or poll request files.
return {development=false}
