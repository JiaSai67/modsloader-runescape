-- Two verified text slots keep the previous settings if a write is interrupted.
-- Preferences are data: never loadfile/dofile a saved tab file.
local Tabs=require('stashlink.bank_tabs')
local M={LIMIT=512*1024}
local function encode(s)return (s:gsub('([^%w%._ /%-])',function(c)return string.format('%%%02X',c:byte())end))end
local function decode(s)
    assert(not s:gsub('%%[%da-fA-F][%da-fA-F]',''):find('%%'),'Invalid text escape')
    return (s:gsub('%%(%x%x)',function(c)return string.char(tonumber(c,16))end))
end
local function checksum(s,yield_work)
    local n,i,next_yield=5381,1,4097
    -- Batch byte reads; keeping the low 32 bits preserves the version-one hash.
    while i+7<=#s do
        local a,b,c,d,e,f,g,h=s:byte(i,i+7)
        n=((((((((n*33+a)*33+b)*33+c)*33+d)*33+e)*33+f)*33+g)*33+h)&0xffffffff
        i=i+8
        if yield_work and i>=next_yield then yield_work();next_yield=next_yield+4096 end
    end
    while i<=#s do n=(n*33+s:byte(i))&0xffffffff;i=i+1 end
    return string.format('%08x',n)
end
M.encode,M.decode,M.checksum=encode,decode,checksum
function M.pack(state,sequence)
    Tabs.validate(state)
    assert(type(sequence)=='number'and sequence>=1 and sequence<=2147483647 and sequence==math.floor(sequence),'Invalid save sequence')
    local lines={'STASHLINK_BANK_TABS\t2\t'..sequence..'\t'..state.next_id}
    for _,tab in ipairs(state.tabs)do
        lines[#lines+1]='T\t'..tab.id..'\t'..encode(tab.name)..'\t'..encode(tab.icon or '')
        for _,definition in ipairs(tab.items)do lines[#lines+1]='I\t'..tab.id..'\t'..encode(definition)end
    end
    local body=table.concat(lines,'\n')..'\n';local value=body..'END\t'..checksum(body)..'\n'
    assert(#value<=M.LIMIT,'Custom tabs exceed the settings size limit');return value
end
function M.unpack(text)
    assert(type(text)=='string'and #text<=M.LIMIT,'Invalid settings size')
    local body,hash=text:match('^(.*\n)END\t(%x+)\n$');assert(body and checksum(body)==hash,'Incomplete custom tab settings')
    local first,tail=body:match('^([^\n]+)\n(.*)$')
    local version,sequence,next_id=first:match('^STASHLINK_BANK_TABS\t([12])\t(%d+)\t(%d+)$')
    sequence=tonumber(sequence);assert(sequence and sequence>=1 and sequence<=2147483647,'Invalid settings version')
    local state={next_id=tonumber(next_id),tabs={}};local by_id={}
    for line in tail:gmatch('[^\n]+')do
        local kind,id,value=line:match('^([TI])\t(t%d+)\t(.*)$');assert(kind,'Invalid settings record')
        if kind=='T'then
            assert(not by_id[id],'Duplicate tab');local name,icon=value,nil
            if version=='2'then name,icon=value:match('^([^\t]*)\t([^\t]*)$');assert(name,'Invalid tab record');icon=decode(icon);if icon==''then icon=nil end end
            local tab={id=id,name=decode(name),icon=icon,items={}};by_id[id]=tab;state.tabs[#state.tabs+1]=tab
        else local tab=assert(by_id[id],'Item without tab');tab.items[#tab.items+1]=decode(value)end
    end
    Tabs.validate(state);return state,sequence
end
local function read(path,limit)
    local f,why,code=io.open(path,'rb')
    if not f then
        if code==2 then return nil end -- ENOENT is the only successful empty read.
        return nil,why or 'File open failed'
    end
    local called,text,problem=pcall(f.read,f,(limit or M.LIMIT)+1)
    local closed,ok,close_error=pcall(f.close,f)
    if not called then return nil,text end
    if text==nil and problem then return nil,problem end
    if not closed or not ok then return nil,closed and (close_error or 'File close failed') or ok end
    -- A successfully opened empty file reaches EOF immediately; its known
    -- contents are corrupt data, rather than an unresolved I/O failure.
    return text or ''
end
local function write(path,text)
    local f,why=io.open(path,'wb');if not f then return nil,why end
    local called,ok,problem=pcall(f.write,f,text)
    local flushed,flush_ok,flush_error=pcall(f.flush,f)
    local closed,close_ok,close_error=pcall(f.close,f)
    if not called or not ok then return nil,called and problem or ok end
    if not flushed or not flush_ok then return nil,flushed and flush_error or flush_ok end
    if not closed or not close_ok then return nil,closed and close_error or close_ok end
    return true
end
function M.new(prefix,io_functions,codec)
    codec=codec or M
    local io_ops=io_functions or {read=function(path)return read(path,codec.LIMIT)end,write=write}
    local self={prefix=prefix,sequence=0,slot=nil}
    local function read_copy(path)
        local called,text,why=pcall(io_ops.read,path)
        if not called then return nil,tostring(text) end
        if text~=nil and type(text)~='string' then return nil,'Invalid file read result' end
        return text,why
    end
    function self:load()
        local best,any,read_error;local sequence,selected=0,nil
        for _,slot in ipairs({'a','b'})do
            local text,why=read_copy(self.prefix..'-'..slot..'.txt');any=any or text~=nil
            if why then read_error=read_error or 'Could not read saved settings copy '..slot..': '..tostring(why) end
            if text then local ok,state,seq=pcall(codec.unpack,text)
                if ok and (not best or seq>sequence)then best=state;sequence=seq;selected=slot end
            end
        end
        -- An unreadable copy may be newer than a readable alternate. Do not
        -- choose an uncertain revision or permit overwriting either copy.
        self.load_error=read_error or ((any and not best)and 'Neither saved custom-tab copy is readable'or nil)
        if self.load_error then return nil,self.load_error end
        self.sequence,self.slot=sequence,selected
        return best
    end
    function self:save(state,yield_work)
        if self.load_error then return nil,self.load_error end
        local seq=self.sequence+1;local ok,text=pcall(codec.pack,state,seq,yield_work);if not ok then return nil,text end
        local slot=self.slot=='a'and'b'or'a';local path=self.prefix..'-'..slot..'.txt'
        local called,written,why=pcall(io_ops.write,path,text)
        if not called then return nil,'Could not save custom tabs: '..tostring(written)end
        if not written then return nil,'Could not save custom tabs: '..tostring(why or 'write failed')end
        local verified,read_error=read_copy(path)
        if verified~=text or read_error then return nil,'Could not save custom tabs: '..tostring(read_error or 'write verification failed')end
        self.sequence,self.slot=seq,slot;return true
    end
    return self
end
function M.default_path()
    local base=os.getenv('LOCALAPPDATA')
    return base and (base:gsub('\\','/')..'/RSDragonwilds/Saved/Stashlink-bank-tabs')or nil
end
return M
