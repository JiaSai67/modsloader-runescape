-- Read-only tooltip model. Live item identity is checked before requesting stats.
local M={types=nil}
local function valid(o) return o and o:IsValid() end
local function unwrap(o) local ok,r=pcall(function() return o:get() end);return ok and r or o end
function M.clean(value)
    if value==nil then return "" end
    if type(value)~="string" then value=value:ToString() end
    value=value:gsub('<img%s+id="SpecAttackCost"[^>]*></>', 'Special energy: ')
    return value:gsub('<[^>]*>','')
end
function M.format_stat(entry)
    local name,value,prefix=M.clean(entry.Name),M.clean(entry.Value),M.clean(entry.Prefix)
    local number=tonumber(value)
    if number then
        if entry.ValueType==3 then
            local seconds=math.max(0,math.floor(number+.5))
            value=seconds>=60 and string.format('%dm %02ds',math.floor(seconds/60),seconds%60) or (seconds..'s')
        elseif entry.ValueType==2 then value='×'..value
        elseif entry.ValueType==1 then value=(number>=0 and '+' or '')..value
        elseif entry.ValueType==4 then value=string.format('%+.3g%%',number*100)
        elseif entry.ValueType==5 then value=string.format('%.3g%%',number*100) end
    end
    local rendered_value=value
    local title=prefix~='' and prefix or name
    if prefix~='' and name~='' then title=prefix..' '..name end
    if title=='' then title,value=value,'' end
    local raw_name=type(entry.Name)=='string' and entry.Name or entry.Name and entry.Name:ToString() or ''
    if raw_name:find('SpecAttackCost',1,true) then
        name=raw_name:gsub('<img%s+id="SpecAttackCost"[^>]*></>', '')
        name=M.clean(name):gsub('%((.-)%)','(%1 energy)')
    end
    local parts={}
    for _,part in ipairs({{text=prefix,role='prefix'},{text=rendered_value,role='value'},{text=name,role='name'}}) do
        if part.text~='' then parts[#parts+1]=part end
    end
    return {name=title,value=value,parts=parts,raw_name=raw_name,prefix=prefix,native_value=rendered_value,primary=entry.StyleType==1,status=entry.UpgradeStatus}
end
function M.item_for(panel,control)
    local row=control.row
    if not row then return nil end
    local item
    if control.pane=='armour' then
        local selector=require('stashlink.equipment_slots').selector(control)
        if selector==nil then return nil end
        item=panel.pc.LoadoutComponent:GetEquipmentFromSlot(selector)
    else
        local source=row.source or (row.sources and row.sources[1])
        if not source then return nil end
        local inventory=panel.adapter.lookup[source.container_id]
        if not valid(inventory) then return nil end
        item=inventory:GetItemFromSlot(source.slot)
        if not valid(item) then return nil end
        local g=item.Guid
        if table.concat({g.A,g.B,g.C,g.D},':')~=source.identity then return nil end
    end
    if not valid(item) or not valid(item.ItemData) or item.ItemData:GetFullName()~=row.definition then return nil end
    return item
end
local function category(data)
    if not M.types then
        M.types={}
        local lookup=StaticFindObject('/Game/UI/Inventory/ItemTypeLookupTable.ItemTypeLookupTable')
        if valid(lookup) then
            M.base_type=M.clean(lookup.TypeBaseItem)
            lookup.TagTypeMap:ForEach(function(k,v) M.types[unwrap(k).TagName:ToString()]=M.clean(unwrap(v)) end)
        end
    end
    local best,name=0,M.base_type or 'Item'
    data.ItemFilterTags.GameplayTags:ForEach(function(_,wrapped)
        local tag=unwrap(wrapped).TagName:ToString()
        for key,value in pairs(M.types) do
            if #key>best and (tag==key or tag:sub(1,#key+1)==key..'.') then best,name=#key,value end
        end
    end)
    return name
end
function M.read(panel,control)
    if control.row and control.row.placeholder then
        return {name=control.row.name,category='Placeholder',description='No items are stored here. Returning this item reuses its saved position. Release removes only this empty slot.',
            weight=0,count=0,stats={},details={},hints={'Right-click   Release placeholder'},can_move=false,can_transfer=false,use_verb='Release placeholder',
            controller=panel.controller_active==true,controller_family=panel.controller_ui and panel.controller_ui.family}
    end
    local item=M.item_for(panel,control)
    if not item then return nil,'Item changed; hover again after refresh' end
    local data=item.ItemData
    local model={name=M.clean(item:GetPlayerFacingName()),category=category(data),description=M.clean(require('stashlink.item_description').read(data,control.row.contents)),
        power=data:GetBasePowerLevel(),weight=data.Weight,count=control.row.total,stats={},details={},hints={}}
    -- GetStatDetails takes equipment power level, not masterwork upgrade count.
    local level=math.max(0,math.min(255,model.power))
    local entries=data:GetStatDetails(panel.pc.Pawn,item.GameplayTags,level)
    for _,entry in ipairs(entries) do model.stats[#model.stats+1]=M.format_stat(unwrap(entry)) end
    data.BuffDatas:ForEach(function(_,wrapped)
        local buff=unwrap(wrapped)
        local title,description=M.clean(buff.Title),M.clean(buff.Description)
        if title~='' or description~='' then model.details[#model.details+1]={title=title,description=description} end
    end)
    local contents=control.row.contents
    if contents and not data.FlavourText:ToString():find('{HeldContainerDescription}',1,true) then table.insert(model.stats,1,{name=contents.name,value=contents.quantity..' / '..contents.capacity,primary=true,status=0}) end
    if data.BaseDurability>0 then model.durability=item.Durability;model.max_durability=item:GetMaxDurability() end
    if control.pane=='armour' or control.row.protected or (control.row.writable and control.row.available==0) then model.hints={'Equipped item protected'}
    elseif not control.row.writable then
        model.hints={control.row.rearrange and 'Drag   Rearrange backpack' or 'Read only in Stashlink'}
    else model.hints={'Ctrl-click   Transfer stack','Drag   '..(control.pane=='stored' and 'Withdraw stack' or 'Move / deposit stack'),'Double-click   Move the chosen amount','F4   Type an amount'} end
    if control.row.writable and control.row.available>1 and (control.row.stack_size or 0)>1 then model.hints[#model.hints+1]='Shift-drag   Half stack' end
    local use_label
    if not panel.networked then use_label=require('stashlink.item_policy').use_label(control.row) end
    if use_label then model.hints[#model.hints+1]='Right-click   '..use_label end
    model.can_move=control.row.writable and control.row.available>0 and control.pane~='armour'
    model.can_transfer=model.can_move
    model.use_verb=use_label
    model.controller=panel.controller_active==true
    model.controller_family=panel.controller_ui and panel.controller_ui.family
    return model
end
function M.hit_test(groups,x,y)
    for _,group in ipairs(groups) do
        for _,control in ipairs(group) do
            local b=control.bounds
            if control.row and b and not control.clipped and not control.bank_hidden and x>=b.x and x<b.x+b.w and y>=b.y and y<b.y+b.h then return control end
        end
    end
end
function M.slot_at(groups,x,y)
    for _,group in ipairs(groups) do
        for _,control in ipairs(group) do
            local b=control.bounds
            if b and not control.clipped and not control.bank_hidden and x>=b.x and x<b.x+b.w and y>=b.y and y<b.y+b.h then return control end
        end
    end
end
function M.place(x,y,width,height,viewport_width,viewport_height,bounds)
    local scale=math.min(1,(viewport_width-24)/width,(viewport_height-24)/height)
    local w,h=width*scale,height*scale
    local left=bounds and bounds.x+bounds.w+20 or x+24
    local top=bounds and bounds.y+8 or y+18
    if left+w>viewport_width-12 then left=(bounds and bounds.x-20 or x-24)-w end
    return math.max(12,math.min(left,viewport_width-w-12)),math.max(12,math.min(top,viewport_height-h-12)),scale
end
return M
