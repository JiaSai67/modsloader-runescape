-- Native Niagara UI systems, one emitter per visible panel and one shared hover emitter.
local Scheduler=require('stashlink.scheduler')
local M={}
local function valid(o) return o and o:IsValid() end
function M.release(P,native_allowed)
    local E=P.effects
    if not E or E.P~=P then
        E=M.current and M.current.P==P and M.current or nil
    end
    if not E then return true end
    -- Detach ownership first so a resumed task cannot revisit this tree.
    if M.current==E then M.current=nil end
    if P.effects==E then P.effects=nil end
    local ok,why=true,nil
    if native_allowed==true then
        local called,stopped,err=pcall(E.stop,E)
        ok=called and stopped~=false
        if called then why=err else why=stopped end
    end
    E.released=true
    for _,entry in ipairs(E.entries) do
        entry.widget=nil;entry.slot=nil;entry.active=false
    end
    E.entries={};E.hover=nil;E.hover_target=nil;E.P=nil;E.V=nil
    return ok,why
end
function M.bind(P,V,H,frames)
    if M.current then M.release(M.current.P,true) end
    local cls=StaticFindObject('/Script/NiagaraUIRenderer.NiagaraSystemWidget')
    assert(valid(cls),'Native UI particle widget unavailable')
    local original=H.asset('/Game/Art/VFX/UI/M_VFX_UI_Embers.M_VFX_UI_Embers')
    local remap=H.asset('/Game/Art/VFX/UI/M_VFX_UI_Embers_UI.M_VFX_UI_Embers_UI')
    local E={entries={},P=P,V=V,hover_target=nil}
    local function create(parent,width,height,kind)
        local system=H.asset('/Game/Art/VFX/UI/'..kind..'.'..kind)
        local w=StaticConstructObject(cls,H.tree,FName('StashlinkFX_'..P.serial..'_'..(#E.entries+1)),0x40)
        assert(valid(w),'Could not create UI particles')
        w.AutoActivate=false;w.NiagaraSystemReference=system;w.ShowDebugSystemInWorld=false
        w:SetRemapMaterial(original,remap);w:SetDesiredWidgetSize({X=width,Y=height})
        w:SetVisibility(3)
        local slot=H.place(parent,w,0,0,width,height);slot:SetZOrder(15)
        local entry={widget=w,slot=slot,width=width,height=height,kind=kind,active=false}
        E.entries[#E.entries+1]=entry;return entry
    end
    for _,frame in ipairs(frames) do
        local entry
        if frame.native then
            entry={widget=frame.native.particles,width=frame.width,height=frame.height,kind=frame.height<200 and 'NS_UI_InventoryPanel_Armour' or 'NS_UI_InventoryPanel',active=false}
            E.entries[#E.entries+1]=entry
        else entry=create(frame.parent,frame.width,frame.height,frame.height<200 and 'NS_UI_InventoryPanel_Armour' or 'NS_UI_InventoryPanel') end
        entry.drawer=frame.drawer
    end
    E.hover=create(H.canvas,64,64,'NS_UI_InventorySlot')
    E.hover.slot:SetZOrder(25)
    function E:set_active(entry,enabled)
        if self.released then return end
        if not valid(entry.widget) then return end
        if enabled and not entry.active then
            local component=entry.widget:GetNiagaraComponent()
            if not valid(component) then return end
            if not entry.configured then
                local width=entry.kind=='NS_UI_InventorySlot' and 56 or entry.width-21
                local height=entry.kind=='NS_UI_InventorySlot' and 56 or entry.height-20
                component:SetVariableVec3(FName('User.FX_BoxSize'),{X=width,Y=0,Z=height})
                entry.configured=true
            end
            entry.widget:ActivateSystem(true);entry.active=true
        elseif not enabled and entry.active then
            entry.widget:DeactivateSystem();entry.active=false
        end
    end
    function E:highlight(control)
        if self.released then return end
        if control==self.hover_target then return end
        self:set_active(self.hover,false);self.hover_target=control
        if control and control.bounds and self.V.open then
            self.hover.slot:SetPosition({X=control.bounds.x+(control.bounds.w-64)/2,Y=control.bounds.y+(control.bounds.h-64)/2})
            self:set_active(self.hover,true)
        end
    end
    function E:tick()
        if self.released then return end
        local open=self.V.open and valid(self.P.root)
        for _,entry in ipairs(self.entries) do
            local enabled=open and (entry~=self.hover or self.hover_target~=nil) and (not entry.drawer or self.P.extras_open)
            self:set_active(entry,enabled)
        end
    end
    function E:stop()
        if self.released then return true end
        local ok,why=true,nil
        for _,entry in ipairs(self.entries) do
            local stopped,err=pcall(self.set_active,self,entry,false)
            if not stopped then ok=false;why=why or err end
        end
        self.hover_target=nil
        return ok,why
    end
    P.effects=E;M.current=E
    if not M.scheduled then Scheduler.every(80,function() if M.current then M.current:tick() end end);M.scheduled=true end
end
return M
