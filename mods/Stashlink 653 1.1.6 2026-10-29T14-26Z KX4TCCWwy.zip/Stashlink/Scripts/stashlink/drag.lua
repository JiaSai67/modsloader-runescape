-- Resolve a pointer gesture into one explicit intent. Releasing outside a valid
-- destination cancels; selecting and dragging never mutates inventory.
local M={}
function M.source_valid(source)
    if not source or source.invalid_cell then return false end
    local control=source.control
    if not control then return true end
    return not control.invalid_cell and (not source.binding or source.binding==control.bag_binding)
        and control.row and source.row and control.row.key==source.row.key
end
function M.resolve(source,target)
    if not source or not source.row or not target then return nil,"Drag cancelled" end
    if not M.source_valid(source)or target.invalid_cell
        or target.bag_binding and (target.slot==nil or target.bound_snapshot and target.bound_snapshot.token~=source.token)then
        return nil,'Inventory changed; select the item again'
    end
    local row=source.row
    if row.placeholder then return nil,'Placeholder: no items are stored here'end
    local pane=source.pane=='hotbar' and 'held' or source.pane
    local target_pane=target.pane=='hotbar' and 'held' or target.pane
    local action={row=row,snapshot_token=source.token}
    if pane=="stored" and target_pane=="held" then
        if not row.writable or row.available<=0 then return nil,"This item is read only" end
        action.direction="withdraw"; action.quantity=math.min(row.available,row.stack_size)
        if source.half then action.quantity=math.max(1,math.floor(action.quantity/2)) end
        action.destination_slot=target.slot
        if target.slot~=nil then action.target_identity=target.row and target.row.source.identity or "" end
    elseif pane=="held" and target_pane=="stored" then
        if not row.writable or row.available<=0 then return nil,"This item is protected or read only" end
        action.direction="deposit"; action.quantity=row.available
        if source.half then action.quantity=math.max(1,math.floor(action.quantity/2)) end
    elseif pane=="held" and target_pane=="held" and target.slot~=nil then
        if not row.rearrange or row.source.slot==target.slot then return nil,"No slot change or protected slot" end
        action.direction="rearrange"; action.quantity=row.total; action.destination_slot=target.slot
        if source.half then action.quantity=math.max(1,math.floor(action.quantity/2)) end
        action.target_identity=target.row and target.row.source.identity or ""
    else return nil,"Drag cancelled" end
    return action
end
return M
