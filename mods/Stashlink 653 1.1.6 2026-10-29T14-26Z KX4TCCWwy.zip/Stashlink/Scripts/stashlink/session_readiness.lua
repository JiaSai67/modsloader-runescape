-- Readiness only; do not construct widgets, remap input or scan inventories.
local M={}
local function valid(o)return o and o:IsValid()end
function M.check(c)
 if not c.networked then return true end
 local class=StaticFindObject('/Script/Engine.WorldPartitionSubsystem')
 local library=StaticFindObject('/Script/Engine.Default__SubsystemBlueprintLibrary')
 if not valid(class)or not valid(library)then return false,'Streaming readiness unavailable'end
 local partition=library:GetWorldSubsystem(c.world,class)
 if not valid(partition)or partition:IsAllStreamingCompleted()~=true then return false,'World streaming'end
 local movement=c.pawn.CharacterMovement
 if not valid(movement)then return false,'Movement not initialized'end
 local floor=movement.CurrentFloor
 if tonumber(movement.MovementMode)~=1 or floor.bBlockingHit~=true or floor.bWalkableFloor~=true then
  return false,'Waiting for initial floor collision'
 end
 return true
end
return M
