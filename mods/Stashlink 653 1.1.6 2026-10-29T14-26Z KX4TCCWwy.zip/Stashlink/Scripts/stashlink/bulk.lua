-- One bounded transfer per scheduler pulse; every chunk is revalidated by the
-- coordinator. Closing the ledger cancels remaining intents without rollback.
local M={job=nil}
function M.plan(snapshot,mode)
 local work={}
 if mode=='take_all' then
  for _,row in ipairs(snapshot.stored) do
   if row.writable and row.available>0 then work[#work+1]={key=row.key,remaining=row.available,stack=row.stack_size,direction='withdraw'} end
  end
 else
  local destinations={}
  for _,row in ipairs(snapshot.stored) do
   if row.writable then destinations[row.key]=row.sources end
  end
  for _,row in ipairs(snapshot.held) do
   if row.writable and row.available>0 and destinations[row.key] then
    local seen,ids={},{}
    for _,source in ipairs(destinations[row.key]) do
     if not seen[source.container_id] then seen[source.container_id]=true;ids[#ids+1]=source.container_id end
    end
    work[#work+1]={key=row.key,remaining=row.available,stack=row.stack_size,direction='deposit',destinations=ids,destination=1}
   end
  end
 end
 return work
end
function M.cancel(reason)
 local job=M.job
 if not job then return end
 if job.awaiting and job.service.coordinator then
  local observed=job.service.coordinator:result(job.awaiting)
  if observed then job.moved=job.moved+observed.moved end
  job.service.coordinator:cancel(reason or 'Transfer cancelled')
 end
 M.job=nil;job.view.status=(reason or 'Transfer cancelled')..' · '..job.moved..' items moved'
 if job.view.open and job.service.render then pcall(job.service.render) end
 return job.view.status
end
function M.start(service,view,mode)
 if M.job then view.status='A bulk transfer is already running. Esc cancels it.';return view.status end
 assert(not service.coordinator or not service.coordinator.busy,'Waiting for the server; a transfer is already pending')
 assert(service.adapter.validated and service.adapter:build_supported(),'Inventory transfers are unavailable on this game build')
 local snapshot=service.refresh();local work=M.plan(snapshot,mode)
 if #work==0 then view.status=mode=='take_all' and 'No transferable items in storage' or 'No matching items to deposit';return view.status end
 M.job={service=service,view=view,mode=mode,work=work,index=1,moved=0,skipped=0,session=snapshot.session}
 view.status=(mode=='take_all' and 'Taking items' or 'Filling stacks')..' · Esc to cancel'
 if not M.scheduled then
  local scheduler=require('stashlink.scheduler')
  scheduler.every(32,M.tick);scheduler.tasks[#scheduler.tasks].key='stashlink.bulk';M.scheduled=true
 end
 return view.status
end
function M.tick()
 local job=M.job;if not job then return end
 local service,view=job.service,job.view
 if not view.open or service.stopped or service.adapter:session_id()~=job.session then M.cancel('Transfer cancelled');return end
 local entry=job.work[job.index]
 if not entry then
  local action=job.mode=='take_all' and 'Taken ' or 'Deposited '
  view.status=action..job.moved..' items'..(job.skipped>0 and (' · '..job.skipped..' left at source') or '')
  M.job=nil
 else
  local row
  local result
  if job.awaiting then
   result=service.coordinator:result(job.awaiting)
   if not result then M.cancel('Transfer result unavailable; further transfers are paused');return end
   if result.status=='pending' then
    view.status=(job.mode=='take_all' and 'Taking items' or 'Filling stacks')..' · '..(job.moved+result.moved)..' confirmed · waiting for server · Esc to cancel'
    return
   end
   job.awaiting=nil
  else
   for _,r in ipairs(service.adapter.snapshot[entry.direction=='withdraw' and 'stored' or 'held']) do if r.key==entry.key then row=r;break end end
   if not row or row.available<=0 then job.skipped=job.skipped+entry.remaining;job.index=job.index+1
   else
   local quantity=math.min(entry.remaining,row.available,entry.stack)
   local ok;ok,result=pcall(service.transfer,entry.direction,row,quantity,entry.destinations and entry.destinations[entry.destination])
   if not ok then M.cancel('Transfer stopped: '..tostring(result));return end
   if result.status=='pending' then
    assert(type(result.request_id)=='string' and service.coordinator,'Pending bulk request requires a coordinator result')
    job.awaiting=result.request_id
    view.status='Filling stacks · waiting for server · Esc to cancel'
    return
   end
   end
  end
  if result then
   job.moved=job.moved+result.moved;entry.remaining=entry.remaining-result.moved
   if result.status=='unknown' then M.cancel('Transfer result needs inspection; further transfers are paused');return end
   if job.mode=='take_all' and result.reason=='No eligible destination space' then M.cancel('Backpack full');return end
   if result.status=='rejected' or result.status=='partial' then
    if entry.destinations and entry.destination<#entry.destinations and result.reason=='No eligible destination space' then entry.destination=entry.destination+1
    else
     job.skipped=job.skipped+entry.remaining;job.index=job.index+1
     if result.reason~='No eligible destination space' then M.cancel('Transfer stopped: '..tostring(result.reason));return end
    end
   elseif entry.remaining<=0 then job.index=job.index+1 end
  end
  if M.job then view.status=(job.mode=='take_all' and 'Taking items' or 'Filling stacks')..' · '..job.moved..' moved · Esc to cancel' end
 end
 if view.open and service.render then service.render() end
end
return M
