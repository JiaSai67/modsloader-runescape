local M={}
local uncertain='Transfers paused: items may already have moved. Reconnect, then check both inventories before moving more items.'
local reasons={
 ['Invalid tab name']='Enter a short, non-empty tab name',
 ['No eligible destination space']='No compatible free space in the destination',
 ['Game update changed inventory functions']='This game update changed inventory functions; transfers stay off until Stashlink updates',
 ['Native transfer rejected']='The game declined this move',
 ['Item use in multiplayer is awaiting validation; use the game inventory']='In co-op, use or equip items in the game inventory',
 stale_snapshot='Inventory changed; refresh and try again',
 stale_session='World changed; reopen the ledger',
 insufficient_available_quantity='Not enough unprotected items available',
 invalid_quantity='Enter a positive whole quantity',
 uncertain_previous_transfer=uncertain,
 transfer_in_progress='Waiting for the server; another transfer cannot start yet',
 native_outcome_uncertain=uncertain,
 request_limit_reached='Session transfer limit reached; restart the game',
}
function M.row_error(row)
 if not row then return 'Select an item first' end
 if not row.writable then return row.read_only_reason or 'This item type is read-only in Stashlink' end
 if row.available<=0 then return 'This item is protected' end
end
function M.transfer(direction,row,result)
 local verb=({withdraw='Withdrew',deposit='Deposited',rearrange='Moved'})[direction] or 'Moved'
 local name=row and row.name or 'items'
 if result.status=='pending' then
  return 'Waiting for server · '..result.moved..' of '..result.requested..' × '..name..' confirmed'
 end
 if result.status=='unknown' then return uncertain end
 if result.status=='rejected' then return 'Could not '..(direction=='rearrange' and 'move' or direction)..' '..name..': '..M.text(result.reason) end
 local text=verb..' '..result.moved..' × '..name
 if result.status=='partial' then text=text..' ('..(result.requested-result.moved)..' left) · '..M.text(result.reason) end
 return text
end
function M.text(status)
 status=tostring(status or '')
 if status=='' or status=='Closed' or status=='Drag cancelled' or status:find('^Drag a stack to withdraw') then return '' end
 status=status:gsub('^.-%.lua:%d+:%s*','')
 for code,message in pairs(reasons) do status=status:gsub(code,function() return message end) end
 return status
end
function M.bind(P,V,H)
 local panel=H.make('CanvasPanel',H.tree)
 local bounds=P.drawer_bounds or {x=692,y=552,w=672}
 H.place(H.canvas,panel,bounds.x,bounds.y,bounds.w,60):SetZOrder(30)
 panel:SetVisibility(1)
 local bg=H.make('Border',H.tree);bg:SetBrushColor({R=.025,G=.022,B=.018,A=.94});bg:SetVisibility(3)
 H.place(panel,bg,12,0,bounds.w-24,60)
 local accent=H.make('Border',H.tree);accent:SetVisibility(3);H.place(panel,accent,12,0,3,60)
 local label=H.label(panel,'',26,10,bounds.w-52,44,11,false);label.object:SetAutoWrapText(true)
 P.feedback_panel=panel
 local last,last_version,expires,expired
 function P.refresh_feedback()
  -- Coordinator notices outlive unrelated tab/search messages and expire only
  -- when the pending move settles or its uncertainty lock no longer applies.
  local notice=V.transfer_notice and V.transfer_notice()
  local value=M.text(notice or V.status)
  if value~=last or V.status_version~=last_version or P.feedback_reset then
   last,last_version,expired=value,V.status_version,false;P.feedback_reset=nil
   local success=not notice and (value:match('^Withdrew ') or value:match('^Deposited ') or value:match('^Moved ') or value:match('^Taken ') or value:match('^Using ') or value:match('^Equipping ') or value:match('^Unequipping ') or value:match('^Custom tab ') or value:match('^Tab removed;') or value=='Inventory refreshed' or value=='Backpack sorted')
   expires=success and (P.time_lib:GetRealTimeSeconds(P.pc)+3.5) or nil
   accent:SetBrushColor(success and {R=.65,G=.75,B=.42,A=1} or {R=.85,G=.62,B=.28,A=1})
   panel:SetRenderOpacity(1)
  end
  if value~=label.value then label.object:SetText(FText(value));label.value=value end
  panel:SetVisibility(V.open and not P.extras_open and not P.tab_editor_open and value~='' and not expired and 3 or 1)
 end
 function P.feedback_tick(now)
  if expires and not expired then
   if now>=expires then expired=true;panel:SetVisibility(1)
   elseif now>expires-.4 then panel:SetRenderOpacity(math.max(0,(expires-now)/.4)) end
  end
 end
 if P.on_action~=P.on_action_wrapper then P.base_on_action=P.on_action end
 local action_wrapper=function(action,data)
  if action=='drag' or action=='transfer' or action=='quick_transfer' or action=='matching' then P.feedback_reset=true end
  local reason=action=='transfer' and M.row_error(V.selected())
  local ok,result=true,nil
  if reason then V.status=reason
  else
   ok,result=pcall(P.base_on_action,action,data)
   if not ok then V.status=M.text(result);print('[Stashlink] '..tostring(result)..'\n') end
  end
  if V.open then P.render() end
  return ok and result or nil
 end
 P.on_action_wrapper=action_wrapper;P.on_action=action_wrapper
end
return M
