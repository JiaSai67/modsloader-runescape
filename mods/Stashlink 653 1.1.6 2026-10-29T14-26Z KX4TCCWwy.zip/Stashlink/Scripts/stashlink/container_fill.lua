local M={}
local function valid(o) return o and o:IsValid() end
local function colour(value,fallback)
 if not value then return fallback end
 return {R=value.R,G=value.G,B=value.B,A=value.A}
end
function M.read(item,class_name)
 if class_name~='Class /Script/Dominion.HeldContainerEquipmentItem' then return nil end
 local contents=item.Contents;local capacity=item.ItemData.Capacity
 if type(capacity)~='number' or capacity<=0 then return nil end
 local quantity=contents.Quantity;local data=contents.ContentData
 return {quantity=quantity,capacity=capacity,fraction=math.max(0,math.min(1,quantity/capacity)),
  definition=valid(data) and data:GetFullName() or '',
  name=valid(data) and data.Name:ToString() or 'Empty',
  tint=valid(data) and colour(data.InventorySlotIconTint) or {R=1,G=1,B=1,A=1},
  fill=valid(data) and colour(data.FillColor) or {R=.35,G=.35,B=.35,A=1},
  border=valid(data) and colour(data.BorderColor) or {R=.15,G=.15,B=.15,A=1}}
end
return M
