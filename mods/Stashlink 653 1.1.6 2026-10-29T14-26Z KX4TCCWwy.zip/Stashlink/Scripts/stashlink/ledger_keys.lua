-- Reviewed single keyboard keys. F6 is the permanent fallback/disabled mode.
local M={}
local cache={}
local digits={'Zero','One','Two','Three','Four','Five','Six','Seven','Eight','Nine'}
local reserved={V='backpack sorting',F3='refresh',F4='quantity',F7='panel navigation',F8='search',F10='the console',F12='screenshots'}
function M.normalize(value)
 if type(value)~='string' or #value>24 then return nil,'Enter a single keyboard key, for example G or F9'end
 local key=value:match('^%s*(.-)%s*$'):upper()
 if key=='NONE'or key=='OFF'or key=='DISABLED'or key=='F6 ONLY'then key='F6'end
 if reserved[key]then return nil,key..' is reserved for '..reserved[key]..'; choose another key'end
 if key:match('^[A-Z0-9]$')then return key end
 local n=tonumber(key:match('^F(%d+)$'))
 if n and n>=1 and n<=12 and tostring(n)==key:sub(2)then return key end
 return nil,'Use a letter, number, F1, F2, F5, F9, F11 or F6 only'
end
function M.info(value)
 local key,why=M.normalize(value);if not key then return nil,why end
 if not cache[key]then cache[key]={name=key,unreal=key:match('^%d$')and digits[tonumber(key)+1]or key,vk=#key==1 and key:byte() or 0x6F+tonumber(key:sub(2))}end
 return cache[key]
end
return M
