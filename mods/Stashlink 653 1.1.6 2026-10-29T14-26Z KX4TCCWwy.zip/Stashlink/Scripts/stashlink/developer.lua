-- Optional local diagnostics. Disabled in the distributed settings.
local M={}
function M.start(scripts)
local Scheduler=require("stashlink.scheduler")
local Settings=require("stashlink.settings")
local busy = false
local last_run = 0
local function scan()
    if not Settings.development or busy or os.time() - last_run < 10 then return end
    busy = true
    Scheduler.run(function()
        local ok, result = pcall(require("stashlink.probe").run, scripts .. "/../diagnostics/reflection.txt")
        last_run = os.time()
        busy = false
        print("[Stashlink] " .. (ok and result or ("Discovery failed: " .. tostring(result))) .. "\n")
    end)
end


if type(RegisterKeyBind) == "function" and type(LoopInGameThreadWithDelay) == "function" then
    RegisterKeyBind(Key.B, {ModifierKey.CONTROL, ModifierKey.ALT}, Scheduler.pin(scan))
    print("[Stashlink] Ctrl+Alt+B records storage reflection metadata.\n")
else
    print("[Stashlink] Required UE4SS input/thread APIs unavailable. Inert.\n")
end

-- A bounded, local development interface allows repeatable integration checks.
-- Only explicit allowlisted commands are accepted, bound to this process session.
-- No code evaluation, OS commands, network, or previous-session replay.
local session = tostring(os.time()) .. "-" .. tostring({}):gsub("[^%w]", "")
local directory = scripts .. "/../diagnostics/"
local function write(name, value)
    local file = assert(io.open(directory .. name, "w"))
    file:write(value)
    file:close()
end
local seen = {}
local seen_order = {}
local processing = false
local function dispatch(command, args)
    if command == "probe" then
        package.loaded["stashlink.probe"] = nil
        return require("stashlink.probe").run(directory .. "reflection.txt")
    elseif command == "inspect" then
        package.loaded["stashlink.inspect"] = nil
        return require("stashlink.inspect").run(directory .. "live-inspection.txt")
    elseif command == "reload" then
        error("This build requires a normal game restart; mod-only reload is disabled during runtime stabilization")
    elseif command == "service" then
        return require("stashlink.service").command(args)
    end
    error("Unknown development command")
end

local function poll()
    if not Settings.development or processing then return false end
    local file = io.open(directory .. "dev-request.txt", "r")
    if not file then return false end
    local request = file:read(4097) or ""
    file:close()
    if #request > 4096 then return false end
    local req_session, id, command, args = request:match("^([^|]+)|([%w_-]+)|([%a_]+)|([^\r\n]*)")
    if req_session ~= session or not id or seen[id] then return false end
    if command ~= "probe" and command ~= "inspect" and command ~= "reload" and command ~= "service" then return false end
    seen[id] = true
    seen_order[#seen_order + 1] = id
    -- Do not evict IDs and accidentally replay old requests. Stop accepting at the bound.
    if #seen_order > 1000 then return true end
    processing = true
    Scheduler.run(function()
        local ok, result = pcall(dispatch, command, args)
        local text = id .. "|" .. (ok and "OK" or "ERROR") .. "|" .. tostring(result)
        local saved = pcall(write, "dev-result.txt", text)
        print("[Stashlink] " .. text .. (saved and "\n" or " (report write failed)\n"))
        processing = false
    end)
    return false
end

write("dev-session.txt", session)
Scheduler.every(500,poll);Scheduler.tasks[#Scheduler.tasks].key="stashlink.dev"
if type(RegisterConsoleCommandHandler) == "function" then
    RegisterConsoleCommandHandler("bank", Scheduler.pin(function(full, parameters, out)
        if not Settings.development then return false end
        local command = full:gsub("^bank%s*", "")
        local ok, result = pcall(function() return require("stashlink.service").command(command) end)
        local message = "[Stashlink] " .. tostring(result)
        print(message .. "\n")
        if out then pcall(function() out:Log(message) end) end
        return true
    end))
end


end
return M
