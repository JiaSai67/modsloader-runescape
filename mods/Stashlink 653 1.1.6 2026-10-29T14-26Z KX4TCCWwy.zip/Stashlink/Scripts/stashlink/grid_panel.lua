-- Stashlink's own virtual grid, using installed game artwork at runtime.
-- It never binds the vanilla chest's mutation handlers to virtual rows.
local V=require("stashlink.view")
local Helpers=require("UEHelpers")
local Drag=require("stashlink.drag")
local M=package.loaded['stashlink.grid_panel'] or {root=nil,controls={},updates=0,serial=0,player_tab=1,bag_page=0,bank_row=0,scroll_offset=0,visible_rows=8}
local base_methods
local gold={R=0.80,G=0.64,B=0.33,A=1}
local white={R=0.90,G=0.88,B=0.81,A=1}
local muted={R=0.55,G=0.56,B=0.53,A=1}
local empty={R=0.13,G=0.13,B=0.12,A=0.55}
local clear={R=0,G=0,B=0,A=0}
-- Keep visited pages warm for the session; 256 entries churned through the
-- full catalog and repeatedly forced native synchronous asset loads.
M.icon_cache_limit=2048
local function valid(o) return o and o:IsValid() end
local function text(widget,value)
    value=tostring(value or "")
    if widget.value~=value then widget.object:SetText(FText(value)); widget.value=value end
end
local function load(path)
    local object=StaticFindObject(path)
    if not valid(object) then object=LoadAsset(path) end
    assert(valid(object),"Game UI asset unavailable: "..path)
    return object
end
function M.bind(adapter,on_action) M.adapter=adapter; M.on_action=on_action;M.action_callback=on_action end
function M.create()
    if valid(M.root) then return end
    require("stashlink.chest_layout").create(M,V)
end
function M.bank_rows() return V.filtered_rows("stored") end
function M.current_page()
    return V.snapshot and V.snapshot.pages[M.player_tab]
end
local function evict_icon()
    local candidate,oldest
    for definition,entry in pairs(M.icon_cache) do
        local used=M.pointer and M.pointer.row and M.pointer.row.definition==definition
        if not used then
            for _,control in ipairs(M.controls) do
                if (control.row or control.icon_row)and control.definition==definition then used=true;break end
            end
        end
        if not used and (entry.done or not entry.loader) and (not oldest or (entry.last_used or 0)<oldest) then
            candidate,oldest=definition,entry.last_used or 0
        end
    end
    if not candidate then return false end
    local entry=M.icon_cache[candidate]
    if not entry.done then
        for i,queued in ipairs(M.icon_queue) do if queued==entry then table.remove(M.icon_queue,i);break end end
        M.icons_pending=M.icons_pending-1
    end
    if valid(entry.loader) then entry.loader:RemoveFromParent() end
    if valid(entry.badge_loader) then entry.badge_loader:RemoveFromParent() end
    M.icon_cache[candidate]=nil;M.icon_total=M.icon_total-1
    return true
end
local function request_icon(control,definition)
    control.icon_deferred=false
    if definition=="" then
        control.material:SetScalarParameterValue(M.params.icon_opacity,0)
        control.material:SetScalarParameterValue(M.params.background,.75)
        control.badge:SetVisibility(1)
        return
    end
    control.material:SetScalarParameterValue(M.params.background,1)
    local cached=M.icon_cache[definition]
    if not cached and M.icon_total>=M.icon_cache_limit then evict_icon() end
    if not cached and M.icon_total<M.icon_cache_limit then
        cached={definition=definition,waiters={}}
        M.icon_cache[definition]=cached; M.icon_queue[#M.icon_queue+1]=cached
        M.icon_total=M.icon_total+1; M.icons_pending=M.icons_pending+1
    end
    M.icon_clock=(M.icon_clock or 0)+1
    if cached then cached.last_used=M.icon_clock else control.icon_deferred=true end
    if cached and valid(cached.texture) then
        control.material:SetTextureParameterValue(M.params.icon,cached.texture)
        control.material:SetScalarParameterValue(M.params.icon_opacity,1)
        if valid(cached.badge) and control.pane~="armour" then control.badge:SetBrushFromTexture(cached.badge,false);control.badge:SetVisibility(3) else control.badge:SetVisibility(1) end
        if cached.badge_pending then cached.waiters[control]=true end
    else
        control.material:SetScalarParameterValue(M.params.icon_opacity,0);control.badge:SetVisibility(1)
        if cached and not cached.failed then cached.waiters[control]=true end
    end
end
M.request_icon=request_icon
function M.pump_icons(limit)
    if not V.open or not valid(M.root) then return end
    -- Bound native work per pulse. A page click only queues icons.
    local started=os.clock()
    local loads=0
    -- Finish a badge deferred by an expensive primary-icon load before
    -- starting another asset. A single LoadAsset cannot be interrupted.
    for _,entry in ipairs(M.icon_loading)do
        if entry.badge_pending then
            pcall(M.adapter.apply_badge,M.adapter,entry.badge_loader,entry.definition)
            entry.badge_pending=nil;loads=loads+1
            if loads>=limit or (os.clock()-started)*1000>=3 then break end
        end
    end
    while loads<limit and (os.clock()-started)*1000<3 do
        local entry=table.remove(M.icon_queue,1)
        if not entry then break end
        local needed=M.pointer and M.pointer.row and M.pointer.row.definition==entry.definition
        for control in pairs(entry.waiters) do
            if control.definition==entry.definition then needed=true else entry.waiters[control]=nil end
        end
        if not needed then
            -- A newer page superseded this request before native work began.
            M.icon_cache[entry.definition]=nil;M.icon_total=M.icon_total-1;M.icons_pending=M.icons_pending-1
        else
            entry.loader=M.make("Image",M.tree); M.icon_host:AddChildToVerticalBox(entry.loader)
            local ok,loaded=pcall(M.adapter.apply_icon,M.adapter,entry.loader,entry.definition)
            entry.badge_loader=M.make("Image",M.tree);M.icon_host:AddChildToVerticalBox(entry.badge_loader)
            entry.failed=not ok or not loaded; entry.started=os.time()
            if not entry.failed then
                if (os.clock()-started)*1000>=3 then entry.badge_pending=true
                else pcall(M.adapter.apply_badge,M.adapter,entry.badge_loader,entry.definition)end
            end
            M.icon_loading[#M.icon_loading+1]=entry;loads=loads+1
            -- Cannot interrupt LoadAsset, but avoid stacking another blocking
            -- load onto a pulse that has already exceeded its native budget.
            if (os.clock()-started)*1000>=3 then break end
        end
    end
    for i=#M.icon_loading,1,-1 do
        local entry=M.icon_loading[i]
        local texture=not entry.failed and entry.loader.Brush.ResourceObject or nil
        if valid(texture) or entry.failed or os.time()-entry.started>10 then
            entry.texture=valid(texture) and texture or nil
            entry.failed=not entry.texture
            entry.badge=entry.badge_loader.Brush.ResourceObject
            for control in pairs(entry.waiters) do
                if control.definition==entry.definition and entry.texture then
                    control.material:SetTextureParameterValue(M.params.icon,entry.texture);control.material:SetScalarParameterValue(M.params.icon_opacity,1)
                    if valid(entry.badge) and control.pane~="armour" then control.badge:SetBrushFromTexture(entry.badge,false);control.badge:SetVisibility(3) end
                end
            end
            -- The primary icon is usable immediately. Keep its waiters until
            -- the deferred badge is ready, including cells rebound meanwhile.
            if not entry.badge_pending then
                entry.waiters={};entry.done=true;table.remove(M.icon_loading,i);M.icons_pending=M.icons_pending-1
            end
        end
    end
    for _,control in ipairs(M.controls) do
        if control.icon_deferred and (control.row or control.icon_row)then request_icon(control,control.definition) end
    end
end
local function bind_cell(control,row,selected)
    if M.controller_active then
        selected=M.controller_focus==control and not M.tab_editor_open
            and not (M.controller_ui and M.controller_ui.keyboard_open)and V.entry~='controller_amount'
    end
    if control.pane=='stored'and M.bank_empty then selected=false end
    control.row=row
    local placeholder=row and row.placeholder==true or false
    if control.placeholder~=placeholder then
        control.placeholder=placeholder
        if control.image then control.image:SetRenderOpacity(placeholder and .38 or 1)end
    end
    if control.equipped_icon then control.equipped_icon:SetVisibility(row and row.equipped and control.pane~='armour' and 3 or 1) end
    local burnt=row and row.burnt or false
    if control.burnt~=burnt then
        control.material:SetScalarParameterValue(FName('Burnt Desaturation'),burnt and 1 or 0)
        control.burnt=burnt
    end
    local style=row and row.masterwork_style
    if control.masterwork_style~=style then
        control.masterwork_style=style
        control.material:SetScalarParameterValue(FName('MW Tint Opacity'),style and style.opacity or 0)
        if style then control.material:SetVectorParameterValue(FName('Masterwork Tint Color'),style.color) end
    end
    local upgrades=row and row.masterwork_upgrades or 0
    local ascension=upgrades>0 and row.masterwork_type and (tostring(row.masterwork_type)..':'..(upgrades>=3 and 'full' or 'partial')) or nil
    if control.ascension_state~=ascension then
        control.ascension_state=ascension
        local shown=ascension and M.adapter:apply_ascension_icon(control.ascension_icon,row.masterwork_type,upgrades)
        control.ascension_icon:SetVisibility(shown and 3 or 1)
    end
    local definition=row and row.definition or ""
    if control.definition~=definition then
        control.definition=definition
        request_icon(control,definition)
    end
    text(control.count,row and not (row.total==1 and (not row.stack_size or row.stack_size<=1)) and row.total or "")
    if control.selected~=selected then control.material:SetScalarParameterValue(M.params.selected,selected and 1 or 0);control.selected=selected end
    local durability=row and row.max_durability and row.max_durability>0 and math.max(0,math.min(1,row.durability/row.max_durability)) or nil
    local contents=row and row.contents
    if contents then durability=contents.fraction end
    if control.contents~=contents or not control.durability_colour_set then
        control.contents=contents;control.durability_colour_set=true
        control.durability:SetBrushColor(contents and contents.fill or {R=.462077,G=.396755,B=.287441,A=1})
        if control.fill_background then
            control.fill_background:SetVisibility(contents and 3 or 1);control.fill_gradient:SetVisibility(contents and 3 or 1)
            if contents then control.fill_background:SetColorAndOpacity(contents.border) end
        end
        if control.content_badge then
            if contents and contents.definition~='' then
                if control.contents_definition~=contents.definition then M.adapter:apply_content_badge(control.content_badge,contents) end
                control.content_badge:SetVisibility(3)
            else control.content_badge:SetVisibility(1) end
            control.contents_definition=contents and contents.definition or nil
        end
    end
    local cell_height=control.cell_height or 60
    local bar_width=contents and 52 or (control.pane=='armour' or control.pane=='stored') and 55 or 48
    local bar_left=(control.pane=='armour' or control.pane=='stored') and 2.5 or 6
    local meter_y=contents and cell_height-6+(control.item_offset or 0) or control.pane=='armour' and cell_height-5.5 or control.pane=='hotbar' and cell_height-9 or cell_height-8+(control.item_offset or 0)
    if control.dura_value~=durability or control.meter_y~=meter_y then
        if control.meter_background then
            control.meter_background:SetVisibility(durability and not contents and 3 or 1)
            if durability and not contents then control.meter_background.Slot:SetOffsets({Left=bar_left,Top=meter_y,Right=bar_width,Bottom=3}) end
        end
        control.durability:SetVisibility(durability and 3 or 1)
        if durability then control.durability_slot:SetOffsets({Left=contents and (4+bar_width*(1-durability)) or bar_left,Top=meter_y,Right=bar_width*durability,Bottom=2}) end
        control.dura_value=durability;control.meter_y=meter_y
    end
    local tooltip=row and (row.name.."  x"..row.total..(row.placeholder and "\nPlaceholder — right-click to release"or row.protected and "\nProtected" or not row.writable and "\nRead only" or "")) or ""
    if control.tooltip~=tooltip then control.object:SetToolTipText(FText(tooltip)); control.tooltip=tooltip end
end
-- A rendered bag cell belongs only to the currently displayed native page.
-- Padding is not an empty inventory slot, even if another category occupies it.
function M.bag_capacity()return math.max(1,#(M.backpack or{}))end
function M.cell_available(control)
    if not control or control.invalid_cell then return false end
    if control.bag_binding then
        local page=M.current_page()
        return page and control.bound_snapshot==V.snapshot and control.bound_tab==M.player_tab
            and control.bound_page==M.bag_page and control.slot==page.first+M.bag_page*M.bag_capacity()+control.index-1
            and control.slot<page.first+page.count
    end
    return true
end
function M.bind_backpack()
    local page=M.current_page()
    local capacity=M.bag_capacity()
    local bag_pages=math.max(1,math.ceil(page.count/capacity));M.bag_page=math.max(0,math.min(M.bag_page,bag_pages-1))
    local first=page.first+M.bag_page*capacity
    for i,control in ipairs(M.backpack)do
        local slot=first+i-1;local available=slot<page.first+page.count
        if control.bound_snapshot~=V.snapshot or control.bound_tab~=M.player_tab or control.bound_page~=M.bag_page
            or control.slot~=(available and slot or nil)then control.bag_binding={}end
        control.bound_snapshot=V.snapshot;control.bound_tab=M.player_tab;control.bound_page=M.bag_page
        if control.invalid_cell~=(not available)then
            control.object:SetIsEnabled(available);control.object:SetVisibility(available and 0 or 1)
        end
        control.invalid_cell=not available;control.clipped=not available;control.slot=available and slot or nil
        bind_cell(control,available and V.snapshot.player_slots[slot] or nil,available and V.mode=='held'and V.player_slot==slot)
    end
    if V.mode=='held'and V.player_slot and V.player_slot>=#M.hotbar
        and (V.player_slot<first or V.player_slot>=math.min(first+capacity,page.first+page.count))then V.player_slot=nil end
    return bag_pages
end
function M.invalid_backpack_at(x,y)
    for _,control in ipairs(M.backpack or{})do
        local b=control.bounds
        if not M.cell_available(control)and b and x>=b.x and x<b.x+b.w and y>=b.y and y<b.y+b.h then return control end
    end
end
function M.render_capacity(s)
    if not M.bank_capacity then return end
    local used=math.max(0,math.floor(tonumber(s.occupied)or 0))
    local capacity=math.max(0,math.floor(tonumber(s.capacity)or 0))
    local function number(value)
        return (string.format('%.0f',value):reverse():gsub('(%d%d%d)','%1,'):reverse():gsub('^,',''))
    end
    text(M.bank_capacity,'Used '..number(used)..' / '..number(capacity)..' slots')
    text(M.bank_free,number(math.max(0,capacity-used))..' free')
    local fraction=capacity>0 and math.min(1,used/capacity)or 0
    if M.bank_capacity_fraction~=fraction then
        M.bank_capacity_bar:SetPercent(fraction);M.bank_capacity_fraction=fraction
    end
end
function M.render()
    if not V.open then return end
    assert(valid(M.root),"Inventory grid no longer available")
    local started=os.clock()
    if M.fit_viewport then M.fit_viewport() end
    M.updates=M.updates+1
    local s=V.snapshot
    text(M.subtitle,s.containers.." nearby containers    "..s.occupied.." / "..s.capacity.." occupied slots")
    for i,control in ipairs(M.hotbar) do bind_cell(control,s.player_slots[i-1],V.mode=="held" and V.player_slot==i-1) end
    local bag_pages=M.bind_backpack()
    text(M.bag_page_label,(M.bag_page+1).." / "..bag_pages)
    for _,w in ipairs({M.bag_prev.object,M.bag_next.object,M.bag_page_label.object}) do w:SetVisibility(bag_pages>1 and 0 or 1) end
    for i,b in ipairs(M.tab_buttons) do
        if b.selected~=(i==M.player_tab) then b.selected=i==M.player_tab;b.icon:SetBrushFromTexture(b.selected and b.highlight or b.normal,false) end
    end
    local weight_changed=M.weight.value~=s.weight_text
    text(M.weight,s.weight_text)
    if weight_changed and M.align_weight then M.align_weight() end
    local weight_fraction=s.weight_fraction
    if not weight_fraction then local a,b=s.weight_text:match("([%d.]+)%s*/%s*([%d.]+)");if a and tonumber(b)>0 then weight_fraction=tonumber(a)/tonumber(b) end end
    M.weight_fill_slot:SetSize({X=430*math.max(0,math.min(1,weight_fraction or 0)),Y=12})
    -- Unlimited carry weight shows only the number, as in the native backpack.
    if M.weight_bar then M.weight_bar:SetVisibility(s.weight_unlimited and 1 or 3) end
    text(M.power,s.power_level or "")
    text(M.bank_linked,s.containers.." linked")
    M.render_capacity(s)
    if M.refresh_equipment then M.refresh_equipment(s.equipment_slots)end
    for i,control in ipairs(M.armour) do bind_cell(control,s.armour[i-1],false) end
    local rows=M.bank_rows()
    M.bank_empty=V.result_count('stored')==0 and ((V.placeholder_count and V.placeholder_count())or 0)==0
    if M.empty_message then
        text(M.empty_message,V.empty_text())
        M.empty_message.object:SetVisibility(M.bank_empty and 3 or 1)
    end
    if M.clear_search then M.clear_search.object:SetVisibility(V.query~='' and 0 or 1) end
    if V.mode=='stored'then V.selection=math.min(V.selection,#rows)end
    M.layout_bank(rows)
    local row=V.selected()
    text(M.item_name,row and row.name or "Select an item")
    text(M.source_info,V.source_info(row))
    if not M.amount:HasKeyboardFocus() and row then
        local value=tostring(V.amount(row))
        if M.amount_value~=value then M.amount:SetText(FText(value)); M.amount_value=value end
    end
    text(M.transfer_button.label,V.mode=="stored" and "Withdraw" or "Deposit")
    local drawer_status=tostring(V.status or '')
    if drawer_status:find('^Custom tab ')or drawer_status:find('^Tab removed;')or drawer_status:find('^Drag a stack to withdraw')then drawer_status=''end
    text(M.status,drawer_status)
    M.status.object:SetToolTipText(FText(drawer_status))
    require('stashlink.transfer_controls').update(M,V)
    require('stashlink.bank_tabs_ui').update(M,V)
    M.render_ms=(os.clock()-started)*1000
end
-- Rows of the scrolling bank. The view always spans at least one screen.
function M.bank_total_rows(count)
    local cols=M.bank_layout and M.bank_layout.cols or 8
    return math.max(M.visible_rows,math.ceil((count or #M.bank_rows())/cols))
end
function M.scroll_to_row(row,count)
    local pitch=M.bank_layout and M.bank_layout.pitch_y or 69
    row=math.max(0,math.min(math.floor(row or 0),M.bank_total_rows(count)-M.visible_rows))
    M.bank_row=row;M.scroll_offset=row*pitch;M.scroll_idle=0
    if valid(M.bank_scroll)then M.bank_scroll:SetScrollOffset(M.scroll_offset)end
end
-- Bind the buffered window of cells to the rows under the current scroll offset.
-- Bounds follow the visible position, so hover, drops and controller focus stay exact.
function M.layout_bank(rows)
    local L=M.bank_layout
    if not L then
        for i,control in ipairs(M.stored)do control.row_index=i;bind_cell(control,rows[i],V.mode=='stored'and V.selection==i)end
        return
    end
    local total=M.bank_total_rows(#rows)
    if M.content_rows~=total and valid(M.bank_sizer)then
        M.content_rows=total;M.bank_sizer:SetHeightOverride(L.pad*2+(total-1)*L.pitch_y+L.cell)
    end
    if M.pending_row then local pending=M.pending_row;M.pending_row=nil;M.scroll_to_row(pending,#rows)end
    -- Withdrawals can shorten the bank below the current offset.
    if (M.scroll_offset or 0)>(total-M.visible_rows)*L.pitch_y+.5 then M.scroll_to_row(total-M.visible_rows,#rows)end
    if M.reveal_selection and V.mode=='stored'and V.selection>0 then
        local r=math.floor((V.selection-1)/L.cols);local top=M.bank_row or 0
        if r<top then M.scroll_to_row(r,#rows)elseif r>top+M.visible_rows-1 then M.scroll_to_row(r-M.visible_rows+1,#rows)end
    end
    M.reveal_selection=false
    local offset=M.scroll_offset or 0
    local top=math.floor(offset/L.pitch_y+1e-6);local first=math.max(0,top-1)
    if M.window_first~=first and M.bank_window_slot then
        M.window_first=first
        M.bank_window_slot:SetOffsets({Left=0,Top=L.pad+first*L.pitch_y,Right=(L.cols-1)*L.pitch_x+L.cell,Bottom=(L.rows+2)*L.pitch_y})
    end
    M.bank_row=top
    local view_top=L.origin.y+L.grid_y;local view_bottom=view_top+L.grid_h
    local content_top=view_top+L.pad-offset
    for i,control in ipairs(M.stored) do
        local row_number=first+math.floor((i-1)/L.cols)
        control.row_index=row_number*L.cols+((i-1)%L.cols)+1
        control.bank_hidden=row_number>=total
        local y=content_top+row_number*L.pitch_y
        control.bounds.y=y
        -- Cells outside the ScrollBox are clipped: never hover, drop or tooltip targets.
        control.clipped=y<view_top-1 or y+control.bounds.h>view_bottom+1
        bind_cell(control,not control.bank_hidden and rows[control.row_index] or nil,V.mode=="stored" and V.selection==control.row_index)
    end
end
-- Follow the native ScrollBox (wheel, scrollbar drag). Settle on whole rows when idle.
function M.scroll_tick()
    if not V.open or not valid(M.bank_scroll) or not M.bank_layout then return end
    local ok,offset=pcall(M.bank_scroll.GetScrollOffset,M.bank_scroll)
    if not ok or type(offset)~='number' then return end
    local pitch=M.bank_layout.pitch_y
    if math.abs(offset-(M.scroll_offset or 0))>.5 then
        M.scroll_offset=offset;M.scroll_idle=0;M.render();return
    end
    M.scroll_idle=(M.scroll_idle or 0)+1
    local row=math.floor(offset/pitch+.5)
    if M.scroll_idle==6 and math.abs(row*pitch-offset)>.5 then
        local down=false;pcall(function() down=M.pc:IsInputKeyDown(M.mouse_key) end)
        if down then M.scroll_idle=0 else M.scroll_to_row(row);M.render() end
    end
end
function M.show() M.create();M.search:SetText(FText(V.query)); M.root:SetVisibility(0); V.open=true; M.render();require('stashlink.native_panels').show(M) end
function M.hide()
    M.pointer=nil;M.last_click=nil;M.tab_editor_open=false
    V.open=false
    if not M.root then return end
    if M.effects then M.effects:stop()end
    if M.bank_ui and valid(M.bank_ui.popup)then M.bank_ui.popup:SetVisibility(1)end
    if valid(M.ghost)then M.ghost:SetVisibility(1)end
    V.open=false;require('stashlink.native_panels').hide(M);if valid(M.root)then M.root:SetVisibility(1)end
end
-- Layout functions capture widget trees too. Forget them along with their
-- fields, while retaining the module methods, service binding and preferences.
local transient_fields={
    'panel_bounds',
    'refresh_equipment','equipment_specs','equipment_key',
    'root','tree','pc','layout_lib','time_lib','mouse_key','params','controller_canvas',
    'icon_host','ghost','ghost_slot','close_legend','left_frame','right_frame','bank_frame',
    'extras','extras_content','styled_controls','native_panels','hotbar','backpack','armour',
    'stored','tab_buttons','bag_prev','bag_next','bag_page_label','weight','weight_bar',
    'weight_fill_slot','power','bank_title','bank_linked','bank_scroll','bank_sizer',
    'bank_capacity','bank_free','bank_capacity_bar','bank_capacity_fraction',
    'bank_window_slot','empty_message','search','clear_search','quick_amounts','sort_button',
    'options_button','placeholders_toggle','ledger_key_toggle','ledger_open_input','ledger_open_value','ledger_key_quarantine_until','subtitle','quantity_preview','item_name','source_info','transfer_help',
    'amount','amount_buttons','transfer_button','status','drawer_close','bank_ui','category_buttons',
    'custom_tab_buttons','tab_editor_controls','controller_ui','controller_split','keyboard_controls',
    'feedback_panel','effects','pointer','last_click','last_click_row','controller_focus',
    'make','fit_viewport','align_weight','animate_drawer','refresh_quantity_ui','refresh_feedback',
    'feedback_tick','refresh_skin','set_drawer','refresh_tab_editor','close_tab_editor',
    'open_tab_editor','bank_editor_pointer','bank_action','drop_bank_tab',
    'render_wrapper','hide_wrapper','click_wrapper','pointer_down_wrapper','on_action_wrapper',
    'base_render','base_hide','base_click','base_pointer_down','base_sync_inputs','base_on_action',
    'amount_value','transfer_availability_set','transfer_unavailable','extras_open','tab_editor_open',
    'controller_active','controller_carry','content_rows','window_first','pending_row','last_gesture',
    'bank_layout','bank_grid_bounds','move_hint','feedback_value','feedback_reset',
}
function M.forget()
    -- Post-travel cleanup must never query even IsValid on old wrappers.
    local effects=package.loaded['stashlink.panel_effects']
    if effects and effects.release then effects.release(M,false)end
    local hover=package.loaded['stashlink.hover_card']
    if hover and hover.release then hover.release(M,false)end
    local panels=package.loaded['stashlink.native_panels']
    if panels and panels.active==M then panels.active=nil end
    if base_methods then for name,fn in pairs(base_methods)do M[name]=fn end end
    if M.action_callback then M.on_action=M.action_callback
    elseif M.base_on_action then M.on_action=M.base_on_action end
    for _,name in ipairs(transient_fields)do M[name]=nil end
    M.controls={};M.icon_cache={};M.icon_queue={};M.icon_loading={};M.icons_pending=0;M.icon_total=0
    M.bank_row=0;M.scroll_offset=0;M.scroll_idle=0;M.reveal_selection=false;V.open=false
end
function M.destroy()
    local first_error
    local function attempt(fn,...)
        local ok,result,why=pcall(fn,...)
        if not first_error then
            if not ok then first_error=result elseif result==false then first_error=why or 'UI release failed'end
        end
    end
    local effects=package.loaded['stashlink.panel_effects']
    if effects and effects.release then attempt(effects.release,M,true)end
    local hover=package.loaded['stashlink.hover_card']
    if hover and hover.release then attempt(hover.release,M,true)end
    attempt(M.hide)
    attempt(function()if valid(M.root)then M.root:RemoveFromParent()end end)
    M.forget()
    if first_error then error(first_error)end
end
function M.focus_search() if M.tab_editor_open then return end;V.entry="native_search"; M.search:SetKeyboardFocus() end
function M.focus_amount() if M.tab_editor_open then return end;if M.set_drawer then M.set_drawer(true) else M.extras_open=true;M.extras:SetVisibility(0) end;V.entry="native_amount"; M.amount:SetKeyboardFocus() end
function M.sync_inputs(commit)
    if not V.open then return end
    local value=M.search:GetText():ToString()
    if value~=V.query then V.query=value; V.selection=1; V.mode="stored"; M.scroll_to_row(0); M.render() end
    if commit then
        local number=tonumber(M.amount:GetText():ToString())
        assert(number and number>0 and number<=2147483647 and number==math.floor(number),"Enter a positive whole quantity")
        V.custom_amount=number; V.entry=nil
    elseif M.search:HasKeyboardFocus() then V.entry="native_search"
    elseif M.amount:HasKeyboardFocus() then V.entry="native_amount"
    elseif V.entry=="native_search" or V.entry=="native_amount" then V.entry=nil end
end
function M.navigate(delta)
    if V.mode=="stored" then V.selection=math.max(1,math.min(#M.bank_rows(),V.selection+delta));M.reveal_selection=true
    else
        local page=M.current_page()
        V.player_slot=math.max(page.first,math.min(page.first+page.count-1,(V.player_slot or page.first)+delta))
        M.bag_page=math.floor((V.player_slot-page.first)/M.bag_capacity())
    end
end
function M.click(chosen)
    if not V.open then return end
    if chosen and not M.cell_available(chosen)then return end
    if M.tab_editor_open and (not chosen or not chosen.tab_editor) then return end
    if not chosen and M.search:IsHovered() then M.focus_search(); return end
    if not chosen and M.amount:IsHovered() then M.focus_amount(); return end
    for _,control in ipairs(M.controls) do
        if control==chosen or (not chosen and control.object:IsHovered()) then
            if not M.cell_available(control)then return end
            if M.bank_action and M.bank_action(control.action,control.data)then if V.open then M.render()end;return end
            if control.pane then
                if control.pane=="armour" then V.selection=0; V.player_slot=nil; V.mode="stored"; V.status="Equipped items are protected"
                elseif control.pane=="stored" then V.mode="stored"; V.player_slot=nil; V.selection=control.row and control.row_index or 0
                else V.mode="held"; V.player_slot=control.slot; V.selection=0 end
                local now=os.clock()
                pcall(function() now=M.time_lib:GetRealTimeSeconds(M.pc) end)
                if M.last_click==control and M.last_click_row==control.row
                    and now-(M.last_click_time or 0)<0.35 and control.row and control.pane~="armour" then
                    M.last_click=nil; M.on_action("transfer")
                else M.last_click=control; M.last_click_row=control.row; M.last_click_time=now end
            elseif control.action=='transfer' and M.transfer_unavailable then V.status=M.transfer_unavailable;M.render();return
            elseif control.action=='drawer_close' then M.set_drawer(false);return
            elseif control.action=="extras" then M.set_drawer(not M.extras_open)
            elseif control.action=="tab" then M.player_tab=control.data; M.bag_page=0; V.mode="held"; V.player_slot=nil; V.selection=0
            elseif control.action=="bag_previous" then M.bag_page=math.max(0,M.bag_page-1); V.mode="held"; V.player_slot=nil; V.selection=0
            elseif control.action=="bag_next" then M.bag_page=math.max(0,math.min(math.ceil(M.current_page().count/M.bag_capacity())-1,M.bag_page+1)); V.mode="held"; V.player_slot=nil; V.selection=0
            elseif control.action=="clear_search" then M.search:SetText(FText("")); V.query=""; V.selection=1; M.scroll_to_row(0)
            elseif control.action=="amount_custom" then M.focus_amount()
            elseif control.action=="amount" then
                V.custom_amount=nil; V.amount_index=control.data
                if V.remember_amount then V.remember_amount()end
                local row=V.selected(); if row then M.amount:SetText(FText(tostring(V.amount(row)))); M.amount_value=tostring(V.amount(row)) end
            else M.on_action(control.action,control.data) end
            if V.open then M.render() end
            return
        end
    end
end
function M.hovered()
    for _,control in ipairs(M.controls) do if M.cell_available(control)and control.object:IsHovered() then return control end end
end
function M.select_control(control)
    if not M.cell_available(control)then return end
    M.last_click=nil
    if control.pane=='stored' then V.mode='stored';V.player_slot=nil;V.selection=control.row and control.row_index or 0;M.reveal_selection=true
    elseif control.pane=='held' or control.pane=='hotbar' then V.mode='held';V.player_slot=control.slot;V.selection=0 end
    if control.pane=='armour' then V.mode='stored';V.player_slot=nil;V.selection=0 end
end
function M.right_click()
    if not V.open or M.pointer or M.tab_editor_open or V.entry=='controller_search' or V.entry=='controller_amount' then return end
    local control=M.hovered()
    if control and control.action=='bank_tab'and control.data~='all'then M.open_tab_editor(control.data);return end
    if control and control.pane and control.row then
        M.last_click=nil;V.entry=nil
        M.on_action('use',control)
    end
end
function M.pointer_position()
    local location=M.layout_lib:GetMousePositionOnViewport(M.pc)
    return location.X/(M.content_scale or 1),location.Y/(M.content_scale or 1)
end
-- A drag needs the button held past both a distance and a time threshold, measured only
-- while it is still down: a quick click, even one followed by moving away, stays a click.
M.drag_distance=10;M.drag_hold=.15
function M.pointer_down(force_half,force_quick,pressed)
    if M.controller_active then return end
    if M.tab_editor_open then M.bank_editor_pointer();return end
    if M.pointer then
        if force_half then M.pointer.half=true end
        if force_quick then M.pointer.quick=true end
        return
    end
    if not V.open then return end
    if valid(M.ledger_open_input)and M.ledger_open_input:IsHovered()then
        V.entry='native_ledger_key';M.ledger_key_quarantine_until=os.clock()+.5
        M.ledger_open_input:SetKeyboardFocus();return
    end
    if M.search:IsHovered() then M.focus_search(); return end
    if M.amount:IsHovered() then M.focus_amount(); return end
    local control=M.hovered()
    if not M.cell_available(control)then return end
    if control.action=='bank_tab'and control.data~='all'then
        local x,y=M.pointer_position()
        M.pointer={control=control,tab_id=control.data,tab_revision=V.bank.revision,x=x,y=y,dragging=false,started=pressed or os.clock()}
        return
    end
    if not control.pane or not control.row or control.pane=="armour" then M.click(control); return end
    local x,y=M.pointer_position()
    local half=force_half or M.pc:IsInputKeyDown({KeyName=FName('LeftShift')}) or M.pc:IsInputKeyDown({KeyName=FName('RightShift')})
    local quick=force_quick or M.pc:IsInputKeyDown({KeyName=FName('LeftControl')}) or M.pc:IsInputKeyDown({KeyName=FName('RightControl')})
    M.pointer={control=control,binding=control.bag_binding,pane=control.pane,row=control.row,token=V.snapshot.token,x=x,y=y,dragging=false,half=half,quick=quick,started=pressed or os.clock()}
end
function M.has_work()
    if M.pointer~=nil or (M.icons_pending or 0)>0 then return true end
    for _,control in ipairs(M.controls) do if control.icon_deferred and (control.row or control.icon_row)then return true end end
    return false
end
function M.pointer_tick()
    local pointer=M.pointer
    if not pointer or not V.open then return end
    if not pointer.tab_id and (not M.cell_available(pointer.control)or not Drag.source_valid(pointer))then
        M.pointer=nil;M.last_click=nil;M.ghost:SetVisibility(1);V.status='Inventory changed; select the item again';return
    end
    local pc=M.pc
    local x,y=M.pointer_position()
    local down=pointer.control.object:IsPressed() or pc:IsInputKeyDown(M.mouse_key)
    if down and not pointer.dragging and (x-pointer.x)^2+(y-pointer.y)^2>=M.drag_distance^2
        and os.clock()-(pointer.started or 0)>=M.drag_hold then pointer.dragging=true end
    if pointer.tab_id then
        if down then
            if pointer.dragging then
                local entry=M.icon_cache[pointer.control.definition]
                if entry and valid(entry.texture)then M.ghost:SetBrushFromTexture(entry.texture,false);M.ghost:SetVisibility(3)end
                M.ghost_slot:SetPosition({X=x+12,Y=y+12})
            end
            return
        end
        if not pointer.released then pointer.released=true;return end
        M.pointer=nil;M.ghost:SetVisibility(1)
        if pointer.tab_revision~=V.bank.revision or pointer.control.data~=pointer.tab_id then V.status='Tabs changed; drag the tab again';return end
        if not pointer.dragging then M.click(pointer.control);return end
        local target=M.hovered();local before
        if target and target.action=='bank_tab'then
            -- The dragged tab takes the target's place, whichever direction it moves.
            local tabs=V.bank.state.tabs;local from,to
            for i,tab in ipairs(tabs)do if tab.id==pointer.tab_id then from=i end;if tab.id==target.data then to=i end end
            if target.data=='all'then before=tabs[1].id
            elseif from and to and to>from then before=tabs[to+1]and tabs[to+1].id or nil
            else before=target.data end
        elseif not target or target.action~='bank_new'then V.status='Tab move cancelled';return end
        local ok,why=V.bank:move(pointer.tab_id,before);V.status=ok and 'Custom tab reordered'or tostring(why)
        if ok then V.repack()end;M.render();return
    end
    if down then
        if pointer.dragging then
            local entry=M.icon_cache[pointer.row.definition]
            if entry and valid(entry.texture) then
                if not pointer.ghost_shown then M.ghost:SetBrushFromTexture(entry.texture,false); M.ghost:SetVisibility(3); pointer.ghost_shown=true end
            end
            M.ghost_slot:SetPosition({X=x+12,Y=y+12})
        end
        return
    end
    -- Give Slate one pulse to update hover after releasing captured mouse input.
    if not pointer.released then pointer.released=true; return end
    M.pointer=nil; M.ghost:SetVisibility(1)
    M.last_gesture={half=pointer.half,dragging=pointer.dragging}
    if not pointer.dragging then
        if pointer.token and (pointer.token~=V.snapshot.token or not pointer.control.row
            or pointer.control.row.key~=pointer.row.key)then M.last_click=nil;V.status='Inventory changed; select the item again';return end
        if pointer.half then
            local control=pointer.control
            M.last_click=nil;V.custom_amount=nil;V.amount_index=5
            if control.pane=='stored' then V.mode='stored';V.selection=control.row_index;V.player_slot=nil
            else V.mode='held';V.selection=0;V.player_slot=control.slot end
            M.set_drawer(true);V.status='Choose the split amount, then Withdraw or Deposit';M.render()
            return
        end
        if pointer.quick then
            M.last_click=nil
            M.on_action('quick_transfer',{pane=pointer.pane,row=pointer.row,slot=pointer.control.slot,snapshot_token=pointer.token})
            return
        end
        M.click(pointer.control);return
    end
    M.last_click=nil
    local target=M.hovered()
    if M.invalid_backpack_at(x,y)then V.status='Drag cancelled';return end
    if target and not M.cell_available(target)then V.status='Drag cancelled';return end
    if M.drop_bank_tab and M.drop_bank_tab(pointer,target)then M.render();return end
    if target and not target.pane then V.status='Drag cancelled';return end
    if M.search:IsHovered()or M.amount:IsHovered()then V.status='Drag cancelled';return end
    if not target then
        if M.left_frame:IsHovered() then target={pane="held"}
        elseif M.right_frame:IsHovered() then
            local b=M.bank_grid_bounds
            if not b or(x>=b.x and x<b.x+b.w and y>=b.y and y<b.y+b.h)then target={pane="stored"}end
        end
    end
    local intent,why=Drag.resolve(pointer,target)
    if intent then M.last_gesture.quantity=intent.quantity;M.last_gesture.direction=intent.direction end
    if intent then M.on_action("drag",intent) else V.status=why end
    if V.open then M.render() end
end
base_methods={render=M.render,hide=M.hide,click=M.click,pointer_down=M.pointer_down,sync_inputs=M.sync_inputs}
return M
