-- Presentation categories never grant inventory write permission.
local M={}
M.list={{id='all',name='All items',short='All'},{id='gear',name='Equipment',short='Gear'},
 {id='tools',name='Tools',short='Tools'},{id='food',name='Food and potions',short='Food'},
 {id='materials',name='Materials and seeds',short='Mats'},{id='runes',name='Runes',short='Runes'},
 {id='ammo',name='Ammunition and bait',short='Ammo'},{id='plans',name='Plans and tomes',short='Plans'},
 {id='quest',name='Quest items',short='Quest'},{id='other',name='Other items',short='Other'}}
M.by_id={};for _,entry in ipairs(M.list)do M.by_id[entry.id]=entry end
local classes={BP_Consumables_Food_C='food',BP_Consumables_Drink_C='food',BP_Consumables_Potion_C='food',
 MagicAmmoData='runes',RangedAmmoData='ammo',FishingBaitAmmoData='ammo',
 BP_Consumables_RecipeUnlocker2_C='plans',BP_Consumables_Plan_Base_C='plans',BP_Consumables_SkillTome_C='plans',ConsumableMountUnlocker='plans',
 SpadeToolEquipmentData='tools',FishingRodHeldEquipmentData='tools',HarvestToolEquipmentData='tools',HeldContainerEquipmentData='tools',
 SeedHeldEquipmentData='materials',HeldTreeSeedData='materials',FuelItemData='materials',WhetstoneItemData='materials',
 WearableEquipmentData='gear',TrinketItemData='gear',ShieldData='gear',HeldEquipmentData='gear',JournalItemData='quest'}
-- Fixed tab art, chosen to read on a dark 36 px chip (rune-tier art is too dark).
-- Each list ends with a base-game item in case a content pack is absent;
-- All uses the backpack's own Items glyph instead of item art.
M.icons={
 gear={'HeldEquipmentData /ScornedWilderness/Gameplay/Character/Player/Equipment/Held/Scimitar/ITEM_Scimitar_Dragon.ITEM_Scimitar_Dragon',
  'HeldEquipmentData /Game/Gameplay/Character/Player/Equipment/Held/Sword/ITEM_Sword_Bronze.ITEM_Sword_Bronze'},
 tools={'HeldEquipmentData /Game/Gameplay/Character/Player/Equipment/Held/Pickaxe/ITEM_Pickaxe_Bronze.ITEM_Pickaxe_Bronze'},
 food={'BP_Consumables_Food_C /Game/Gameplay/Items/Consumables/Food/Items/v3/ITEM_Consumable_Bread.ITEM_Consumable_Bread'},
 materials={'FuelItemData /Game/Gameplay/Items/Resources/Wood/ITEM_Resources_Wood_Oak.ITEM_Resources_Wood_Oak'},
 runes={'MagicAmmoData /Game/Gameplay/Items/Resources/Magic/ITEM_Rune_Fire.ITEM_Rune_Fire'},
 ammo={'RangedAmmoData /Game/Gameplay/Character/Player/Equipment/Ammo/ITEM_Ammo_Arrows_Bronze_Bodkin.ITEM_Ammo_Arrows_Bronze_Bodkin'},
 plans={'BP_Consumables_SkillTome_C /Game/Gameplay/Items/Consumables/Tomes/ITEM_Consumable_Tome_Tier1_Magic.ITEM_Consumable_Tome_Tier1_Magic'},
 quest={'JournalItemData /Game/Gameplay/Items/Journaltems/ITEM_JOURNAL_TreasureMap_Scarecrow_1.ITEM_JOURNAL_TreasureMap_Scarecrow_1'},
 other={'BP_Consumables_ItemEmitter_C /Game/Gameplay/Items/Consumables/Misc/ITEM_Consumable_GoblinPack.ITEM_Consumable_GoblinPack'}}
-- The game's Held/Hammer family contains combat warhammers, not tools.
local tools={'/held/axe/','/held/hatchet/','/held/pickaxe/','/held/farming/','/held/fishing/','/held/fishingnet/','/held/torch/','/held/woodcutting/','/held/mining/'}
function M.classify(row)
    if row.category and M.by_id[row.category]then return row.category end
    local definition=row.definition or '';local class=definition:match('^(%S+)')or'';local path=definition:lower()
    if path:find('/quest/',1,true)or path:find('/quests/',1,true)then return 'quest'end
    -- Earth, Law, Nature, Astral and essence are plain ItemData beside the ammo runes.
    if path:find('/resources/magic/item_rune_',1,true)then return 'runes'end
    if class=='HeldEquipmentData'then for _,part in ipairs(tools)do if path:find(part,1,true)then return 'tools'end end end
    if classes[class]then return classes[class]end
    if path:find('/resources/',1,true)or path:find('/seeds/',1,true)then return 'materials'end
    local native=row.class_name or ((row.source or (row.sources and row.sources[1])or{}).signature or ''):match('^([^|]+)')or''
    if native=='Class /Script/Dominion.MagicAmmo'then return 'runes'end
    if native=='Class /Script/Dominion.RangedAmmo'or native=='Class /Script/Dominion.FishingBaitAmmo'then return 'ammo'end
    if native=='Class /Script/Dominion.HeldContainerEquipmentItem'then return 'tools'end
    if native=='Class /Script/Dominion.WearableEquipment'or native=='Class /Script/Dominion.HeldEquipmentItem'
        or native=='Class /Script/Dominion.Shield'or native=='Class /Script/Dominion.Trinket'then return 'gear'end
    -- Content packs keep ores, bars, hides and raw fish outside a /Resources/ folder.
    if class=='ItemData'then return 'materials'end
    return 'other'
end
return M
