-- Saved presentation only: descriptors cannot own items or inventory sources.
local Store=require('stashlink.bank_tab_store')
local Categories=require('stashlink.bank_categories')
local M={LIMIT=4*1024*1024,MAX_SCOPES=16,MAX_ENTRIES=8192,MAX_SCOPE_ENTRIES=4096}
local fields={'id','definition','name','category','class_name','burnt','masterwork_type','masterwork_upgrades','r','g','b','a','opacity'}
local function integer(n,lo,hi)return type(n)=='number'and n==math.floor(n)and n>=lo and n<=hi end
local function text(s,limit)return type(s)=='string'and #s>0 and #s<=limit and not s:find('[%z\1-\31\127]')end
local function number(n)return type(n)=='number'and n==n and n>=0 and n<=16 end
local function defaults()return {amount_index=3,placeholders=true}end
local function scope(key)return {key=key,sort_mode='name',selected_tab='all',category='all',page=0,entries={}}end
local function valid_entry(e)
    assert(text(e.id,8192)and text(e.definition,2048)and text(e.name,512),'Invalid saved item identity')
    assert(Categories.by_id[e.category]and type(e.class_name)=='string'and #e.class_name<=256,'Invalid saved item category')
    assert(type(e.burnt)=='boolean'and integer(e.masterwork_type,0,255)and integer(e.masterwork_upgrades,0,255),'Invalid saved item style')
    for _,key in ipairs({'r','g','b','a','opacity'})do assert(number(e[key]),'Invalid saved item tint')end
end
function M.validate(state,yield_work)
    local p=state.prefs
    assert(type(p)=='table'and integer(p.amount_index,1,5)and type(p.placeholders)=='boolean','Invalid bank preferences')
    assert(p.custom_amount==nil or integer(p.custom_amount,1,2147483647),'Invalid saved quantity')
    assert(type(state.scopes)=='table'and #state.scopes<=M.MAX_SCOPES,'Invalid bank layouts')
    local scopes,total={},0
    for _,s in ipairs(state.scopes)do
        assert(text(s.key,256)and not scopes[s.key],'Invalid or duplicate bank scope');scopes[s.key]=true
        assert(s.sort_mode=='name'or s.sort_mode=='amount'or s.sort_mode=='custom','Invalid bank sort')
        assert(s.selected_tab=='all'or(type(s.selected_tab)=='string'and s.selected_tab:match('^t%d+$')),'Invalid saved tab')
        assert(Categories.by_id[s.category]and integer(s.page,0,4095),'Invalid saved bank view')
        assert(type(s.entries)=='table'and #s.entries<=M.MAX_SCOPE_ENTRIES,'Too many saved slots')
        local ids={}
        for i,e in ipairs(s.entries)do
            valid_entry(e);assert(not ids[e.id],'Duplicate saved slot');ids[e.id]=true;total=total+1
            if yield_work and i%8==0 then yield_work()end
        end
    end
    assert(total<=M.MAX_ENTRIES,'Too many saved slots');return true
end
function M.pack(state,sequence,yield_work)
    M.validate(state,yield_work);assert(integer(sequence,1,2147483647),'Invalid save sequence')
    local p=state.prefs;local lines={'STASHLINK_BANK_MEMORY\t1\t'..sequence,
        table.concat({'P',p.amount_index,p.custom_amount or 0,p.placeholders and 1 or 0},'\t')}
    for _,s in ipairs(state.scopes)do
        lines[#lines+1]=table.concat({'S',Store.encode(s.key),s.sort_mode,s.selected_tab,s.category,s.page},'\t')
        for index,e in ipairs(s.entries)do
            local row={'R'}
            for i,key in ipairs(fields)do
                local value=e[key]
                row[#row+1]=i<=5 and Store.encode(value)or key=='burnt'and(value and '1'or'0')or string.format('%.17g',value)
            end
            lines[#lines+1]=table.concat(row,'\t')
            if yield_work and index%8==0 then yield_work()end
        end
    end
    local body=table.concat(lines,'\n')..'\n';local value=body..'END\t'..Store.checksum(body,yield_work)..'\n'
    assert(#value<=M.LIMIT,'Saved bank layouts exceed the size limit');return value
end
function M.unpack(value)
    assert(type(value)=='string'and #value<=M.LIMIT,'Invalid bank memory size')
    local body,hash=value:match('^(.*\n)END\t(%x+)\n$');assert(body and Store.checksum(body)==hash,'Incomplete bank memory')
    local header,tail=body:match('^([^\n]+)\n(.*)$')
    local sequence=tonumber(header:match('^STASHLINK_BANK_MEMORY\t1\t(%d+)$'))
    assert(integer(sequence,1,2147483647),'Unsupported bank memory version')
    local state={scopes={}};local current
    for line in tail:gmatch('[^\n]+')do
        local columns={};for part in (line..'\t'):gmatch('(.-)\t')do columns[#columns+1]=part end
        if columns[1]=='P'then
            assert(#columns==4 and not state.prefs,'Invalid preference record')
            assert(columns[4]=='0'or columns[4]=='1','Invalid placeholder preference')
            local amount=tonumber(columns[3]);assert(amount~=nil,'Invalid saved quantity')
            state.prefs={amount_index=tonumber(columns[2]),custom_amount=amount~=0 and amount or nil,placeholders=columns[4]=='1'}
        elseif columns[1]=='S'then
            assert(#columns==6,'Invalid scope record')
            current=scope(Store.decode(columns[2]));current.sort_mode=columns[3];current.selected_tab=columns[4];current.category=columns[5];current.page=tonumber(columns[6])
            state.scopes[#state.scopes+1]=current
        elseif columns[1]=='R'then
            assert(current and #columns==#fields+1,'Invalid saved item record');local e={}
            for i,key in ipairs(fields)do
                local v=columns[i+1]
                if i<=5 then e[key]=Store.decode(v)
                elseif key=='burnt'then assert(v=='0'or v=='1','Invalid saved item state');e[key]=v=='1'
                else e[key]=tonumber(v)end
            end
            current.entries[#current.entries+1]=e
        else error('Invalid bank memory record')end
    end
    M.validate(state);return state,sequence
end
function M.id(row)
    if row.memory_id then return row.memory_id end
    local sources=row.sources or{};local source=sources[1]
    if source and source.identity and #sources==1 and ((row.stack_size or 99)<=1 or row.writable==false)then
        return row.definition..'|guid:'..source.identity
    end
    return tostring(row.key or row.definition)
end
local function describe(row,id)
    local style=row.masterwork_style or{};local c=style.color or{}
    local name=row.name and row.name~=''and row.name or row.definition:match('%.([^%.]+)$')or row.definition
    local result={id=id,definition=row.definition,name=name:gsub('[%z\1-\31\127]',' '),
        category=Categories.classify(row),class_name=row.class_name or'',burnt=row.burnt==true,
        masterwork_type=tonumber(row.masterwork_type)or 0,masterwork_upgrades=tonumber(row.masterwork_upgrades)or 0,
        r=c.R or 0,g=c.G or 0,b=c.B or 0,a=c.A or 1,opacity=style.opacity or 0}
    valid_entry(result);return result
end
local function unchanged(previous,row)
    local style=row.masterwork_style or{};local c=style.color or{}
    return previous and previous.definition==row.definition and previous.name==row.name
        and previous.category==(row.category or Categories.classify(row))and previous.class_name==(row.class_name or'')
        and previous.burnt==(row.burnt==true)and previous.masterwork_type==(tonumber(row.masterwork_type)or 0)
        and previous.masterwork_upgrades==(tonumber(row.masterwork_upgrades)or 0)
        and previous.r==(c.R or 0)and previous.g==(c.G or 0)and previous.b==(c.B or 0)
        and previous.a==(c.A or 1)and previous.opacity==(style.opacity or 0)
end
function M.placeholder(entry)
    local style=entry.opacity>0 and {opacity=entry.opacity,color={R=entry.r,G=entry.g,B=entry.b,A=entry.a}}or nil
    -- Classify again: a saved category predates any later classifier correction.
    local category=Categories.classify({definition=entry.definition,class_name=entry.class_name})
    return {key='placeholder:'..entry.id,placeholder=true,placeholder_id=entry.id,name=entry.name,definition=entry.definition,
        category=category,class_name=entry.class_name,total=0,available=0,stack_size=1,writable=false,sources={},
        read_only_reason='Placeholder: no items are stored here',burnt=entry.burnt,masterwork_type=entry.masterwork_type,
        masterwork_upgrades=entry.masterwork_upgrades,masterwork_style=style}
end
function M.new(store)
    local self={store=store,state={prefs=defaults(),scopes={}},volatile={},revision=0,dirty=false,present={},row_ids={}}
    function self:load()
        if not self.store then return true end
        local state,why=self.store:load();if state then self.state=state end
        self.load_error=why;return not why,why
    end
    function self:touch()self.revision=self.revision+1;self.dirty=true;self.changed_at=os.time()end
    function self:activate(key,persistent)
        local identity=(persistent and 'saved:'or 'session:')..key
        if self.identity==identity then return false end
        self.identity=identity;self.current=nil;self.persistent=persistent==true
        if persistent then for _,s in ipairs(self.state.scopes)do if s.key==key then self.current=s;break end end end
        if not self.current then
            if persistent and #self.state.scopes<M.MAX_SCOPES then self.current=scope(key);self.state.scopes[#self.state.scopes+1]=self.current;self:touch()
            else self.volatile[key]=self.volatile[key]or scope(key);self.current=self.volatile[key];self.persistent=false end
        end
        self.index={};for i,e in ipairs(self.current.entries)do self.index[e.id]=i end
        self.present={};self.row_ids={};self.tokens={};self.revision=self.revision+1;return true
    end
    function self:observe(rows)
        if not self.current then return end
        self.present={};self.row_ids={};self.by_definition={}
        local total=0;for _,s in ipairs(self.state.scopes)do total=total+#s.entries end
        local changed=false
        for _,row in ipairs(rows)do
            local id=M.id(row)
            if self.present[id]then id=id..'|duplicate:'..tostring(row.key) end
            self.present[id]=row;self.row_ids[row]=id
            local at=self.index[id];local previous=at and self.current.entries[at]
            local ok,e
            local token=row._presentation
            if not(previous and token and self.tokens[id]==token)and not unchanged(previous,row)then ok,e=pcall(describe,row,id)end
            self.tokens[id]=token
            if ok then
                if previous then
                    local different=false;for _,key in ipairs(fields)do if previous[key]~=e[key]then different=true;break end end
                    if different then self.current.entries[at]=e;changed=true end
                elseif #self.current.entries<M.MAX_SCOPE_ENTRIES and (not self.persistent or total<M.MAX_ENTRIES)then
                    self.current.entries[#self.current.entries+1]=e;self.index[id]=#self.current.entries;total=total+1
                    changed=true
                end
            end
        end
        if changed and self.persistent then self:touch()end
        for _,e in ipairs(self.current.entries)do self.by_definition[e.definition]=self.by_definition[e.definition]or e end
    end
    function self:rows(rows)
        if not self.current then return rows end
        local result,seen={},{}
        for _,e in ipairs(self.current.entries)do
            local row=self.present[e.id]
            if row then result[#result+1]=row;seen[row]=true
            elseif self.state.prefs.placeholders then result[#result+1]=M.placeholder(e)end
        end
        -- Bounds or unrecognized metadata can never hide an actual inventory row.
        for _,row in ipairs(rows)do if not seen[row]then result[#result+1]=row end end
        return result
    end
    function self:definition_row(definition)
        local e=self.by_definition and self.by_definition[definition];return e and M.placeholder(e)or nil
    end
    function self:row_id(row)return row.placeholder_id or self.row_ids[row]or M.id(row)end
    function self:rank(row)return self.index and self.index[self:row_id(row)]or math.huge end
    -- Hand arrangement: the moved slot takes the target's place (or goes last), in
    -- either direction; the others shift by one. Items never move.
    function self:move(row,target_row)
        if not self.current then return nil,'Storage layout unavailable'end
        local id,target=self:row_id(row),target_row and self:row_id(target_row)
        if id==target then return true end
        local from=self.index[id];if not from then return nil,'This item has no saved slot yet'end
        local to=target and self.index[target]
        if target and not to then return nil,'The destination slot changed'end
        local entries=self.current.entries;local entry=table.remove(entries,from)
        table.insert(entries,to or #entries+1,entry)
        self.index={};for i,e in ipairs(entries)do self.index[e.id]=i end
        self.current.sort_mode='custom';self:touch();return true
    end
    function self:set_order(mode)
        assert(mode=='name'or mode=='amount'or mode=='custom','Invalid bank sort')
        if self.current and self.current.sort_mode~=mode then self.current.sort_mode=mode;self:touch()end
    end
    function self:set_amount(index,amount)
        assert(integer(index,1,5)and(amount==nil or integer(amount,1,2147483647)),'Invalid saved quantity')
        local p=self.state.prefs
        if p.amount_index~=index or p.custom_amount~=amount then p.amount_index=index;p.custom_amount=amount;self:touch()end
    end
    function self:release(id)
        if not self.current or self.present[id]then return nil,'Only empty placeholders can be released'end
        local at=self.index[id];if not at then return nil,'This placeholder changed'end
        table.remove(self.current.entries,at);self.index={}
        self.by_definition={}
        for i,e in ipairs(self.current.entries)do self.index[e.id]=i;self.by_definition[e.definition]=self.by_definition[e.definition]or e end
        self:touch();return true
    end
    function self:set_placeholders(enabled)
        assert(type(enabled)=='boolean');if self.state.prefs.placeholders~=enabled then self.state.prefs.placeholders=enabled;self:touch()end
    end
    function self:sort(mode)
        if not self.current then return end
        table.sort(self.current.entries,function(a,b)
            if mode=='amount'then local x=self.present[a.id];local y=self.present[b.id];local ax,by=x and x.total or 0,y and y.total or 0
                if ax~=by then return ax>by end
            end
            if a.name~=b.name then return a.name<b.name end;return a.id<b.id
        end)
        self.index={};for i,e in ipairs(self.current.entries)do self.index[e.id]=i end
        self.current.sort_mode=mode;self:touch()
    end
    function self:remember(values)
        local p=self.state.prefs;local changed=false
        for _,key in ipairs({'amount_index','custom_amount'})do if p[key]~=values[key]then p[key]=values[key];changed=true end end
        if self.current then for _,key in ipairs({'selected_tab','category','sort_mode','page'})do
            if self.current[key]~=values[key]then self.current[key]=values[key];changed=changed or self.persistent end
        end end
        if changed then self:touch()end
    end
    function self:flush(force)
        if not self.store or not self.dirty then return true end
        if self.load_error then return nil,self.load_error end
        local now=os.time()
        if force and self.saving and self.saving_revision~=self.revision then self.saving=nil end
        if not self.saving then
            if not force and(now<(self.retry_at or 0)or now-(self.changed_at or 0)<2)then return true end
            local p=self.state.prefs
            local snapshot={prefs={amount_index=p.amount_index,custom_amount=p.custom_amount,placeholders=p.placeholders},scopes={}}
            for _,s in ipairs(self.state.scopes)do
                local copy={key=s.key,sort_mode=s.sort_mode,selected_tab=s.selected_tab,category=s.category,page=s.page,entries={}}
                -- Descriptors are replaced, never mutated; snapshot their ordering.
                for i,e in ipairs(s.entries)do copy.entries[i]=e end
                snapshot.scopes[#snapshot.scopes+1]=copy
            end
            self.saving_revision=self.revision
            self.saving=coroutine.create(function()return self.store:save(snapshot,function()coroutine.yield()end)end)
        end
        local start=os.clock()
        repeat
            local resumed,ok,why=coroutine.resume(self.saving)
            if not resumed or coroutine.status(self.saving)=='dead'then
                self.saving=nil
                if not resumed then why=ok;ok=nil end
                if ok then self.dirty=self.saving_revision~=self.revision;self.retry_at=nil;self.save_error=nil
                else self.retry_at=now+30;self.save_error=why end
                self.last_save_step_ms=(os.clock()-start)*1000
                return ok,why
            end
        until not force and os.clock()-start>=.002
        self.last_save_step_ms=(os.clock()-start)*1000
        return true
    end
    return self
end
function M.default_path()
    local base=os.getenv('LOCALAPPDATA');return base and(base:gsub('\\','/')..'/RSDragonwilds/Saved/Stashlink-bank-memory')or nil
end
return M
