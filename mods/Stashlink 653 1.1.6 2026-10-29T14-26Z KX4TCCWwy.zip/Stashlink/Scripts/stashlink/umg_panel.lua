-- Transient UMG tree; no HUD draw hook and no saved mod actor.
-- Construction approach informed by Matthew Arvidson's MIT-licensed ue4ss-ModMenu.
local V=require("stashlink.view")
local Helpers=require("UEHelpers")
local M={root=nil,rows={},serial=0,updates=0}
local function valid(o) return o and o:IsValid() end
local background={R=0.025,G=0.035,B=0.045,A=0.98}
local selected={R=0.08,G=0.24,B=0.22,A=1}
local gold={R=1,G=0.77,B=0.36,A=1}
local light={R=0.92,G=0.94,B=0.92,A=1}
local muted={R=0.57,G=0.66,B=0.67,A=1}
local function construct(path,outer,name)
    local class=StaticFindObject(path)
    assert(valid(class),"UMG class unavailable: "..path)
    local object=StaticConstructObject(class,outer,FName(name),0x40)
    assert(valid(object),"UMG construction failed: "..path)
    return object
end
local function set_text(widget,text)
    text=tostring(text)
    if widget.text~=text then widget.object:SetText(FText(text)); widget.text=text end
end
function M.create()
    if valid(M.root) then return end
    local pc=Helpers.GetPlayerController()
    assert(valid(pc),"No player controller for Stashlink panel")
    M.serial=M.serial+1
    local suffix=tostring(os.time()).."_"..M.serial.."_"..tostring(M):gsub("[^%w]","")
    local root=construct("/Script/UMG.UserWidget",pc,"Stashlink_Root_"..suffix)
    M.root=root
    local tree=construct("/Script/UMG.WidgetTree",root,"Stashlink_Tree_"..suffix)
    root.WidgetTree=tree
    local canvas=construct("/Script/UMG.CanvasPanel",tree,"Stashlink_Canvas_"..suffix)
    tree.RootWidget=canvas
    local border=construct("/Script/UMG.Border",tree,"Stashlink_Border_"..suffix)
    border:SetBrushColor(background)
    border:SetPadding({Left=24,Top=20,Right=24,Bottom=20})
    local slot=canvas:AddChildToCanvas(border)
    slot:SetAnchors({Minimum={X=0.13,Y=0.06},Maximum={X=0.87,Y=0.94}})
    slot:SetOffsets({Left=0,Top=0,Right=0,Bottom=0})
    local box=construct("/Script/UMG.VerticalBox",tree,"Stashlink_Content_"..suffix)
    border:SetContent(box)
    local function label(parent,name,size,color)
        local text=construct("/Script/UMG.TextBlock",tree,"Stashlink_"..name.."_"..suffix)
        text.Font.Size=size
        text:SetColorAndOpacity({SpecifiedColor=color,ColorUseRule=0})
        text:SetAutoWrapText(true)
        parent:AddChildToVerticalBox(text):SetPadding({Left=0,Top=2,Right=0,Bottom=3})
        return {object=text}
    end
    M.title=label(box,"Title",24,gold)
    M.subtitle=label(box,"Subtitle",14,muted)
    M.search=label(box,"Search",16,light)
    M.rows={}
    for i=1,14 do
        local rowborder=construct("/Script/UMG.Border",tree,"Stashlink_Row_"..i.."_"..suffix)
        rowborder:SetPadding({Left=10,Top=2,Right=10,Bottom=2})
        box:AddChildToVerticalBox(rowborder)
        local rowbox=construct("/Script/UMG.HorizontalBox",tree,"Stashlink_RowBox_"..i.."_"..suffix)
        rowborder:SetContent(rowbox)
        local name=construct("/Script/UMG.TextBlock",tree,"Stashlink_Item_"..i.."_"..suffix)
        local count=construct("/Script/UMG.TextBlock",tree,"Stashlink_Count_"..i.."_"..suffix)
        name.Font.Size=16; count.Font.Size=16
        name:SetColorAndOpacity({SpecifiedColor=light,ColorUseRule=0})
        count:SetColorAndOpacity({SpecifiedColor=light,ColorUseRule=0})
        rowbox:AddChildToHorizontalBox(name):SetSize({SizeRule=1,Value=1})
        rowbox:AddChildToHorizontalBox(count)
        M.rows[i]={border=rowborder,name={object=name},count={object=count}}
    end
    M.amount=label(box,"Amount",17,gold)
    M.status=label(box,"Status",13,muted)
    M.controls=label(box,"Controls",14,light)
    root:AddToViewport(10000)
    root:SetVisibility(1)
end
function M.render()
    if not V.open then return end
    assert(valid(M.root),"Stashlink widget is no longer available")
    M.updates=M.updates+1
    local snapshot=V.snapshot
    set_text(M.title,"STASHLINK")
    set_text(M.subtitle,(V.mode=="stored" and "STORAGE > BACKPACK" or "BACKPACK > STORAGE").."    |    "..snapshot.containers.." linked containers    |    "..snapshot.occupied.." / "..snapshot.capacity.." slots")
    set_text(M.search,"Search: "..(V.query=="" and "all items" or V.query)..(V.entry=="search" and "_" or ""))
    local rows=V.rows()
    local first=math.floor(math.max(0,V.selection-1)/14)*14+1
    for i,control in ipairs(M.rows) do
        local index=first+i-1
        local row=rows[index]
        control.border:SetBrushColor(index==V.selection and selected or background)
        set_text(control.name,row and ((index==V.selection and "> " or "   ")..row.name) or " ")
        set_text(control.count,row and (row.total..(not row.writable and "  [read only]" or row.available<row.total and "  [protected]" or "")) or "")
    end
    local row=V.selected()
    set_text(M.amount,V.entry=="amount" and ("Enter quantity: "..(V.amount_text or "").."_") or row and ("Amount: "..V.amount(row).."   "..row.name) or "Select an item")
    set_text(M.status,V.status)
    set_text(M.controls,"Arrows: select / amount   Enter: transfer   F7: switch panel\nF8: search   F4: custom quantity   F9 twice: deposit matching   F6 / Esc: close")
end
function M.show()
    M.create()
    assert(valid(M.root),"Stashlink panel unavailable")
    M.root:SetVisibility(0)
    V.open=true
    M.render()
end
function M.hide()
    V.open=false
    if valid(M.root) then M.root:SetVisibility(1) end
end
function M.destroy()
    V.open=false
    if valid(M.root) then M.root:RemoveFromParent() end
    M.root=nil; M.rows={}
end
return M
