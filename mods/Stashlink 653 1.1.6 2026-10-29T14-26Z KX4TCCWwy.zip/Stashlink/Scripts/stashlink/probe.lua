local M = {}
local terms = {"inventory", "storage", "ledger", "container", "itemstack", "iteminstance", "spud", "savegame", "playerstate"}

local function relevant(name)
    name = name:lower()
    for _, term in ipairs(terms) do
        if name:find(term, 1, true) then return true end
    end
    return false
end

function M.run(path)
    local output, err = io.open(path, "w")
    if not output then error("Cannot open discovery report: " .. tostring(err)) end
    local classes, objects, errors = 0, 0, 0
    local function line(text) output:write(text, "\n") end
    local function metadata(struct)
        struct:ForEachProperty(function(property)
            line("  PROPERTY " .. property:GetFullName())
        end)
        struct:ForEachFunction(function(fn)
            line("  FUNCTION " .. fn:GetFullName())
            fn:ForEachProperty(function(property)
                line("    PARAM " .. property:GetFullName())
            end)
        end)
    end
    local ok, failure = pcall(function()
        line("Stashlink read-only reflection discovery")
        line("Generated " .. os.date("!%Y-%m-%dT%H:%M:%SZ"))
        line("This records loaded metadata, not verified transfer semantics or complete world stock.")
        ForEachUObject(function(object)
            local success, issue = pcall(function()
                if not object:IsValid() then return end
                local name = object:GetFullName()
                if not relevant(name) then return end
                if object:IsAnyClass() then
                    classes = classes + 1
                    line("CLASS " .. name)
                    local super = object:GetSuperStruct()
                    if super and super:IsValid() then line("  SUPER " .. super:GetFullName()) end
                    metadata(object)
                elseif name:match("^ScriptStruct ") then
                    line("STRUCT " .. name)
                    object:ForEachProperty(function(property)
                        line("  PROPERTY " .. property:GetFullName())
                    end)
                elseif not name:match("^Function ") and objects < 1500 then
                    objects = objects + 1
                    line("OBJECT " .. name)
                end
            end)
            if not success then
                errors = errors + 1
                if errors <= 20 then line("ERROR " .. tostring(issue)) end
            end
        end)
        line(string.format("END classes=%d objects=%d errors=%d", classes, objects, errors))
    end)
    output:close()
    if not ok then error(failure) end
    return string.format("Discovery complete: %d classes, %d objects, %d errors. Report: %s", classes, objects, errors, path)
end

return M
