-- Chest layout using the game's own panel, slot, tab, weight and keycap assets.
local M={}
local Equipment=require('stashlink.equipment_slots')
local function valid(o) return o and o:IsValid() end
function M.create(P,V)
 P.page_size=64;P.controls={};P.styled_controls={};P.icon_cache={};P.icon_queue={};P.icon_loading={};P.icons_pending=0;P.icon_total=0;P.native_panels={}
 -- Native snapshot pages are available before layout creation. Retain the
 -- legacy three rows when Items fits 24; current 32-slot categories use four.
 local primary=V.snapshot and V.snapshot.pages and V.snapshot.pages[1]
 local bag_rows=primary and primary.count<=24 and 3 or 4
 local row_extra=(bag_rows-3)*69
 -- The pager has its own row; leave the weight meter below its 30px buttons.
 local extra=row_extra+(bag_rows>3 and 32 or 0)
 local pager_extra=row_extra+(bag_rows>3 and 7 or 0)
 P.drawer_bounds={x=28,y=628+extra,w=613,h=230}
 P.panel_bounds={held={28,57,613,420+extra},armour={28,470+extra,613,150},stored={692,57,672,782}}
 -- A rebuilt widget starts from a fresh scroll window and content height.
 P.content_rows=nil;P.window_first=nil;P.scroll_offset=0;P.bank_row=0;P.reveal_selection=false
 P.serial=P.serial+1; P.pc=P.adapter:context().pc
 P.layout_lib=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary')
 P.time_lib=StaticFindObject('/Script/Engine.Default__GameplayStatics');P.mouse_key={KeyName=FName('LeftMouseButton')}
 local classes,assets,origins,frames,content_for,static_for={},{},{},{},{},{};local n=0
 local suffix=os.time()..'_'..P.serial..'_'..tostring(P):gsub('[^%w]','')
 local function make(kind,outer)
  n=n+1;local cls=classes[kind];if not cls then cls=StaticFindObject('/Script/UMG.'..kind);classes[kind]=cls end
  local o=StaticConstructObject(cls,outer,FName('Stashlink_'..suffix..'_'..n),0x40);assert(valid(o),'Could not create '..kind);return o
 end
 local function asset(path)
  if assets[path] then return assets[path] end
  local o=StaticFindObject(path);if not valid(o) then o=LoadAsset(path) end
  assert(valid(o),'Missing game UI asset '..path);assets[path]=o;return o
 end
 local function tex(name) return asset('/Game/Art/UI/Inventory/'..name..'.'..name) end
 local white={R=.86,G=.85,B=.8,A=1};local clear={R=0,G=0,B=0,A=0}
 local amiri=asset('/Game/UI/Fonts/Amiri-Regular_Font.Amiri-Regular_Font')
 local poppins=asset('/Game/UI/Fonts/Poppins-Regular_Font.Poppins-Regular_Font')
 local panelmat=asset('/Game/Art/UI/ShaderWork/MI_Menu_PanelBG_Shared.MI_Menu_PanelBG_Shared')
 local slotmat=asset('/Game/Materials/UI/MI_Item_Selected.MI_Item_Selected')
 local slot_background=asset('/Game/Art/UI/Common/T_Common_ItemSlotsBackground.T_Common_ItemSlotsBackground')
 local keytex=asset('/Game/Art/UI/Inputs/Keyboard/T_Keys-Special-Blank.T_Keys-Special-Blank')
 local underline=asset('/Game/Materials/UI/UI_Library_MM/MI_Menu_Underline.MI_Menu_Underline')
 P.params={icon=FName('Item Image'),selected=FName('Selection Opacity'),icon_opacity=FName('Icon Opacity'),background=FName('Background Opacity'),background_texture=FName('Background Image'),background_texture_opacity=FName('Background Texture Opacity')}
 P.root=make('UserWidget',P.pc);local tree=make('WidgetTree',P.root);P.root.WidgetTree=tree
 local root_canvas=make('CanvasPanel',tree);tree.RootWidget=root_canvas
 local canvas=make('CanvasPanel',tree);local content_slot=root_canvas:AddChildToCanvas(canvas)
 content_slot:SetAnchors({Minimum={X=0,Y=0},Maximum={X=1,Y=1}});content_slot:SetOffsets({Left=0,Top=0,Right=0,Bottom=0})
 canvas:SetRenderTransformPivot({X=0,Y=0});P.tree=tree;P.make=make;P.content_scale=1;P.controller_canvas=canvas
 P.fit_viewport=function()
  local size=P.layout_lib:GetViewportSize(P.pc);local dpi=P.layout_lib:GetViewportScale(P.pc)
  local height=P.extras_open and math.max(848,P.drawer_bounds.y+P.drawer_bounds.h+24)or 848
  local factor=math.min(1,(size.X/dpi-24)/1384,(size.Y/dpi-56)/height)
  factor=math.max(.25,factor)
  if math.abs(factor-P.content_scale)>.001 then canvas:SetRenderScale({X=factor,Y=factor});P.content_scale=factor end
 end
 local function place(parent,w,x,y,width,height)
  local host=content_for[parent:GetAddress()] or parent
  local s=host:AddChildToCanvas(w);s:SetOffsets({Left=x,Top=y,Right=width,Bottom=height});return s
 end
 local function image(parent,texture,x,y,w,h)
  local o=make('Image',tree);o:SetBrushFromTexture(texture,false);o:SetVisibility(3);local s=place(parent,o,x,y,w,h);return o,s
 end
 local function label(parent,value,x,y,w,h,size,serif,spacing)
  local o=make('TextBlock',tree);o.Font.FontObject=serif and amiri or poppins;o.Font.Size=size or 11;o.Font.LetterSpacing=spacing or 0
  o:SetColorAndOpacity({SpecifiedColor=white,ColorUseRule=0});o:SetText(FText(value or ''));o:SetVisibility(3)
  place(parent,o,x,y,w,h);return {object=o,value=tostring(value or '')}
 end
 local function native_bar(parent,x,y,w,h)
  local bar=make('ProgressBar',tree)
  for _,spec in ipairs({{'BackgroundImage','T_Inventory_WeightBarBackground',32},{'FillImage','T_Inventory_WeightBarFill',18}}) do
   local brush=bar.WidgetStyle[spec[1]];brush.ResourceObject=tex(spec[2]);brush.DrawAs=1
   brush.ImageSize.X=spec[3];brush.ImageSize.Y=spec[3]
   brush.Margin.Left=.5;brush.Margin.Top=.5;brush.Margin.Right=.5;brush.Margin.Bottom=.5
  end
  bar:SetFillColorAndOpacity({R=1,G=1,B=1,A=1});bar:SetVisibility(3)
  return bar,place(parent,bar,x,y,w,h)
 end
 local function frame(x,y,w,h,drawer)
  local c=make('CanvasPanel',tree);place(canvas,c,x,y,w,h);origins[c:GetAddress()]={x=x,y=y}
  local native=require('stashlink.native_panels').create(P,{asset=asset,place=place},c,w,h,h<200)
  local content=make('CanvasPanel',tree);place(c,content,0,0,w,h)
  content:SetVisibility(4);content:SetRenderOpacity(0)
  local pivot=native.widget.BackgroundPanel.RenderTransformPivot
  content:SetRenderTransformPivot({X=pivot.X,Y=pivot.Y})
  if y==57 then
   local persistent=make('CanvasPanel',tree);place(c,persistent,0,0,w,h)
   persistent:SetVisibility(4);static_for[c:GetAddress()]=persistent
  end
  content_for[c:GetAddress()]=content
  native.content=content;native.drawer=drawer or false
  frames[#frames+1]={parent=c,width=w,height=h,drawer=drawer or false,native=native}
  return c
 end
 local function popup_background(parent,w,h)
  local native=require('stashlink.native_panels').create(P,{asset=asset,place=place},parent,w,h,true)
  return function()
   native.widget:SetVisibility(4);native.widget:SetPanelVisibility(true)
  end
 end
 local function button(parent,x,y,w,h,action,data)
  local b=make('Button',tree);local style=b.WidgetStyle
  for _,key in ipairs({'Normal','Hovered','Pressed','Disabled'}) do style[key].DrawAs=0 end
  for _,pad in ipairs({style.NormalPadding,style.PressedPadding}) do pad.Left=0;pad.Top=0;pad.Right=0;pad.Bottom=0 end
  b:SetBackgroundColor(clear)
  local c=make('CanvasPanel',tree);local size=make('SizeBox',tree);size:SetWidthOverride(w);size:SetHeightOverride(h);size:SetContent(c)
  local slot=b:SetContent(size);slot:SetPadding({Left=0,Top=0,Right=0,Bottom=0});slot:SetHorizontalAlignment(0);slot:SetVerticalAlignment(0)
  b.IsFocusable=true
  local origin=origins[parent:GetAddress()] or {x=0,y=0}
  place(parent,b,x,y,w,h);local control={object=b,size=size,action=action,data=data,canvas=c,id=n,drawer=parent==P.extras,
   bounds={x=origin.x+x,y=origin.y+y,w=w,h=h}}
  P.controls[#P.controls+1]=control;return control,c
 end
 local function keybutton(parent,key,caption,x,y,w,action,data,letter_spacing)
  local control,c=button(parent,x,y,w,34,action,data);local kw=key=='SPACE' and 43 or 30
  local flipped=key=='V' or key=='ESC';local kx=flipped and w-kw or 0
  local glyph_y=key=='R' and 2 or key=='F' and 1 or key=='SPACE' and 6 or 5
  local glyph_x=kx+(key=='F' and 1 or 0)
  control.key_image=image(c,keytex,kx,0,kw,32);local kl=label(c,key,glyph_x,glyph_y,kw,24,(key=='SPACE' or key=='ESC') and 8 or 13,false);kl.object:SetJustification(1)
  control.key_label=kl;control.keyboard_key=key
  control.label=label(c,caption,flipped and 0 or kw+10,4,w-kw-10,28,12,false,letter_spacing or 120);return control
 end
 local function tiny(parent,caption,x,y,w,action,data,boxed)
  local b,c=button(parent,x,y,w,30,action,data)
  b.outline=make('Border',tree);b.outline:SetBrushColor(boxed and {R=.38,G=.33,B=.23,A=1} or {R=.19,G=.14,B=.08,A=.8});place(c,b.outline,0,0,w,30)
  b.face=make('Border',tree);b.face:SetBrushColor(boxed and {R=.055,G=.05,B=.04,A=.95} or {R=.024,G=.022,B=.019,A=.9});place(c,b.face,1,1,w-2,28)
  local glyph_size=(caption=='<' or caption=='>' or caption=='×') and 15 or 12
  b.label=label(c,caption,0,2,w,28,glyph_size,false);b.label.object:SetJustification(1)
  if action=='transfer'or action=='bank_save'then b.label.object.Font.FontObject=amiri;b.label.object.Font.Size=13;b.label.object.Font.LetterSpacing=110 end
  if action=='amount'then b.label.object.Font.Size=11 end
  require('stashlink.ui_skin').decorate(P,b,{make=make,tree=tree,place=place,image=image,grain=slot_background,underline=underline})
  return b
 end
 local function input(parent,x,y,w,value)
  local outline=make('Border',tree);outline:SetBrushColor({R=.10,G=.075,B=.035,A=1});place(parent,outline,x,y,w,34)
  local b=make('Border',tree);b:SetBrushColor({R=.002,G=.003,B=.003,A=.97});b:SetPadding({Left=7,Top=3,Right=7,Bottom=3})
  local e=make('EditableTextBox',tree);local style=e.WidgetStyle
  style.TextStyle.Font.FontObject=poppins;style.TextStyle.Font.Size=11
  for _,key in ipairs({'BackgroundImageNormal','BackgroundImageHovered','BackgroundImageFocused','BackgroundImageReadOnly'}) do style[key].DrawAs=0 end
  e:SetForegroundColor(white);e:SetText(FText(value));b:SetContent(e);place(parent,b,x+1,y+1,w-2,32);return e
 end
 local function grid(parent,rows,columns,pane,x,y,pitch,row_pitch)
  local cells={}
  local width,height=60,pane=='held'and 66 or 60
  local item_offset=(pane=='held' or pane=='stored') and -7 or 0
  local host=pane=='hotbar' and static_for[parent:GetAddress()] or parent
  for i=1,rows*columns do
   local control,c=button(host,x+((i-1)%columns)*pitch,y+math.floor((i-1)/columns)*(row_pitch or 69),width,height,nil,nil)
   local equipment_spec=pane=='armour'and P.equipment_specs and P.equipment_specs[i]
   if equipment_spec and(equipment_spec.name=='Trinket'or equipment_spec.name=='Necklace')then
    local placeholder=image(c,tex(equipment_spec.name=='Necklace'and'T_Inventory_EquipmentRing'or'T_Inventory_EquipmentTrinket'),0,0,52,52);placeholder:SetColorAndOpacity({R=.5,G=.5,B=.5,A=.35})
   end
   local icon=make('Image',tree);icon:SetBrushFromMaterial(slotmat);icon:SetVisibility(4)
   place(c,icon,0,item_offset<0 and -1 or 0,width,60)
   local mat=icon:GetDynamicMaterial();assert(valid(mat),'Native slot material unavailable')
   mat:SetScalarParameterValue(P.params.icon_opacity,0);mat:SetScalarParameterValue(P.params.selected,0)
   mat:SetTextureParameterValue(P.params.background_texture,slot_background)
   mat:SetScalarParameterValue(P.params.background_texture_opacity,1)
   mat:SetScalarParameterValue(FName('Controller on/off'),0);mat:SetScalarParameterValue(P.params.background,.28)
   local ascension_icon=make('Image',tree);ascension_icon:SetVisibility(1);place(c,ascension_icon,20,0,20,20)
   local count=label(c,'',width-5,height-.5+(item_offset<0 and -3 or 0),0,0,10,true);count.object:SetJustification(2);count.object.Slot:SetAutoSize(true);count.object.Slot:SetAlignment({X=1,Y=1})
   local equipped_icon=image(c,tex('T_QuickAccess_Overlay'),3,3,width-6,height-6);equipped_icon:SetColorAndOpacity({R=.397569,G=.122308,B=.014289,A=1});equipped_icon:SetVisibility(1)
   local badge=make('Image',tree);badge:SetVisibility(1);place(c,badge,44,-9,25,25)
   local meter_bg=make('Border',tree);meter_bg:SetBrushColor({R=0,G=0,B=0,A=1});meter_bg:SetVisibility(1);place(c,meter_bg,0,50,52,2)
   local fill_bg=image(c,asset('/Game/Art/UI/Farming/T_Bar_Fill_Bg.T_Bar_Fill_Bg'),-8.3,height-10+item_offset,72.3,10);fill_bg:SetVisibility(1)
   local dura=make('Border',tree);dura:SetBrushColor({R=.462077,G=.396755,B=.287441,A=1});dura:SetVisibility(1);local ds=place(c,dura,0,50,52,2)
   local fill_gradient=image(c,asset('/Game/Art/UI/Farming/T_Container_FillBarGradient.T_Container_FillBarGradient'),4,height-6+item_offset,52,2);fill_gradient:SetVisibility(1)
   local content_badge=make('Image',tree);content_badge:SetVisibility(1);place(c,content_badge,38,6,14,19)
   if pane=='hotbar' then label(c,tostring(i),7,4,15,29,12,true) end
   control.cell_width=width;control.cell_height=height
   control.image=icon;control.material=mat;control.ascension_icon=ascension_icon;control.count=count;control.badge=badge;control.durability=dura;control.durability_slot=ds;control.meter_background=meter_bg
   control.equipped_icon=equipped_icon;control.fill_background=fill_bg;control.fill_gradient=fill_gradient;control.content_badge=content_badge
   local origin=origins[parent:GetAddress()]
   control.bounds={x=origin.x+x+((i-1)%columns)*pitch,y=origin.y+y+math.floor((i-1)/columns)*(row_pitch or 69),w=width,h=height}
   control.pane=pane;control.item_offset=item_offset;control.index=i;control.slot=i-1;cells[i]=control
   if equipment_spec then control.nativeequipment_slot=equipment_spec.slot;control.equipment_name=equipment_spec.name end
  end
  return cells
 end
 P.icon_host=make('VerticalBox',tree);place(canvas,P.icon_host,0,0,1,1);P.icon_host:SetVisibility(1)
 local left=frame(28,57,613,420+extra);P.left_frame=left
 P.hotbar=grid(left,1,8,'hotbar',37.2,34.7,68.5375)
 image(left,asset('/Game/Art/UI/Building/T_Build_FinishPattern_L.T_Build_FinishPattern_L'),50.7,108.2,200,30)
 image(left,asset('/Game/Art/UI/Building/T_Build_FinishPattern_R.T_Build_FinishPattern_R'),363,108.2,200,30)
 image(left,asset('/Game/Art/UI/Building/T_Build_Finish_Left.T_Build_Finish_Left'),60.7,114.7,85,17)
 image(left,asset('/Game/Art/UI/Building/T_Build_Finish_Right.T_Build_Finish_Right'),468,114.7,85,17)
 image(left,tex('T_SubMenu_Inventory'),117.35,103.7,377,43)
 P.tab_buttons={}
 for i,name in ipairs({'Items','Runes','ArrowsBolts','Quests'}) do
  local b,c=button(left,189.85+(i-1)*56,110.2,64,32,'tab',i)
  b.normal=tex('T_Icon_'..name..'_Normal');b.highlight=tex('T_Icon_'..name..'_Highlight')
  b.icon=image(c,b.normal,0,0,64,32);b.object:SetToolTipText(FText(({'Items','Runes','Ammunition','Quest'})[i]));P.tab_buttons[i]=b
 end
 P.backpack=grid(left,bag_rows,8,'held',37.2,155.7,68.6625)
 P.bag_prev=tiny(left,'<',420,354+pager_extra,24,'bag_previous');P.bag_next=tiny(left,'>',540,354+pager_extra,24,'bag_next')
 P.bag_page_label=label(left,'',450,358+pager_extra,80,22,10,false);P.bag_page_label.object:SetJustification(1)
 image(left,tex('T_Inventory_WeightIcon'),32.7,363.7+extra,40,40)
 P.weight=label(left,'',73.2,370.7+extra,96,27,11,true,200)
 local bar,bar_slot=native_bar(left,149.2,379.2+extra,424.8,12)
 P.align_weight=function()
  P.weight.object:ForceLayoutPrepass();local width=P.weight.object:GetDesiredSize().X
  if width>0 then local x=73.2+width+10;bar_slot:SetOffsets({Left=x,Top=379.2+extra,Right=574-x,Bottom=12})end
 end
 P.weight_bar=bar
 -- Compatibility with the currently loaded renderer during this UI-only update.
 P.weight_fill_slot={SetSize=function(_,size) bar:SetPercent(math.max(0,math.min(1,size.X/430))) end}
 local armour=frame(28,470+extra,613,150)
 label(armour,'ARMOUR',39.7,40.7,130,29,12,true,200)
 P.equipment_specs=V.snapshot and V.snapshot.equipment_slots or Equipment.specs()
 P.equipment_key=Equipment.key(P.equipment_specs)
 local equipment_layout=Equipment.layout(P.equipment_specs)
 P.armour=grid(armour,1,equipment_layout.count,'armour',equipment_layout.x,equipment_layout.y,equipment_layout.pitch)
 local sort=keybutton(armour,'V','Sort',equipment_layout.sort_x,equipment_layout.sort_y,88,'bag_sort',nil,200)
 sort.label.object.Slot:SetOffsets({Left=6,Top=3,Right=48,Bottom=28})
 P.refresh_equipment=function(specs)
  if not specs or P.equipment_key==Equipment.key(specs)then return end
  local old={};for _,control in ipairs(P.armour)do
   old[control]=true;control.invalid_cell=true;control.clipped=true;control.row=nil;control.definition=nil
   control.object:RemoveFromParent()
  end
  for i=#P.controls,1,-1 do if old[P.controls[i]]then table.remove(P.controls,i)end end
  P.equipment_specs=specs;P.equipment_key=Equipment.key(specs)
  local layout=Equipment.layout(specs)
  P.armour=grid(armour,1,layout.count,'armour',layout.x,layout.y,layout.pitch)
  sort.object.Slot:SetOffsets({Left=layout.sort_x,Top=layout.sort_y,Right=88,Bottom=34})
  sort.bounds.y=470+extra+layout.sort_y
 end
 image(armour,asset('/Game/Art/UI/PowerLevel/T_PowerLevel_AboveZone.T_PowerLevel_AboveZone'),516.9625,71.7,60,60)
 P.power=label(armour,'',546.9625,101.7,0,0,16,false);P.power.object.Slot:SetAutoSize(true);P.power.object.Slot:SetAlignment({X=.5,Y=.5});P.power.object:SetJustification(1);P.power.object:SetColorAndOpacity({SpecifiedColor={R=0,G=0,B=0,A=1},ColorUseRule=0})
 local bank_frame=frame(692,57,672,782);P.bank_frame=bank_frame
 -- Frame-local geometry of the storage panel. Slot pitch matches the native chest and backpack.
 local L={tab_x=54,tab_y=4,tab_w=52,tab_h=50,tab_pitch=55,rail_x=24,rail_y=60,rail_w=40,rail_h=46,rail_pitch=54.5,
  grid_x=74,grid_y=58,cols=8,rows=8,pitch_x=68.66,pitch_y=69,cell=60,pad=3,bar=15,capacity_y=612,row_y=638,footer_y=676}
 L.grid_w=(L.cols-1)*L.pitch_x+L.cell+L.bar;L.grid_h=L.pad*2+(L.rows-1)*L.pitch_y+L.cell
 L.origin={x=692,y=101};P.bank_layout=L;P.visible_rows=L.rows;P.page_size=L.rows*L.cols
 image(bank_frame,tex('T_ToolTips_Title'),24,10,624,40)
 local heading=label(bank_frame,'STASHLINK',116,15,440,28,17,true,240);heading.object:SetJustification(1)
 heading.object:SetTextOverflowPolicy(1)
 heading.object:SetColorAndOpacity({SpecifiedColor={R=.85,G=.69,B=.38,A=1},ColorUseRule=0});P.bank_title=heading
 P.bank_linked=label(bank_frame,'',560,19,72,22,10,false);P.bank_linked.object:SetJustification(2)
 P.bank_linked.object:SetColorAndOpacity({SpecifiedColor={R=.6,G=.58,B=.52,A=1},ColorUseRule=0});P.bank_linked.object:SetVisibility(0)
 P.options_button=tiny(bank_frame,'Options',32,15,80,'extras',nil,true)
 P.options_button.object:SetToolTipText(FText('Open Stashlink options and ledger key settings'))
 local right=make('CanvasPanel',tree);place(bank_frame,right,0,44,672,738);right:SetVisibility(4)
 origins[right:GetAddress()]={x=L.origin.x,y=L.origin.y};P.right_frame=right
 -- A native ScrollBox owns the mouse wheel and scrollbar. Ten rows of cells (one
 -- spare above and below the view) follow its offset; items are rebound, never moved.
 local scroll=make('ScrollBox',tree);place(right,scroll,L.grid_x,L.grid_y,L.grid_w,L.grid_h)
 local function try(fn) pcall(fn) end
 try(function() scroll:SetConsumeMouseWheel(1) end)
 try(function() scroll:SetAllowOverscroll(false) end)
 try(function() scroll:SetAnimateWheelScrolling(false) end)
 -- Slate scrolls 32 units per notch; scale that to exactly one slot row.
 try(function() scroll:SetWheelScrollMultiplier(L.pitch_y/32) end)
 try(function() scroll:SetAlwaysShowScrollbar(true) end)
 try(function() scroll:SetScrollbarThickness({X=6,Y=6}) end)
 try(function() scroll:SetScrollbarPadding({Left=9,Top=2,Right=0,Bottom=2}) end)
 -- Right-click stays the native use/manage gesture, never a drag-scroll.
 try(function() scroll:SetAllowRightClickDragScrolling(false) end)
 try(function() scroll.AllowRightClickDragScrolling=false end)
 -- The native chest has no scroll-edge shadows.
 try(function()
  local style=scroll.WidgetStyle
  for _,key in ipairs({'TopShadowBrush','BottomShadowBrush','LeftShadowBrush','RightShadowBrush'}) do style[key].DrawAs=0 end
 end)
 local function tint(brush,c)
  local t=brush.TintColor;t.SpecifiedColor.R=c[1];t.SpecifiedColor.G=c[2];t.SpecifiedColor.B=c[3];t.SpecifiedColor.A=c[4];t.ColorUseRule=0
 end
 try(function()
  local bar=scroll.WidgetBarStyle
  tint(bar.NormalThumbImage,{.34,.25,.10,.95});tint(bar.HoveredThumbImage,{.58,.43,.19,1});tint(bar.DraggedThumbImage,{.85,.66,.32,1})
  tint(bar.VerticalBackgroundImage,{.02,.018,.012,.75})
 end)
 local sizer=make('SizeBox',tree);sizer:SetHeightOverride(L.grid_h);scroll:AddChild(sizer)
 local grid_content=make('CanvasPanel',tree);sizer:SetContent(grid_content)
 local window=make('CanvasPanel',tree);local window_slot=grid_content:AddChildToCanvas(window)
 window_slot:SetOffsets({Left=0,Top=L.pad,Right=(L.cols-1)*L.pitch_x+L.cell,Bottom=(L.rows+2)*L.pitch_y})
 origins[window:GetAddress()]={x=L.origin.x+L.grid_x,y=L.origin.y+L.grid_y+L.pad}
 P.bank_scroll=scroll;P.bank_sizer=sizer;P.bank_window_slot=window_slot
 P.stored=grid(window,L.rows+2,L.cols,'stored',0,0,L.pitch_x,L.pitch_y)
 P.bank_grid_bounds={x=L.origin.x+L.grid_x,y=L.origin.y+L.grid_y,w=L.grid_w,h=L.grid_h}
 P.empty_message=label(right,'',L.grid_x,250,L.grid_w-L.bar,72,14,false);P.empty_message.object:SetJustification(1);P.empty_message.object:SetVisibility(1)
 -- Physical chest capacity stays visible while browsing any tab or search.
 -- Use the existing snapshot counts; placeholders and aggregate rows are not slots.
 P.bank_capacity=label(right,'',24,L.capacity_y,258,22,11,false)
 P.bank_capacity_bar=native_bar(right,292,L.capacity_y+7,220,10)
 P.bank_free=label(right,'',520,L.capacity_y,112,22,11,false);P.bank_free.object:SetJustification(2)
 P.bank_capacity_fraction=nil
 local divider=make('Border',tree);divider:SetBrushColor({R=.16,G=.11,B=.045,A=.44});place(right,divider,24,L.row_y-4,608,1)
 P.search=input(right,24,L.row_y,232,V.query)
 P.search:SetHintText(FText('Search linked chests'))
 P.search:SetToolTipText(FText('Filter items across every linked chest'))
 P.clear_search=tiny(right,'×',260,L.row_y+2,30,'clear_search')
 P.clear_search.object:SetToolTipText(FText('Clear search'))
 -- Always-visible amount: double-click, Enter and Withdraw use it.
 local amount_label=label(right,'Amount',298,L.row_y+7,54,22,10,false)
 amount_label.object:SetColorAndOpacity({SpecifiedColor={R=.6,G=.58,B=.52,A=1},ColorUseRule=0})
 P.quick_amounts={};local qx=354
 for _,preset in ipairs({{'1',1,34},{'10',2,38},{'Half',5,46},{'Stack',3,50},{'All',4,36},{'X',nil,36}}) do
  local c=tiny(right,preset[1],qx,L.row_y+2,preset[3],preset[2] and 'amount' or 'amount_custom',preset[2],true)
  c.quick_amount=true;P.quick_amounts[#P.quick_amounts+1]=c;qx=qx+preset[3]+4
  c.object:SetToolTipText(FText('Double-click, Enter and Withdraw move this amount'))
 end
 P.quick_amounts[#P.quick_amounts].object:SetToolTipText(FText('Type an exact amount'))
 local footer=make('Border',tree);footer:SetBrushColor({R=.003,G=.004,B=.004,A=.85});footer:SetVisibility(3);place(right,footer,20,L.footer_y,612,40)
 keybutton(right,'F','Fill Stacks',28,L.footer_y+3,150,'matching')
 P.sort_button=keybutton(right,'SPACE','Sort: A–Z',192,L.footer_y+3,190,'sort')
 -- Native-chest style checkbox, like its Linked and Private toggles.
 local toggle,tc=button(right,404,L.footer_y+3,212,34,'bank_placeholders')
 toggle.label=label(tc,'Placeholders',0,4,170,28,12,false,120)
 toggle.outline=make('Border',tree);toggle.outline:SetBrushColor({R=.38,G=.33,B=.23,A=1});place(tc,toggle.outline,180,5,24,24)
 toggle.face=make('Border',tree);toggle.face:SetBrushColor({R=.02,G=.02,B=.017,A=1});place(tc,toggle.face,181,6,22,22)
 toggle.fill=make('Border',tree);toggle.fill:SetBrushColor({R=.84,G=.66,B=.32,A=1});place(tc,toggle.fill,186,11,12,12);toggle.fill:SetVisibility(1)
 toggle.object:SetToolTipText(FText('Keep empty items as saved slots. Right-click a placeholder to release it.'))
 toggle.skin={update=function()
  local focused=P.controller_active and P.controller_focus==toggle;local lit=focused or toggle.object:IsHovered()
  local state=tostring(lit)..tostring(toggle.on)
  if toggle.skin_state==state then return end;toggle.skin_state=state
  toggle.outline:SetBrushColor(lit and {R=.84,G=.66,B=.32,A=1} or toggle.on and {R=.55,G=.43,B=.2,A=1} or {R=.38,G=.33,B=.23,A=1})
  toggle.label.object:SetColorAndOpacity({SpecifiedColor=lit and {R=1,G=.95,B=.79,A=1} or white,ColorUseRule=0})
 end}
 P.styled_controls[#P.styled_controls+1]=toggle;P.placeholders_toggle=toggle
 local drawer=P.drawer_bounds
 P.extras=frame(drawer.x,drawer.y,drawer.w,drawer.h,true);P.extras_content=content_for[P.extras:GetAddress()]
 P.extras:SetVisibility(1);P.extras_open=false
 P.animate_drawer=function() require('stashlink.native_panels').show_drawer(P) end
 P.subtitle=label(P.extras,'',28,149,557,14,8,false)
 P.subtitle.object:SetColorAndOpacity({SpecifiedColor={R=.48,G=.46,B=.38,A=1},ColorUseRule=0})
 P.quantity_preview=make('Image',tree);place(P.extras,P.quantity_preview,28,26,44,44);P.quantity_preview:SetVisibility(1)
 P.item_name=label(P.extras,'Select an item',86,27,334,28,16,true);P.item_name.object:SetTextOverflowPolicy(1)
 P.source_info=label(P.extras,'',86,58,330,20,10,false)
 local ledger_toggle,lc=button(P.extras,426,55,159,24,'ledger_swap')
 ledger_toggle.label=label(lc,'Swap F / E',0,0,130,24,11,false)
 ledger_toggle.outline=make('Border',tree);ledger_toggle.outline:SetBrushColor({R=.38,G=.33,B=.23,A=1});place(lc,ledger_toggle.outline,135,0,23,23)
 ledger_toggle.face=make('Border',tree);ledger_toggle.face:SetBrushColor({R=.02,G=.02,B=.017,A=1});place(lc,ledger_toggle.face,136,1,21,21)
 ledger_toggle.fill=make('Border',tree);ledger_toggle.fill:SetBrushColor({R=.84,G=.66,B=.32,A=1});place(lc,ledger_toggle.fill,141,6,11,11);ledger_toggle.fill:SetVisibility(1)
 ledger_toggle.object:SetToolTipText(FText('Storage Ledger only. On (new installs): E opens Stashlink, F deposits through the game. Off: F opens Stashlink, E deposits through the game. While Stashlink is open, F still fills stacks.'))
 ledger_toggle.skin={update=function()
  local focused=P.controller_active and P.controller_focus==ledger_toggle;local lit=focused or ledger_toggle.object:IsHovered()
  local state=tostring(lit)..tostring(ledger_toggle.on)
  if ledger_toggle.skin_state==state then return end;ledger_toggle.skin_state=state
  ledger_toggle.outline:SetBrushColor(lit and {R=.84,G=.66,B=.32,A=1} or ledger_toggle.on and {R=.55,G=.43,B=.2,A=1} or {R=.38,G=.33,B=.23,A=1})
  ledger_toggle.label.object:SetColorAndOpacity({SpecifiedColor=lit and {R=1,G=.95,B=.79,A=1} or white,ColorUseRule=0})
 end}
 P.styled_controls[#P.styled_controls+1]=ledger_toggle;P.ledger_key_toggle=ledger_toggle
 label(P.extras,'Opening key',28,176,103,24,10,false)
 P.ledger_open_input=input(P.extras,135,169,92,require('stashlink.ledger_key_preferences').key())
 P.ledger_open_value=require('stashlink.ledger_key_preferences').key()
 P.ledger_open_input:SetToolTipText(FText('Type one keyboard key, for example G or F9, then Apply. F6 only disables E/F opening. The Swap F / E checkbox restores the original layout.'))
 tiny(P.extras,'Apply',237,171,76,'ledger_key_apply',nil,true)
 tiny(P.extras,'F6 only',323,171,102,'ledger_key_none',nil,true)
 label(P.extras,'F6 always opens nearby',439,178,147,20,8,false)
 label(P.extras,'QUANTITY',28,80,105,18,9,false,80)
 P.transfer_help=label(P.extras,'',145,80,440,18,10,false)
 P.transfer_unavailable=nil;P.transfer_availability_set=false
 P.amount=input(P.extras,28,98,74,'1')
 P.amount_buttons={}
 for i,preset in ipairs({{'1',1},{'10',2},{'Half',5},{'Stack',3},{'All',4}}) do P.amount_buttons[i]=tiny(P.extras,preset[1],108+(i-1)*49,100,46,'amount',preset[2],true) end
 P.transfer_button=tiny(P.extras,'Withdraw',370,100,215,'transfer',nil,true)
 tiny(P.extras,'Refresh',430,24,72,'refresh',nil,true);tiny(P.extras,'Close',514,24,71,'close',nil,true)
 P.status=label(P.extras,'',28,133,557,20,9,false);P.status.object:SetAutoWrapText(false);P.status.object:SetTextOverflowPolicy(1)
 P.base_sync_inputs=P.base_sync_inputs or P.sync_inputs
 P.sync_inputs=function(commit)
  local row=V.selected()
  local preset=commit and row and V.custom_amount==nil and tonumber(P.amount:GetText():ToString())==V.amount(row)
  P.base_sync_inputs(commit)
  if P.ledger_open_input:HasKeyboardFocus()then V.entry='native_ledger_key';P.ledger_key_quarantine_until=os.clock()+.5
  elseif V.entry=='native_ledger_key'then V.entry=nil end
  if preset then V.custom_amount=nil end
  if commit and V.remember_amount then V.remember_amount()end
 end
 P.refresh_quantity_ui=function()
  local preferences=require('stashlink.ledger_key_preferences')
  local current_key=preferences.key()
  if P.ledger_open_value~=current_key and not P.ledger_open_input:HasKeyboardFocus()then
   P.ledger_open_input:SetText(FText(current_key));P.ledger_open_value=current_key
  end
  local swapped=preferences.enabled()
  if ledger_toggle.on~=swapped then
   ledger_toggle.on=swapped;ledger_toggle.selected=swapped;ledger_toggle.fill:SetVisibility(swapped and 3 or 1);ledger_toggle.skin:update()
  end
  local row=V.selected();local enabled=row and row.writable and row.available>0 or false
  local cached=row and P.icon_cache[row.definition]
  if cached and valid(cached.texture)and not(P.controller_ui and P.controller_ui.keyboard_open)then P.quantity_preview:SetBrushFromTexture(cached.texture,false);P.quantity_preview:SetVisibility(3)else P.quantity_preview:SetVisibility(1)end
  local typed=nil
  if P.amount:HasKeyboardFocus() then typed=tonumber(P.amount:GetText():ToString()) or false end
  -- The amount is a saved preference, so it stays editable without a selection.
  require('stashlink.transfer_controls').update(P,V);P.amount:SetIsReadOnly(false)
  local function mark(b,selected)
   if b.selected~=selected then
    b.selected=selected
    if b.skin then b.skin:update()
    else b.outline:SetBrushColor(selected and {R=.84,G=.66,B=.32,A=1} or {R=.38,G=.33,B=.23,A=1});b.face:SetBrushColor(selected and {R=.25,G=.19,B=.09,A=.95} or {R=.055,G=.05,B=.04,A=.95})end
   end
  end
  for i,b in ipairs(P.amount_buttons) do
   b.object:SetIsEnabled(enabled)
   mark(b,enabled and V.preset_selected(b.data,row,typed))
  end
  -- The footer amount stays readable without a selection; it is a saved preference.
  for _,b in ipairs(P.quick_amounts or {}) do
   if b.action=='amount_custom' then
    local n=V.custom_amount;local caption=not n and 'X' or n<10000 and tostring(n) or math.floor(n/1000)..'k'
    if b.label.value~=caption then b.label.object:SetText(FText(caption));b.label.value=caption end
    mark(b,V.custom_amount~=nil)
   else mark(b,V.preset_selected(b.data,nil,nil)) end
  end
 end
 P.ghost=make('Image',tree);P.ghost:SetVisibility(1);P.ghost_slot=place(canvas,P.ghost,0,0,48,48);P.ghost_slot:SetZOrder(20)
 -- Native-style lower-right close legend follows the viewport corner.
 local close=keybutton(root_canvas,'ESC','Close',0,0,130,'close')
 P.close_legend=close.object;P.close_legend:SetRenderOpacity(0)
 close.object.Slot:SetAnchors({Minimum={X=1,Y=1},Maximum={X=1,Y=1}})
 close.object.Slot:SetOffsets({Left=-156,Top=-70,Right=130,Bottom=34})
 local old_hover=package.loaded['stashlink.hover_card'];if old_hover then old_hover.hide() end
 package.loaded['stashlink.tooltip_data']=nil
 package.loaded['stashlink.native_tooltip_view']=nil
 package.loaded['stashlink.hover_card']=nil
 local hover=require('stashlink.hover_card');hover.previous_pulse=old_hover and old_hover.pulse
 hover.bind(P,V,{make=make,tree=tree,canvas=canvas,asset=asset,label=label,image=image,place=place})
 package.loaded['stashlink.quantity_ui']=nil
 package.loaded['stashlink.feedback']=nil
 require('stashlink.quantity_ui').bind(P,V)
 require('stashlink.feedback').bind(P,V,{make=make,tree=tree,canvas=canvas,label=label,place=place})
 require('stashlink.bank_tabs_ui').bind(P,V,{make=make,tree=tree,canvas=canvas,label=label,place=place,tiny=tiny,image=image,input=input,tab_texture=slot_background,popup_background=popup_background,texture=tex})
 require('stashlink.controller_ui').bind(P,V,{make=make,tree=tree,canvas=canvas,label=label,place=place,tiny=tiny,image=image})
 require('stashlink.ui_skin').bind(P,V)
 require('stashlink.panel_effects').bind(P,V,{tree=tree,canvas=canvas,asset=asset,place=place},frames)
 P.root:AddToViewport(10000);P.root:SetVisibility(1)
end
return M
