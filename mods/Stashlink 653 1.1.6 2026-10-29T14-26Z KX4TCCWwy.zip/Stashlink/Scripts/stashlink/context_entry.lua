-- F is an entry action only for the actual ledger under the game's reticle.
-- The overlay is read-only; no native primary/secondary interaction is rewritten.
local Scheduler=require('stashlink.scheduler')
local MenuGuard=require('stashlink.menu_guard')
local NativeHint=require('stashlink.native_hint')
local Keyboard=require('stashlink.ledger_keyboard')
local M={}
local function hint(method,...)
    if NativeHint.disabled and method~='reset' then return end
    local ok,why=pcall(NativeHint[method],...)
    if not ok then
        pcall(NativeHint.reset);NativeHint.disabled=true
        print('[Stashlink] Native hint unavailable; ledger controls remain active: '..tostring(why)..'\n')
    end
end
local function valid(o) return o and o:IsValid() end
local ledger_path='/Game/Gameplay/World/Stations/BP_InventoryDropOffPoint.BP_InventoryDropoffPoint_C'
local function is_ledger(actor)
    -- The focus callback can run inside UE4SS's script-hook mutex. Loading an
    -- unloaded ledger Blueprint here waits for the async loader, which needs
    -- that same mutex for object construction: a 120-second loading deadlock.
    -- An existing actor already owns its class hierarchy. Inspect only that
    -- hierarchy, without global object searches or synchronous asset loads.
    local class=actor:GetClass()
    for _=1,16 do
        if not valid(class)then return false end
        if class:GetFullName():gsub('^%S+%s+','')==ledger_path then return true end
        class=class:GetSuperStruct()
    end
    return false
end
function M.is_ledger(actor)
    return valid(actor)and is_ledger(actor)or false
end
function M.focused(adapter,view,checked_context)
    if view.open then return nil end
    -- The early event already validated this context synchronously. Reuse it
    -- only within that call; never retain it as an access authorization.
    local c=checked_context
    if not c then
        local ok;ok,c=pcall(adapter.context,adapter)
        if not ok then return nil end
    end
    if MenuGuard.blocked(c.pc) then return nil end
    local detector=c.pawn.InteractableDetector
    if not valid(detector) then return nil end
    local interaction=detector.CurrentInteractable
    local actor=valid(interaction) and interaction:GetOwner() or detector.CurrentWorldActor
    if not valid(actor) or not is_ledger(actor) or actor.bIsPreview or actor.bIsGhosted then return nil end
    interaction=actor.Interaction
    if not valid(interaction) or interaction:IsDisabledLocally() or interaction:HasSecondaryInteraction() then return nil end
    if actor:GetWorld():GetAddress()~=c.world:GetAddress() then return nil end
    local a,b=actor:K2_GetActorLocation(),c.pawn:K2_GetActorLocation()
    local distance=math.sqrt((a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2)
    if distance>adapter:interaction_range(actor,c) then return nil end
    return actor,c
end
function M.hide()
    hint('hide')
    if M.visible and valid(M.root) then M.root:SetVisibility(1) end
    M.visible=false;M.actor=nil;M.context=nil
end
-- Controller entry shares the prompt's bounded reticle observation. Opening
-- still calls focused() again, so a stale prompt can never authorize access.
function M.current()
    if valid(M.actor) and M.context and valid(M.context.pc) then return M.actor,M.context end
end
function M.forget(keep_keyboard)
    -- Post-travel cleanup drops wrappers without querying native validity.
    if NativeHint.forget then NativeHint.forget()end
    if not keep_keyboard then Keyboard.forget();M.keyboard_key='F'end
    M.root=nil;M.owner=nil;M.actor=nil;M.context=nil;M.visible=false
    M.key_image=nil;M.key_label=nil;M.keyboard_texture=nil;M.controller_active=nil;M.action_label=nil
    M.asset_retry_at=nil
end
function M.destroy(keep_keyboard)
    local root=M.root
    if not keep_keyboard then
        local ok,why=Keyboard.reset();if not ok then print('[Stashlink] Ledger keyboard cleanup: '..tostring(why)..'\n')end
    end
    hint('reset');M.forget(keep_keyboard)
    if valid(root)then root:RemoveFromParent()end
end
function M.create(pc)
    if valid(M.root) and M.owner==pc:GetAddress() then return true end
    local now=os.clock()
    if M.asset_retry_at and now<M.asset_retry_at then return false end
    -- A passive world prompt must not flush async asset loading. The native
    -- HUD already supplies these assets; defer decoration until they exist.
    local font=StaticFindObject('/Game/UI/Fonts/Poppins-Regular_Font.Poppins-Regular_Font')
    local key_font=StaticFindObject('/Game/UI/Fonts/Poppins-Medium_Font.Poppins-Medium_Font')
    local texture=StaticFindObject('/Game/Art/UI/Inputs/Keyboard/T_Keys-Special-Blank.T_Keys-Special-Blank')
    if not valid(font) or not valid(texture) then M.asset_retry_at=now+.5;return false end
    M.asset_retry_at=nil
    if not valid(key_font) then key_font=font end
    M.destroy(true);M.serial=(M.serial or 0)+1
    local n=0
    local function make(kind,outer)
        n=n+1
        local o=StaticConstructObject(StaticFindObject('/Script/UMG.'..kind),outer,FName('StashlinkContext_'..os.time()..'_'..M.serial..'_'..n),0x40)
        assert(valid(o),'Context prompt could not be created');return o
    end
    M.root=make('UserWidget',pc);M.owner=pc:GetAddress()
    M.root:SetOwningPlayer(pc)
    local tree=make('WidgetTree',M.root);M.root.WidgetTree=tree
    local canvas=make('CanvasPanel',tree);tree.RootWidget=canvas
    local row=make('CanvasPanel',tree);local slot=canvas:AddChildToCanvas(row)
    slot:SetAnchors({Minimum={X=.5,Y=.5},Maximum={X=.5,Y=.5}})
    -- Match the native ledger's left key column and 36px action-row pitch.
    slot:SetOffsets({Left=64,Top=55,Right=453,Bottom=36})
    local function place(o,x,y,w,h) row:AddChildToCanvas(o):SetOffsets({Left=x,Top=y,Right=w,Bottom=h}) end
    local text=make('TextBlock',tree);text.Font.FontObject=font;text.Font.Size=13;text.Font.LetterSpacing=100
    text:SetColorAndOpacity({SpecifiedColor={R=.65,G=.65,B=.65,A=1},ColorUseRule=0})
    text:SetShadowOffset({X=2,Y=2});text:SetShadowColorAndOpacity({R=0,G=0,B=0,A=.9})
    text:SetText(FText('Open Stashlink'));text:SetJustification(0);place(text,41,3,412,30)
    local image=make('Image',tree)
    image:SetBrushFromTexture(texture,false);place(image,0,0,32,32)
    local key=make('TextBlock',tree);key.Font.FontObject=key_font;key.Font.Size=13;key.Font.LetterSpacing=-80
    key:SetColorAndOpacity({SpecifiedColor={R=.76,G=.76,B=.76,A=1},ColorUseRule=0})
    key:SetShadowOffset({X=1,Y=1});key:SetShadowColorAndOpacity({R=0,G=0,B=0,A=.9})
    key:SetText(FText(M.keyboard_key or 'F'));key:SetJustification(1);place(key,-1,2,32,28)
    M.key_image=image;M.key_label=key;M.keyboard_texture=texture;M.action_label=text
    M.root:AddToViewport(9990);M.root:SetVisibility(1)
    return true
end
function M.set_controller(active,key,family)
    key=key or 'Y';family=family or 'Xbox'
    M.desired_controller,M.desired_key,M.desired_family=active,key,family
    hint('set_controller',active,key,family)
    local mode=tostring(active)..':'..key..':'..family..':'..(M.keyboard_key or 'F')
    if not valid(M.root) or M.controller_active==mode then return end
    if valid(M.action_label)then M.action_label:SetText(FText(active and key=='MENU'and 'Open Stashlink (Hold and release Menu)'or 'Open Stashlink'))end
    if active then
        local G=require('stashlink.controller_glyph');local image=StaticFindObject(G.path(key,family))
        if not valid(image) then
            M.key_image:SetBrushFromTexture(M.keyboard_texture,false)
            M.key_label:SetText(FText(key=='MENU'and 'Menu'or key));M.key_label:SetVisibility(3)
            return
        end
        if valid(image)then M.key_image:SetBrushFromTexture(image,false)end
        M.key_label:SetVisibility(1)
    else
        M.key_image:SetBrushFromTexture(M.keyboard_texture,false);M.key_label:SetText(FText(M.keyboard_key or 'F'));M.key_label:SetVisibility(3)
    end
    M.controller_active=mode
end
function M.set_keyboard_key(key)
    hint('set_keyboard_key',key)
    if key==M.keyboard_key then return end
    M.keyboard_key=key;M.controller_active=nil
    M.set_controller(M.desired_controller or false,M.desired_key,M.desired_family)
end
function M.bind(service,view)
    M.service=service;M.view=view
    if M.bound then return end;M.bound=true
    Scheduler.every(80,function()
        if view.open then Keyboard.tick(nil,nil,true);M.hide();return end
        local ok,actor,c=pcall(M.focused,service.adapter,view)
        Keyboard.tick(ok and actor or nil,ok and c or nil,false)
        if not ok or not actor then M.hide();return end
        local keyboard_key=Keyboard.entry_key()
        if not keyboard_key then M.hide();return end
        M.set_keyboard_key(keyboard_key)
        -- The remote prompt belongs to the existing local HUD. The old
        -- standalone viewport widget caused movement/collision regressions.
        M.actor,M.context=actor,c
        if c.networked then
            if require('stashlink.profile').remote_controller_entry~=true then hint('set_controller',false)end
            hint('primary',c.pc,actor,keyboard_key=='E'and'F'or nil)
            hint('show',c.pc,actor);return
        end
        hint('hide',true)
        local created=M.create(c.pc)
        M.actor,M.context=actor,c
        if not created then return end
        hint('primary',c.pc,actor,keyboard_key=='E'and'F'or nil)
        if not M.visible then M.root:SetVisibility(3);M.visible=true end
    end)
end
return M
