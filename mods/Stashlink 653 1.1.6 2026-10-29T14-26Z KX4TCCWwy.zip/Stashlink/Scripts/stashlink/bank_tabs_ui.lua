local Categories=require('stashlink.bank_categories')
local M={}
local function valid(o)return o and o:IsValid()end
local function text(label,value)if label.value~=value then label.object:SetText(FText(value));label.value=value end end
local function show(o,on)if valid(o)then o:SetVisibility(on and 3 or 1)end end
local function count_text(n,word)n=n or 0;return n..' '..word..(n==1 and ''or's')end
local function first_item(V,tab,fallback)
    local definition=tab and tab.items and tab.items[1]
    return definition and((V.icon_row and V.icon_row(definition))or fallback)or nil
end
-- Custom tabs run across the top like the OSRS bank; automatic categories are a
-- quieter filter rail beside the grid, so the two never read as rival tab rows.
local layout={tab_x=54,tab_y=4,tab_w=52,tab_h=50,tab_pitch=55,rail_x=24,rail_y=60,rail_w=40,rail_h=46,rail_pitch=54.5,origin={x=692,y=101}}
function M.bind(P,V,H)
    local ui={icon_rows={},failed_icons={}};P.bank_ui=ui;P.category_buttons={};P.custom_tab_buttons={};P.tab_editor_open=false
    local L=P.bank_layout or layout;ui.layout=L
    local function tab(parent,x,y,w,h,caption,action,data,icon)
        local c=H.tiny(parent,caption,x,y,w,action,data,true)
        c.size:SetHeightOverride(h)
        c.object.Slot:SetOffsets({Left=x,Top=y,Right=w,Bottom=h});c.bounds.h=h
        c.face.Slot:SetOffsets({Left=1,Top=1,Right=w-2,Bottom=h-2})
        c.outline.Slot:SetOffsets({Left=0,Top=0,Right=w,Bottom=h})
        c.label.object.Font.Size=22;c.label.object.Slot:SetOffsets({Left=0,Top=(h-34)/2,Right=w,Bottom=34})
        icon=icon or 34
        c.image=H.make('Image',H.tree);H.place(c.canvas,c.image,(w-icon)/2,(h-icon)/2,icon,icon):SetZOrder(6);show(c.image,false)
        c.badge=H.make('Image',H.tree);H.place(c.canvas,c.badge,0,0,1,1);show(c.badge,false)
        c.material={SetTextureParameterValue=function(_,_,texture)c.image:SetBrushFromTexture(texture,false);show(c.image,true)end,
            SetScalarParameterValue=function(_,key,value)if key==P.params.icon_opacity then c.image:SetRenderOpacity(value)end end}
        c.bank_tab_control=true;return c
    end
    for i,category in ipairs(Categories.list)do
        P.category_buttons[i]=tab(P.right_frame,L.rail_x,L.rail_y+(i-1)*L.rail_pitch,L.rail_w,L.rail_h,'','bank_category',category.id,36)
    end
    -- All uses the backpack's own Items glyph rather than borrowing an item.
    local all=P.category_buttons[1]
    if H.texture then
        local ok_n,normal=pcall(H.texture,'T_Icon_Items_Normal');local ok_h,highlight=pcall(H.texture,'T_Icon_Items_Highlight')
        if ok_n and ok_h then
            all.glyph_normal,all.glyph_highlight=normal,highlight
            all.image.Slot:SetOffsets({Left=(L.rail_w-38)/2,Top=(L.rail_h-19)/2,Right=38,Bottom=19})
        end
    end
    ui.all=tab(P.right_frame,L.tab_x,L.tab_y,L.tab_w,L.tab_h,'∞','bank_tab','all')
    for i=1,9 do P.custom_tab_buttons[i]=tab(P.right_frame,L.tab_x+i*L.tab_pitch,L.tab_y,L.tab_w,L.tab_h,'','bank_tab',nil,38)end
    ui.add=tab(P.right_frame,L.tab_x+L.tab_pitch,L.tab_y,L.tab_w,L.tab_h,'+','bank_new')
    ui.add.object:SetToolTipText(FText('New custom tab\nDrag a stored item here to create a tab'))
    local popup=H.make('CanvasPanel',H.tree);H.place(H.canvas,popup,748,268,560,280):SetZOrder(600);popup:SetVisibility(1)
    local backing=H.make('Border',H.tree);backing:SetBrushColor({R=.006,G=.006,B=.005,A=.99});H.place(popup,backing,0,0,560,280)
    ui.show_background=H.popup_background(popup,560,280)
    ui.preview=H.make('Image',H.tree);H.place(popup,ui.preview,32,24,30,30);show(ui.preview,false)
    ui.edit_title=H.label(popup,'Custom tab',76,24,452,28,16,true)
    ui.name=H.input(popup,32,56,496,'')
    ui.edit_help=H.label(popup,'Tab changes never move or remove stored items.',32,228,496,28,9,false)
    ui.edit_help.object:SetAutoWrapText(true)
    P.tab_editor_controls={}
    for i,spec in ipairs({{'Save name','bank_save',32,190},{'Cancel','bank_cancel',236,122},{'Remove tab','bank_remove',382,146}})do
        local c=H.tiny(popup,spec[1],spec[3],188,spec[4],spec[2],nil,true)
        c.tab_editor=true;c.bounds={x=748+spec[3],y=456,w=spec[4],h=30};P.tab_editor_controls[i]=c
    end
    H.label(popup,'Your first item is the tab icon.\nDrag any item to the first slot to change it.',32,100,496,36,10,false)
    ui.up=H.tiny(popup,'Move tab left',32,148,240,'bank_shift',-1,true)
    ui.down=H.tiny(popup,'Move tab right',286,148,242,'bank_shift',1,true)
    for _,c in ipairs({ui.up,ui.down})do c.tab_editor=true;c.bounds={x=748+c.bounds.x,y=416,w=c.bounds.w,h=30};P.tab_editor_controls[#P.tab_editor_controls+1]=c end
    ui.popup=popup
    function P.refresh_tab_editor()
        local current=ui.edit_id and V.bank:get(ui.edit_id)
        local preview=first_item(V,current,ui.custom_reps and current and ui.custom_reps[current.id])
        local cached=P.icon_cache and preview and P.icon_cache[preview.definition]
        if cached and valid(cached.texture)then ui.preview:SetBrushFromTexture(cached.texture,false);show(ui.preview,true)else show(ui.preview,false)end
        local index
        for i,entry in ipairs(V.bank.state.tabs)do if current and entry.id==current.id then index=i;break end end
        ui.up.object:SetIsEnabled(index~=nil and index>1)
        ui.down.object:SetIsEnabled(index~=nil and index<#V.bank.state.tabs)
    end
    function P.close_tab_editor()
        P.tab_editor_open=false;popup:SetVisibility(1);V.entry=nil
        local C=require('stashlink.controller');if C.modal=='tab_editor'then
            C.modal=nil;local c=ui.return_control
            if ui.return_tab then
                c=nil
                if V.bank:get(ui.return_tab)then for _,candidate in ipairs(P.custom_tab_buttons)do if candidate.data==ui.return_tab then c=candidate;break end end end
            end
            if c and c.action=='bank_tab'and c.data~='all'and not V.bank:get(c.data)then c=nil end
            C.focus(c or P.stored[1])
        end
    end
    function P.open_tab_editor(id)
        local tab=id and V.bank:get(id)or{name='Tab '..(#V.bank.state.tabs+1)};if not tab then return end
        ui.edit_id=id;ui.name:SetText(FText(tab.name));text(ui.edit_title,id and 'Manage custom tab' or 'Create custom tab')
        text(ui.edit_help,'Tab order saves immediately. Stored items never move.')
        P.tab_editor_controls[3].object:SetIsEnabled(id~=nil)
        P.refresh_tab_editor()
        P.tab_editor_open=true;popup:SetVisibility(4);ui.show_background();V.entry='bank_tab_name'
        require('stashlink.hover_card').hide();if P.refresh_feedback then P.refresh_feedback()end
        if P.controller_active then
            text(P.tab_editor_controls[1].label,'Enter name');ui.name:SetIsReadOnly(true)
            local C=require('stashlink.controller');ui.return_control=C.focused;ui.return_tab=id;C.modal='tab_editor';C.focus(P.tab_editor_controls[1])
        else text(P.tab_editor_controls[1].label,'Save name');ui.name:SetIsReadOnly(false);ui.name:SetKeyboardFocus()end
    end
    function P.bank_editor_pointer()
        if ui.name:IsHovered()then ui.name:SetKeyboardFocus();return end
        local c=P.hovered();if c and c.tab_editor then P.click(c)end
    end
    local function reset_view(repack,keep_scroll)
        P.last_click=nil;P.pointer=nil;V.selection=0;V.player_slot=nil;V.mode='stored'
        if not keep_scroll and P.scroll_to_row then P.scroll_to_row(0)end
        require('stashlink.hover_card').hide();if repack then V.repack()end
    end
    local function result(ok,why,keep_scroll)
        V.status=ok and 'Custom tab saved' or require('stashlink.feedback').text(why)
        if ok then reset_view(true,keep_scroll)
        elseif P.tab_editor_open then text(ui.edit_help,V.status)end
        return ok
    end
    function P.bank_action(action,data)
        if action=='bank_category'then V.select_category(data);reset_view()
        elseif action=='bank_tab'then V.select_bank_tab(data);reset_view()
        elseif action=='bank_placeholders'then if V.toggle_placeholders then V.toggle_placeholders();reset_view(true)end
        elseif action=='bank_new'then
            if #V.bank.state.tabs>=9 then V.status='All nine custom tabs are in use'else P.open_tab_editor()end
        elseif action=='bank_save'then
            if P.controller_active then
                local id=ui.edit_id;P.close_tab_editor();require('stashlink.controller').rename_tab(id)
            else
                local name=ui.name:GetText():ToString();local ok,why
                if ui.edit_id then ok,why=V.bank:rename(ui.edit_id,name)
                else ok,why=V.bank:add(name);if ok then V.select_bank_tab(ok)end end
                if result(ok,why)then P.close_tab_editor()end
            end
        elseif action=='bank_shift'then
            local ok,why=V.bank:shift(ui.edit_id,data);result(ok,why);P.refresh_tab_editor()
        elseif action=='bank_remove'then
            local ok,why=V.bank:remove(ui.edit_id);if result(ok,why)then P.close_tab_editor();V.status='Tab removed; its items remain in All'end
        elseif action=='bank_cancel'then P.close_tab_editor()
        else return false end
        return true
    end
    function P.drop_bank_tab(source,target)
        local tab_target=target and (target.action=='bank_tab'or target.action=='bank_new')
        local reorder=target and target.pane=='stored'and source.pane=='stored'
        if not tab_target and not reorder then return false end
        if source.pane~='stored'then V.status='Move this item into storage before assigning a custom tab';return true end
        if source.token~=V.snapshot.token or not source.row or not source.control
            or not source.control.row or source.control.row.key~=source.row.key then V.status='Storage changed; pick up the item again';return true end
        local definition=source.row.definition
        local ok,why
        if reorder and V.bank.selected=='all'then
            -- Arranging All changes saved presentation order only; the view keeps its scroll.
            if not V.arrange then V.status='Choose a custom tab to arrange items';return true end
            ok,why=V.arrange(source.row,target.row or nil)
            V.status=ok and '' or require('stashlink.feedback').text(why);return true
        end
        if target.action=='bank_new'then ok,why=V.bank:add(nil,definition);if ok then V.select_bank_tab(ok)end
        else ok,why=V.bank:assign(reorder and V.bank.selected or target.data,definition,reorder and target.row and target.row.definition or nil)end
        if ok and reorder then
            -- Show the tab's own order. The saved All arrangement is left untouched.
            if V.sort_mode=='amount'then if V.use_custom_order then V.use_custom_order()else V.sort_mode='custom'end end
            V.status='';V.repack();return true
        end
        -- Assigning to an existing tab keeps this view; creating a tab opens a new one.
        result(ok,why,target.action~='bank_new');return true
    end
end
function M.update(P,V)
    local ui=P.bank_ui;if not ui then return end
    local category_counts,custom_counts,reps,custom_reps={},{},{},{}
    local memory_revision=V.memory and V.memory.revision
    if ui.snapshot~=V.snapshot or ui.query~=V.query or ui.revision~=V.bank.revision or ui.selected~=V.bank.selected or ui.category~=V.bank_category or ui.memory_revision~=memory_revision then
        local query=V.query:lower()
        for _,row in ipairs(V.snapshot.stored)do
            local category=Categories.classify(row);local tab,rank=V.bank:membership(row.definition)
            reps.all=reps.all or row;reps[category]=reps[category]or row
            if tab and (not custom_reps[tab]or rank<select(2,V.bank:membership(custom_reps[tab].definition)))then custom_reps[tab]=row end
            if query==''or row.name:lower():find(query,1,true)then
                if V.bank:matches(row)then
                    category_counts.all=(category_counts.all or 0)+1;category_counts[category]=(category_counts[category]or 0)+1
                end
                if V.bank_category=='all'or category==V.bank_category then
                    custom_counts.all=(custom_counts.all or 0)+1
                    if tab then custom_counts[tab]=(custom_counts[tab]or 0)+1 end
                end
            end
        end
        if V.memory_active then
            for _,row in ipairs(V.memory:rows(V.snapshot.stored))do if row.placeholder then
                local category=Categories.classify(row);local tab,rank=V.bank:membership(row.definition)
                reps.all=reps.all or row;reps[category]=reps[category]or row
                if tab and(not custom_reps[tab]or rank<select(2,V.bank:membership(custom_reps[tab].definition)))then custom_reps[tab]=row end
            end end
        end
        ui.counts,ui.custom_counts,ui.reps,ui.custom_reps=category_counts,custom_counts,reps,custom_reps
        ui.snapshot,ui.query,ui.revision,ui.selected,ui.category=V.snapshot,V.query,V.bank.revision,V.bank.selected,V.bank_category
        ui.memory_revision=memory_revision
    else category_counts,custom_counts,reps,custom_reps=ui.counts,ui.custom_counts,ui.reps,ui.custom_reps end
    local function category_icon(id,fallback)
        for _,definition in ipairs(Categories.icons and Categories.icons[id] or {})do
            local cached=P.icon_cache and P.icon_cache[definition]
            if cached and cached.failed then ui.failed_icons[definition]=true end
            if not ui.failed_icons[definition]then
                ui.icon_rows[definition]=ui.icon_rows[definition]or{definition=definition}
                return ui.icon_rows[definition]
            end
        end
        return fallback
    end
    local function update(c,title,count,selected,row,extra)
        c.selected=selected
        local focused=P.controller_active and P.controller_focus==c
        if c.skin then c.skin:update()
        else
            c.outline:SetBrushColor((selected or focused)and {R=.84,G=.66,B=.32,A=1}or{R=.28,G=.25,B=.19,A=.8})
            c.face:SetBrushColor(selected and {R=.25,G=.19,B=.09,A=.95}or{R=.055,G=.05,B=.04,A=.95})
        end
        local tip=title..' · '..count_text(count,'item')..(extra or '')
        if c.tooltip~=tip then c.object:SetToolTipText(FText(tip));c.tooltip=tip end
        local definition=row and row.definition
        if c.definition~=definition then
            c.definition=definition;c.icon_row=row;show(c.image,false)
            if definition then P.request_icon(c,definition)end
        end
    end
    for i,category in ipairs(Categories.list)do
        local c=P.category_buttons[i]
        local hint=V.bank_category==category.id and category.id~='all'and '\nClick All to clear this filter'or''
        if category.id=='all'and c.glyph_normal then
            update(c,'All categories',category_counts.all,V.bank_category=='all',nil)
            local glyph=c.selected and c.glyph_highlight or c.glyph_normal
            if c.glyph~=glyph then c.glyph=glyph;c.image:SetBrushFromTexture(glyph,false);show(c.image,true)end
        else update(c,category.name,category_counts[category.id],V.bank_category==category.id,category_icon(category.id,reps[category.id]),hint)end
    end
    local current=V.bank:get(V.bank.selected)
    if P.bank_title then text(P.bank_title,current and current.name:upper()or 'STASHLINK')end
    -- Counts live in tooltips; the title is just the tab's name.
    local placeholders=V.placeholder_count and V.placeholder_count()or 0
    local summary='\n'..count_text(category_counts[V.bank_category],'item')..(placeholders>0 and ' · '..count_text(placeholders,'placeholder')or'')
    local s=V.snapshot
    if P.bank_linked and s.containers then
        local tip=s.containers..' linked containers · '..tostring(s.occupied)..' / '..tostring(s.capacity)..' slots used'..summary
        if P.bank_linked.tooltip~=tip then P.bank_linked.object:SetToolTipText(FText(tip));P.bank_linked.tooltip=tip end
    end
    local toggle=P.placeholders_toggle
    if toggle then
        local on=V.memory and V.memory.state.prefs.placeholders==true or false
        if toggle.on~=on then toggle.on=on;toggle.selected=on;show(toggle.fill,on);if toggle.skin then toggle.skin:update()end end
    end
    if P.sort_button and V.sort_label then
        local label='Sort: '..V.sort_label()
        text(P.sort_button.label,label)
        local tip=V.sort_mode=='custom'and 'Your arranged order. Press twice to sort A–Z.'
            or V.sort_mode=='amount'and 'Sorted by quantity. Press to sort A–Z.'or'Sorted A–Z. Press to sort by quantity.'
        if P.sort_button.tooltip~=tip then P.sort_button.object:SetToolTipText(FText(tip..'\nDrag items in All to arrange them by hand.'));P.sort_button.tooltip=tip end
    end
    update(ui.all,'All storage',custom_counts.all,V.bank.selected=='all',nil,V.bank.selected=='all'and placeholders>0 and ' · '..count_text(placeholders,'placeholder')or nil)
    for i,c in ipairs(P.custom_tab_buttons)do
        local tab=V.bank.state.tabs[i];c.object:SetVisibility(tab and 0 or 1);c.bank_hidden=not tab
        c.data=tab and tab.id or nil
        if tab then
            local row=first_item(V,tab,custom_reps[tab.id])
            update(c,tab.name,custom_counts[tab.id],V.bank.selected==tab.id,row,'\nDrag to reorder · right-click / X to manage')
        else c.definition=nil;c.icon_row=nil;show(c.image,false)end
    end
    local count=#V.bank.state.tabs;local L=ui.layout
    ui.add.object:SetVisibility(count<9 and 0 or 1);ui.add.bank_hidden=count>=9
    local x=L.tab_x+(count+1)*L.tab_pitch
    ui.add.object.Slot:SetOffsets({Left=x,Top=L.tab_y,Right=L.tab_w,Bottom=L.tab_h});ui.add.bounds.x=L.origin.x+x
end
return M
