-- Bindings revalidated in Steam build 25466454; every runtime is checked
-- against the recorded signatures in compat.lua. See BINDINGS.md.
-- All entry points run on the game thread. Live handles remain in this adapter.
local Helpers = require("UEHelpers")
local ItemPolicy = require("stashlink.item_policy")
local ContainerFill = require("stashlink.container_fill")
local SoftRef = require("stashlink.soft_ref")
local NetworkObservation=require('stashlink.network_observation')
local M = {}
local fishing_storage_classes={
    ['BlueprintGeneratedClass /Fishing/Gameplay/BaseBuilding/BuildingPieces/Fishing/BP_BaseBuilding_TackleBox.BP_BaseBuilding_TackleBox_C']=true,
    ['BlueprintGeneratedClass /Fishing/Gameplay/BaseBuilding/BuildingPieces/Fishing/BP_BaseBuilding_FishingBarrel.BP_BaseBuilding_FishingBarrel_C']=true,
}
local function valid(o) return o and o:IsValid() end
local function get_wrapped(v)return v:get()end
local function unwrap(v)
    local ok, result = pcall(get_wrapped,v)
    return ok and result or v
end
local function id(o) return o:GetFullName() .. "@" .. tostring(o:GetAddress()) end
local function same_world(actor,world)
    local actual=actor:GetWorld()
    return valid(actual) and actual:GetAddress()==world:GetAddress()
end
local function guid(item)
    local g = item.Guid
    if not g or type(g.A)~="number" then g=item:GetGuid() end
    return table.concat({g.A,g.B,g.C,g.D}, ":")
end
local function signature(item,metadata)
    local tags = {}
    item.GameplayTags.GameplayTags:ForEach(function(_, element)
        tags[#tags + 1] = unwrap(element).TagName:ToString()
    end)
    table.sort(tags)
    local class_name=metadata and metadata.class_name or item:GetClass():GetFullName()
    return table.concat({class_name, metadata and metadata.definition or item.ItemData:GetFullName(),
        tostring(item.Durability), tostring(item.NumMasterworkUpgradesApplied), table.concat(tags, ",")}, "|")..ItemPolicy.effects(item,class_name)
end
M.signature=signature
local function distance(a,b)
    local x,y=a:K2_GetActorLocation(),b:K2_GetActorLocation()
    return math.sqrt((x.X-y.X)^2+(x.Y-y.Y)^2+(x.Z-y.Z)^2)
end
local function slots(inventory)
    local n=inventory.MaxSlotCount
    assert(type(n)=="number" and n>=0 and n<=4096 and n==math.floor(n),"Unsupported inventory capacity")
    return n
end

local function fingerprint(inventory,metadata_for)
    local result={tostring(inventory.MaxSlotCount)}
    inventory.ItemSlots:ForEach(function(index,wrapped)
        local item=unwrap(wrapped)
        if valid(item) then
            result[#result+1]=table.concat({index,item:GetAddress(),item.Count,guid(item),signature(item,metadata_for and metadata_for(item))},":")
        end
    end)
    return table.concat(result,";")
end

local function linked_container(inventory,c,player_id,character_guid,names)
    if not valid(inventory) then return end
    local key=id(inventory);if key==player_id then return end
    local owner=inventory:GetOwner()
    if not valid(owner) or not same_world(owner,c.world) or owner.bIsPreview or owner.bIsGhosted then return end
    local linked,ownership=owner.LinkedInventoryComponent,owner.OwnershipComponent
    local other=inventory.CurrentActor
    local accessible_link=valid(linked) and linked:IsLinkable() and not linked.bIsLocked
        and valid(ownership) and not ownership:IsPrivatelyLockedFromPlayer(character_guid)
    local fishing_storage=not accessible_link and fishing_storage_classes[owner:GetClass():GetFullName()]==true
        and (not valid(linked) or (linked:IsLinkable() and not linked.bIsLocked))
        and ((not c.networked and not valid(ownership)) or (valid(ownership) and not ownership:IsPrivatelyLockedFromPlayer(character_guid)))
    if (accessible_link or fishing_storage) and not valid(other) and inventory.bAllowAdds and inventory.bAllowRemoves
        and inventory.MaxSlotCount>0 and #inventory.ItemSlots<=inventory.MaxSlotCount then
        return {id=key,object=inventory,owner=owner,name=names and owner:GetDisplayName():ToString() or nil}
    end
end

function M.new(existing)
    local profile=require("stashlink.profile")
    -- A developer-only method refresh can retain the same adapter/coordinator,
    -- including request history and the uncertain-outcome lock.
    local self=existing or {anchor=nil,snapshot=nil,revision=0,epoch=1,validated=profile.native_transfers_validated,lookup={},process=tostring(os.time()),metadata={},observed={},inventory_cache={},changed={},bindings={},icon_data={}}
    self.stack_items=self.stack_items or {}
    if self.network_validated==nil then self.network_validated=profile.multiplayer_transfers_validated==true end
    local source=debug.getinfo(1,"S").source:gsub("^@",""):gsub("\\","/")
    local steamapps=source:match("^(.*)/common/")
    function self:binding(name,path)
        local object=self.bindings[name]
        if not valid(object) then
            object=StaticFindObject(path)
            if not valid(object) and path:sub(1,6)=='/Game/' then object=LoadAsset(path) end
            self.bindings[name]=object
        end
        assert(valid(object),"Missing native binding: "..name)
        return object
    end
    function self:steam_build()
        if not steamapps then return nil end
        local file=io.open(steamapps.."/appmanifest_1374490.acf","r")
        if not file then return nil end
        local text=file:read("*a"); file:close()
        return text:match('"buildid"%s+"([^"]+)"')
    end
    -- A familiar Steam build cannot override evidence of changed runtime
    -- bindings (including a different loader). Validate every installation.
    function self:build_supported()
        if self.build_ok~=nil then return self.build_ok end
        local build=self:steam_build()
        local label=build and ("game build "..build) or "this game install"
        local called,ok,problem=pcall(require("stashlink.compat").check)
        if not called then ok,problem=false,"binding check failed: "..tostring(ok) end
        self.build_ok=ok==true
        self.build_note=self.build_ok and (label..": native inventory bindings match") or (label..": "..tostring(problem))
        return self.build_ok
    end
    function self:invalidate()
        self.network_test_session=nil
        self.epoch=self.epoch+1; self.anchor=nil; self.anchor_object=nil; self.cached_pc=nil; self.snapshot=nil; self.lookup={}; self.metadata={}; self.observed={}; self.inventory_cache={};self.stack_items={}; self.changed={}; self.weight_widget=nil; self.icon_data={};self.watch_pending=nil;self.watch_addresses=nil;self.membership_pending=nil;self.membership_next=nil
    end
    function self:context(fresh)
        local pc=self.cached_pc
        if fresh or not valid(pc) then pc=Helpers.GetPlayerController(); self.cached_pc=pc end
        assert(valid(pc) and pc:IsLocalPlayerController(),"Local player unavailable")
        local pawn,world=pc.Pawn,pc:GetWorld()
        assert(valid(pawn) and valid(world),"Enter a world")
        local game_state=world.GameState
        assert(valid(game_state) and #game_state.PlayerArray>0,"Player session not ready")
        local networked=not pawn:HasAuthority() or #game_state.PlayerArray>1
        assert(not networked or profile.multiplayer_preview==true,"Multiplayer preview is disabled")
        local inventory=pc.InventoryComponent
        assert(valid(inventory) and inventory.bHasLoadedFromSave,"Player inventory not ready")
        return {pc=pc,pawn=pawn,world=world,inventory=inventory,networked=networked,
            session=self.process..":"..self.epoch..":"..id(world)..":"..id(pc)..":"..id(pawn)}
    end
    function self:session_id()
        local ok,c=pcall(self.context,self)
        return ok and c.session or nil
    end
    function self:item_metadata(item)
        local data,class=item.ItemData,item:GetClass()
        local key=tostring(data:GetAddress())..":"..class:GetAddress()
        local definition,class_name=data:GetFullName(),class:GetFullName()
        local metadata=self.metadata[key]
        if not metadata or metadata.definition~=definition or metadata.class_name~=class_name then
            metadata={definition=definition,name=item:GetPlayerFacingName():ToString(),class_name=class_name,stack_size=data.MaxStackSize}
            metadata.use_verb=self:use_verb(data,metadata.class_name)
            metadata.category=require('stashlink.bank_categories').classify(metadata)
            metadata.masterwork_style=self:item_style(data)
            self.metadata[key]=metadata
        end
        if not metadata.visuals_checked then
            metadata.masterwork_type=data.bIsMasterworkItem and data.MasterworkType or nil
            local ok,status=pcall(function() return data.ItemStatus.TagName:ToString() end)
            metadata.burnt=ok and status=='Item.Status.Burnt'
            metadata.visuals_checked=true
        end
        return metadata
    end
    -- Never read the soft icon fields directly; see soft_ref.lua.
    function self:load_masterwork_styles()
        if self.masterwork_styles and self.ascension_icons then return end
        local settings=self:binding('inventory_settings','/Script/Dominion.Default__InventorySettings')
        local styles,icons={},{}
        local struct='/Script/Dominion.MasterworkEquipmentSlotStyling'
        settings.MasterworkSlotStyling:ForEach(function(key,wrapped)
            local value=unwrap(wrapped);local c=value.BackgroundHighlightColor
            local kind=unwrap(key)
            styles[kind]={opacity=value.BackgroundHighlightMaxOpacity,color={R=c.R,G=c.G,B=c.B,A=c.A}}
            local ok,partial,full,partial_name,full_name=pcall(function()
                local a=SoftRef.load_in_struct(value,struct,'PartiallyAscendedIcon')
                local b=SoftRef.load_in_struct(value,struct,'FullyAscendedIcon')
                return a,b,valid(a) and a:GetFullName() or nil,valid(b) and b:GetFullName() or nil
            end)
            icons[kind]=ok and {partial=partial,full=full,partial_name=partial_name,full_name=full_name} or {}
        end)
        self.masterwork_styles,self.ascension_icons=styles,icons
    end
    function self:item_style(data)
        self:load_masterwork_styles()
        return require('stashlink.masterwork_style').select(self.masterwork_styles,data.bIsMasterworkItem,data.MasterworkType)
    end
    function self:use_verb(data,class_name)
        local kind=ItemPolicy.kind(class_name)
        if kind and kind~='item' then return 'Equip' end
        if kind=='item' and data:IsA(self:binding('consumable_data','/Script/Dominion.ConsumableItemData')) then
            local verb=data.UseVerb:ToString();return verb~='' and verb or 'Use'
        end
    end
    function self:equipped(c)
        local identities,stamp={},{}
        c.pc.LoadoutComponent.ItemSlots:ForEach(function(index,wrapped)
            local item=unwrap(wrapped)
            if valid(item) then local identity=guid(item);identities[identity]=true;stamp[#stamp+1]=index..":"..identity end
        end)
        return identities,table.concat(stamp,";")
    end
    function self:nearest(max_distance,context)
        local c=context or self:context()
        local selected,best=nil,max_distance or 300
        for _,actor in ipairs(FindAllOf("BP_InventoryDropoffPoint_C") or {}) do
            if valid(actor) and same_world(actor,c.world)
                and not actor.bIsPreview and not actor.bIsGhosted then
                local d=distance(actor,c.pawn)
                if d<=best then selected,best=actor,d end
            end
        end
        return selected,best
    end
    function self:interaction_range(anchor,c)
        local range=300
        local detector=c.pawn.InteractableDetector
        if valid(detector) and valid(anchor.Interaction) then
            detector.InteractionRanges:ForEach(function(k,v)
                if unwrap(k)==anchor.Interaction.InteractionDistance then
                    local n=unwrap(v);if type(n)=="number" and n>0 and n<=5000 then range=n end
                end
            end)
        end
        return range
    end
    function self:open(preferred)
        local c=self:context()
        local anchor=preferred or self:nearest(1200,c)
        assert(valid(anchor),"Approach a Storage Ledger")
        self.access_range=self:interaction_range(anchor,c)
        assert(distance(anchor,c.pawn)<=self.access_range,"Move within the ledger's interaction range")
        self.anchor=id(anchor);self.anchor_object=anchor
        return self:refresh()
    end
    function self:check_access()
        local c=self:context()
        local anchor=self.anchor_object
        if not valid(anchor) then anchor=self:nearest(self.access_range or 300,c) end
        assert(valid(anchor) and id(anchor)==self.anchor,"Ledger access lost; approach the selected ledger")
        assert(distance(anchor,c.pawn)<=(self.access_range or 300),"Ledger access lost; approach the selected ledger")
        assert(same_world(anchor,c.world),"World changed")
        assert(valid(anchor.Interaction) and not anchor.Interaction:IsDisabledLocally(),"Ledger interaction disabled")
        self.anchor_object=anchor
        c.anchor=anchor
        return c
    end
    function self:scope()
        local started=os.clock()
        local c=self:check_access()
        self.access_ms=(os.clock()-started)*1000
        local anchor=c.anchor
        local library=self:binding("crafting","/Script/Dominion.Default__CraftingFunctionLibrary")
        assert(valid(library),"Native linked-storage resolver unavailable")
        local raw={}
        local query_start=os.clock()
        library:GetLinkedInventories(anchor,anchor:K2_GetActorLocation(),{},raw)
        self.query_ms=(os.clock()-query_start)*1000
        local containers,seen={},{}
        local player_id,character_guid=id(c.inventory),c.pc:GetCharacterGuid()
        for _,wrapped in ipairs(raw) do
            local container=linked_container(unwrap(wrapped),c,player_id,character_guid,true)
            if container and not seen[container.id] then
                seen[container.id]=true;containers[#containers+1]=container
            end
        end
        table.sort(containers,function(a,b) return a.id<b.id end)
        c.anchor,c.containers=anchor,containers
        self.scope_ms=(os.clock()-started)*1000
        return c
    end
    function self:refresh(dirty)
        local started=os.clock()
        local c=self:scope()
        if not self.snapshot or self.snapshot.session~=c.session then self.inventory_cache,self.stack_items={},{} end
        local read_start=os.clock()
        local equipped,equipment_stamp=self:equipped(c)
        if equipment_stamp~=self.equipment_stamp and dirty then dirty[c.inventory:GetAddress()]=true end
        self.equipment_stamp=equipment_stamp
        local records,lookup,observed,retained={},{},{},{}
        local fresh_records,fresh_items,record_items={},{},{}
        local read_count=0
        local function read(inventory,container_id,container_name,player)
            local address=inventory:GetAddress()
            local total=slots(inventory)
            lookup[container_id]=inventory; observed[address]=true; retained[address]=true
            local cached=self.inventory_cache[address]
            if cached and cached.compatibility_version==1 and cached.id==container_id and cached.capacity==total and dirty and not dirty[address] then
                record_items[cached]=self.stack_items[address]
                records[#records+1]=cached; return
            end
            read_count=read_count+1
            local record={id=container_id,player=player,capacity=total,slots={}}
            fresh_records[record]={}
            local item_handles={};record_items[record]=item_handles
            local observed_state={tostring(total)}
            local function inspect(slot,item)
                if not valid(item) then return end
                local count=item.Count
                assert(type(count)=="number" and count>0 and count==math.floor(count),"Invalid native item count")
                local data=item.ItemData
                local metadata=self:item_metadata(item)
                self.icon_data[metadata.definition]=data
                local sig,instance=signature(item,metadata),guid(item)
                observed_state[#observed_state+1]=table.concat({slot+1,item:GetAddress(),count,instance,sig},":")
                local writable=ItemPolicy.writable(metadata.class_name,metadata.definition)
                local protected=player and (slot<inventory.NumberOfQuickActionSlots or equipped[instance]==true)
                local hotbar=player and slot<inventory.NumberOfQuickActionSlots
                local contents=ContainerFill.read(item,metadata.class_name)
                if contents and contents.definition~='' then self.icon_data[contents.definition]=item.Contents.ContentData end
                local source={container_id=container_id,container_name=container_name,slot=slot,identity=instance,
                    signature=sig,count=count,protected=protected,writable=writable}
                local key=sig
                if not writable or metadata.stack_size<=1 then
                    key=key.."|source:"..container_id..":"..slot..":"..instance
                end
                record.slots[slot]={key=key,name=metadata.name,definition=metadata.definition,class_name=metadata.class_name,category=metadata.category,
                    memory_id=(key~=sig)and(metadata.definition..'|guid:'..instance)or key,
                    total=count,available=(writable and (hotbar or not protected)) and count or 0,writable=writable,protected=protected and not hotbar,
                    read_only_reason=not writable and "This item type is not supported yet" or nil,
                    contents=contents,equipped=player and equipped[instance]==true,use_verb=metadata.use_verb,masterwork_style=metadata.masterwork_style,
                    burnt=metadata.burnt,masterwork_type=metadata.masterwork_type,masterwork_upgrades=item.NumMasterworkUpgradesApplied or 0,
                    rearrange=writable and player,
                    stack_size=metadata.stack_size,source=source,durability=item.Durability,max_durability=data.BaseDurability>0 and item:GetMaxDurability() or 0}
                if writable and metadata.stack_size>1 then
                    local cell=record.slots[slot]
                    fresh_items[cell]=item;fresh_records[record][#fresh_records[record]+1]=cell;item_handles[slot]=item
                end
            end
            -- Read the native array; never edit it. Avoid two ProcessEvent calls
            -- per slot, including the many empty backpack/quest slots.
            local array=inventory.ItemSlots
            assert(#array<=total,"Native slot array exceeds capacity")
            array:ForEach(function(index,wrapped)
                assert(index>=1 and index<=total,"Native array index is out of range")
                inspect(index-1,unwrap(wrapped))
            end)
            record.fingerprint=table.concat(observed_state,";")
            self.inventory_cache[address]=record;self.stack_items[address]=item_handles; records[#records+1]=record
        end
        for _,container in ipairs(c.containers) do read(container.object,container.id,container.name,false) end
        read(c.inventory,id(c.inventory),"Backpack",true)
        -- Equal signatures still need the game's stack-compatibility check.
        -- Reused aggregate cells retain that proof; validate a bounded number
        -- of their observed items only when a fresh item needs a representative.
        -- Never rescan every retained native inventory for an incremental draw.
        if next(fresh_items) then
            local retained_reps,reps={},{}
            for _,record in ipairs(records) do
                if not fresh_records[record] then
                    for _,cell in pairs(record.slots) do
                        local sig=cell.source.signature
                        if cell.writable and cell.stack_size>1 and cell.key==sig then
                            local candidates=retained_reps[sig] or {};retained_reps[sig]=candidates
                            if #candidates<4 then
                                candidates[#candidates+1]={item=record_items[record] and record_items[record][cell.source.slot],identity=cell.source.identity}
                            end
                        end
                    end
                end
            end
            for _,record in ipairs(records) do
                if fresh_records[record] then
                    for _,cell in ipairs(fresh_records[record]) do
                        local item=fresh_items[cell]
                        if item then
                            local sig=cell.source.signature
                            local rep=reps[sig]
                            if rep==nil then
                                local candidates=retained_reps[sig]
                                if candidates then
                                    rep=false
                                    for _,source in ipairs(candidates) do
                                        local candidate=source.item
                                        if valid(candidate) and guid(candidate)==source.identity and signature(candidate)==sig then
                                            rep=candidate;break
                                        end
                                    end
                                else rep=item end
                                reps[sig]=rep
                            end
                            if not rep or (rep~=item and not item:IsSameType(rep)) then
                                local source=cell.source
                                cell.key=sig.."|source:"..source.container_id..":"..source.slot..":"..source.identity
                                cell.memory_id=cell.definition..'|guid:'..source.identity
                            end
                        end
                    end
                end
            end
        end
        for record in pairs(fresh_records) do record.compatibility_version=1 end
        self.player_address=c.inventory:GetAddress()
        for address in pairs(self.inventory_cache) do if not retained[address] then self.inventory_cache[address]=nil;self.stack_items[address]=nil end end
        self.lookup,self.observed=lookup,observed
        self.read_ms=(os.clock()-read_start)*1000
        local tail_start=os.clock()
        local model=require("stashlink.snapshot").assemble(records)
        local pages,offset={},c.inventory.NumberOfQuickActionSlots
        c.inventory.InventoryPages:ForEach(function(_,wrapped)
            local page=unwrap(wrapped)
            pages[#pages+1]={slot_type=page.SlotType,first=offset,count=page.NumSlots}
            offset=offset+page.NumSlots
        end)
        local members={}
        for _,container in ipairs(c.containers) do members[#members+1]=container.id..":"..slots(container.object) end
        self.membership=table.concat(members,";")
        local armour={}
        local equipment_slots=require('stashlink.equipment_slots').specs()
        for index,spec in ipairs(equipment_slots)do
            local item=c.pc.LoadoutComponent:GetEquipmentFromSlot(spec.slot)
            if valid(item) then
                local metadata=self:item_metadata(item)
                armour[index-1]={nativeequipment_slot=spec.slot,key=guid(item),name=item:GetPlayerFacingName():ToString(),definition=item.ItemData:GetFullName(),total=1,writable=false,protected=true,equipped=true,use_verb='Equip',masterwork_style=metadata.masterwork_style,burnt=metadata.burnt,masterwork_type=metadata.masterwork_type,masterwork_upgrades=item.NumMasterworkUpgradesApplied or 0,available=0,durability=item.Durability,max_durability=item.ItemData.BaseDurability>0 and item:GetMaxDurability() or 0}
            end
        end
        local weight_text=string.format("Weight %.0f",c.inventory:ComputeCurrentWeight())
        local weight_fraction,weight_unlimited
        pcall(function()
            local encumbrance=c.pawn:GetPlayerEncumbranceComponent()
            if not valid(encumbrance) then return end
            local current,maximum=encumbrance:GetCurrentCarryWeight(),encumbrance:GetMaxCarryWeight()
            if type(current)=='number' and type(maximum)=='number' and maximum>0 then
                weight_text=string.format('%.0f/%.0f',current,maximum);weight_fraction=current/maximum
            elseif type(current)=='number' and type(maximum)=='number' and maximum==0 then
                weight_text=string.format('%.0f',current);weight_fraction=0;weight_unlimited=true
            end
        end)
        self.revision=self.revision+1
        model.session=c.session; model.token=tostring(self.revision); model.pages=pages; model.hotbar_count=c.inventory.NumberOfQuickActionSlots
        model.power_level=c.pc.LoadoutComponent:GetPowerLevel()
        model.armour=armour;model.equipment_slots=equipment_slots; model.weight_text=weight_text; model.weight_fraction=weight_fraction;model.weight_unlimited=weight_unlimited
        model.containers=#c.containers; model.player_id=id(c.inventory); model.anchor=self.anchor
        model.bank_scope=require('stashlink.bank_identity').read(c)
        self.snapshot=model
        self.watch_pending=nil;self.watch_addresses=nil;self.membership_pending=nil;self.membership_next=os.clock()+2
        self.tail_ms=(os.clock()-tail_start)*1000
        self.refresh_ms=(os.clock()-started)*1000; self.last_inventory_reads=read_count
        self.refresh_count=(self.refresh_count or 0)+1
        return model
    end
    function self:detect_changes(limit,checked_context)
        local started=os.clock()
        local changed={}
        local c=checked_context or self:context();local _,stamp=self:equipped(c)
        if stamp~=self.equipment_stamp then changed[c.inventory:GetAddress()]=true end
        local addresses=self.watch_addresses
        if not addresses then
            addresses={};for address in pairs(self.inventory_cache)do addresses[#addresses+1]=address end
            table.sort(addresses);self.watch_addresses=addresses
        end
        if limit then
            -- Explicit synchronous audits are retained for diagnostics. Runtime
            -- observation below is bounded; transfer verification is unchanged.
            local count=math.min(limit,#addresses)
            for step=1,count do
                local address=addresses[((self.watch_cursor or 0)+step-1)%#addresses+1]
                local record=self.inventory_cache[address];local inventory=self.lookup[record.id]
                if not valid(inventory) or fingerprint(inventory,function(item)return self:item_metadata(item)end)~=record.fingerprint then changed[address]=true end
            end
            if #addresses>0 then self.watch_cursor=((self.watch_cursor or 0)+count)%#addresses end
            self.watch_pending=nil
        else
            local budget=os.clock()+.002;local reads,finished=0,0
            while #addresses>0 and reads<64 and finished<2 do
                local address=addresses[((self.watch_cursor or 0)%#addresses)+1]
                local record=self.inventory_cache[address];local inventory=record and self.lookup[record.id]
                local pending=self.watch_pending
                local done=false
                if not valid(inventory) then changed[address]=true;done=true
                else
                    local array=inventory.ItemSlots;local capacity=slots(inventory);local length=#array
                    assert(length<=capacity,'Native slot array exceeds capacity')
                    if capacity~=record.capacity then changed[address]=true;done=true
                    else
                        if not pending or pending.address~=address or pending.record~=record then
                            pending={address=address,record=record,length=length,next=1,parts={tostring(capacity)}};self.watch_pending=pending
                        end
                        if length~=pending.length then changed[address]=true;done=true
                        else
                            while pending.next<=length and reads<64 do
                                local index=pending.next;local item=unwrap(array[index]);reads=reads+1
                                if valid(item)then
                                    pending.parts[#pending.parts+1]=table.concat({index,item:GetAddress(),item.Count,guid(item),signature(item,self:item_metadata(item))},':')
                                end
                                pending.next=index+1
                                if os.clock()>=budget then break end
                            end
                            if pending.next>length then
                                if table.concat(pending.parts,';')~=record.fingerprint then changed[address]=true end
                                done=true
                            end
                        end
                    end
                end
                if done then self.watch_pending=nil;self.watch_cursor=((self.watch_cursor or 0)+1)%#addresses;finished=finished+1 end
                if os.clock()>=budget then break end
            end
        end
        self.detect_ms=(os.clock()-started)*1000
        return changed
    end
    function self:membership_changed(checked_context)
        local now=os.clock();local pending=self.membership_pending
        if not pending and now<(self.membership_next or 0)then return false end
        if not pending then
            local c=checked_context or self:check_access();local raw={}
            self:binding('crafting','/Script/Dominion.Default__CraftingFunctionLibrary'):GetLinkedInventories(c.anchor,c.anchor:K2_GetActorLocation(),{},raw)
            pending={context=c,raw=raw,next=1,members={},seen={},player_id=id(c.inventory),character_guid=c.pc:GetCharacterGuid()}
            self.membership_pending=pending
        end
        local budget=os.clock()+.002;local count=0
        while pending.next<=#pending.raw and count<8 do
            local container=linked_container(unwrap(pending.raw[pending.next]),pending.context,pending.player_id,pending.character_guid,false)
            if container and not pending.seen[container.id]then
                pending.seen[container.id]=true;pending.members[container.id]=container.id..':'..slots(container.object)
            end
            pending.next=pending.next+1;count=count+1;if os.clock()>=budget then break end
        end
        if pending.next<=#pending.raw then return false end
        local ids,values={},{};for id in pairs(pending.members)do ids[#ids+1]=id end;table.sort(ids)
        for _,id in ipairs(ids)do values[#values+1]=pending.members[id]end
        self.membership_pending=nil;self.membership_next=os.clock()+2
        return table.concat(values,';')~=self.membership
    end
    function self:apply_icon(image,definition)
        local path=definition:gsub("^%S+%s+","")
        local data=self.icon_data[definition]
        if not valid(data)or data:GetFullName()~=definition then data=LoadAsset(path); self.icon_data[definition]=data end
        if not valid(data)or data:GetFullName()~=definition then return false end
        local texture=SoftRef.load(data,'/Script/Dominion.ItemData','Icon')
        if not texture then return false end
        image:SetBrushFromTexture(texture,false)
        return true
    end
    function self:apply_badge(image,definition)
        local data=self.icon_data[definition]
        if not valid(data)or data:GetFullName()~=definition then return false end
        local texture=SoftRef.load(data,'/Script/Dominion.ItemData','CategoryClassIcon')
        if not texture then return false end
        image:SetBrushFromTexture(texture,false)
        return true
    end
    function self:apply_ascension_icon(image,kind,upgrades)
        if not kind or not upgrades or upgrades<=0 then return false end
        self:load_masterwork_styles()
        local field=upgrades>=3 and 'full' or 'partial'
        local style=self.ascension_icons[kind]
        local icon=style and style[field]
        local expected=style and style[field..'_name']
        -- A Lua wrapper can remain valid after its native address is reused.
        -- This secondary cache must preserve the resolver's asset identity.
        if not valid(icon) or not expected or icon:GetFullName()~=expected then
            self.masterwork_styles,self.ascension_icons=nil,nil
            self:load_masterwork_styles()
            style=self.ascension_icons[kind];icon=style and style[field]
            expected=style and style[field..'_name']
        end
        if not valid(icon) or not expected or icon:GetFullName()~=expected then return false end
        image:SetBrushFromTexture(icon,false)
        return true
    end
    function self:apply_content_badge(image,contents)
        if contents.definition=='' then return false end
        local data=self.icon_data[contents.definition]
        if not valid(data)or data:GetFullName()~=contents.definition then return false end
        local texture=SoftRef.load(data,'/Script/Dominion.ContainerContentDataAsset','InventorySlotIcon')
        if not texture then return false end
        image:SetBrushFromTexture(texture,false)
        image:SetColorAndOpacity(contents.tint)
        return true
    end
    function self:network_write_ready(c)
        if self.network_validated then return true end
        -- A manual development trial does not certify multiplayer support.
        -- Its permission expires with this exact world/controller/pawn session.
        return self.network_test_session~=nil and self.network_test_session==c.session
            and require('stashlink.settings').development==true
    end
    function self:can_write(request)
        if not self:build_supported() then return false,"Game update changed inventory functions" end
        local ok,c=pcall(self.check_access,self)
        if not ok then return false,tostring(c) end
        if c.session~=request.session then return false,"stale_session" end
        if not self.validated then return false,"Native transfer validation is not complete" end
        if c.networked then
            if not self:network_write_ready(c) then return false,"Multiplayer transfers await dedicated-server validation" end
            if self.network_ok==nil then
                local checked,matched,note=pcall(require('stashlink.compat').check_network)
                self.network_ok=checked and matched==true
                self.network_note=checked and note or tostring(matched)
            end
            if not self.network_ok then return false,"Network inventory bindings changed: "..tostring(self.network_note) end
        end
        return true
    end
    function self:capture_use(control)
        local row=assert(control.row,'Choose an item')
        assert(row.use_verb,'This item has no right-click action')
        local source=row.source or (row.sources and row.sources[1])
        local c=self:context()
        if control.pane=='armour' then
            local selector=assert(require('stashlink.equipment_slots').selector(control),'Equipment selector unavailable')
            local equipment=c.pc.LoadoutComponent:GetEquipmentFromSlot(selector)
            assert(valid(equipment) and equipment.ItemData:GetFullName()==row.definition,'Equipped item changed')
            local identity=guid(equipment)
            c.pc.LoadoutComponent.ItemSlots:ForEach(function(index,wrapped)
                local item=unwrap(wrapped)
                if valid(item) and guid(item)==identity then source={container_id=id(c.pc.LoadoutComponent),slot=index-1,identity=identity,signature=signature(item)} end
            end)
        end
        assert(source,'Item location unavailable')
        return {session=self.snapshot.session,snapshot_token=self.snapshot.token,source_id=source.container_id,slot=source.slot,
            identity=source.identity,signature=source.signature,name=row.name,verb=ItemPolicy.use_label(row)}
    end
    function self:resolve_use(request)
        if not self.snapshot or request.snapshot_token~=self.snapshot.token then return nil,'Inventory changed; click the item again' end
        local c=self:scope();local inventory
        if c.networked then return nil,'Item use in multiplayer is awaiting validation; use the game inventory' end
        if request.source_id==id(c.inventory) then inventory=c.inventory
        elseif request.source_id==id(c.pc.LoadoutComponent) then inventory=c.pc.LoadoutComponent
        else for _,container in ipairs(c.containers) do if container.id==request.source_id then inventory=container.object;break end end end
        if not valid(inventory) then return nil,'Item is no longer accessible' end
        if type(request.slot)~='number' or request.slot<0 or request.slot>=slots(inventory) or request.slot~=math.floor(request.slot) then return nil,'Item slot is invalid' end
        local item=inventory:GetItemFromSlot(request.slot)
        if not valid(item) or guid(item)~=request.identity or signature(item)~=request.signature then return nil,'Item changed; click it again' end
        if not self:use_verb(item.ItemData,item:GetClass():GetFullName()) then return nil,'This item has no right-click action' end
        if not valid(c.pc.InventoryController) then return nil,'Game inventory controller unavailable' end
        if not self.use_binding_checked then
            local fn=self:binding('use_item','/Script/Dominion.InventoryController:UseItemFromInventory');local fields={}
            fn:ForEachProperty(function(p)fields[#fields+1]=p:GetFullName():match('^(%S+)')..':'..p:GetFullName():match('([^:]+)$')end)
            assert(table.concat(fields,'|')=='ObjectProperty:Inventory|IntProperty:SlotIndex','Native item-use signature changed')
            self.use_binding_checked=true
        end
        return {controller=c.pc.InventoryController,inventory=inventory,slot=request.slot,player=c.inventory}
    end
    function self:invoke_use(target)
        self.changed[target.inventory:GetAddress()]=true;self.changed[target.player:GetAddress()]=true
        target.controller:UseItemFromInventory(target.inventory,target.slot)
    end
    function self:plan(request)
        local snapshot=self.snapshot
        if not snapshot or request.snapshot_token~=snapshot.token then return nil,"stale_snapshot" end
        if request.direction=="rearrange" then
            local cell=snapshot.player_slots[request.source_slot]
            if not cell or not cell.writable or not cell.rearrange or cell.key~=request.row_key or cell.source.identity~=request.source_identity then
                return nil,"Backpack item changed or slot is protected"
            end
            return {{quantity=math.min(request.quantity,cell.total),source=cell.source,definition=cell.definition}}
        end
        if request.direction=='deposit' and type(request.source_slot)=='number' and request.source_slot>=0
            and request.source_slot<(snapshot.hotbar_count or 0) then
            local cell=snapshot.player_slots[request.source_slot]
            if not cell or not cell.writable or cell.available<=0 or cell.key~=request.row_key
                or cell.source.identity~=request.source_identity then return nil,'Hotbar stack changed; select it again' end
            return {{quantity=math.min(request.quantity,cell.available),source=cell.source,definition=cell.definition}}
        end
        local rows=request.direction=="withdraw" and snapshot.stored or snapshot.held
        local selected
        for _,row in ipairs(rows) do if row.key==request.row_key then selected=row; break end end
        if not selected or not selected.writable then return nil,"Item is read-only in this build" end
        local remaining,fragments=request.quantity,{}
        for _,source in ipairs(selected.sources) do
            if not source.protected and source.writable and remaining>0
                and (request.source_slot==nil or (source.slot==request.source_slot and source.identity==request.source_identity)) then
                local amount=math.min(remaining,source.count)
                fragments[#fragments+1]={quantity=amount,source=source,definition=selected.definition}
                remaining=remaining-amount
            end
        end
        return fragments
    end
    function self:destination_slots(candidate,item,player_inventory)
        local result={}
        local count=slots(candidate)
        if id(candidate)~=id(player_inventory) then
            for slot=0,count-1 do result[#result+1]=slot end
            return result
        end
        local offset=candidate.NumberOfQuickActionSlots
        local taglib=self:binding("tags","/Script/GameplayTags.Default__BlueprintGameplayTagLibrary")
        assert(valid(taglib),"Native inventory page filter unavailable")
        candidate.InventoryPages:ForEach(function(_,wrapped)
            local page=unwrap(wrapped)
            assert(page.NumSlots>=0 and page.NumSlots==math.floor(page.NumSlots),"Invalid inventory page")
            -- Use the borrowed native property. Returned structs containing arrays
            -- do not round-trip correctly through this installed Lua bridge.
            local accepts=taglib:IsTagQueryEmpty(page.AllowedItemFilter)
                or taglib:DoesContainerMatchTagQuery(item.ItemData.ItemFilterTags,page.AllowedItemFilter)
            if accepts then
                for slot=offset,offset+page.NumSlots-1 do result[#result+1]=slot end
            end
            offset=offset+page.NumSlots
        end)
        assert(offset==count,"Inventory page layout changed; writes disabled")
        return result
    end
    function self:move(fragment,request)
        local c=self:scope()
        local source_record=fragment.source
        local available={[id(c.inventory)]=c.inventory}
        for _,container in ipairs(c.containers) do available[container.id]=container.object end
        local source=available[source_record.container_id]
        if not valid(source) then return {status="rejected",reason="Source is no longer linked"} end
        local item=source:GetItemFromSlot(source_record.slot)
        if not valid(item) or guid(item)~=source_record.identity or signature(item)~=source_record.signature then
            return {status="rejected",reason="Selected slot changed; refresh"}
        end
        local manual_hotbar=source_record.container_id==id(c.inventory) and source_record.slot>=0
            and source_record.slot<c.inventory.NumberOfQuickActionSlots
            and request.source_slot==source_record.slot and request.source_identity==source_record.identity
        if request.direction=="deposit" and (source_record.slot<c.inventory.NumberOfQuickActionSlots
            or self:equipped(c)[source_record.identity]) and not manual_hotbar then return {status="rejected",reason="Protected item"} end
        if not ItemPolicy.writable(item:GetClass():GetFullName(),item.ItemData:GetFullName()) then return {status="rejected",reason="This item type is read-only in Stashlink"} end
        if not source.bAllowRemoves then return {status="rejected",reason="Source rejects removals"} end
        local candidates={}
        if request.direction=="withdraw" or request.direction=="rearrange" then candidates={c.inventory}
        else for _,container in ipairs(c.containers) do
            if not request.destination_id or request.destination_id=="" or request.destination_id==container.id then
                candidates[#candidates+1]=container.object
            end
        end end
        if request.destination_slot~=nil then
            local slot=request.destination_slot
            if type(slot)~="number" or slot~=math.floor(slot) or slot<0 or slot>=slots(c.inventory) then
                return {status="rejected",reason="Drop into a valid backpack or hotbar slot"}
            end
            if request.direction=="deposit" then return {status="rejected",reason="Storage grid has virtual slots"} end
            local into_hotbar=slot<c.inventory.NumberOfQuickActionSlots
            if into_hotbar and type(request.target_identity)~='string'then
                return {status='rejected',reason='Select the hotbar destination again'}
            end
            if request.direction=="rearrange" and (source_record.container_id~=id(c.inventory) or source_record.slot==slot
                or (source_record.slot<c.inventory.NumberOfQuickActionSlots and not manual_hotbar)) then
                return {status="rejected",reason="No slot change or protected source"}
            end
            -- Hotbar access is explicit only. Automatic destination searches
            -- remain restricted to the player's matching backpack pages.
            local permitted=into_hotbar
            for _,n in ipairs(self:destination_slots(c.inventory,item,c.inventory)) do if n==slot then permitted=true; break end end
            if not permitted or not c.inventory.bAllowAdds or not c.inventory:IsItemAllowed(item) then return {status="rejected",reason="Item does not fit this inventory page"} end
            local target=c.inventory:GetItemFromSlot(slot)
            local target_valid=valid(target)
            local target_guid=target_valid and guid(target) or ""
            if request.target_identity~=nil and target_guid~=request.target_identity then return {status="rejected",reason="Drop slot changed"} end
            local matching=target_valid and target:IsSameType(item) and signature(target)==source_record.signature
            if target_valid and not matching then
                if not ItemPolicy.writable(target:GetClass():GetFullName(),target.ItemData:GetFullName()) then
                    return {status="rejected",reason="The other item type is read-only in Stashlink"}
                end
                if request.direction~="rearrange" or fragment.quantity~=source:GetNumItemsInSlot(source_record.slot) then
                    return {status="rejected",reason="Drop onto an empty slot or a matching stack"}
                end
                local reverse=manual_hotbar
                for _,n in ipairs(self:destination_slots(c.inventory,target,c.inventory)) do if n==source_record.slot then reverse=true; break end end
                if not reverse then return {status="rejected",reason="The other item cannot fit the source slot"} end
                local before_source=source:GetNumItemsInSlot(source_record.slot)
                local before_target=c.inventory:GetNumItemsInSlot(slot)
                local target_sig=signature(target)
                if c.networked then
                    return self:network_move(c,source,source_record.slot,c.inventory,slot,before_source,{
                        source={count=before_source,identity=source_record.identity,signature=source_record.signature},
                        target={count=before_target,identity=target_guid,signature=target_sig},swap=true})
                end
                self.changed[source:GetAddress()]=true
                local accepted=source:MoveItem(source_record.slot,c.inventory,slot,c.pawn,before_source)
                local a,b=source:GetItemFromSlot(source_record.slot),source:GetItemFromSlot(slot)
                if valid(a) and valid(b) and guid(a)==target_guid and guid(b)==source_record.identity
                    and signature(a)==target_sig and signature(b)==source_record.signature
                    and source:GetNumItemsInSlot(source_record.slot)==before_target and source:GetNumItemsInSlot(slot)==before_source and accepted then
                    return {status="confirmed",moved=before_source}
                end
                if valid(a) and valid(b) and guid(a)==source_record.identity and guid(b)==target_guid
                    and signature(a)==source_record.signature and signature(b)==target_sig
                    and source:GetNumItemsInSlot(source_record.slot)==before_source and source:GetNumItemsInSlot(slot)==before_target then
                    return {status="rejected",reason="Native inventory did not swap these items"}
                end
                return {status="unknown"}
            end
        end
        local destination,target_slot,target_item,space
        local eligible={}
        for _,candidate in ipairs(candidates) do
            if candidate.bAllowAdds and candidate:IsItemAllowed(item) then
                local eligible_slots=request.destination_slot~=nil and {request.destination_slot} or self:destination_slots(candidate,item,c.inventory)
                eligible[#eligible+1]={inventory=candidate,slots=eligible_slots}
            end
        end
        -- Fill compatible partial stacks before consuming an empty slot.
        -- Remote merges still confirm both counts, item state and target GUID.
        for pass=1,2 do
            for _,entry in ipairs(eligible) do
                for _,slot in ipairs(entry.slots) do
                    local existing=entry.inventory:GetItemFromSlot(slot)
                    local occupied=valid(existing)
                    local compatible=occupied and existing:IsSameType(item) and signature(existing)==source_record.signature
                    if (pass==1 and compatible) or (pass==2 and not occupied) then
                        local free=occupied and existing:GetStackFreeSpace() or item.ItemData.MaxStackSize
                        if free>0 then destination,target_slot,target_item,space=entry.inventory,slot,existing,free; break end
                    end
                end
                if destination then break end
            end
            if destination then break end
        end
        if not valid(destination) then return {status="rejected",reason="No eligible destination space"} end
        local before_source=source:GetNumItemsInSlot(source_record.slot)
        local before_target=valid(target_item) and destination:GetNumItemsInSlot(target_slot) or 0
        local target_identity=valid(target_item) and guid(target_item) or nil
        local unique=item.ItemData.MaxStackSize<=1
        local amount=math.min(fragment.quantity,before_source,space)
        if amount<=0 then return {status="rejected",reason="Source is empty"} end
        if c.networked then
            return self:network_move(c,source,source_record.slot,destination,target_slot,amount,{
                source={count=before_source,identity=source_record.identity,signature=source_record.signature},
                target={count=before_target,identity=target_identity or '',signature=before_target>0 and source_record.signature or ''},
                unique=unique,continue=request.destination_slot==nil and amount<fragment.quantity})
        end
        self.changed[source:GetAddress()]=true; self.changed[destination:GetAddress()]=true
        local accepted=source:MoveItem(source_record.slot,destination,target_slot,c.pawn,amount)
        local after_source=source:GetItemFromSlot(source_record.slot)
        local after_target=destination:GetItemFromSlot(target_slot)
        if not accepted and valid(after_source) and guid(after_source)==source_record.identity
            and signature(after_source)==source_record.signature
            and source:GetNumItemsInSlot(source_record.slot)==before_source
            and ((not valid(after_target) and before_target==0) or (valid(after_target)
                and guid(after_target)==target_identity and signature(after_target)==source_record.signature
                and destination:GetNumItemsInSlot(target_slot)==before_target)) then
            return {status="rejected",reason="Native transfer rejected"}
        end
        if valid(after_source) and (guid(after_source)~=source_record.identity or signature(after_source)~=source_record.signature) then
            return {status="unknown"}
        end
        if not valid(after_target) or signature(after_target)~=source_record.signature then return {status="unknown"} end
        if target_identity and guid(after_target)~=target_identity then return {status="unknown"} end
        if unique and guid(after_target)~=source_record.identity then return {status="unknown"} end
        local source_count=valid(after_source) and source:GetNumItemsInSlot(source_record.slot) or 0
        local target_count=destination:GetNumItemsInSlot(target_slot)
        local moved=before_source-source_count
        if moved~=target_count-before_target or moved<0 or moved>amount then return {status="unknown"} end
        if not accepted and moved>0 then return {status="unknown"} end
        if moved==0 then return {status="rejected",reason="Native transfer rejected"} end
        return {status="confirmed",moved=moved,destination_identity=guid(after_target),continue=request.destination_slot==nil and moved==amount and moved<fragment.quantity}
    end
    function self:network_move(c,source,source_slot,target,target_slot,amount,spec)
        local controller=c.pc.InventoryController
        assert(self:network_write_ready(c) and self.network_ok,'Network writes are not validated')
        assert(valid(controller),'Player inventory controller unavailable')
        local owner=controller:GetOwner()
        assert(valid(owner) and owner:GetAddress()==c.pc:GetAddress(),'Network request requires the local player-owned controller')
        spec.session,spec.quantity=c.session,amount
        local operation={source=source,target=target,source_slot=source_slot,target_slot=target_slot,
            source_id=id(source),target_id=id(target),track=NetworkObservation.new(spec,os.clock())}
        -- All item/state/capacity checks above have completed before this call.
        -- There is no local mutation, optimistic success, or combine-after-send.
        -- A whole-stack RPC has no amount parameter: a stack grown by another
        -- player before execution could exceed an exact requested quantity.
        -- Numeric quantities therefore use the bounded split RPC, even when
        -- they currently equal the whole stack. Singleton items retain identity.
        if spec.swap or spec.unique then
            assert(spec.swap or (amount==1 and spec.source.count==1),'Invalid singleton transfer')
            controller:Server_MoveItemBetweenInventories(source,source_slot,target,target_slot)
        else
            controller:Server_SplitAndPutStack(source,source_slot,amount,target,target_slot)
        end
        return {status='pending',operation=operation,moved=0}
    end
    function self:poll_move(operation)
        local ok,c=pcall(self.context,self)
        -- A UE4SS wrapper can remain non-null after its world is destroyed.
        -- Establish the connection session before touching either retained
        -- inventory; IsValid alone cannot make an old-world reference safe.
        if not ok or c.session~=operation.track.spec.session then
            return NetworkObservation.observe(operation.track,{session=ok and c.session or nil,endpoints_valid=false},os.clock())
        end
        local good=ok and valid(operation.source) and valid(operation.target)
        if good then
            good=id(operation.source)==operation.source_id and id(operation.target)==operation.target_id
                and same_world(operation.source:GetOwner(),c.world) and same_world(operation.target:GetOwner(),c.world)
        end
        local function read(inventory,slot)
            local item=inventory:GetItemFromSlot(slot)
            if not valid(item) then return {count=0,identity='',signature=''} end
            return {count=inventory:GetNumItemsInSlot(slot),identity=guid(item),signature=signature(item)}
        end
        local reading={session=ok and c.session or nil,endpoints_valid=good==true}
        if good then
            reading.source=read(operation.source,operation.source_slot)
            reading.target=read(operation.target,operation.target_slot)
        end
        local result=NetworkObservation.observe(operation.track,reading,os.clock())
        if result.status~='pending' then
            if valid(operation.source) then self.changed[operation.source:GetAddress()]=true end
            if valid(operation.target) then self.changed[operation.target:GetAddress()]=true end
        end
        return result
    end
    return self
end

return M
