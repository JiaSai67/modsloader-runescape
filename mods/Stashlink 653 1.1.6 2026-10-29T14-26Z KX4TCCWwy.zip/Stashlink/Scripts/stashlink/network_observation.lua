-- Pure replicated-state confirmation. Dispatch alone is never an acknowledgment.
local M={}
local function count(value)
    return type(value)=='number' and value==math.floor(value) and value>=0 and value<=2147483647
end
local function same(actual,expected)
    if type(actual)~='table' or not count(actual.count) then return false end
    if expected.count==0 then return actual.count==0 end
    return actual.count==expected.count and actual.signature==expected.signature
        and type(actual.identity)=='string' and #actual.identity>0
        and (not expected.identity or actual.identity==expected.identity)
end
local function key(slot)
    if not slot or slot.count==0 then return 'empty' end
    return tostring(slot.count)..':'..tostring(slot.identity)..':'..tostring(slot.signature)
end
function M.new(spec,now)
    assert(type(spec)=='table' and type(now)=='number' and now==now,'Invalid network observation')
    assert(type(spec.session)=='string' and #spec.session>0,'Missing inventory session')
    assert(count(spec.quantity) and spec.quantity>0,'Invalid transfer amount')
    assert(same(spec.source,spec.source) and same(spec.target,spec.target),'Invalid endpoint state')
    assert(spec.source.count>=spec.quantity,'Transfer exceeds source')
    assert(type(spec.source.signature)=='string' and #spec.source.signature>0,'Missing source state')
    local timeout,settle=spec.timeout or 12,spec.settle or .12
    assert(type(timeout)=='number' and timeout>0 and timeout<math.huge,'Invalid confirmation timeout')
    assert(type(settle)=='number' and settle>=0 and settle<timeout,'Invalid confirmation interval')
    local source,target
    if spec.swap then
        assert(spec.quantity==spec.source.count and spec.target.count>0,'Invalid swap')
        source,target=spec.target,spec.source
    else
        source={count=spec.source.count-spec.quantity,identity=spec.source.identity,signature=spec.source.signature}
        target={count=spec.target.count+spec.quantity,signature=spec.source.signature,
            identity=spec.target.count>0 and spec.target.identity or (spec.unique and spec.source.identity or nil)}
        assert(spec.target.count==0 or spec.target.signature==spec.source.signature,'Incompatible target')
        assert(count(target.count),'Target count overflow')
    end
    return {spec=spec,expected_source=source,expected_target=target,started=now,last_time=now,
        timeout=timeout,settle=settle,status='pending'}
end
function M.observe(track,reading,now)
    if track.result then return track.result end
    local function unknown(reason)
        track.status='unknown';track.result={status='unknown',moved=0,reason=reason};return track.result
    end
    if type(now)~='number' or now~=now or now<track.last_time then return unknown('Network observation clock changed') end
    track.last_time=now
    if type(reading)~='table' or reading.session~=track.spec.session or reading.endpoints_valid~=true then
        return unknown('Connection or inventory endpoints changed while awaiting the server')
    end
    if same(reading.source,track.expected_source) and same(reading.target,track.expected_target) then
        local state=key(reading.source)..'>'..key(reading.target)
        if state~=track.match_key then track.match_key,track.match_since=state,now end
        if now-track.match_since>=track.settle then
            track.status='confirmed'
            track.result={status='confirmed',moved=track.spec.quantity,destination_identity=reading.target.identity,
                continue=track.spec.continue==true}
            return track.result
        end
    else track.match_key,track.match_since=nil,nil end
    if now-track.started>=track.timeout then
        return unknown('Server result timed out; the request may still arrive. Reconnect before another transfer')
    end
    return {status='pending',moved=0}
end
return M
