-- Right-stick scrolling has no inventory intents. Releasing the stick arms it
-- after a panel, popup, filter, or device change; delayed frames never catch up.
local M={deadzone=.35}
function M.new()return {}end
local function finite(value)
    return type(value)=='number'and value==value and value>-math.huge and value<math.huge
end
function M.step(s,axis,enabled,context,now)
    axis=tonumber(axis)or 0
    if not finite(axis)then axis=0 end
    axis=math.max(-1,math.min(1,axis))
    local direction=math.abs(axis)>M.deadzone and(axis<0 and -1 or 1)or 0
    if not finite(now)then s.blocked=true;s.direction=nil;return end
    if s.context~=context or s.enabled~=enabled or s.last_time and now<s.last_time then
        s.context=context;s.enabled=enabled;s.blocked=direction~=0;s.direction=nil;s.repeat_at=nil;s.last_time=now
        return
    end
    s.last_time=now
    if not enabled or direction==0 then
        s.blocked=direction~=0;s.direction=nil;s.repeat_at=nil;return
    end
    if s.blocked then return end
    if direction~=s.direction or now>=(s.repeat_at or 0)then
        local strength=(math.abs(axis)-M.deadzone)/(1-M.deadzone)
        s.direction=direction;s.repeat_at=now+.24-strength*.16
        return direction
    end
end
return M
