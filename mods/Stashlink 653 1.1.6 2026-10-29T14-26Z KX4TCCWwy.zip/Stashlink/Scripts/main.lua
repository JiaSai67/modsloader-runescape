-- Stashlink bootstrap. All game work belongs to the shared game-thread loop.
local source=debug.getinfo(1,"S").source:gsub("^@","")
local scripts=source:match("^(.*)[/\\][^/\\]+$") or "."
package.path=scripts.."/?.lua;"..scripts.."/?/init.lua;"..package.path
local profile=require("stashlink.profile")
if profile.disabled then print("[Stashlink] Disabled.\n");return end
local Requirements=require("stashlink.runtime_requirements")
local available,reason=Requirements.check()
if not available then print("[Stashlink] Startup unavailable: "..reason.."\n");return end
local Scheduler=require("stashlink.scheduler")
-- Establish the game-thread loop before attaching callbacks. A failed
-- registration leaves even a partially registered loop stopped and inert.
local started,start_error=pcall(function()
 Scheduler.start()
 assert(Scheduler.handle~=nil and Scheduler.handle~=false,"LoopInGameThreadWithDelay returned no action handle")
end)
if not started then
 pcall(Scheduler.stop)
 print("[Stashlink] Startup failed: game-thread loop registration: "..tostring(start_error)..". "..Requirements.repair_hint.."\n");return
end
local ok,err=pcall(function() require("stashlink.service").attach() end)
if not ok then pcall(Scheduler.stop);print("[Stashlink] Startup failed: "..tostring(err).."\n");return end
if require("stashlink.settings").development then
 local dev_ok,why=pcall(function() require("stashlink.developer").start(scripts) end)
 if not dev_ok then print("[Stashlink] Diagnostics unavailable: "..tostring(why).."\n") end
end
Scheduler.run(function()
 local adapter=require("stashlink.service").adapter
 local enabled=adapter:build_supported()
 print("[Stashlink] Transfers "..(enabled and "enabled" or "disabled").." ("..tostring(adapter.build_note)..").\n")
end)
print("[Stashlink] "..require("stashlink.version").." ready. Look at a Storage Ledger and press F.\n")
