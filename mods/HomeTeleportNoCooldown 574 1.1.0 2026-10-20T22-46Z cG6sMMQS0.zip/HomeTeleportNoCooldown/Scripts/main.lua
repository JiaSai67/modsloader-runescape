local dir=debug.getinfo(1,'S').source:sub(2):match('(.*[/\\])')
local cooldown=dofile(dir..'cooldown.lua')
-- Settings: config.txt next to this folder, or live from Mod Menu (Nexus mod 548) when installed.
local config={Enabled=true,CooldownSeconds=0}
local function loadConfig()
 local f=io.open(dir..'../config.txt','r');if not f then return end
 for line in f:lines() do
  local k,v=line:match('^%s*([%w_]+)%s*=%s*([^#;]-)%s*$')
  if k=='Enabled' then config.Enabled=v:lower()=='true' or v=='1'
  elseif k=='CooldownSeconds' then config.CooldownSeconds=tonumber(v) or config.CooldownSeconds end
 end
 f:close()
end
local mmRev
local function modMenuSync()
 local ok,rev=pcall(function() return ModRef:GetSharedVariable('ModMenu.HomeTeleportNoCooldown.rev') end)
 if not ok or type(rev)~='number' or rev==mmRev then return end
 mmRev=rev
 for key,default in pairs({Enabled=true,CooldownSeconds=0}) do
  local okV,v=pcall(function() return ModRef:GetSharedVariable('ModMenu.HomeTeleportNoCooldown.'..key) end)
  if okV and type(v)==type(default) then config[key]=v end
 end
end
local lastError
local function refresh()
 modMenuSync()
 local seconds=config.Enabled and math.max(0,config.CooldownSeconds) or nil
 local ok,found,changed,value,needs,original=pcall(cooldown.apply,seconds)
 if not ok then
  if tostring(found)~=lastError then lastError=tostring(found);print('[HomeTeleportNoCooldown] ERROR '..lastError..'\n') end
 else
  lastError=nil
  if found and changed then
   print(string.format('[HomeTeleportNoCooldown] Home Teleport cooldown=%s (original %s, %s); unlock requirement preserved=%s\n',
    tostring(value),tostring(original),config.Enabled and 'mod enabled' or 'mod disabled',tostring(needs)))
  end
 end
 ExecuteInGameThreadWithDelay(1000,refresh)
end
loadConfig()
ExecuteInGameThread(refresh)
