-- Station Feeder - RuneScape: Dragonwilds
--
-- Processing stations restock themselves from your nearby chests when you open them.
--
-- WHY THIS EXISTS
--   The game has two kinds of workstation and they work completely differently.
--   A CraftingStation (crafting bench, armour bench, cooking, pottery, rune altar, mystic forge,
--   fletching, tools and melee) has no inventory of its own and the crafting screen already reaches
--   into your linked chests. A ProcessingStation OWNS its input: it has its own Resources inventory,
--   its own Fuel inventory and its own output, and it will only ever use what you personally carried
--   over and dropped in. That is all thirteen of them, not the five that get mentioned around the
--   forums: Smelter, Advanced Smelter, Sawmill, Stonecutter, Charcoal Kiln, Grill, Fermentation
--   Barrel, Tanner, Advanced Tannery, Loom, Spinning Wheel, Grindstone and Cauldron, plus the
--   Advanced Spinning Wheel from the Scorned Wilderness.
--
-- HOW YOU TELL IT WHAT YOU WANT
--   You load the station by hand once. From then on, every time you open it, the mod tops up
--   whatever is already in its slots from the chests around it. It never fills an empty slot, so it
--   can never decide for you and can never load a station you only opened to look at.
--   That is the default, "Top up" mode. With RememberLastLoad on (the default) it also remembers what
--   was last in each station, so one that ran completely dry, or burned its fuel to zero, is refilled
--   with those same items. See "Station memory" below.
--
--   "Fill a recipe" mode is the opt-in alternative: the mod reads the station's own recipe list,
--   finds one your chests can supply COMPLETELY, and moves in exactly those ingredients. It exists
--   because a Furnace has two input slots and Bronze Bar needs copper AND tin, so a naive
--   first-come feed can leave you with iron in one slot, silver in the other, and no valid recipe.
--   It is off by default because it makes a choice on your behalf.
--
-- THE RECIPE PANEL (1.6.0)
--   Beside the station window: every recipe the station has, oldest unlock first, with how many you can
--   make from your backpack and linked chests; locked recipes show as "?". Pick one, set a quantity and
--   press LOAD, LOAD & START or START/STOP. The rules (counts, fuel, order, where leftovers go) live in
--   recipes.lua, which has no game calls so tools/test_stationfeeder_16_offline.py can test them.
--   Controller (1.7.1): move onto a panel button with the stick or D-pad and press A, the same as a click.
--
-- WHAT IT WILL NOT TOUCH
--   * Your backpack, on the automatic top-up. That pass only ever moves OUT of chests and INTO the
--     station you just opened: its sources are always actors that have a LinkedInventoryComponent, and
--     the player's inventories have none. The backpack is used only when YOU click LOAD or LOAD & START
--     in the recipe panel (and "Panel uses backpack" is on), the same as the game's crafting bench.
--     Leftovers returned from a station go to chests, never into the backpack.
--   * With "Keep one" on, the last one of any item in your chests.
--   * Anything the station does not accept, checked against the station's own accepted lists.
--   * Locked chests, and chests marked private, unless you turn that off.
--   * Crafting stations, which already work.
--
-- Items move with the game's own MoveItem, a single transfer call rather than a remove followed by
-- an add, and the amount is clamped to what the source slot actually holds and what the target can
-- actually take, both re-read immediately before the move.
--
-- Scope: single player, the co-op HOST, and (1.8.0) worlds you JOIN: a dedicated server or someone else's
-- co-op world. There the moves are requests to the server (see "Worlds you JOIN" below); only the player
-- needs the mod. WorkWhenJoined = false turns it off in joined worlds.

local VERSION = "1.8.2"
local TAG = "[StationFeeder] "
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

-- Worlds you JOIN (1.8.0) --------------------------------------------------------------------------
-- On a dedicated server or as a co-op guest this PC may not move items itself. It asks the server through the
-- game's own requests on the player's InventoryController, the ones a drag in the inventory screen sends, so the
-- server needs no mod. The answer comes back later (about 0.1 s for one move, about 0.8 s each in a burst), so
-- every move is sent alone and the mod waits until the counts it can read have changed.
--
-- Waiting in the middle of a job needs a coroutine, and UE4SS only answers game calls on its main Lua state:
-- inside a coroutine every one fails (sfprobe-1012: 60 of 60 reads nil). Every game call in this file sits
-- inside pcall(function() ... end), so while the job runs `pcall` hands the function to the main loop, which
-- runs it there and resumes the job with the result. Hosts and solo never use any of this: their tick runs
-- straight on the main state, as it always has.
local rawpcall = pcall
local NET = { joined = false, pc = nil, job = nil, MOVE_WAIT = 2.5, TOGGLE_WAIT = 2.0 }
local JOB_CALL, JOB_WAIT = {}, {}
local function pcall(f, ...)
    local job = NET.job
    if job and coroutine.running() == job.co then return coroutine.yield(JOB_CALL, f, ...) end
    return rawpcall(f, ...)
end
-- print is UE4SS's and fails inside the job like every game call (run sf180-1012: a log line killed the job
-- right after the top-up, so no panel came up). So log() goes through pcall as well.
do
    local rawlog = log
    log = function(msg) pcall(rawlog, msg) end
end

-- Wait until pred() is true, at most `seconds`. Returns whether it became true. Outside a job (host, solo)
-- it is a single check.
local function netWait(pred, seconds)
    local job = NET.job
    if job and coroutine.running() == job.co then return coroutine.yield(JOB_WAIT, pred, seconds) end
    local ok, v = rawpcall(pred)
    return ok and v == true
end

-- Runs on the main state. Returns an error message if the job died with one.
local function jobPump()
    local job = NET.job
    if not job then return nil end
    local args = job.args or { n = 0 }
    if job.pred then
        local ok, v = rawpcall(job.pred)
        local done = ok and v == true
        if not done and os.clock() < job.waitEnd then return nil end
        job.pred, job.waitEnd = nil, nil
        args = { n = 1, done }
    end
    job.args = nil
    while true do
        local res = table.pack(coroutine.resume(job.co, table.unpack(args, 1, args.n)))
        if not res[1] then NET.job = nil; return tostring(res[2]) end
        if coroutine.status(job.co) == "dead" then NET.job = nil; return nil end
        if res[2] == JOB_CALL then
            args = table.pack(rawpcall(res[3], table.unpack(res, 4, res.n)))
        elseif res[2] == JOB_WAIT then
            job.pred, job.waitEnd = res[3], os.clock() + (tonumber(res[4]) or 1)
            return nil
        else
            NET.job = nil
            return "job yielded something unknown"
        end
    end
end

-- One transfer of `amount` from (src, slot) to (dst, to). Host and solo: the game's own MoveItem, done when it
-- returns. Joined: a request to the server, then a wait for the result.
local function netMove(src, slot, dst, to, pawn, amount)
    if not NET.joined then
        pcall(function() src:MoveItem(slot, dst, to, pawn, amount) end)
        return
    end
    local ic = nil
    pcall(function() ic = NET.pc.BP_Components_InventoryController end)
    local sName, tName, before, dBefore = nil, nil, nil, nil
    pcall(function() before = src:GetNumItemsInSlot(slot) end)
    pcall(function() sName = src:GetItemFromSlot(slot).ItemData:GetFullName() end)
    if type(before) ~= "number" or before <= 0 or not sName then return end
    -- The server checks nothing about the target slot. A split onto a slot holding a DIFFERENT item pushes
    -- that item out, and from a one-slot fuel inventory it lands on the ground (sfprobe-1012, 2 of 2 runs).
    -- So: only into an empty slot or a stack of the same item, read right now.
    local occupiedBy = nil
    pcall(function()
        local ti = dst:GetItemFromSlot(to)
        if ti and ti:IsValid() then occupiedBy = ti.ItemData:GetFullName() end
    end)
    if occupiedBy and occupiedBy ~= sName then return end
    pcall(function() dBefore = dst:GetNumItemsInSlot(to) end)
    local whole = amount >= before
    local sent = pcall(function()
        if whole then ic:MoveItemBetweenInventories(src, slot, dst, to)
        else ic:SplitAndPutStack(src, slot, amount, dst, to) end
    end)
    if not sent then return end
    -- Both ends, so the "left the chest but did not arrive" check after a move compares settled numbers.
    netWait(function()
        return src:GetNumItemsInSlot(slot) ~= before and dst:GetNumItemsInSlot(to) ~= dBefore
    end, NET.MOVE_WAIT)
end

local cfg = {
    Enabled            = true,
    FeedMode           = "topup",  -- "topup" = refill what is already in the slots (default)
                                   -- "recipe" = fill a recipe the chests can supply completely
    FeedResources      = true,     -- the station's ingredient slots
    FeedFuel           = true,     -- the station's fuel slots
    Radius             = 0,        -- metres. 0 = the game's own linked-storage radius (30 m)
    SkipLockedChests   = true,     -- leave locked and privately-owned chests alone
    WorkWhenJoined     = true,     -- worlds you join (dedicated server, co-op guest). Replaces AllowAsClient (1.7.x)
    RememberLastLoad   = true,     -- top-up: refill a station that ran dry with what was last in it
    KeepOne            = false,    -- never take the last one of an item out of your chests
    ShowPanel          = true,     -- recipe panel beside the station window
    PanelUsesBackpack  = true,     -- panel LOAD buttons may also take from the backpack (clicks only)
    ReturnLeftovers    = true,     -- LOAD of a different recipe moves the old items back to chests
    DefaultQuantity    = "last",    -- "max" or "last" (the station's last quantity)
    PanelKeys          = true,     -- Left/Right change the quantity, Enter = LOAD & START
    PanelColumns       = 6,        -- recipe tiles per row
    PanelX             = 1380,     -- panel position inside the station window, 1920x1080 UI units
    PanelY             = 57,
    Verbose            = false,
}

local DEFAULT_RADIUS_UU = 3000.0   -- InventorySettings.LinkedStorageRadius, read live below
local MAX_CHESTS        = 40       -- ceiling so one pass can never walk a whole mega-base

-- Helpers ------------------------------------------------------------------------------------------

local function valid(o)
    if not o then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v
end

local function full(o)
    local ok, n = pcall(function() return o:GetFullName() end)
    return ok and tostring(n) or "?"
end

local function shortName(o)
    return (full(o):match("([%w_]+)$")) or "item"
end

-- Bounded class-chain test. The walk STOPS at Object: UE4SS has no null guard on GetSuperStruct
-- past the root and walking off the end kills the Lua state.
local function isA(o, className)
    if not valid(o) then return false end
    local cls = nil
    pcall(function() cls = o:GetClass() end)
    local level = 0
    while valid(cls) and level < 10 do
        local n = "?"
        pcall(function() n = cls:GetFName():ToString() end)
        if n == className then return true end
        if n == "Object" then return false end
        local sup = nil
        pcall(function() sup = cls:GetSuperStruct() end)
        if not valid(sup) then return false end
        cls = sup
        level = level + 1
    end
    return false
end

local function modRoot()
    local src = (debug.getinfo(1, "S").source or ""):gsub("^@", "")
    local dir = src:match("^(.*)[/\\][^/\\]*$")
    if not dir then return nil end
    return (dir:match("^(.*)[/\\][^/\\]*$"))
end

local function clampCfg()
    if type(cfg.PanelColumns) ~= "number" then cfg.PanelColumns = 6 end
    cfg.PanelColumns = math.max(4, math.min(8, math.floor(cfg.PanelColumns)))
    if type(cfg.PanelX) ~= "number" then cfg.PanelX = 1380 end
    if type(cfg.PanelY) ~= "number" then cfg.PanelY = 57 end
    local q = tostring(cfg.DefaultQuantity):lower()
    if q ~= "max" and q ~= "last" then q = "max" end
    cfg.DefaultQuantity = q
    if type(cfg.Radius) ~= "number" or cfg.Radius < 0 then cfg.Radius = 0 end
    if cfg.Radius > 200 then cfg.Radius = 200 end
    local m = tostring(cfg.FeedMode):lower()
    if m ~= "topup" and m ~= "recipe" then m = "topup" end
    cfg.FeedMode = m
end

local function loadConfig()
    local root = modRoot()
    if not root then log("could not locate mod folder, using defaults"); return end
    local path = root .. "\\config.txt"
    local f = io.open(path, "r")
    if not f then log("no config.txt at " .. path .. ", using defaults"); return end
    for line in f:lines() do
        line = line:gsub("^%s+", ""):gsub("%s+$", "")
        if line ~= "" and line:sub(1, 1) ~= "#" then
            local k, v = line:match("^([%w_]+)%s*=%s*(.+)$")
            if k and v then v = v:gsub("%s*[#;].*$", "") end
            if k and v and cfg[k] ~= nil then
                if type(cfg[k]) == "boolean" then
                    cfg[k] = (v:lower() == "true" or v == "1")
                elseif type(cfg[k]) == "string" then
                    cfg[k] = v:gsub("^%s+", ""):gsub("%s+$", "")
                else
                    local n = tonumber(v)
                    if n then cfg[k] = n else log("bad value for " .. k .. ": " .. v) end
                end
            elseif k then
                log("unknown config key ignored: " .. k)
            end
        end
    end
    f:close()
    clampCfg()
    log("config loaded from " .. path)
end

loadConfig()

-- The panel rules (recipes.lua, pure Lua). The whole mod needs it: memory lines and "keep one" live there.
local R = nil
do
    local root = modRoot()
    local chunk = root and loadfile(root .. "\\Scripts\\recipes.lua")
    local okR, t = false, nil
    if chunk then okR, t = pcall(chunk) end
    if okR and type(t) == "table" then R = t end
end
if not R then
    log("Scripts\\recipes.lua is missing or broken; reinstall the mod. Station Feeder is off.")
    return
end

-- The most a chest pull may take of one item. nil = no limit (1.4.0 behavior). 0 = take nothing.
-- With KeepOne the last one of the item stays in your chests.
local function chestLimit(total)
    if not cfg.KeepOne then return nil end
    return R.chestAvail(total, true)
end

-- The local, in-world player controller. FindAllOf walks every object in the game (about 50 ms on
-- the game thread), so it is cached and re-scanned at most every 3 seconds.
local cachedPC, nextPCScan = nil, 0
local function localPC()
    if cachedPC and valid(cachedPC) then
        local okL, isLocal = pcall(function() return cachedPC:IsLocalController() end)
        if okL and isLocal then return cachedPC end
    end
    cachedPC = nil
    local now = os.clock()
    if now < nextPCScan then return nil end
    nextPCScan = now + 3
    local ok, all = pcall(FindAllOf, "PlayerController")
    if not ok or not all then return nil end
    for _, pc in ipairs(all) do
        if valid(pc) then
            local okL, isLocal = pcall(function() return pc:IsLocalController() end)
            if not full(pc):find("MainMenu", 1, true) and okL and isLocal then cachedPC = pc; return pc end
        end
    end
    return nil
end

-- The station UI's own API object. This is the trigger: its ProcessingStationComponent is empty
-- until the player opens a station, and fills the moment they do.
local cachedAPI, nextAPIScan = nil, 0
local function stationAPI()
    if valid(cachedAPI) then return cachedAPI end
    cachedAPI = nil
    local now = os.clock()
    if now < nextAPIScan then return nil end
    nextAPIScan = now + 3
    local hud = nil
    pcall(function() hud = FindFirstOf("HUDUISubsystem") end)
    if valid(hud) then
        local a = nil
        pcall(function() a = hud.ProcessingStationAPI end)
        if valid(a) then cachedAPI = a; return a end
    end
    local a2 = nil
    pcall(function() a2 = FindFirstOf("ProcessingStationUIAPI") end)
    if valid(a2) then cachedAPI = a2; return a2 end
    return nil
end

-- The game's own linked-storage radius, so the default matches vanilla rather than a number I chose.
local radiusUU = nil
local function linkRadius()
    if cfg.Radius and cfg.Radius > 0 then return cfg.Radius * 100.0 end
    if radiusUU then return radiusUU end
    -- StaticFindObject can hand back a non-nil INVALID object, so a bare nil check is not enough.
    local s = nil
    pcall(function() s = StaticFindObject("/Script/Dominion.Default__InventorySettings") end)
    if valid(s) then
        local v = nil
        pcall(function() v = s.LinkedStorageRadius end)
        if type(v) == "number" and v > 0 then radiusUU = v; return v end
    end
    radiusUU = DEFAULT_RADIUS_UU
    return radiusUU
end

-- Chests -------------------------------------------------------------------------------------------
-- LinkedInventoryComponent exists only on containers the game treats as linkable storage, and the
-- owner must also be a BaseBuildingActor, so gravestones and other container families cannot be
-- drained. The player's own backpack has neither, which is the backbone of the no-backpack promise.
--
-- OWNERSHIP: the component is OwnershipComponent and the only readable flag is bIsPrivatelyOwned.
-- There is NO readable "is this mine" bool anywhere in the game (privacy is keyed on a character
-- GUID), so a private chest is skipped outright rather than guessed at. An earlier build read
-- `BP_Components_Ownership.bIsOwnedByLocalPlayer`; neither name exists, so both reads returned fake
-- handles and every private chest was silently drained.
local skippedLocked, skippedPrivate, ownerUnreadable, truncated = 0, 0, 0, 0
local function nearbyChests(origin)
    skippedLocked, skippedPrivate, ownerUnreadable, truncated = 0, 0, 0, 0
    local found = {}
    local r = linkRadius()
    local r2 = r * r
    local ok, comps = pcall(FindAllOf, "LinkedInventoryComponent")
    if not ok or not comps then return {} end
    for _, c in ipairs(comps) do
        if valid(c) then
            local owner = nil
            pcall(function() owner = c:GetOwner() end)
            if valid(owner) and not full(owner):find("Default__", 1, true)
               and isA(owner, "BaseBuildingActor") then
                local loc = nil
                pcall(function() loc = owner:K2_GetActorLocation() end)
                if loc and origin then
                    local dx, dy, dz = loc.X - origin.X, loc.Y - origin.Y, loc.Z - origin.Z
                    local d2 = dx * dx + dy * dy + dz * dz
                    if d2 <= r2 then
                        local skip = false
                        if cfg.SkipLockedChests then
                            local locked = nil
                            pcall(function() locked = c.bIsLocked end)
                            if locked == true then skip = true; skippedLocked = skippedLocked + 1 end
                            if not skip then
                                local oc = nil
                                pcall(function() oc = owner.OwnershipComponent end)
                                if valid(oc) then
                                    local priv = nil
                                    pcall(function() priv = oc.bIsPrivatelyOwned end)
                                    if priv == true then skip = true; skippedPrivate = skippedPrivate + 1 end
                                else
                                    -- A game patch renaming this component is exactly what made the
                                    -- previous build drain private chests while looking healthy.
                                    ownerUnreadable = ownerUnreadable + 1
                                end
                            end
                        end
                        if not skip then
                            local inv = nil
                            pcall(function() inv = owner.BP_Components_WorldItemInventory end)
                            if valid(inv) then found[#found + 1] = { inv = inv, d2 = d2 } end
                        end
                    end
                end
            end
        end
    end
    -- Nearest first, so a base with more chests than the cap always reads the same ones. Truncating
    -- in FindAllOf order would make "sometimes it finds my copper" a real complaint.
    table.sort(found, function(a, b) return a.d2 < b.d2 end)
    if #found > MAX_CHESTS then truncated = #found - MAX_CHESTS end
    local out = {}
    for i = 1, math.min(#found, MAX_CHESTS) do out[i] = found[i].inv end
    return out
end

-- Build the set of items a station accepts, keyed by full object name. UObject userdata does not
-- compare with ==, so names are the only reliable identity here.
local function acceptSet(arr)
    local set, n = {}, nil
    if arr == nil then return set end
    pcall(function() n = arr:GetArrayNum() end)
    if type(n) ~= "number" or n <= 0 then return set end
    for i = 1, n do
        local e = nil
        pcall(function() e = arr[i] end)
        local ee = e
        pcall(function() ee = e:get() end)
        if valid(ee) then set[full(ee)] = true end
    end
    return set
end

local function slotCount(inv)
    local m = 0
    pcall(function() m = inv.MaxSlotCount end)
    if type(m) ~= "number" or m <= 0 or m > 2000 then return 0 end
    return m
end

-- Every occupied slot of an inventory, as { slot = i, data = ItemData, count = n }.
local function occupied(inv)
    local out = {}
    if not valid(inv) then return out end            -- checked once, not once per slot
    for i = 0, slotCount(inv) - 1 do
        local it = nil
        local okI = pcall(function() it = inv:GetItemFromSlot(i) end)
        if okI and valid(it) then
            local d, n = nil, 0
            pcall(function() d = it.ItemData end)
            pcall(function() n = inv:GetNumItemsInSlot(i) end)
            if valid(d) and type(n) == "number" and n > 0 then
                out[#out + 1] = { slot = i, data = d, count = n }
            end
        end
    end
    return out
end

-- How much of an item the chests hold, and where.
local function chestStacks(chests)
    local byItem = {}
    for _, inv in ipairs(chests) do
        for _, s in ipairs(occupied(inv)) do
            local key = full(s.data)
            local list = byItem[key]
            if not list then list = { data = s.data, total = 0, stacks = {} }; byItem[key] = list end
            list.total = list.total + s.count
            list.stacks[#list.stacks + 1] = { inv = inv, slot = s.slot }
        end
    end
    return byItem
end

-- Move as much of one item as will fit, from the chests into a target inventory. Returns how many
-- ACTUALLY arrived, measured at the destination rather than assumed from the request.
--
-- Everything is re-read immediately before the move, because the snapshot in `stacks` was taken
-- before any transfer in this pass and an item can be both an accepted resource and an accepted
-- fuel, so the same stack can be visited twice.
-- `limit` (optional) caps the total moved (the recipe panel's quantity, "keep one"). nil = all that fits,
-- 0 or less = nothing. `from` names the source in the loss warning (default "the chests").
local function pullItem(targetInv, itemData, stacks, pawn, limit, from)
    if not valid(targetInv) then return 0 end
    if type(limit) == "number" and limit <= 0 then return 0 end
    local budget = (type(limit) == "number" and limit > 0) and limit or nil
    local key = full(itemData)
    local cap = nil
    pcall(function() cap = itemData.MaxStackSize end)
    if type(cap) ~= "number" or cap <= 0 then cap = nil end

    -- nil, NOT 0, when the read fails. Reporting a failed read as zero lets the mod claim it moved
    -- the station's whole holding, or claim it moved nothing right after draining a chest.
    local function held()
        local n = nil
        local ok = pcall(function() n = targetInv:GetNumItemsByData(itemData) end)
        if not ok then return nil end
        return tonumber(n)
    end

    -- What the chests hold, so a stack that LEAVES a chest without ARRIVING can be noticed. Items
    -- vanishing is the one failure this mod must never be silent about.
    local function sourceTotal()
        local t, seen = 0, {}
        for _, s in ipairs(stacks) do
            if valid(s.inv) then
                local nm = full(s.inv)
                if not seen[nm] then
                    seen[nm] = true
                    local n = nil
                    local ok = pcall(function() n = s.inv:GetNumItemsByData(itemData) end)
                    if not ok or type(n) ~= "number" then return nil end
                    t = t + n
                end
            end
        end
        return t
    end

    local function slotRoom(i)
        if not cap then return nil end
        local n = nil
        local ok = pcall(function() n = targetInv:GetNumItemsInSlot(i) end)
        if not ok or type(n) ~= "number" then return nil end
        return cap - n
    end

    -- One transfer. Returns the number that left the source slot, or 0 if nothing could be moved.
    local function tryOneMove(s)
        -- Re-read the source slot: both the item AND how much of it is actually there.
        local it = nil
        local okI = pcall(function() it = s.inv:GetItemFromSlot(s.slot) end)
        local amount = 0
        if okI and valid(it) then
            local d = nil
            pcall(function() d = it.ItemData end)
            if valid(d) and full(d) == key then
                local n = nil
                pcall(function() n = s.inv:GetNumItemsInSlot(s.slot) end)
                amount = tonumber(n) or 0
            end
        end
        if amount <= 0 then return 0 end
        if budget then
            if budget <= 0 then return 0 end
            if amount > budget then amount = budget end
        end

        -- Inventory-wide room, so a full chest stack against a nearly-full station moves the part
        -- that fits instead of the all-or-nothing CanAddItemByData answer.
        local space = nil
        pcall(function() space = targetInv:GetSpaceAvailableForItemByData(itemData) end)
        if type(space) == "number" and amount > space then amount = space end
        if amount <= 0 then return 0 end

        local room = nil
        pcall(function() room = targetInv:CanAddItemByData(itemData, amount) end)
        if room ~= true then return 0 end

        -- Scan EVERY slot. Stopping at the first slot holding this item is what made the first
        -- version of this fix under-deliver: with a full slot 0 and an empty slot 1 it found the
        -- match, never saw the empty slot, and gave up with 90 ore still in the chest.
        local matchWithRoom, anyMatch, firstEmpty = nil, nil, nil
        for i = 0, slotCount(targetInv) - 1 do
            local ti = nil
            local okT = pcall(function() ti = targetInv:GetItemFromSlot(i) end)
            if okT and valid(ti) then
                local td = nil
                pcall(function() td = ti.ItemData end)
                if valid(td) and full(td) == key then
                    if anyMatch == nil then anyMatch = i end
                    local r = slotRoom(i)
                    -- With no readable stack cap, treat a matching slot as usable and let the
                    -- inventory-wide checks above carry the risk, as they did before.
                    if matchWithRoom == nil and (r == nil or r > 0) then matchWithRoom = i end
                end
            elseif okT and firstEmpty == nil then
                -- Only a slot we could READ counts as empty. A slot whose read threw is not a
                -- slot we may write into.
                firstEmpty = i
            end
        end
        -- Merge into a part-filled stack first so slots are not wasted, else start a new one.
        local dst = matchWithRoom or firstEmpty or anyMatch
        if dst == nil then return 0 end

        -- THE ROOM CHECKS ABOVE ARE INVENTORY-WIDE. MoveItem targets ONE SLOT. A station slot
        -- holding 90 of a 99 stack has room for 9 while the inventory reports room for 108, so
        -- without this the surplus is handed to native code whose overflow behaviour has never
        -- been verified here. Clamp to the slot; the caller loops and re-targets the remainder.
        if cap then
            local sr = slotRoom(dst)
            -- Could not measure the destination slot: do not guess, and do not move.
            if sr == nil or sr <= 0 then return 0 end
            if amount > sr then amount = sr end
        end
        if amount <= 0 or not valid(pawn) then return 0 end

        local srcBefore = nil
        pcall(function() srcBefore = s.inv:GetNumItemsInSlot(s.slot) end)
        netMove(s.inv, s.slot, targetInv, dst, pawn, amount)
        local srcAfter = nil
        pcall(function() srcAfter = s.inv:GetNumItemsInSlot(s.slot) end)
        if type(srcBefore) == "number" and type(srcAfter) == "number" then
            local left = srcBefore - srcAfter
            if left > 0 then
                if budget then budget = budget - left end
                return left
            end
        end
        return 0
    end

    local before, srcBefore = held(), sourceTotal()

    for _, s in ipairs(stacks) do
        if not valid(targetInv) then break end
        -- A dead chest skips to the next stack rather than abandoning the rest of them.
        if valid(s.inv) then
            -- One chest stack can need several moves: a part-filled slot takes what fits and the
            -- remainder goes to the next slot. Bounded by the slot count so it can never spin.
            for _ = 1, slotCount(targetInv) + 1 do
                if tryOneMove(s) <= 0 then break end
            end
        end
    end

    local after, srcAfter = held(), sourceTotal()
    if before == nil or after == nil then
        -- The caller must not print a number this function cannot stand behind.
        return nil
    end
    local gained = after - before
    if gained < 0 then gained = 0 end
    if type(srcBefore) == "number" and type(srcAfter) == "number" then
        local lost = srcBefore - srcAfter
        if lost ~= gained then
            log("WARNING: " .. lost .. " x " .. shortName(itemData) ..
                " left " .. (from or "the chests") .. " but " .. gained .. " arrived in the station. " ..
                "Please report this with your UE4SS.log.")
        end
    end
    return gained
end

-- Recipe mode: the first recipe the chests plus the station can supply COMPLETELY, and that the
-- station has the free slots to hold. A recipe already partly loaded wins, so reopening a station
-- you set up keeps it on the same job.
local function chooseRecipe(ps, res, byItem, accepts)
    local rc = nil
    pcall(function() rc = ps.RecipesCache end)
    local n = nil
    if rc ~= nil then pcall(function() n = rc:GetArrayNum() end) end
    if type(n) ~= "number" or n <= 0 then return nil end

    local occ = occupied(res)
    local inStation = {}
    for _, s in ipairs(occ) do
        local k = full(s.data)
        inStation[k] = (inStation[k] or 0) + s.count
    end
    local slots = slotCount(res)

    local best, bestScore = nil, -1
    for i = 1, n do
        local e = nil
        pcall(function() e = rc[i] end)
        local r = e
        pcall(function() r = e:get() end)
        if valid(r) then
            local ins = nil
            pcall(function() ins = r.ItemsConsumed end)
            local inn = nil
            if ins ~= nil then pcall(function() inn = ins:GetArrayNum() end) end
            if type(inn) == "number" and inn > 0 then
                local want, ok, score = {}, true, 0
                for j = 1, inn do
                    local c1 = nil
                    pcall(function() c1 = ins[j] end)
                    local cc = c1
                    pcall(function() cc = c1:get() end)
                    local it, ct = nil, nil
                    pcall(function() it = cc.ItemData end)
                    pcall(function() ct = cc.Count end)
                    if not valid(it) or type(ct) ~= "number" then ok = false break end
                    local k = full(it)
                    -- An ingredient the station will not accept cannot be delivered, and feeding
                    -- the rest would leave exactly the half-load this function exists to avoid.
                    if accepts and not accepts[k] then ok = false break end
                    -- inStation counts the station's own slots, byItem counts the chests. The
                    -- station's Resources has no LinkedInventoryComponent so it can never be in
                    -- both: no double counting.
                    local have = (inStation[k] or 0) +
                        R.chestAvail((byItem[k] and byItem[k].total) or 0, cfg.KeepOne)
                    if have < ct then ok = false break end
                    if inStation[k] then score = score + 1 end
                    want[k] = it        -- a set keyed by name, so a repeated ingredient counts once
                end
                -- Count the slots this recipe still NEEDS against the slots actually free.
                -- Counting "blocked" slots instead assumed one slot per wanted item, which is
                -- wrong when one wanted item sits in two part-stacks: two slots of copper made
                -- blocked = 0, Bronze Bar was accepted, and tin then had nowhere to go.
                if ok then
                    local newItems = 0
                    for k in pairs(want) do
                        if not inStation[k] then newItems = newItems + 1 end
                    end
                    if newItems > slots - #occ then ok = false end
                end
                if ok and score > bestScore then
                    local need = {}
                    for _, it in pairs(want) do need[#need + 1] = it end
                    best, bestScore = need, score
                end
            end
        end
    end
    return best
end

-- Station name -> we have already told the player that station is empty. Declared HERE, above
-- feedStation: a Lua local is invisible to code written before it, and a reference above the
-- declaration silently reads a nil global instead.
local toldEmpty = {}

-- Station memory -----------------------------------------------------------------------------------
-- Top-up only refills what is already sitting in a station, so a station that ran completely dry
-- had nothing left to recognise and was left empty. The mod now remembers what was last in each
-- station (while you have it open, sampled twice a second) and, when you open one that has run dry,
-- refills it with those same items. It never touches a running station and it never chooses for you:
-- it only repeats what you last put in yourself.
--
-- A station is identified by its class plus its position. Object names change on every load, and
-- placed buildings cannot move, so class + position is stable; MATCH_UU only absorbs float rounding.
-- The memory lives outside the mod folder so it survives mod updates, and is plain text, safe to delete.
local MEMORY_FILE = nil
do
    local base = os.getenv("LOCALAPPDATA")
    if base and base ~= "" then MEMORY_FILE = base .. "\\RSDragonwilds\\Saved\\StationFeeder-memory.txt" end
end
local MATCH_UU = 50
local memory = {}          -- { cls, x, y, z, res = {full names}, fuel = {full names}, rec = recipe path, qty = n }

local function loadMemory()
    memory = {}
    if not MEMORY_FILE then return end
    local f = io.open(MEMORY_FILE, "r")
    if not f then return end
    for line in f:lines() do
        -- 1.4.0 lines (6 fields) and 1.6.0 lines (plus the panel recipe and quantity) both load.
        local m = R.parseMemoryLine(line)
        if m then memory[#memory + 1] = m end
    end
    f:close()
end

local function saveMemory()
    if not MEMORY_FILE then return false end
    local f = io.open(MEMORY_FILE, "w")
    if not f then log("could not write " .. MEMORY_FILE .. ", stations will not be remembered"); return false end
    f:write("# Station Feeder: what was last in each processing station. Safe to delete.\n")
    for _, m in ipairs(memory) do
        f:write(R.formatMemoryLine(m) .. "\n")
    end
    f:close()
    return true
end

local function findMemory(cls, loc)
    if not loc then return nil, nil end
    for i, m in ipairs(memory) do
        if m.cls == cls then
            local dx, dy, dz = m.x - loc.X, m.y - loc.Y, m.z - loc.Z
            if dx * dx + dy * dy + dz * dz <= MATCH_UU * MATCH_UU then return m, i end
        end
    end
    return nil, nil
end

loadMemory()

-- One open station at a time. Holds plain strings and numbers only, never game objects, so it is
-- safe to commit after the screen (or the whole world) has gone away.
local session = nil

local function namesIn(inv)
    local out, seen = {}, {}
    for _, s in ipairs(occupied(inv)) do
        local k = full(s.data)
        if k ~= "?" and not seen[k] then seen[k] = true; out[#out + 1] = k end
    end
    return out
end

local function stationInvs(api, ps)
    local resInv, fuelInv = nil, nil
    pcall(function() resInv = api.StationIngredientsInventory end)
    pcall(function() fuelInv = api.StationFuelInventory end)
    if not valid(resInv) then pcall(function() resInv = ps.Resources end) end
    if not valid(fuelInv) then pcall(function() fuelInv = ps.Fuel end) end
    return resInv, fuelInv
end

-- How many of an item the player is carrying, across the three inventories on the controller.
local PLAYER_INVS = { "BP_Components_Inventory", "BP_Components_PersonalInventory", "BP_Components_Loadout" }
local function playerCount(pc, data)
    if not valid(pc) or not valid(data) then return nil end
    local total, any = 0, false
    for _, name in ipairs(PLAYER_INVS) do
        local inv = nil
        pcall(function() inv = pc[name] end)
        if valid(inv) then
            local n = nil
            pcall(function() n = inv:GetNumItemsByData(data) end)
            if type(n) == "number" then total = total + n; any = true end
        end
    end
    return any and total or nil
end

local function sampleSession(pc, api, ps, force)
    if not session then return end
    local now = os.clock()
    if not force and now < session.nextSample then return end
    session.nextSample = now + 0.5
    local resInv, fuelInv = stationInvs(api, ps)
    -- Per item, not per station. An item that disappears from the station is only dropped from
    -- memory if it turned up in YOUR inventories (you took it out). One that was simply used up,
    -- like tin running out before copper in a bronze furnace, or fuel burning down, stays remembered.
    local anyNow = false
    for _, side in ipairs({ { key = "res", inv = resInv }, { key = "fuel", inv = fuelInv } }) do
        local present, order = {}, {}
        for _, sl in ipairs(occupied(side.inv)) do
            local k = full(sl.data)
            if k ~= "?" and not present[k] then present[k] = sl.data; order[#order + 1] = k end
        end
        local kept = {}
        for _, k in ipairs(session[side.key]) do
            if present[k] then
                kept[#kept + 1] = k
            else
                local e = session.info[k]
                local nowCarried = e and playerCount(pc, e.data) or nil
                local tookOut = e and type(nowCarried) == "number" and type(e.carried) == "number"
                                and nowCarried > e.carried
                if tookOut then session.removedByHand = true else kept[#kept + 1] = k end
            end
        end
        local inKept = {}
        for _, k in ipairs(kept) do inKept[k] = true end
        -- Something new went in after you took items out by hand: you are switching what this
        -- station makes (bronze to iron, say), so the old items that are no longer in it go.
        local switching = false
        if session.removedByHand then
            for _, k in ipairs(order) do if not inKept[k] then switching = true end end
        end
        if switching then
            kept, inKept = {}, {}
            session.rec, session.qty = nil, nil   -- 1.7: no longer the panel batch, so no batch cap either
        end
        for _, k in ipairs(order) do
            if not inKept[k] then kept[#kept + 1] = k; inKept[k] = true end
            -- Baseline for "did you take it out": what you carry while it is still in the station.
            session.info[k] = { data = present[k], carried = playerCount(pc, present[k]) }
            anyNow = true
        end
        session[side.key] = kept
    end
    if anyNow then session.hadItems = true end
    -- Forget the station when it now holds nothing and you took items out of it by hand during this
    -- visit. A station that emptied by itself (processing, fuel burning) is never forgotten.
    if anyNow then
        session.emptied = false
    else
        session.emptied = session.hadItems and session.removedByHand
    end
end

local function startSession(pc, api, ps)
    session = nil
    if not cfg.RememberLastLoad then return end
    local owner, loc = nil, nil
    pcall(function() owner = ps:GetOwner() end)
    if not valid(owner) then return end
    pcall(function() loc = owner:K2_GetActorLocation() end)
    if not loc then return end
    local cls = full(owner):match("([%w_]+)_C_%d+") or "station"
    -- Start from what is already remembered, so an ingredient the chests could not supply this
    -- time is not silently dropped from memory when the visit is saved.
    local m = findMemory(cls, loc)
    local res, fuel = {}, {}
    if m then
        for _, k in ipairs(m.res) do res[#res + 1] = k end
        for _, k in ipairs(m.fuel) do fuel[#fuel + 1] = k end
    end
    session = { cls = cls,
                x = loc.X, y = loc.Y, z = loc.Z, res = res, fuel = fuel,
                rec = m and m.rec or nil, qty = m and m.qty or nil,
                info = {}, removedByHand = false,
                hadItems = false, emptied = false, nextSample = 0 }
    sampleSession(pc, api, ps, true)
end

local function commitSession()
    local s = session
    session = nil
    if not s or not cfg.RememberLastLoad then return end
    local m, i = findMemory(s.cls, { X = s.x, Y = s.y, Z = s.z })
    if s.emptied then
        if m then
            table.remove(memory, i)
            saveMemory()
            log(s.cls .. " emptied by hand, so it will no longer be refilled from memory")
        end
        return
    end
    if #s.res == 0 and #s.fuel == 0 then return end
    local same = m and table.concat(m.res, ";") == table.concat(s.res, ";")
                   and table.concat(m.fuel, ";") == table.concat(s.fuel, ";")
                   and m.rec == s.rec and m.qty == s.qty
    if same then return end
    if m then
        m.res, m.fuel, m.rec, m.qty = s.res, s.fuel, s.rec, s.qty
    else
        memory[#memory + 1] = { cls = s.cls, x = s.x, y = s.y, z = s.z, res = s.res, fuel = s.fuel,
                                rec = s.rec, qty = s.qty }
    end
    if saveMemory() and cfg.Verbose then
        log(s.cls .. ": remembered " .. #s.res .. " ingredient(s) and " .. #s.fuel .. " fuel(s)")
    end
end

local function forgetAll()
    local n = #memory
    memory = {}
    session = nil
    saveMemory()
    log("forgot " .. n .. " remembered station(s)")
end

local readRecipes   -- defined with the recipe panel below; feedStation reads the last panel batch with it

-- One feed pass ------------------------------------------------------------------------------------
local function feedStation(pc, api, ps)
    local pawn = nil
    pcall(function() pawn = pc.Pawn end)
    if not valid(pawn) then return end          -- MoveItem takes it as Instigator
    local owner = nil
    pcall(function() owner = ps:GetOwner() end)
    if not valid(owner) then return end
    local origin = nil
    pcall(function() origin = owner:K2_GetActorLocation() end)
    if not origin then return end
    local stationName = full(owner):match("([%w_]+)_C_%d+") or "station"

    -- Prefer the UI API's inventories: they are what the open screen is showing. They are the same
    -- objects as the component's own (checked in game), so the fallback is equivalent, not a guess.
    local resInv, fuelInv = nil, nil
    pcall(function() resInv = api.StationIngredientsInventory end)
    pcall(function() fuelInv = api.StationFuelInventory end)
    if not valid(resInv) then pcall(function() resInv = ps.Resources end) end
    if not valid(fuelInv) then pcall(function() fuelInv = ps.Fuel end) end

    local chests = nearbyChests(origin)
    if cfg.Verbose then
        local extra = ""
        if skippedLocked + skippedPrivate > 0 then
            extra = string.format("  (skipped %d locked, %d private)", skippedLocked, skippedPrivate)
        end
        log(stationName .. ": " .. #chests .. " chest(s) within " ..
            math.floor(linkRadius() / 100) .. " m" .. extra)
    end
    -- Both of these are printed whether or not Verbose is on, because both look from the outside
    -- like "the mod just does not find my stuff".
    if truncated > 0 then
        log(stationName .. ": " .. #chests .. " nearest chests used, " .. truncated ..
            " more in range ignored (the cap is " .. MAX_CHESTS .. ")")
    end
    if ownerUnreadable > 0 then
        log(stationName .. ": could not read who owns " .. ownerUnreadable ..
            " chest(s), so private ones may not have been skipped. Please report this.")
    end
    if #chests == 0 then
        -- Say WHY, or a player whose chests are all private sees a mod that silently does nothing.
        if skippedLocked + skippedPrivate > 0 then
            log(stationName .. ": " .. (skippedLocked + skippedPrivate) ..
                " chest(s) in range were skipped as locked or private")
        end
        return
    end
    local byItem = chestStacks(chests)

    -- In top-up mode a station with nothing in either inventory is deliberately left alone, and
    -- that is the state most people meet first. Noted here, before anything is moved, so the
    -- report at the end can name the real reason instead of listing possibilities.
    local emptyStation = (cfg.FeedMode == "topup")
        and #occupied(resInv) == 0 and #occupied(fuelInv) == 0

    local moved, lines, unmeasured = 0, {}, false
    -- What this station was last loaded with (top-up mode only; recipe mode already fills empty
    -- stations by its own rule).
    local mem = nil
    if cfg.RememberLastLoad and cfg.FeedMode == "topup" then
        mem = findMemory(stationName, origin)
    end
    local fromMemory, missingRemembered = false, {}
    -- 1.7: a batch loaded from the panel is restocked only up to its own size (queue 1 bread, get 1 flour back,
    -- not a full stack). Items outside that recipe, and anything loaded by hand, top up as before.
    local batch = nil
    if mem and mem.rec and type(mem.qty) == "number" and mem.qty > 0 then
        for _, rec in ipairs(readRecipes(pc, ps)) do
            if rec.key == mem.rec then
                batch = {}
                for _, g in ipairs(rec.ings) do batch[g.key] = g.need * mem.qty end
                break
            end
        end
    end
    local function take(targetInv, itemData, what)
        local k = full(itemData)
        local entry = byItem[k]
        if not entry then return end
        -- Chests only, never the backpack. KeepOne leaves the last one of the item in the chests.
        local limit = chestLimit(entry.total)
        if batch and batch[k] and targetInv == resInv then
            local have = 0
            for _, sl in ipairs(occupied(resInv)) do if full(sl.data) == k then have = have + sl.count end end
            local room = math.max(0, batch[k] - have)
            limit = (type(limit) == "number") and math.min(limit, room) or room
        end
        if limit == 0 then return end
        local n = pullItem(targetInv, itemData, entry.stacks, pawn, limit)
        if n == nil then
            -- The transfer may well have happened; what failed is our ability to count it. Say so
            -- rather than printing a number, or reporting nothing after a real move.
            unmeasured = true
            return
        end
        if n > 0 then
            moved = moved + n
            lines[#lines + 1] = n .. " x " .. shortName(itemData) .. " -> " .. what
        end
    end

    -- An accepted-item list that could not be READ comes back empty, which looks exactly like
    -- "this station accepts nothing you have". Tell them apart so the player is not sent to
    -- rummage through chests over a broken read.
    local function acceptsFor(fieldName)
        local arr = nil
        local ok = pcall(function() arr = ps[fieldName] end)
        if not ok or arr == nil then
            log(stationName .. ": could not read the station's " .. fieldName ..
                " list, so nothing will be moved this time")
            return nil
        end
        return acceptSet(arr)
    end

    if cfg.FeedResources and valid(resInv) then
        local accepts = acceptsFor("AcceptedResources")
        if accepts == nil then accepts = {} end
        if cfg.FeedMode == "recipe" then
            local need = chooseRecipe(ps, resInv, byItem, accepts)
            if need then
                for _, item in ipairs(need) do
                    if accepts[full(item)] then take(resInv, item, "resources") end
                end
            elseif cfg.Verbose then
                log(stationName .. ": no recipe your chests can supply completely")
            end
        else
            -- Top up: only ever more of what is already in a slot. An empty station is left alone,
            -- which is the whole point - the mod never decides what a station should be making.
            local seen = {}
            for _, s in ipairs(occupied(resInv)) do
                local k = full(s.data)
                -- The same item can occupy two slots; pull for it once.
                if not seen[k] and accepts[k] then
                    seen[k] = true
                    take(resInv, s.data, "resources")
                end
            end
            -- Anything that was in this station last time but has run out since: bring it back.
            -- Only items the player put in themselves ever get here, so nothing is chosen for them.
            if mem then
                for _, k in ipairs(mem.res) do
                    if not seen[k] and accepts[k] then
                        seen[k] = true
                        if byItem[k] then
                            local before = moved
                            take(resInv, byItem[k].data, "resources")
                            if moved > before then fromMemory = true end
                        else
                            missingRemembered[#missingRemembered + 1] = k
                        end
                    end
                end
            end
        end
    end

    if cfg.FeedFuel and valid(fuelInv) then
        local accepts = acceptsFor("AcceptedFuelsIncludingRecipeOverrides")
        if accepts == nil then accepts = {} end
        local occ = occupied(fuelInv)
        if #occ > 0 then
            local seen = {}
            for _, s in ipairs(occ) do
                local k = full(s.data)
                if not seen[k] and accepts[k] then
                    seen[k] = true
                    take(fuelInv, s.data, "fuel")
                end
            end
        elseif mem and #mem.fuel > 0 then
            -- The fuel burned down to zero: refill it with the fuel this station was last given.
            for _, k in ipairs(mem.fuel) do
                if accepts[k] then
                    if byItem[k] then
                        local before = moved
                        take(fuelInv, byItem[k].data, "fuel")
                        if moved > before then fromMemory = true; break end
                    else
                        missingRemembered[#missingRemembered + 1] = k
                    end
                end
            end
        elseif cfg.FeedMode == "recipe" then
            -- Only recipe mode may pick a fuel for you; top-up mode never fills an empty slot.
            -- Sorted, because pairs() order is unspecified and an arbitrary choice between two
            -- accepted fuels would differ between sessions on an identical base.
            local keys = {}
            for key in pairs(byItem) do
                if accepts[key] and R.chestAvail(byItem[key].total, cfg.KeepOne) > 0 then keys[#keys + 1] = key end
            end
            table.sort(keys)
            if keys[1] then take(fuelInv, byItem[keys[1]].data, "fuel") end
        end
    end

    if moved > 0 then
        log(stationName .. ": moved " .. moved .. " item(s) from nearby chests" ..
            (fromMemory and " (including what it ran out of, from memory)" or ""))
        if cfg.Verbose then for _, l in ipairs(lines) do log("   " .. l) end end
    elseif unmeasured then
        log(stationName .. ": a transfer could not be counted, so the total above may be wrong")
    elseif mem and emptyStation then
        -- It remembers what goes in, the chests just do not have any of it right now.
        local names = {}
        for _, k in ipairs(missingRemembered) do names[#names + 1] = (k:match("([%w_]+)$")) or k end
        log(stationName .. " ran out, and none of what you last put in it is in the chests nearby" ..
            (#names > 0 and (" (" .. table.concat(names, ", ") .. ")") or ""))
    elseif emptyStation then
        -- The commonest first-run case, and the one the default mode deliberately does nothing
        -- about. Printed once per station whether or not Verbose is on: a silent mod looks broken.
        if not toldEmpty[stationName] then
            toldEmpty[stationName] = true
            log(stationName .. " is empty, so there is nothing to top up. Put what you want it to " ..
                "make into it once, and from then on it will restock itself.")
        end
    elseif cfg.Verbose then
        if cfg.FeedMode == "topup" then
            log(stationName .. ": nothing moved (either the station is full, or its slots hold " ..
                "nothing your chests can top up)")
        else
            log(stationName .. ": nothing in range that this station accepts")
        end
    end
end

-- Recipe panel -------------------------------------------------------------------------------------
-- Docked into the station window's own root canvas (WBP_ProcessingStation_MainPanel_C.WidgetTree.RootWidget),
-- right of the vanilla frame, in the station's own frame (WBP_Panel_Processing), so it opens, hides and closes
-- with the game's window. One MainPanel is shared by every station, so the panel is built ONCE and refilled.
--
--   STATION NAME / PULLS FROM BACKPACK + LINKED CHESTS
--   recipe tiles (icon + how many you can make; selected = gold; locked = "?")
--   ------------------------------------------------------------
--   RECIPE NAME  [icon]   "Makes 1 X - 8-12 s each"
--   REQUIREMENTS  [icon 116/99] ... [fuel 4/3]
--   QUANTITY  < 33 > ====o====  [MAX]
--   [ LOAD & START ] [ LOAD ] [ START / STOP ]
--
-- CRASH RULE (probe P6, 2026-09-28, exe +0x3952A59): creating buttons, styling them BEFORE they had a parent
-- and setting the slider's max in the frame it was parented crashed the game. So the build runs over three
-- ticks: (1) the frame is created and docked, (2) every widget is created INTO an already-placed parent, top
-- down, and nothing is configured, (3) the queued configuration (fonts, colors, sizes, labels, button styles,
-- slider range) runs. Fills and slider values only ever happen after that.
--
-- Clicks: one CommonButtonBase:HandleButtonClicked hook only RECORDS which of our buttons was clicked; the
-- work runs on the next tick. Icons come from the baked itemicons.lua table, never from an item's soft
-- pointer (UE4SS #1433). Texture handles are never kept between fills (a brush holds its own reference).

local GOLD  = { R = 0.91, G = 0.77, B = 0.48, A = 1.0 }
local CREAM = { R = 0.90, G = 0.87, B = 0.80, A = 1.0 }
local DIM   = { R = 0.55, G = 0.53, B = 0.50, A = 1.0 }
local RED   = { R = 0.90, G = 0.35, B = 0.28, A = 1.0 }
local RULE  = { R = 0.79, G = 0.64, B = 0.37, A = 0.45 }
local TILE, GAP, REQ_TILE = 64, 6, 52
local MAX_TILES, MAX_REQS = 36, 4          -- the last requirement tile (MAX_REQS + 1) is the fuel
local BTN_ROW_W = 436                      -- LOAD & START 210 + LOAD 100 + START 110 + gaps
local HOST_CLASS = "WBP_ProcessingStation_MainPanel_C"
local ALLCAPS = "/Game/UI/Common/WBP_DomAllCapsButton"
local FRAME_CLASSES = { "/Game/UI/Panels/WBP_Panel_Processing", "/Game/UI/Panels/WBP_Panel" }
local SLIDER_CLASS = "/Game/UI/Crafting/Craft/WBP_Crafting_Slider"
local PRIMARY_STYLE = "/Game/UI/Styles/Buttons/CUIS_CraftButtonStyle"      -- gold bar, dark text (probe P6)
local TEX_SLOT = "/Game/Art/UI/Common/T_Common_ItemSlotsBackground.T_Common_ItemSlotsBackground"
local TEX_HOT  = "/Game/Art/UI/Common/T_Common_ItemSlotsHighlight.T_Common_ItemSlotsHighlight"
local TEX_REQ  = "/Game/Art/UI/Craft/T_Craft_RequirementsSlot.T_Craft_RequirementsSlot"

local ITEMICONS = {}
pcall(function()
    local root = modRoot()
    local chunk = root and loadfile(root .. "\\Scripts\\itemicons.lua")
    local t = chunk and chunk()
    if type(t) == "table" then ITEMICONS = t end
end)

local function objPath(o)
    local f = full(o)
    return f:match("^%S+ (.+)$") or ""
end

-- Loaded fresh each time it is needed and never stored: a kept texture handle can go stale.
local function texture(path)
    if not path then return nil end
    local t = nil
    pcall(function() t = LoadAsset(path) end)
    local ok = false
    pcall(function() ok = t:IsValid() and t:GetClass():GetFName():ToString() == "Texture2D" end)
    return ok and t or nil
end

local function itemName(d)
    local nm = nil
    pcall(function() nm = d.Name:ToString() end)
    if type(nm) ~= "string" or nm == "" then nm = shortName(d) end
    return nm
end

local classCache = {}
local function loadClass(pkg)
    if classCache[pkg] ~= nil then return classCache[pkg] or nil end
    local asset = pkg:match("([^/]+)$")
    pcall(function() LoadAsset(pkg) end)
    local c = nil
    pcall(function() c = StaticFindObject(pkg .. "." .. asset .. "_C") end)
    classCache[pkg] = valid(c) and c or false
    return classCache[pkg] or nil
end

local umg = {}
local function construct(tree, name)
    local c = umg[name]
    if c == nil then
        pcall(function() c = StaticFindObject("/Script/UMG." .. name) end)
        if not valid(c) then c = false end
        umg[name] = c
    end
    if not c then return nil end
    local w = nil
    pcall(function() w = StaticConstructObject(c, tree) end)
    return valid(w) and w or nil
end

local function setText(tb, s) if tb then pcall(function() tb:SetText(FText(s)) end) end end
local function setColor(tb, c) if tb then pcall(function() tb:SetColorAndOpacity({ SpecifiedColor = c, ColorUseRule = 0 }) end) end end
-- ESlateVisibility: 0 Visible, 1 Collapsed, 3 HitTestInvisible, 4 SelfHitTestInvisible.
local function showBtn(w, on) if w then pcall(function() w:SetVisibility(on and 0 or 1) end) end end
local function showBox(w, on) if w then pcall(function() w:SetVisibility(on and 4 or 1) end) end end
local function vis(w, on) if w then pcall(function() w:SetVisibility(on and 3 or 1) end) end end

local P = {
    host = nil, hostName = nil,
    ui = nil, stage = nil,   -- "content" -> "config" -> "ready" ("broken" = gave up, said why once)
    acts = {},               -- our button's full name -> action
    btns = {},               -- 1.7.1: our buttons, for the controller (PAD below)
    click = nil,             -- the one click recorded by the hook, done on the next tick
    key = nil,               -- { act, t } from a panel key
    hooked = false,
    st = nil,                -- the open station: recipes, counts, selection, quantity
}

-- Controller (1.7.1, Nexus report 2026-10-06: "Pressing A on LOAD & START or load or start doesn't do
-- anything"). A pad's A never reaches the HandleButtonClicked hook below (CommonUI clicks from C++, and in the
-- station window A is an Enhanced Input action), so every panel button was dead on a pad. The panel is docked
-- INSIDE the station window's own canvas (buildFrame), but the game's pad navigation still never moved onto it
-- (in-game run c1006c), so explicit navigation links carry the pad in from the station's right-hand slots and
-- back (PAD.wire). Pad presses are read two ways, both routed through the same dispatch as a mouse click
-- (routeClick / doAction):
--   * selection: our buttons are made selectable once the game has built them, and a selected button with
--     no hook click is a pad press (Mod Menu 1.0.12 / Storage Search 2.1, measured in the pause menu);
--   * hover + A: pad navigation moves the hover onto our buttons, and A going down while one of them is
--     hovered (or seen hovered within 150 ms: a pad press clears the hover) is a press (the route Linked
--     Storage Stations uses in this same station window; proven in run c1006c). A tap is shorter than the
--     300 ms main tick, so A is sampled by a small loop that does nothing while the panel is closed.
-- One press seen both ways is done once (PAIR_S). A mouse click still wins and clears its own selection.
local PAD = { SAMPLE_MS = 50, PAIR_S = 0.8, STALE_S = 2.0, HOVER_KEEP_S = 0.15, hits = {}, aDown = nil, pc = nil,
              lastHit = nil, lastSel = nil, keyA = nil, errs = 0, takeErrs = 0,
              hov = nil,                 -- { name, t }: the last panel button seen hovered or focused (sampler)
              edges = nil, linked = false, target = nil, navSig = nil }   -- navigation links (PAD.wire)
pcall(function() PAD.keyA = FName("Gamepad_FaceButton_Bottom") end)

local warnedBuild = false
local function buildWarn(msg)
    if not warnedBuild then warnedBuild = true; log(msg .. "; the recipe panel is unavailable") end
end

-- Build helpers. Every widget is added to its (already placed) parent the moment it is created; all
-- configuration is queued with later() and runs a tick after the content exists.
local function add(parent, kind, w)
    if not (parent and w) then return nil end
    local s = nil
    if kind == "v" then pcall(function() s = parent:AddChildToVerticalBox(w) end)
    elseif kind == "h" then pcall(function() s = parent:AddChildToHorizontalBox(w) end)
    elseif kind == "o" then pcall(function() s = parent:AddChildToOverlay(w) end)
    else pcall(function() s = parent:AddChild(w) end) end
    return s
end
local function later(ui, fn) ui.queue[#ui.queue + 1] = fn end
local function prim(ui, cls, parent, kind)
    local w = construct(ui.tree, cls)
    if not w then return nil, nil end
    return w, add(parent, kind, w)
end
local function sizeBox(ui, parent, kind, W, H)
    local b, s = prim(ui, "SizeBox", parent, kind)
    if b then
        if W then later(ui, function() b:SetWidthOverride(W) end) end
        if H then later(ui, function() b:SetHeightOverride(H) end) end
    end
    return b, s
end
local function pad(ui, slot, l, t, r, b)
    if slot then later(ui, function() slot:SetPadding({ Left = l or 0, Top = t or 0, Right = r or 0, Bottom = b or 0 }) end) end
end
local function align(ui, slot, h, v)       -- 0 fill, 1 left/top, 2 center, 3 right/bottom
    if not slot then return end
    if h then later(ui, function() slot:SetHorizontalAlignment(h) end) end
    if v then later(ui, function() slot:SetVerticalAlignment(v) end) end
end
local function grow(ui, slot) if slot then later(ui, function() slot:SetSize({ Value = 1.0, SizeRule = 1 }) end) end end
local function textIn(ui, parent, kind, s, size, color)
    local tb = nil
    pcall(function() tb = StaticConstructObject(ui.textC, ui.tree) end)
    if not valid(tb) then return nil, nil end
    local sl = add(parent, kind, tb)
    later(ui, function() local f = tb.Font; f.Size = size; tb:SetFont(f) end)
    later(ui, function() tb:SetColorAndOpacity({ SpecifiedColor = color, ColorUseRule = 0 }) end)
    later(ui, function() tb:SetText(FText(s)) end)
    later(ui, function() tb:SetVisibility(3) end)
    return tb, sl
end
local function imageIn(ui, parent, kind, texPath, color)
    local img, sl = prim(ui, "Image", parent, kind)
    if img then
        later(ui, function() img:SetVisibility(3) end)
        if texPath then later(ui, function() local t = texture(texPath); if t then img:SetBrushFromTexture(t, false) end end) end
        if color then later(ui, function() img:SetColorAndOpacity(color) end) end
    end
    return img, sl
end
local function buttonIn(ui, parent, kind, label, act, style)
    local b = nil
    pcall(function() b = ui.wbl:Create(ui.pc, ui.btnC, ui.pc) end)
    if not valid(b) then return nil, nil end
    local s = add(parent, kind, b)
    P.acts[full(b)] = act
    P.btns[#P.btns + 1] = b
    later(ui, function() b:SetLabelText(FText(label)) end)
    if style then later(ui, function() b:SetStyle(style) end) end
    return b, s
end

-- The game's panel frames (WBP_Panel, WBP_Panel_Processing) carry a UI ember effect (a NiagaraSystemWidget)
-- sized by the game's own layout events; on our panels it traces a phantom box across the screen (Nexus report,
-- proven in game 2026-09-30: collapsing it by a tree walk removes the sweep, the frame art is unchanged).
local function hideEmbers(frame)
    local function walk(w, depth)
        if depth > 10 or not (w and w:IsValid()) then return end
        local cls = ""
        pcall(function() cls = w:GetClass():GetFName():ToString() end)
        if cls == "NiagaraSystemWidget" then pcall(function() w:SetVisibility(1) end); return end
        local n = 0
        pcall(function() n = w:GetChildrenCount() end)
        for i = 0, (n or 0) - 1 do
            local c = nil
            pcall(function() c = w:GetChildAt(i) end)
            walk(c, depth + 1)
        end
    end
    pcall(function() walk(frame.WidgetTree.RootWidget, 0) end)
end

-- Stage 1: the frame, docked and collapsed until its first fill.
local function buildFrame(pc, host)
    local tree, canvas = nil, nil
    pcall(function() tree = host.WidgetTree end)
    pcall(function() canvas = tree.RootWidget end)
    if not (valid(tree) and valid(canvas) and isA(canvas, "CanvasPanel")) then
        buildWarn("station window layout not recognized"); return nil
    end
    local wbl = nil
    pcall(function() wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
    local textC, btnC = loadClass("/Game/UI/Common/WBP_DomTextBlock"), loadClass(ALLCAPS)
    local frameC = nil
    for _, p in ipairs(FRAME_CLASSES) do
        frameC = loadClass(p)
        if frameC then break end
    end
    if not (valid(wbl) and frameC and textC and btnC) then buildWarn("could not load the game's panel widgets"); return nil end
    local frame = nil
    pcall(function() frame = wbl:Create(pc, frameC, pc) end)
    if not valid(frame) then buildWarn("could not create the panel frame"); return nil end
    hideEmbers(frame)
    -- Background at 80 %, text at 100 % (user, 2026-10-01; proven in Ghost Flock): fade only the panel background image.
    pcall(function() local bg = frame.BackgroundPanel; if bg and bg:IsValid() then bg:SetRenderOpacity(0.8) end end)
    local okA, cslot = pcall(function() return canvas:AddChildToCanvas(frame) end)
    if not okA or not valid(cslot) then buildWarn("could not attach the panel to the station window"); return nil end
    pcall(function() frame:SetVisibility(1) end)
    pcall(function() cslot:SetAutoSize(false) end)
    pcall(function() cslot:SetZOrder(100) end)
    pcall(function() cslot:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 0, Y = 0 } }) end)
    pcall(function() cslot:SetAlignment({ X = 0, Y = 0 }) end)
    pcall(function() cslot:SetPosition({ X = cfg.PanelX, Y = cfg.PanelY }) end)
    local ft = nil
    pcall(function() ft = frame.WidgetTree end)
    if not valid(ft) then buildWarn("the panel frame has no widget tree"); return nil end
    return { frame = frame, slot = cslot, tree = ft, pc = pc, wbl = wbl, textC = textC, btnC = btnC,
             sliderC = loadClass(SLIDER_CLASS), primary = loadClass(PRIMARY_STYLE),
             queue = {}, tiles = {}, rows = {}, reqs = {} }
end

-- Stage 2: everything inside the frame, top down, nothing configured yet.
local function buildContent(ui)
    local col = construct(ui.tree, "VerticalBox")
    if not col then return false end
    if not pcall(function() ui.frame.PanelContent:AddChild(col) end) then return false end
    ui.col = col
    local s

    ui.title = textIn(ui, col, "v", "", 22, GOLD)
    ui.caption, s = textIn(ui, col, "v", "", 13, DIM)
    pad(ui, s, 0, 0, 0, 8)

    -- Recipe tiles: a game button underneath for the click, our slot art, icon and count on top
    -- (HitTestInvisible, so the click falls through to the button).
    local cols = cfg.PanelColumns
    local i = 0
    for r = 1, math.ceil(MAX_TILES / cols) do
        local row, rs = prim(ui, "HorizontalBox", col, "v")
        if not row then break end
        pad(ui, rs, 0, 0, 0, GAP)
        ui.rows[r] = row
        for _ = 1, cols do
            if i >= MAX_TILES then break end
            i = i + 1
            local t = {}
            local bx, bs = sizeBox(ui, row, "h", TILE, TILE)
            pad(ui, bs, 0, 0, GAP, 0)
            local ov = bx and prim(ui, "Overlay", bx, "box")
            if ov then
                local s2
                t.btn, s2 = buttonIn(ui, ov, "o", "", { kind = "tile", i = i }); align(ui, s2, 0, 0)
                t.bg, s2 = imageIn(ui, ov, "o", TEX_SLOT); align(ui, s2, 0, 0)
                t.hot, s2 = imageIn(ui, ov, "o", TEX_HOT); align(ui, s2, 0, 0)
                t.icon, s2 = imageIn(ui, ov, "o"); align(ui, s2, 0, 0); pad(ui, s2, 9, 6, 9, 12)
                t.count, s2 = textIn(ui, ov, "o", "", 13, CREAM); align(ui, s2, 1, 3); pad(ui, s2, 5, 0, 0, 2)
                t.mark, s2 = textIn(ui, ov, "o", "", 26, DIM); align(ui, s2, 2, 2)
            end
            t.root = bx
            ui.tiles[i] = t
        end
    end

    local dv, ds = sizeBox(ui, col, "v", nil, 2)
    pad(ui, ds, 0, 4, 0, 10)
    if dv then imageIn(ui, dv, "box", nil, RULE) end

    -- The selected recipe.
    local dh = prim(ui, "HorizontalBox", col, "v")
    if dh then
        local dcol, dcs = prim(ui, "VerticalBox", dh, "h")
        grow(ui, dcs); align(ui, dcs, nil, 2)
        if dcol then
            ui.name = textIn(ui, dcol, "v", "", 20, GOLD)
            ui.makes = textIn(ui, dcol, "v", "", 14, CREAM)
        end
        local ib, ibs = sizeBox(ui, dh, "h", 52, 52)
        align(ui, ibs, nil, 2)
        if ib then ui.outIcon = imageIn(ui, ib, "box") end
    end

    ui.reqLabel, s = textIn(ui, col, "v", "REQUIREMENTS", 13, DIM)
    pad(ui, s, 0, 10, 0, 4)
    local rh = prim(ui, "HorizontalBox", col, "v")
    for k = 1, MAX_REQS + 1 do
        local q = {}
        local vb, vbs = nil, nil
        if rh then vb, vbs = prim(ui, "VerticalBox", rh, "h") end
        pad(ui, vbs, 0, 0, 10, 0)
        if vb then
            local bx = sizeBox(ui, vb, "v", REQ_TILE, REQ_TILE)
            local ov = bx and prim(ui, "Overlay", bx, "box")
            if ov then
                local s3
                q.bg, s3 = imageIn(ui, ov, "o", TEX_REQ); align(ui, s3, 0, 0)
                q.icon, s3 = imageIn(ui, ov, "o"); align(ui, s3, 0, 0); pad(ui, s3, 7, 7, 7, 7)
            end
            local ts
            q.text, ts = textIn(ui, vb, "v", "", 14, CREAM)
            align(ui, ts, 2, nil)
        end
        q.root = vb
        ui.reqs[k] = q
    end

    -- Quantity: the crafting bench's own slider (arrows, value, bar), else our own < > and a number.
    local qh, qhs = prim(ui, "HorizontalBox", col, "v")
    pad(ui, qhs, 0, 12, 0, 6)
    if qh then
        local _, qls = textIn(ui, qh, "h", "QUANTITY", 13, DIM)
        align(ui, qls, nil, 2); pad(ui, qls, 0, 0, 10, 0)
        if ui.sliderC then
            local sb, sbs = sizeBox(ui, qh, "h", 250, 56)
            align(ui, sbs, nil, 2)
            local sl = nil
            if sb then pcall(function() sl = ui.wbl:Create(ui.pc, ui.sliderC, ui.pc) end) end
            if valid(sl) then
                add(sb, "box", sl)
                ui.slider = sl
                later(ui, function() sl.InputSlider:SetMinValue(1.0) end)
                later(ui, function() sl.InputSlider:SetStepSize(1.0) end)
            end
        end
        if not ui.slider then
            local b1 = sizeBox(ui, qh, "h", 48, 48)
            if b1 then ui.minus = buttonIn(ui, b1, "box", "<", { kind = "minus" }) end
            local qs
            ui.qtyText, qs = textIn(ui, qh, "h", "", 18, CREAM)
            align(ui, qs, nil, 2); pad(ui, qs, 10, 0, 10, 0)
            local b2 = sizeBox(ui, qh, "h", 48, 48)
            if b2 then ui.plus = buttonIn(ui, b2, "box", ">", { kind = "plus" }) end
        end
        local mb, mbs = sizeBox(ui, qh, "h", 86, 48)
        align(ui, mbs, nil, 2); pad(ui, mbs, 8, 0, 0, 0)
        if mb then ui.maxBtn = buttonIn(ui, mb, "box", "MAX", { kind = "max" }) end
    end

    local bh, bhs = prim(ui, "HorizontalBox", col, "v")
    pad(ui, bhs, 0, 6, 0, 0)
    local function actBtn(W, label, act, style, gap)
        if not bh then return nil end
        local bx, bxs = sizeBox(ui, bh, "h", W, 56)
        pad(ui, bxs, 0, 0, gap, 0)
        if not bx then return nil end
        return (buttonIn(ui, bx, "box", label, act, style))
    end
    ui.loadStart = actBtn(210, "LOAD & START", { kind = "loadstart" }, ui.primary, 8)
    ui.load = actBtn(100, "LOAD", { kind = "load" }, nil, 8)
    ui.toggle = actBtn(110, "START", { kind = "toggle" }, nil, 0)

    ui.status, s = textIn(ui, col, "v", "", 13, DIM)
    pad(ui, s, 0, 8, 0, 0)
    if ui.status then later(ui, function() ui.status:SetAutoWrapText(true) end) end
    return true
end

-- Station data (read on open) -----------------------------------------------------------------------

-- Recipe path -> position in the live RecipesUnlocked set, which iterates in unlock order (probe P2).
local function unlockOrder(prog)
    local order, n = {}, 0
    local set = nil
    pcall(function() set = prog.RecipesUnlocked end)
    if set == nil then return order end
    pcall(function()
        set:ForEach(function(el)
            local o = el
            pcall(function() o = el:get() end)
            if valid(o) then
                local k = objPath(o)
                if k ~= "" and not order[k] then n = n + 1; order[k] = n end
            end
        end)
    end)
    return order
end

-- Array<ItemDataContainer> -> { { key, data, need, cap } }
local function readItems(arr)
    local out, n = {}, nil
    if arr ~= nil then pcall(function() n = arr:GetArrayNum() end) end
    if type(n) ~= "number" or n <= 0 then return out end
    for j = 1, n do
        local c1 = nil
        pcall(function() c1 = arr[j] end)
        local cc = c1
        pcall(function() cc = c1:get() end)
        local it, ct = nil, nil
        pcall(function() it = cc.ItemData end)
        pcall(function() ct = cc.Count end)
        if valid(it) and type(ct) == "number" then
            local cap = nil
            pcall(function() cap = it.MaxStackSize end)
            out[#out + 1] = { key = full(it), data = it, need = ct,
                              cap = (type(cap) == "number" and cap > 0) and cap or nil }
        end
    end
    return out
end

-- Every recipe the station has (RecipesCache holds the locked ones too, probe P1), in panel order.
function readRecipes(pc, ps)
    local list = {}
    local rc, n = nil, nil
    pcall(function() rc = ps.RecipesCache end)
    if rc ~= nil then pcall(function() n = rc:GetArrayNum() end) end
    if type(n) ~= "number" or n <= 0 then return list end
    local prog = nil
    pcall(function() prog = pc.ProgressComponent end)
    local order = valid(prog) and unlockOrder(prog) or {}
    for i = 1, n do
        local e = nil
        pcall(function() e = rc[i] end)
        local r = e
        pcall(function() r = e:get() end)
        if valid(r) then
            local key = objPath(r)
            local unlocked = nil
            if valid(prog) then pcall(function() unlocked = prog:IsRecipeUnlocked(r) end) end
            if type(unlocked) ~= "boolean" then unlocked = order[key] ~= nil end
            local ins, outs, tmin, tmax = nil, nil, nil, nil
            pcall(function() ins = r.ItemsConsumed end)
            pcall(function() outs = r.ItemsCreated end)
            pcall(function() tmin = r.MinProcessingTime end)
            pcall(function() tmax = r.MaxProcessingTime end)
            local out = readItems(outs)[1]
            local rec = { key = key, unlocked = unlocked == true, ings = R.merge(readItems(ins)), ingKeys = {},
                          outData = out and out.data or nil, count = out and out.need or 1,
                          tmin = tmin, tmax = tmax, n = 0 }
            for _, g in ipairs(rec.ings) do rec.ingKeys[g.key] = true end
            rec.name = out and itemName(out.data) or shortName(r)
            list[#list + 1] = rec
        end
    end
    return R.order(list, order)
end

-- key -> { n, data, stacks = { { inv, slot } } } for one inventory
local function tally(inv)
    local t = {}
    for _, s in ipairs(occupied(inv)) do
        local k = full(s.data)
        local e = t[k]
        if not e then e = { n = 0, data = s.data, stacks = {} }; t[k] = e end
        e.n = e.n + s.count
        e.stacks[#e.stacks + 1] = { inv = inv, slot = s.slot }
    end
    return t
end

local function playerBag(pc)
    local b = nil
    pcall(function() b = pc.BP_Components_Inventory end)
    return valid(b) and b or nil
end

local function isHost(pc)
    local h = nil
    local ok = pcall(function() h = pc:HasAuthority() end)
    return ok and h == true
end

local function isRunning(ps)
    local r = nil
    pcall(function() r = ps:IsProcessing() end)
    return r == true
end

-- What the panel counts as "have": chests (keep one applied) + backpack (if the panel may use it) + station.
local function haveOf(st, key)
    local c, b, s = st.byItem[key], st.bag[key], st.inRes[key]
    return R.have(c and c.total or 0, b and b.n or 0, s and s.n or 0, cfg.KeepOne, cfg.PanelUsesBackpack)
end
local function fuelHave(st, key)
    local c, b, s = st.byItem[key], st.bag[key], st.inFuel[key]
    return R.have(c and c.total or 0, b and b.n or 0, s and s.n or 0, cfg.KeepOne, cfg.PanelUsesBackpack)
end

-- Counts: chests, backpack, station. Every open and after every panel action (one chest search each).
local function scan(pc, st)
    st.chests = st.origin and nearbyChests(st.origin) or {}
    st.skipped = skippedLocked + skippedPrivate
    st.byItem = chestStacks(st.chests)
    local bag = playerBag(pc)
    st.bag = bag and tally(bag) or {}
    st.inRes = tally(st.res)
    st.inFuel = tally(st.fuel)
    st.resOcc = {}
    for _, s in ipairs(occupied(st.res)) do
        st.resOcc[#st.resOcc + 1] = { slot = s.slot, key = full(s.data), count = s.count, data = s.data }
    end
    st.resSlots = valid(st.res) and slotCount(st.res) or 0
    st.fuelSlots = valid(st.fuel) and slotCount(st.fuel) or 0
    local arr = nil
    pcall(function() arr = st.ps.AcceptedFuelsIncludingRecipeOverrides end)
    st.accFuel = acceptSet(arr)
    for _, rec in ipairs(st.recipes) do
        local n = R.makeable(rec.ings, function(k) return haveOf(st, k) end)
        -- 2026-10-13: the station makes a recipe the game still counts as locked (Ground Sandstone, Nexus
        -- comments), so holding everything it needs counts as knowing it.
        if n > 0 then rec.unlocked = true end
        rec.n = rec.unlocked and n or 0
    end
end

-- The fuel for a batch: what is in the fuel slot now, else the fuel this station was last given, else the
-- first accepted fuel you have (by name, so the choice is the same every time). Returns key, data or nil.
local function fuelChoice(st)
    if st.fuelSlots <= 0 then return nil end
    local keys = {}
    for k in pairs(st.inFuel) do keys[#keys + 1] = k end
    table.sort(keys)
    if keys[1] then return keys[1], st.inFuel[keys[1]].data end
    local function dataOf(k)
        local e = st.byItem[k]
        if e then return e.data end
        local b = st.bag[k]
        if b and cfg.PanelUsesBackpack then return b.data end
        return nil
    end
    if st.mem then
        for _, k in ipairs(st.mem.fuel) do
            if st.accFuel[k] and fuelHave(st, k) > 0 and dataOf(k) then return k, dataOf(k) end
        end
    end
    local cands = {}
    for k in pairs(st.accFuel) do
        if fuelHave(st, k) > 0 and dataOf(k) then cands[#cands + 1] = k end
    end
    table.sort(cands)
    if cands[1] then return cands[1], dataOf(cands[1]) end
    return nil
end

-- MAX for a recipe: what you can make, capped by what the station can hold. Other items in the station
-- block their slots unless they will be returned to chests first.
local function recipeMax(st, rec)
    if not (rec and rec.unlocked) then return 0 end
    local blocked = 0
    if not cfg.ReturnLeftovers then blocked = #R.leftovers(st.resOcc, rec.ingKeys) end
    return R.maxQuantity(rec.n, R.capacity(rec.ings, st.resSlots, blocked))
end

local function lastQty(st, rec)
    if session and session.rec == rec.key and type(session.qty) == "number" then return session.qty end
    if st.mem and st.mem.rec == rec.key then return st.mem.qty end
    return nil
end

-- Filling ------------------------------------------------------------------------------------------

local function setIcon(holder, img, data)
    local p = data and ITEMICONS[objPath(data)] or nil
    if p and holder.iconPath ~= p then
        local tex = texture(p)
        if tex and img then
            pcall(function() img:SetBrushFromTexture(tex, false) end)
            holder.iconPath = p
        else
            p = nil
        end
    end
    vis(img, p ~= nil)
end

local function tilesFill(ui, st)
    local recs = st.recipes
    for i, t in ipairs(ui.tiles) do
        local rec = recs[i]
        local v = rec and R.tile(rec, rec.n)
        if not v then
            showBox(t.root, false)
        else
            showBox(t.root, true)
            showBtn(t.btn, true)
            local selected = (i == st.sel)
            vis(t.hot, selected)
            if v.icon then setIcon(t, t.icon, rec.outData) else vis(t.icon, false) end
            setText(t.count, v.count)
            setColor(t.count, selected and GOLD or ((rec.n or 0) > 0 and CREAM or DIM))
            setText(t.mark, v.mark)
            vis(t.mark, v.mark ~= "")
        end
    end
    local cols = cfg.PanelColumns
    for r, row in ipairs(ui.rows) do showBox(row, (r - 1) * cols < #recs) end
end

local function reqFill(q, data, have, need, known)
    showBox(q.root, true)
    setIcon(q, q.icon, data)
    if known then
        setText(q.text, R.haveNeedText(have, need))
        setColor(q.text, have >= need and CREAM or RED)
    else
        setText(q.text, tostring(math.max(0, math.floor(have))) .. "/?")
        setColor(q.text, DIM)
    end
end

local function detailFill(ui, st)
    local rec = st.sel and st.recipes[st.sel] or nil
    for _, q in ipairs(ui.reqs) do showBox(q.root, false) end
    if not (rec and rec.unlocked) then
        -- A locked recipe never reaches here (it cannot be selected), so nothing about it can leak.
        setText(ui.name, #st.recipes == 0 and "NO RECIPES" or "PICK A RECIPE")
        setText(ui.makes, "")
        vis(ui.outIcon, false)
        vis(ui.reqLabel, false)
        return
    end
    vis(ui.reqLabel, true)
    setText(ui.name, rec.name:upper())
    setText(ui.makes, R.makesText(rec.count, rec.name, rec.tmin, rec.tmax))
    setIcon(ui, ui.outIcon, rec.outData)
    local q = math.max(1, st.qty or 0)
    for k = 1, MAX_REQS do
        local g = rec.ings[k]
        if g then reqFill(ui.reqs[k], g.data, haveOf(st, g.key), g.need * q, true) end
    end
    local fq = ui.reqs[MAX_REQS + 1]
    if st.fuelSlots > 0 and fq then
        local fk, fdata = fuelChoice(st)
        if fk then
            local fv = nil
            pcall(function() fv = fdata.FuelValue end)
            local need = R.fuelUnits(q, rec.tmax, fv)
            reqFill(fq, fdata, fuelHave(st, fk), need or 0, need ~= nil)
        else
            showBox(fq.root, true)
            setIcon(fq, fq.icon, nil)
            setText(fq.text, "NO FUEL")
            setColor(fq.text, RED)
        end
    end
end

-- Slider range + value, and whether the LOAD buttons can do anything.
local function qtyFill(ui, st)
    local top = math.max(1, st.max or 0)
    if ui.slider then
        pcall(function() ui.slider:UpdateMaxValue(top) end)
        -- 1.8.2: write the inner slider, not the bench widget. Its SetValue snaps to a 9-step grid (sftaps: max 20,
        -- SetValue(8) showed 7, SetValue(19) showed 20); InputSlider:SetValue + UpdateValueText land exactly.
        local q = math.max(1, st.qty or 0) * 1.0
        if not pcall(function() ui.slider.InputSlider:SetValue(q); ui.slider:UpdateValueText() end) then
            pcall(function() ui.slider:SetValue(q) end)
        end
        -- 1.8.2: remember what the slider READS right after our write. GetValue can return a stale value here (sf182:
        -- SetValue(19) read 20), and the follow code in panelTick must not take that as the player moving the slider.
        st.sliderSeen = nil
        pcall(function() st.sliderSeen = ui.slider:GetValue() end)
    end
    if ui.qtyText then setText(ui.qtyText, tostring(st.qty or 0)) end
    local can = (st.max or 0) > 0
    for _, b in ipairs({ ui.loadStart, ui.load, ui.maxBtn }) do
        if b then
            pcall(function() b:SetIsEnabled(can) end)
            -- the dark button style has no disabled brush and draws a near-white box (sf16 shots 03/07): dim instead
            pcall(function() b:SetRenderOpacity(can and 1.0 or 0.35) end)
        end
    end
end

local function sizePanel(ui, st)
    local cols = cfg.PanelColumns
    local rows = math.max(1, math.ceil(math.min(#st.recipes, MAX_TILES) / cols))
    local w = math.max(cols * (TILE + GAP), BTN_ROW_W) + 84
    local h = math.min(1000, 500 + rows * (TILE + GAP))
    pcall(function() ui.slot:SetSize({ X = w, Y = h }) end)
    pcall(function() ui.slot:SetPosition({ X = cfg.PanelX, Y = cfg.PanelY }) end)
end

local function defaultStatus(st)
    local n = #st.chests
    if n == 0 then
        return st.skipped > 0 and "Only locked or private chests in range" or "No chests in range"
    end
    local s = n .. " linked chest" .. (n == 1 and "" or "s") .. " nearby"
    if cfg.KeepOne then s = s .. ", keeping one of each item" end
    if #st.recipes > MAX_TILES then s = s .. " (" .. (#st.recipes - MAX_TILES) .. " more recipes not shown)" end
    return s
end

local function toggleLabel(ui, st)
    local run = isRunning(st.ps)
    if st.shownRun ~= run then
        st.shownRun = run
        if ui.toggle then pcall(function() ui.toggle:SetLabelText(FText(run and "STOP" or "START")) end) end
    end
end

local function selectRecipe(ui, st, i)
    st.sel = i
    local rec = i and st.recipes[i] or nil
    st.max = recipeMax(st, rec)
    st.qty = rec and R.defaultQty(cfg.DefaultQuantity, lastQty(st, rec), st.max) or 0
    tilesFill(ui, st)
    detailFill(ui, st)
    qtyFill(ui, st)
end

-- Re-read chests, backpack and station after something moved, keeping the selection and quantity.
local function refresh(pc, ui, st)
    scan(pc, st)
    local rec = st.sel and st.recipes[st.sel] or nil
    st.max = recipeMax(st, rec)
    if (st.qty or 0) > st.max or ((st.qty or 0) == 0 and st.max > 0) then
        st.qty = rec and R.defaultQty(cfg.DefaultQuantity, lastQty(st, rec), st.max) or 0
    end
    tilesFill(ui, st)
    detailFill(ui, st)
    qtyFill(ui, st)
end

local function firstFill(pc, ui, st)
    scan(pc, st)
    st.recipes = R.usableFirst(st.recipes, MAX_TILES)
    st.mem = findMemory(st.cls, st.origin)
    local inStation = {}
    for _, s in ipairs(st.resOcc) do inStation[s.key] = true end
    local pick = R.pickDefault(st.recipes, st.mem and st.mem.rec or nil, inStation)
    setText(ui.title, st.name:upper())
    setText(ui.caption, cfg.PanelUsesBackpack and "PULLS FROM BACKPACK + LINKED CHESTS" or "PULLS FROM LINKED CHESTS")
    setText(ui.status, defaultStatus(st))
    selectRecipe(ui, st, pick)
    st.shownRun = nil
    toggleLabel(ui, st)
    sizePanel(ui, st)
    showBtn(ui.frame, true)
    st.filled = true
end

-- Actions ------------------------------------------------------------------------------------------

-- Move `want` of one item into the station for a panel click: chests first ("keep one" applies), then,
-- with "Panel uses backpack" on, your backpack for the rest. Returns how many arrived.
local function pullFor(st, target, key, data, want, pawn, bag)
    local got = 0
    local c = st.byItem[key]
    local chestN = R.planSources(want, c and R.chestAvail(c.total, cfg.KeepOne) or 0, 0, true, false)
    if chestN > 0 and c then
        local n = pullItem(target, data, c.stacks, pawn, chestN) or 0
        got = got + n
        c.total = math.max(0, c.total - n)     -- the same item may be pulled again (ingredient and fuel)
    end
    local rest = want - got
    if rest > 0 and bag then
        local b = tally(bag)[key]
        local _, bagN = R.planSources(rest, 0, b and b.n or 0, true, cfg.PanelUsesBackpack)
        if bagN > 0 and b then
            got = got + (pullItem(target, data, b.stacks, pawn, bagN, "your backpack") or 0)
        end
    end
    return got
end

-- How many of `key` sit in one slot, re-read now (0 if the slot holds something else).
local function slotHolds(inv, slot, key)
    local it = nil
    local okI = pcall(function() it = inv:GetItemFromSlot(slot) end)
    if not (okI and valid(it)) then return 0 end
    local d = nil
    pcall(function() d = it.ItemData end)
    if not (valid(d) and full(d) == key) then return 0 end
    local n = nil
    pcall(function() n = inv:GetNumItemsInSlot(slot) end)
    return tonumber(n) or 0
end

local function chestSnapshot(chests)
    local snap = {}
    for ci, inv in ipairs(chests) do
        local c = { n = valid(inv) and slotCount(inv) or 0, s = {} }
        for _, s in ipairs(occupied(inv)) do c.s[s.slot] = { key = full(s.data), n = s.count } end
        snap[ci] = c
    end
    return snap
end

-- Switching recipe: whatever the new recipe does not use goes back to your chests (chests that already
-- hold that item first, then the nearest empty slot; never the backpack). Measured like pullItem.
local function returnLeftovers(st, left, pawn)
    local snap = chestSnapshot(st.chests)
    local back, stuck = {}, {}
    for _, s in ipairs(left) do
        local cap = nil
        pcall(function() cap = s.data.MaxStackSize end)
        if type(cap) ~= "number" or cap <= 0 then cap = nil end
        local total = 0
        for _ = 1, 8 do
            local have = slotHolds(st.res, s.slot, s.key)
            if have <= 0 then break end
            local ci, dst, amt = R.returnTarget(snap, s.key, cap, have)
            if not ci then break end
            local chest = st.chests[ci]
            if not valid(chest) then
                snap[ci].n = 0                          -- gone: try the next chest
            else
                local cb, ca = nil, nil
                pcall(function() cb = chest:GetNumItemsByData(s.data) end)
                netMove(st.res, s.slot, chest, dst, pawn, amt)
                pcall(function() ca = chest:GetNumItemsByData(s.data) end)
                local moved = have - slotHolds(st.res, s.slot, s.key)
                if type(cb) == "number" and type(ca) == "number" and ca - cb ~= moved then
                    log("WARNING: " .. moved .. " x " .. shortName(s.data) .. " left the station but " ..
                        (ca - cb) .. " arrived in the chest. Please report this with your UE4SS.log.")
                end
                local nNow = nil
                pcall(function() nNow = chest:GetNumItemsInSlot(dst) end)
                snap[ci].s[dst] = { key = s.key, n = tonumber(nNow) or ((snap[ci].s[dst] and snap[ci].s[dst].n or 0) + moved) }
                if moved <= 0 then break end
                total = total + moved
            end
        end
        local rem = slotHolds(st.res, s.slot, s.key)
        if total > 0 then back[#back + 1] = total .. " " .. itemName(s.data) end
        if rem > 0 then stuck[#stuck + 1] = rem .. " " .. itemName(s.data) end
    end
    return back, stuck
end

-- Start / stop the station the way the game's own START button does (ProcessingStationUIAPI). The direct
-- ProcessingStationComponent:ToggleProcessing(pawn) crashed the game natively when starting Bread in a Charcoal
-- Kiln (1.6.1 fix, 3 crashes at exe +0x4341F1D; the UI API started it fine). Direct call only if the API is gone.
local function toggleProcessing(st, pawn)
    local was = isRunning(st.ps)
    local sent = valid(st.api) and pcall(function() st.api:ToggleProcessingStationStarted() end)
    if not sent then pcall(function() st.ps:ToggleProcessing(pawn) end) end
    -- Joined: the server starts or stops it and tells us a moment later. Wait, so what follows reads the new state.
    if NET.joined then netWait(function() return (st.ps:IsProcessing() == true) ~= was end, NET.TOGGLE_WAIT) end
end

-- LOAD and LOAD & START. Returns the status line.
local function loadRecipe(pc, st, start)
    local rec = st.sel and st.recipes[st.sel] or nil
    if not (rec and rec.unlocked) then return "Pick a recipe first" end
    local q = st.qty or 0
    if q <= 0 then return "Not enough for one " .. rec.name .. " in your chests" ..
        (cfg.PanelUsesBackpack and " and backpack" or "") end
    local pawn = nil
    pcall(function() pawn = pc.Pawn end)
    if not (valid(pawn) and valid(st.res)) then return "Cannot reach the station right now" end
    local notes = {}

    -- 1. Items of another recipe go back to the chests, so the new one has its slots. Re-read the
    -- station first: you may have put something in by hand since the panel last counted.
    st.resOcc = {}
    for _, s in ipairs(occupied(st.res)) do
        st.resOcc[#st.resOcc + 1] = { slot = s.slot, key = full(s.data), count = s.count, data = s.data }
    end
    local left = R.leftovers(st.resOcc, rec.ingKeys)
    if #left > 0 then
        if cfg.ReturnLeftovers then
            if isRunning(st.ps) then
                toggleProcessing(st, pawn)
                notes[#notes + 1] = "Stopped the station to switch recipe."
            end
            local back, stuck = returnLeftovers(st, left, pawn)
            if #back > 0 then notes[#notes + 1] = "Returned " .. table.concat(back, ", ") .. " to your chests." end
            if #stuck > 0 then notes[#notes + 1] = "No chest room for " .. table.concat(stuck, ", ") .. "; left in the station." end
        else
            notes[#notes + 1] = "Other items are still in the station."
        end
    end

    -- 2. Ingredients for q crafts, counting what is already in the station.
    local bag = playerBag(pc)
    local short = {}
    for _, g in ipairs(rec.ings) do
        local inNow = nil
        pcall(function() inNow = st.res:GetNumItemsByData(g.data) end)
        local want = g.need * q - (tonumber(inNow) or 0)
        if want > 0 then
            local got = pullFor(st, st.res, g.key, g.data, want, pawn, bag)
            if got < want then short[#short + 1] = itemName(g.data) end
        end
    end
    if #short > 0 then notes[#notes + 1] = "Short of " .. table.concat(short, ", ") .. "." end

    -- 3. Fuel for the whole batch: ceil(q x longest craft time / burn time); what is in the slot counts.
    local fuelKey = nil
    if st.fuelSlots > 0 and valid(st.fuel) then
        local fk, fdata = fuelChoice(st)
        if fk then
            fuelKey = fk
            local fv, inSlot = nil, nil
            pcall(function() fv = fdata.FuelValue end)
            pcall(function() inSlot = st.fuel:GetNumItemsByData(fdata) end)
            local addN = R.fuelToAdd(q, rec.tmax, fv, tonumber(inSlot) or 0)
            if addN and addN > 0 then
                local got = pullFor(st, st.fuel, fk, fdata, addN, pawn, bag)
                if got < addN then notes[#notes + 1] = "Not enough " .. itemName(fdata) .. " for the whole batch." end
            end
        else
            notes[#notes + 1] = "No fuel found."
        end
    end

    -- 4. Remember it: a station that runs dry refills to this recipe, and the panel reopens on it.
    if session then
        session.rec, session.qty = rec.key, q
        local keys = {}
        for _, g in ipairs(rec.ings) do keys[#keys + 1] = g.key end
        session.res = keys
        if fuelKey then session.fuel = { fuelKey } end
    end

    -- 5. Start.
    if start and not isRunning(st.ps) then
        toggleProcessing(st, pawn)
        st.startCheck = os.clock() + 0.5
    end
    if cfg.Verbose then log("panel: loaded " .. q .. " x " .. rec.name .. (start and " and started" or "")) end
    table.insert(notes, 1, "Loaded " .. q .. " x " .. rec.name .. ".")
    return table.concat(notes, " ")
end

local function toggleStation(pc, st)
    local pawn = nil
    pcall(function() pawn = pc.Pawn end)
    if not valid(pawn) then return nil end
    local was = isRunning(st.ps)
    toggleProcessing(st, pawn)
    if was then
        st.startCheck = nil
        -- True to the game (probe P3): a stop throws away the rest of the fuel unit that was burning.
        -- 1.7: only said on stations that burn fuel (a kiln or grill has no fuel slot).
        return (st.fuelSlots or 0) > 0 and "Stopped. The fuel unit that was burning is used up." or "Stopped."
    end
    st.startCheck = os.clock() + 0.5
    return "Started."   -- 1.7: before, START left the last "Stopped." line up; the start check below corrects it
end

-- Wiring -------------------------------------------------------------------------------------------

local function hidePanel()
    if P.ui and valid(P.ui.frame) then showBtn(P.ui.frame, false) end
    P.st, P.click, P.key = nil, nil, nil
    PAD.hits, PAD.aDown, PAD.pc, PAD.hov = {}, nil, nil, nil
    PAD.unlink()
end

-- One dispatch for a press on one of our buttons, by full name. The mouse reaches it through the hook below
-- (it only records; the work happens on the next tick); a pad press reaches the same action through PAD.take.
local function routeClick(n)
    if not P.acts[n] then return end
    P.click = P.acts[n]
end

local function hookPanelClicks()
    if P.hooked then return end
    P.hooked = true
    local ok = pcall(RegisterHook, "/Script/CommonUI.CommonButtonBase:HandleButtonClicked", function(self)
        local okN, n = pcall(function() return self:get():GetFullName() end)
        if not okN then return end
        routeClick(n)
    end)
    if not ok then log("could not watch panel clicks; the recipe panel buttons will not respond") end
end

-- SetIsSelected(false) is ignored on these buttons; toggling SetIsSelectable clears a selection.
function PAD.unselect(b)
    if not valid(b) then return end
    pcall(function() b:SetIsSelectable(false) end)
    pcall(function() b:SetIsSelectable(true) end)
end

-- Once per opening, on the tick after the first fill (the game has built the buttons by then and may reset
-- the flag while building): every button selectable and unselected, and the A sampler armed.
function PAD.arm(pc, st)
    for _, b in ipairs(P.btns) do PAD.unselect(b) end
    PAD.hits, PAD.aDown, PAD.lastHit, PAD.lastSel, PAD.hov = {}, nil, nil, nil, nil
    PAD.pc = pc
    st.padArmed = true
    PAD.unlink()
    PAD.edges = PAD.findEdges(P.host)
    if #PAD.edges ~= PAD.edgesLogged then
        PAD.edgesLogged = #PAD.edges
        log("controller: " .. #PAD.edges .. " station slot(s) link Right into the recipe panel")
    end
end

-- The panel buttons a pad can be on right now: the tiles in use plus the quantity and action buttons.
function PAD.liveButtons()
    local ui, st, out = P.ui, P.st, {}
    if not (ui and st) then return out end
    for i = 1, math.min(#(st.recipes or {}), MAX_TILES) do
        local t = ui.tiles[i]
        if t and t.btn then out[#out + 1] = t.btn end
    end
    for _, b in ipairs({ ui.minus or false, ui.plus or false, ui.maxBtn or false, ui.loadStart or false,
                         ui.load or false, ui.toggle or false }) do
        if b then out[#out + 1] = b end
    end
    return out
end

-- The one under the pad's hover (mod 585: pad navigation moves the hover) or, failing that, its focus.
function PAD.current(btns)
    for _, b in ipairs(btns) do
        if valid(b) then
            local okH, h = pcall(function() return b:IsHovered() end)
            if okH and h == true then return b end
        end
    end
    for _, b in ipairs(btns) do
        if valid(b) then
            local okF, f = pcall(function() return b:HasKeyboardFocus() end)
            if okF and f == true then return b end
        end
    end
    return nil
end

-- The fast loop: A going down while one of our (enabled) buttons is hovered. Only records; PAD.take routes it.
-- In game (run c1006c) a pad press clears the hover, so the 50 ms sample could read "nothing hovered" at the
-- moment A went down and lose the press (LOAD 0/2, START/STOP 1 of 4 lost). Every sample now remembers the
-- button last seen hovered or focused; A going down uses it when it was seen within HOVER_KEEP_S, once.
function PAD.sample()
    local st = P.st
    if not (st and st.padArmed and P.stage == "ready" and PAD.keyA) then PAD.aDown, PAD.hov = nil, nil; return end
    local pc = PAD.pc
    if not valid(pc) then PAD.aDown, PAD.hov = nil, nil; return end
    local ok, down = pcall(function() return pc:IsInputKeyDown({ KeyName = PAD.keyA }) end)
    if not ok then
        PAD.errs = PAD.errs + 1
        if PAD.errs == 1 then log("controller: could not read the A button (" .. tostring(down) .. "); pad presses rely on selection only") end
        if PAD.errs >= 5 then PAD.keyA = nil end       -- stop asking; the selection route still works
        return
    end
    down = (down == true)
    local now = os.clock()
    local cur = PAD.current(PAD.liveButtons())
    if cur then PAD.hov = { b = cur, t = now } end
    local was = PAD.aDown
    PAD.aDown = down
    if was == nil or was or not down then return end   -- the first read after arming is only a baseline
    local b = cur
    if not b and PAD.hov and now - PAD.hov.t <= PAD.HOVER_KEEP_S then b = PAD.hov.b end
    PAD.hov = nil                                      -- one press per sighting
    if not valid(b) then return end
    local okE, en = pcall(function() return b:GetIsEnabled() end)
    if okE and en == false then return end             -- a grayed-out LOAD / MAX does nothing, as with the mouse
    local n = full(b)
    if P.acts[n] and #PAD.hits < 4 then PAD.hits[#PAD.hits + 1] = { name = n, t = now } end
end

-- Navigation links (c1006c: P1 FAIL, a pad never reached the panel: Right from the station's slots stops at the
-- window edge, the right stick only swaps station <-> backpack). Same pattern as Quest Log 1.4 CardPadLinks:
--   * IN: the station window's right-hand slots (StationSlotBase widgets inside THIS MainPanel, the last one of
--     each row) get Right -> our first panel button. Only a slot whose Right rule is the default (Escape, 0) or
--     Stop (3) is touched, and it gets that rule back whenever the panel hides.
--   * OUT: Left from the panel's left edge -> the right-most usable ingredient slot (else another edge slot),
--     re-chosen every tick: an explicit target that cannot take focus kills that direction (mod 585 notes).
--   * Inside: Up/Down/Left/Right between tiles, the quantity row and the action row; only to buttons that can
--     take focus (a grayed-out LOAD / MAX is skipped). The bench slider keeps its own left/right.
-- EUINavigation 0 Left, 1 Right, 2 Up, 3 Down.
local function navLink(from, dir, to)
    if not valid(from) then return end
    if valid(to) then pcall(function() from:SetNavigationRuleExplicit(dir, to) end)
    else pcall(function() from:SetNavigationRuleBase(dir, 0) end) end
end

-- The Right rule a widget has now: 0 when it has no navigation object (the default), nil when unreadable.
local function rightRule(w)
    local nav = nil
    pcall(function() nav = w.Navigation end)
    if not valid(nav) then return 0 end
    local r = nil
    pcall(function() r = nav.Right.Rule end)
    return type(r) == "number" and r or nil
end

local function shown(w)
    if not valid(w) then return false end
    local okV, v = pcall(function() return w:IsVisible() end)
    if not (okV and v == true) then return false end
    local okE, e = pcall(function() return w:GetIsEnabled() end)
    return not (okE and e == false)
end
local function focusTarget(w)
    if not shown(w) then return false end
    local okF, f = pcall(function() return w:GetIsFocusable() end)
    return not (okF and f == false)
end

-- One FindAllOf (35-50 ms) per station opening. Edge = the last child of a row (HorizontalBox and other boxes),
-- every member of a VerticalBox, the highest Column per Row of a UniformGridPanel, or a slot on its own.
function PAD.findEdges(host)
    local edges = {}
    local hn = nil
    pcall(function() hn = host:GetFName():ToString() end)
    if type(hn) ~= "string" or hn == "" then return edges end
    local ok, all = pcall(FindAllOf, "StationSlotBase")
    if not ok or type(all) ~= "table" then return edges end
    local groups, order = {}, {}
    for _, w in ipairs(all) do
        local n = valid(w) and full(w) or ""
        if n ~= "" and not n:find("Default__", 1, true) and n:find(hn, 1, true) and shown(w) then
            local par, pcls = nil, ""
            pcall(function() par = w:GetParent() end)
            local key = valid(par) and full(par) or ("solo " .. n)
            if valid(par) then pcall(function() pcls = par:GetClass():GetFName():ToString() end) end
            local idx, col, row = -1, nil, nil
            if valid(par) then pcall(function() idx = par:GetChildIndex(w) end) end
            if pcls == "UniformGridPanel" then
                pcall(function() col = w.Slot.Column end)
                pcall(function() row = w.Slot.Row end)
            end
            local g = groups[key]
            if not g then g = { cls = pcls, list = {} }; groups[key] = g; order[#order + 1] = key end
            local wc = ""
            pcall(function() wc = w:GetClass():GetFName():ToString() end)
            g.list[#g.list + 1] = { w = w, idx = tonumber(idx) or -1, col = col, row = row,
                                    ing = wc:find("Ingredient", 1, true) ~= nil }
        end
    end
    for _, key in ipairs(order) do
        local g, picks = groups[key], {}
        if g.cls == "VerticalBox" then
            picks = g.list
        elseif g.cls == "UniformGridPanel" then
            local best, rows = {}, {}
            for _, e in ipairs(g.list) do
                local r = tonumber(e.row) or 0
                if not best[r] then rows[#rows + 1] = r end
                if not best[r] or (tonumber(e.col) or 0) > (tonumber(best[r].col) or 0) then best[r] = e end
            end
            table.sort(rows)
            for _, r in ipairs(rows) do picks[#picks + 1] = best[r] end
        else
            local best = nil
            for _, e in ipairs(g.list) do if not best or e.idx > best.idx then best = e end end
            picks = { best }
        end
        for _, e in ipairs(picks) do
            local r = rightRule(e.w)
            if r == 0 or r == 3 then edges[#edges + 1] = { w = e.w, rule = r, ing = e.ing } end
        end
    end
    return edges
end

-- The station's slots get their own Right rule back: whenever the panel hides, and before a new opening.
function PAD.unlink()
    if PAD.linked then
        for _, e in ipairs(PAD.edges or {}) do
            if valid(e.w) then pcall(function() e.w:SetNavigationRuleBase(1, e.rule) end) end
        end
    end
    PAD.linked, PAD.target, PAD.navSig = false, nil, nil
end

-- Every ready tick; does nothing unless something that changes the links changed.
function PAD.wire(ui, st)
    local back = nil
    for pass = 1, 2 do
        for _, e in ipairs(PAD.edges or {}) do
            if not back and (pass == 2 or e.ing) and focusTarget(e.w) then back = e.w end
        end
    end
    local n = math.min(#(st.recipes or {}), MAX_TILES)
    local can = (st.max or 0) > 0
    local sig = n .. "|" .. tostring(can) .. "|" .. (back and full(back) or "-") .. "|" .. tostring(cfg.PanelColumns)
    if sig == PAD.navSig then return end
    PAD.navSig = sig
    local cols = cfg.PanelColumns
    local function tile(i) local t = ui.tiles[i]; return (i >= 1 and i <= n and t and valid(t.btn)) and t.btn or nil end
    local qty = {}                                     -- the quantity row's buttons, left to right
    for _, b in ipairs({ ui.minus or false, ui.plus or false, (can and ui.maxBtn) or false }) do
        if b and valid(b) then qty[#qty + 1] = b end
    end
    local acts = {}                                    -- the action row, left to right
    for _, b in ipairs({ (can and ui.loadStart) or false, (can and ui.load) or false, ui.toggle or false }) do
        if b and valid(b) then acts[#acts + 1] = b end
    end
    local lastRowFirst = n > 0 and (math.floor((n - 1) / cols) * cols + 1) or 0
    local aboveQty = tile(lastRowFirst)
    for i = 1, n do
        local b, c = tile(i), (i - 1) % cols
        navLink(b, 0, (c > 0 and tile(i - 1)) or back)
        navLink(b, 1, (c < cols - 1 and tile(i + 1)) or b)
        navLink(b, 2, tile(i - cols) or b)
        navLink(b, 3, tile(i + cols) or (i < lastRowFirst and tile(n)) or qty[1] or acts[1] or b)
    end
    for i, b in ipairs(qty) do
        if i > 1 or ui.minus then navLink(b, 0, qty[i - 1] or back) end   -- MAX beside the slider keeps its own Left
        navLink(b, 1, qty[i + 1] or b)
        navLink(b, 2, aboveQty or b)
        navLink(b, 3, acts[1] or b)
    end
    for i, b in ipairs(acts) do
        navLink(b, 0, acts[i - 1] or back)
        navLink(b, 1, acts[i + 1] or b)
        navLink(b, 2, qty[#qty] or aboveQty or b)
        navLink(b, 3, b)
    end
    local target = tile(1) or qty[1] or acts[1]
    local tn = target and full(target) or nil
    if tn and not (PAD.linked and PAD.target == tn) then
        for _, e in ipairs(PAD.edges or {}) do navLink(e.w, 1, target) end
        PAD.linked, PAD.target = #(PAD.edges or {}) > 0, tn
    end
end

-- Every ready tick: the pad action for this tick, or nil. `mouse` = the hook recorded a click this tick: a
-- selection is then the mouse's own (cleared, ignored) and any pad hit waits for the next tick.
function PAD.take(mouse)
    local now = os.clock()
    local sel = nil
    for _, b in ipairs(P.btns) do
        if valid(b) then
            local ok, s = pcall(function() return b:GetSelected() end)
            if ok and s == true then
                if mouse then PAD.unselect(b) elseif not sel then sel = b end
            end
        end
    end
    if mouse then return nil end
    local selName = sel and full(sel) or nil
    while #PAD.hits > 0 do
        local h = table.remove(PAD.hits, 1)
        if now - h.t <= PAD.STALE_S and P.acts[h.name] then
            local ls = PAD.lastSel
            if ls and not ls.paired and ls.name == h.name and math.abs(h.t - ls.t) < PAD.PAIR_S then
                ls.paired = true                       -- this press was already done through its selection
            else
                PAD.lastHit = { name = h.name, t = h.t }
                if selName == h.name then PAD.unselect(sel); PAD.lastHit.paired = true end
                if cfg.Verbose then log("controller: A (hover) -> " .. tostring(P.acts[h.name].kind)) end
                return P.acts[h.name]
            end
        end
    end
    if sel then
        PAD.unselect(sel)
        local lh = PAD.lastHit
        if lh and not lh.paired and lh.name == selName and now - lh.t < PAD.PAIR_S then
            lh.paired = true                           -- the selection of a press already done through hover + A
            return nil
        end
        PAD.lastSel = { name = selName, t = now }
        if cfg.Verbose and P.acts[selName] then log("controller: A (selection) -> " .. tostring(P.acts[selName].kind)) end
        return P.acts[selName]
    end
    return nil
end

-- Panel keys: the key bind only records the request; the tick does the work, and only while the panel is
-- open, filled and the keys option is on. A request older than half a second is dropped.
local function bindPanelKeys()
    if type(Key) ~= "table" and type(Key) ~= "userdata" then return end
    for name, act in pairs({ LEFT_ARROW = "minus", RIGHT_ARROW = "plus", RETURN = "loadstart" }) do
        local k = nil
        pcall(function() k = Key[name] end)
        if k then pcall(RegisterKeyBind, k, function() P.key = { act = act, t = os.clock() } end) end
    end
end
bindPanelKeys()

local function findHost()
    if valid(P.host) then return P.host end
    P.host = nil
    local h = nil
    pcall(function() h = FindFirstOf(HOST_CLASS) end)
    -- FindFirstOf can hand back the blueprint's template copy ("...:WidgetTree.Name"); only the live one will do.
    local hn = valid(h) and full(h) or ""
    if hn ~= "" and not hn:find("Default__", 1, true) and not hn:find(":WidgetTree.", 1, true) then P.host = h end
    return P.host
end

-- The station window just opened (after the automatic top-up, so the counts are what is left).
local function panelOpen(pc, api, ps)
    P.click, P.key = nil, nil
    PAD.hits, PAD.aDown = {}, nil
    -- Joined worlds: the panel's moves go to the server as requests (1.8.0), unless that is turned off.
    if not cfg.ShowPanel or not (isHost(pc) or cfg.WorkWhenJoined) then hidePanel(); return end
    hookPanelClicks()
    local host = findHost()
    if not host then return end
    local hn = full(host)
    if P.stage == "broken" and P.hostName == hn then return end
    if P.hostName ~= hn or not (P.ui and valid(P.ui.frame)) then
        P.acts, P.btns, P.ui, P.stage = {}, {}, nil, nil
        local ui = buildFrame(pc, host)
        P.hostName = hn
        if not ui then P.stage = "broken"; return end
        P.ui, P.stage = ui, "content"
    end
    local st = { ps = ps, api = api, filled = false }
    local owner = nil
    pcall(function() owner = ps:GetOwner() end)
    if valid(owner) then pcall(function() st.origin = owner:K2_GetActorLocation() end) end
    st.cls = valid(owner) and (full(owner):match("([%w_]+)_C_%d+") or "station") or "station"
    local nm = nil
    pcall(function() nm = ps.StationName:ToString() end)
    if type(nm) ~= "string" or nm == "" then nm = st.cls:gsub("^BP_Station_", ""):gsub("^BP_", ""):gsub("_", " ") end
    st.name = nm
    st.res, st.fuel = stationInvs(api, ps)
    st.recipes = readRecipes(pc, ps)
    P.st = st
end

local function doAction(pc, ui, st, act)
    local kind = act.kind
    if kind == "tile" then
        local rec = st.recipes[act.i]
        if not rec then return end
        if not rec.unlocked then setText(ui.status, "Not unlocked yet"); return end
        selectRecipe(ui, st, act.i)
        setText(ui.status, defaultStatus(st))
    elseif kind == "minus" or kind == "plus" or kind == "max" then
        if (st.max or 0) <= 0 then return end
        local q = st.qty or 0
        if kind == "minus" then q = q - 1 elseif kind == "plus" then q = q + 1 else q = st.max end
        st.qty = math.max(1, math.min(st.max, q))
        qtyFill(ui, st)
        detailFill(ui, st)
    elseif kind == "load" or kind == "loadstart" then
        local msg = loadRecipe(pc, st, kind == "loadstart")
        refresh(pc, ui, st)
        setText(ui.status, msg)
    elseif kind == "toggle" then
        local msg = toggleStation(pc, st)
        if msg then setText(ui.status, msg) end
        refresh(pc, ui, st)
    end
    toggleLabel(ui, st)
end

-- The game resets the bench slider to max 1 / value 1 whenever the backpack changes while a station window is open
-- (sf16 test 2026-09-29). When its max no longer matches ours, put our max and quantity back. Shared by panelTick
-- and the fast pass (fastRestore below); returns true when it had to put them back.
local function restoreSlider(ui, st)
    local sm = nil
    pcall(function() sm = ui.slider.InputSlider.MaxValue end)
    local want = math.max(1, st.max or 0)
    if type(sm) == "number" and math.abs(sm - want) > 0.5 then
        if (st.qty or 0) > want then st.qty = want end
        qtyFill(ui, st)
        detailFill(ui, st)
        return true
    end
    return false
end

-- Every tick while the station window is open: finish building, fill, then carry out a click or key.
local function panelTick(pc, api, ps)
    local ui, st = P.ui, P.st
    if not cfg.ShowPanel then if st then hidePanel() end; return end      -- turned off in Mod Menu while open
    if not (ui and st) then P.click, P.key = nil, nil; return end
    if not valid(ui.frame) then P.ui, P.hostName, P.stage = nil, nil, nil; return end
    if P.stage == "content" then
        if buildContent(ui) then P.stage = "config"
        else buildWarn("could not build the recipe panel"); P.stage = "broken"; showBtn(ui.frame, false) end
        return
    elseif P.stage == "config" then
        for _, fn in ipairs(ui.queue) do pcall(fn) end
        ui.queue = {}
        P.stage = "ready"
        return
    elseif P.stage ~= "ready" then
        return
    end
    st.ps = ps
    st.res, st.fuel = stationInvs(api, ps)
    if not st.filled then firstFill(pc, ui, st); P.click, P.key = nil, nil; return end
    if not st.padArmed then pcall(PAD.arm, pc, st) end

    local act = P.click
    P.click = nil
    if st.padArmed then                                -- 1.7.1: a pad press, routed like a click
        local okP, padAct = pcall(PAD.take, act ~= nil)
        if okP then
            if not act then act = padAct end
        else
            PAD.takeErrs = PAD.takeErrs + 1
            if PAD.takeErrs <= 3 then log("controller error: " .. tostring(padAct)) end
        end
    end
    local k = P.key
    P.key = nil
    if not act and k and cfg.PanelKeys and os.clock() - k.t < 0.5 then act = { kind = k.act } end
    if act then doAction(pc, ui, st, act) end

    -- The bench slider changes its own value (arrows, drag); follow it. But the game also resets it to max 1 /
    -- value 1 whenever the backpack changes while a station window is open (sf16 test 2026-09-29): when its max
    -- no longer matches ours, put our max and quantity back instead of following that reset.
    if ui.slider then
        restoreSlider(ui, st)
        local v = nil
        pcall(function() v = ui.slider:GetValue() end)
        -- 1.8.2: only follow a slider that CHANGED since the last read (the player's drag or arrow click). A value
        -- equal to the last read is our own write coming back stale, and adopting it would undo a plus/minus.
        local seen = st.sliderSeen
        if type(v) == "number" then st.sliderSeen = v end
        if type(v) == "number" and (st.max or 0) > 0 and v ~= seen then
            local q = math.max(1, math.min(st.max, math.floor(v + 0.5)))
            if q ~= st.qty then st.qty = q; detailFill(ui, st) end
        end
    end
    if st.startCheck and os.clock() >= st.startCheck then
        st.startCheck = nil
        if not isRunning(ps) then
            setText(ui.status, "The station did not start: it needs a full set of ingredients" ..
                (st.fuelSlots > 0 and " and fuel." or "."))
        end
    end
    toggleLabel(ui, st)
    -- 1.7.1: navigation links follow what this tick changed (recipe picked, LOAD grayed out, slots moved).
    if st.padArmed then
        local okW, errW = pcall(PAD.wire, ui, st)
        if not okW then
            PAD.takeErrs = PAD.takeErrs + 1
            if PAD.takeErrs <= 3 then log("controller links error: " .. tostring(errW)) end
        end
    end
end

-- Trigger ------------------------------------------------------------------------------------------
-- Fed once per opening, keyed on the station's full object name, so closing and reopening feeds
-- again (you may have topped a chest up) while holding one open does not loop.
local fedFor = nil
local errors, disabledByErrors = 0, false
local panelErrors = 0          -- the panel runs every tick while open: log its first few errors only

-- The station screen closed (or the world went away): store what was in it.
local function endOpen()
    if session then pcall(commitSession) end
    session = nil
    if fedFor then pcall(hidePanel) end
    fedFor = nil
end

local function tick()
    if not cfg.Enabled then endOpen(); return end
    local pc = localPC()
    if not valid(pc) then endOpen(); return end
    local host = nil
    local okH = pcall(function() host = pc:HasAuthority() end)
    -- Fail CLOSED: if authority cannot be read we do not know which kind of world this is.
    if not okH or type(host) ~= "boolean" then endOpen(); return end
    if not host and not cfg.WorkWhenJoined then endOpen(); return end
    -- Which way netMove goes. A job (a coroutine) only exists in a joined world, see runTick.
    NET.joined, NET.pc = not host, pc
    local api = stationAPI()
    if not valid(api) then return end
    local ps = nil
    pcall(function() ps = api.ProcessingStationComponent end)
    if not valid(ps) then endOpen(); return end
    local key = full(ps)
    if fedFor == key then
        -- Still open: keep noting what is in it, which is how it learns what you load by hand.
        pcall(sampleSession, pc, api, ps)
        -- rawpcall: a LOAD inside it waits for the server, and a wait only works inside the job itself.
        local okP, errP = rawpcall(panelTick, pc, api, ps)
        if not okP then
            panelErrors = panelErrors + 1
            if panelErrors <= 3 then log("panel error: " .. tostring(errP)) end
        end
        return
    end
    endOpen()
    fedFor = key
    feedStation(pc, api, ps)
    startSession(pc, api, ps)
    -- After the automatic top-up, so the panel shows what is left in the chests.
    local okP, errP = pcall(panelOpen, pc, api, ps)
    if not okP then log("panel error: " .. tostring(errP)) end
end

-- Mod Menu (optional) ------------------------------------------------------------------------------
local MODMENU_ID = "StationFeeder"
local mmRev = nil
local function modMenuApply(get)
    local wasEnabled = cfg.Enabled
    for _, k in ipairs({ "Enabled", "FeedMode", "FeedResources", "FeedFuel", "Radius",
                         "SkipLockedChests", "WorkWhenJoined", "RememberLastLoad", "KeepOne", "ShowPanel",
                         "PanelUsesBackpack", "ReturnLeftovers", "DefaultQuantity", "PanelKeys", "Verbose" }) do
        local v = get(k)
        if v ~= nil and type(v) == type(cfg[k]) then cfg[k] = v end
    end
    clampCfg()
    radiusUU = nil     -- re-read the radius after a settings change
    -- Turning the mod back on rearms the breaker, which would otherwise never fire again.
    if cfg.Enabled and not wasEnabled then errors, disabledByErrors = 0, false end
end
-- Mod Menu buttons arrive on the "action" channel. The first read is only a baseline, so a click
-- left over from before this mod started never fires.
local actionBaselined, lastAction = false, nil
local function modMenuActions()
    local ok, a = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".action") end)
    if not ok or type(a) ~= "string" then a = nil end
    if not actionBaselined then actionBaselined, lastAction = true, a; return end
    if a and a ~= "" and a ~= lastAction then
        lastAction = a
        if a:match("^([^#]+)") == "ForgetStations" then forgetAll() end
    end
end
local function modMenuSync()
    pcall(modMenuActions)
    local ok, rev = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. ".rev") end)
    if not ok or type(rev) ~= "number" or rev == mmRev then return end
    if mmRev ~= nil then log("settings updated from Mod Menu") end
    mmRev = rev
    modMenuApply(function(key)
        local okV, v = pcall(function() return ModRef:GetSharedVariable("ModMenu." .. MODMENU_ID .. "." .. key) end)
        if okV then return v end
        return nil
    end)
end

-- Game-thread work is never queued while the previous job is still pending. There is no
-- "is there anything to do" predicate, because the trigger itself has to be polled; the depth
-- guard is what matters and is the same one StorageSearch and Loot Sliders 1.0.4 ship. Queueing unconditionally is what aborted UE4SS during a world load in Open All, and
-- what stacked up eight jobs deep in Loot Sliders. ExecuteInGameThread is called THROUGH pcall and a
-- failed send releases the flag at once; a job that never runs is released after 5 s so the mod can
-- never latch itself off for the session.
local queued, queuedAt = false, 0
-- Main loop ON THE GAME THREAD. UE4SS runs LoopAsync callbacks on a separate thread without the lock
-- its game-thread side holds, so a LoopAsync mod's Lua can run on two OS threads at once (measured
-- 2026-09-23: ~1,480 overlaps in 150 jobs on stable and latest UE4SS alike; on the newer build it
-- corrupted a mod's Lua state under load). LoopInGameThreadWithDelay keeps all of it on one thread.
-- Joined worlds run the tick as a job that can wait for the server; hosts and solo run it straight.
-- NET.joined is what the last tick found, so the first tick after joining still runs straight: it only
-- reads, since a station window cannot be open that early.
local function runTick()
    if NET.job then
        local e = jobPump()
        if e then error(e, 0) end
        return
    end
    if not NET.joined then tick(); return end
    NET.job = { co = coroutine.create(tick) }
    local e = jobPump()
    if e then error(e, 0) end
end
local function mainTick()
    pcall(modMenuSync)
    local ok, err = pcall(runTick)
    if not ok then
        errors = errors + 1
        if errors <= 3 then log("tick error: " .. tostring(err)) end
        if errors >= 25 and not disabledByErrors then
            cfg.Enabled = false
            disabledByErrors = true
            log("too many errors, disabling for this session")
        end
    end
end
local okLoop = pcall(LoopInGameThreadWithDelay, 300, function()
    local ok, err = pcall(mainTick)
    if not ok then print("main loop error: " .. tostring(err) .. "\n") end
end)
if okLoop then print("[StationFeeder] main loop on the game thread\n") end
if okLoop then
    pcall(LoopInGameThreadWithDelay, 60, function()   -- not 50: that is the pad sampler, and the offline test finds loops by period
        if not (NET.job and NET.job.pred) then return end
        local ok, e = rawpcall(jobPump)
        if ok and e then log("job error: " .. tostring(e)) end
    end)
end
-- 1.8.2: a fast pass that ONLY puts the bench slider back after the game's reset (see restoreSlider), so the number
-- shows 1 for about 100 ms instead of up to 300 ms. Returns at once unless a station panel is ready, and does nothing
-- while a joined-world job is mid-flight (the job owns the panel then). No FindAllOf: it reads P.ui / P.st only.
-- 100 ms: the other loops are 300, 60 and PAD.SAMPLE_MS (50), and the offline test finds loops by period.
local function fastRestore()
    local ui, st = P.ui, P.st
    if not (ui and st and ui.slider) then return end
    if P.stage ~= "ready" or not st.filled or NET.job then return end
    if not (cfg.Enabled and cfg.ShowPanel) then return end
    if not valid(ui.frame) or not valid(ui.slider) then return end
    restoreSlider(ui, st)
end
if okLoop then
    pcall(LoopInGameThreadWithDelay, 100, function() pcall(fastRestore) end)
end
-- 1.7.1: the controller's A sampler (PAD.sample), also on the game thread. It returns at once unless the recipe
-- panel is open and ready, so it costs nothing outside a station window. Not on the old LoopAsync fallback:
-- there a pad press still works through the selection route.
if okLoop and not pcall(LoopInGameThreadWithDelay, PAD.SAMPLE_MS, function() pcall(PAD.sample) end) then
    log("controller: no A sampler; pad presses rely on selection only")
end
if not okLoop then
    -- Older UE4SS without LoopInGameThreadWithDelay: the previous guarded LoopAsync route.
    local queued, queuedAt = false, 0
    LoopAsync(300, function()
        if queued and os.clock() - queuedAt > 5 then queued = false end
        if queued then return false end
        queued, queuedAt = true, os.clock()
        local sent = pcall(ExecuteInGameThread, function() queued = false; pcall(mainTick) end)
        if not sent then queued = false end
        return false
    end)
end

log("loaded v" .. VERSION .. ", mode '" .. tostring(cfg.FeedMode) .. "'. Stations restock from nearby chests when you open them.")
