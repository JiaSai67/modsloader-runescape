-- Station Feeder: recipe panel rules (pure Lua, no game calls, so tools/test_stationfeeder_16_offline.py
-- can run every rule here against fixtures). main.lua reads the game and hands plain tables and numbers in.
--
-- Where each rule comes from (in-game probes 2026-09-28/29, docs/design-station-feeder-recipes.md):
--   * Recipe order: the live ProgressComponent.RecipesUnlocked set iterates in unlock order (new unlocks are
--     appended last), so "oldest first" is that order. Locked recipes go last and show as "?".
--   * Craft time is a random value in [Min, Max] per craft, not scaled by the station's ProcessingRate.
--   * Fuel: one unit is burned at START and one more every FuelValue seconds of running; stopping throws away
--     what is left of the burning unit. A batch of Q crafts is covered by ceil(Q * Max / FuelValue) units.
--   * Station -> chest moves work; a move onto a slot holding a DIFFERENT item shuffles that stack, so a
--     return only ever targets a slot holding the same item, or an empty slot.

local R = {}

local floor, max, min = math.floor, math.max, math.min

local function int(x)
    if type(x) ~= "number" or x ~= x then return 0 end
    return floor(x)
end

-- Fuel -----------------------------------------------------------------------------------------------
-- Units a fresh start of q crafts can burn at most (every craft at its longest time).
-- nil when the fuel's burn time is unknown or zero (swamp tar reads 0): the panel shows "?" then.
function R.fuelUnits(q, tmax, fuelValue)
    q = int(q)
    if q <= 0 then return 0 end
    if type(tmax) ~= "number" or tmax <= 0 then return 0 end
    if type(fuelValue) ~= "number" or fuelValue <= 0 then return nil end
    -- The small epsilon keeps 10 x 12 s / 120 s at exactly 1 despite float rounding.
    return math.ceil(q * tmax / fuelValue - 1e-9)
end

-- Units still to add, counting what already sits in the fuel slot.
function R.fuelToAdd(q, tmax, fuelValue, inSlot)
    local u = R.fuelUnits(q, tmax, fuelValue)
    if u == nil then return nil end
    return max(0, u - max(0, int(inSlot)))
end

-- Sources --------------------------------------------------------------------------------------------
-- What the chests may give of one item. With keepOne the mod never takes the last one out of your
-- chests: a total of 1 gives nothing, 5 gives 4. It applies to chests only, never to the backpack.
function R.chestAvail(total, keepOne)
    total = max(0, int(total))
    if keepOne then return max(0, total - 1) end
    return total
end

-- Split `want` more of an item between chests and backpack. Chests first. The backpack is only ever
-- used for a panel CLICK (LOAD, LOAD & START) with the backpack option on; the automatic top-up that
-- runs when you open a station never touches it. Returns fromChests, fromBackpack.
function R.planSources(want, chestAvail, bagHave, fromClick, useBag)
    want = max(0, int(want))
    local c = min(want, max(0, int(chestAvail)))
    local b = 0
    if fromClick == true and useBag == true then
        b = min(want - c, max(0, int(bagHave)))
    end
    return c, b
end

-- How many of an item count as "have" on the panel.
function R.have(chestTotal, bagCount, stationCount, keepOne, useBag)
    return R.chestAvail(chestTotal, keepOne) + (useBag and max(0, int(bagCount)) or 0) + max(0, int(stationCount))
end

-- Counting -------------------------------------------------------------------------------------------
-- A recipe can list the same item twice; the station needs the sum.
-- ings: { { key =, need =, cap = (MaxStackSize or nil), data = (any) }, ... }
function R.merge(ings)
    local out, at = {}, {}
    for _, g in ipairs(ings or {}) do
        local n = int(g.need)
        if g.key and n > 0 then
            local e = at[g.key]
            if e then e.need = e.need + n
            else
                e = { key = g.key, need = n, cap = g.cap, data = g.data }
                at[g.key] = e
                out[#out + 1] = e
            end
        end
    end
    return out
end

-- Whole crafts the player can supply. haveOf(key) -> count. 0 for a recipe with no ingredients.
function R.makeable(ings, haveOf)
    local best = nil
    for _, g in ipairs(ings) do
        local n = floor(max(0, int(haveOf(g.key))) / g.need)
        if best == nil or n < best then best = n end
    end
    return best or 0
end

-- Crafts the station can hold at once. Each ingredient gets floor(S / k) of the S resource slots (the
-- remainder going to the first ones) at MaxStackSize each. Furnace bronze: 2 slots, 99 per slot, 3 per
-- bar -> 33. `blocked` = slots held by other items that will stay in the station.
function R.capacity(ings, slots, blocked)
    local k = #ings
    local s = int(slots) - max(0, int(blocked))
    if k == 0 or s < k then return 0 end
    local per, extra = floor(s / k), s % k
    local c = nil
    for i, g in ipairs(ings) do
        local mySlots = per + ((i <= extra) and 1 or 0)
        local cap = (type(g.cap) == "number" and g.cap > 0) and g.cap or 1
        local n = floor(mySlots * cap / g.need)
        if c == nil or n < c then c = n end
    end
    return c or 0
end

function R.maxQuantity(makeable, capacity)
    return max(0, min(int(makeable), int(capacity)))
end

-- The starting quantity when a recipe is selected. mode "last" reuses the station's last quantity.
function R.defaultQty(mode, last, maxQ)
    maxQ = max(0, int(maxQ))
    if maxQ == 0 then return 0 end
    if mode == "last" and type(last) == "number" and last >= 1 then return min(int(last), maxQ) end
    return maxQ
end

-- Order ----------------------------------------------------------------------------------------------
-- recs: the station's recipe list in its own (data table) order, each { key =, unlocked = bool }.
-- setOrder: recipe key -> position in the live RecipesUnlocked set (1 = unlocked first).
-- Unlocked recipes first, oldest unlock first; an unlocked recipe missing from the set read (should not
-- happen) after those, in station order; locked recipes last, in station order. Returns a NEW list.
function R.order(recs, setOrder)
    setOrder = setOrder or {}
    local tmp = {}
    for i, r in ipairs(recs or {}) do
        local grp, rank
        if r.unlocked then
            local p = setOrder[r.key]
            if p then grp, rank = 1, p else grp, rank = 2, i end
        else
            grp, rank = 3, i
        end
        tmp[#tmp + 1] = { r = r, grp = grp, rank = rank, i = i }
    end
    table.sort(tmp, function(a, b)
        if a.grp ~= b.grp then return a.grp < b.grp end
        if a.rank ~= b.rank then return a.rank < b.rank end
        return a.i < b.i
    end)
    local out = {}
    for i, t in ipairs(tmp) do out[i] = t.r end
    return out
end

-- recs: R.order output with .unlocked and .n (makeable) set by the scan. cap: how many tiles the panel has.
-- 2026-10-13: a station makes a recipe the game still counts as locked once you hold what it needs (Ground
-- Sandstone), so the scan marks those unlocked and this moves them ahead of the "?" tiles. With more unlocked
-- recipes than tiles, the ones you can make now come first so none of them is cut off. Order inside each group
-- is kept. Returns a NEW list.
function R.usableFirst(recs, cap)
    local unlocked = 0
    for _, r in ipairs(recs or {}) do if r.unlocked then unlocked = unlocked + 1 end end
    local over = unlocked > int(cap)
    local a, b, c = {}, {}, {}
    for _, r in ipairs(recs or {}) do
        if not r.unlocked then c[#c + 1] = r
        elseif over and int(r.n) <= 0 then b[#b + 1] = r
        else a[#a + 1] = r end
    end
    for _, r in ipairs(b) do a[#a + 1] = r end
    for _, r in ipairs(c) do a[#a + 1] = r end
    return a
end

-- What a tile shows. Locked: "?" and nothing else (no icon, no name, no count), and not selectable.
function R.tile(rec, n)
    if not rec then return nil end
    if not rec.unlocked then
        return { mark = "?", icon = false, name = nil, count = "", selectable = false }
    end
    return { mark = "", icon = true, name = rec.name, count = tostring(max(0, int(n))), selectable = true }
end

-- Text -----------------------------------------------------------------------------------------------
local function num(x)
    local r = floor(x + 0.5)
    if math.abs(x - r) < 0.05 then return tostring(r) end
    return string.format("%.1f", x)
end

function R.timeText(tmin, tmax)
    if type(tmin) ~= "number" or type(tmax) ~= "number" or tmax <= 0 then return nil end
    if tmin <= 0 or math.abs(tmin - tmax) < 0.05 then return num(tmax) .. " s" end
    return num(tmin) .. "-" .. num(tmax) .. " s"
end

-- "Makes 1 Wool Cloth - 8-12 s each"
function R.makesText(count, name, tmin, tmax)
    local c = max(1, int(count))
    local s = "Makes " .. c .. " " .. tostring(name or "?")
    local t = R.timeText(tmin, tmax)
    if t then s = s .. " - " .. t .. " each" end
    return s
end

function R.haveNeedText(have, need)
    return tostring(max(0, int(have))) .. "/" .. tostring(max(0, int(need)))
end

-- Leftovers ------------------------------------------------------------------------------------------
-- Station slots whose item the chosen recipe does not use. slots: { { slot =, key =, count = } }.
function R.leftovers(slots, recipeKeys)
    local out = {}
    for _, s in ipairs(slots or {}) do
        if not recipeKeys[s.key] then out[#out + 1] = s end
    end
    return out
end

-- Where one leftover stack goes. chests: nearest first, each { n = slot count, s = { [slot] = { key =, n = } } }
-- (a missing entry is an empty slot). First a chest that already holds this item (a same-item stack
-- with room, else that chest's empty slot), nearest first; then the nearest chest with an empty slot.
-- Never a slot holding a different item. cap = the item's MaxStackSize (nil: same-item stacks are not
-- used, an empty slot still takes the whole amount). Returns chestIndex, slot, amount or nil.
function R.returnTarget(chests, key, cap, amount)
    amount = max(0, int(amount))
    if amount <= 0 then return nil end
    local hasCap = type(cap) == "number" and cap > 0
    for ci, c in ipairs(chests or {}) do
        local holds, same, empty, room = false, nil, nil, 0
        for i = 0, int(c.n) - 1 do
            local s = c.s and c.s[i]
            if s then
                if s.key == key then
                    holds = true
                    if same == nil and hasCap and s.n < cap then same, room = i, cap - s.n end
                end
            elseif empty == nil then
                empty = i
            end
        end
        if holds and same ~= nil then return ci, same, min(amount, room) end
        if holds and empty ~= nil then return ci, empty, hasCap and min(amount, cap) or amount end
    end
    for ci, c in ipairs(chests or {}) do
        for i = 0, int(c.n) - 1 do
            if not (c.s and c.s[i]) then return ci, i, hasCap and min(amount, cap) or amount end
        end
    end
    return nil
end

-- Default selection ----------------------------------------------------------------------------------
-- ordered: R.order output, each with .key, .unlocked, .ingKeys (set), .n (makeable).
-- 1. the recipe remembered for this station; 2. the recipe that uses everything already in the station;
-- 3. the first unlocked recipe you can make; 4. the first unlocked recipe. nil if none is unlocked.
function R.pickDefault(ordered, rememberedKey, stationKeys)
    local firstUnlocked, firstMakeable = nil, nil
    for i, r in ipairs(ordered or {}) do
        if r.unlocked then
            if rememberedKey and r.key == rememberedKey then return i end
            firstUnlocked = firstUnlocked or i
            if firstMakeable == nil and int(r.n) > 0 then firstMakeable = i end
        end
    end
    if stationKeys and next(stationKeys) ~= nil then
        for i, r in ipairs(ordered or {}) do
            if r.unlocked and r.ingKeys then
                local all = true
                for k in pairs(stationKeys) do if not r.ingKeys[k] then all = false; break end end
                if all then return i end
            end
        end
    end
    return firstMakeable or firstUnlocked
end

-- Station memory lines -------------------------------------------------------------------------------
-- 1.4.0 wrote 6 tab-separated fields: class x y z resources fuels. 1.6.0 adds two optional ones: the
-- recipe picked in the panel and its quantity. Old lines still load, and a line with no recipe is still
-- written in the old 6-field form.
local function splitNames(s)
    local t = {}
    for p in tostring(s or ""):gmatch("[^;]+") do t[#t + 1] = p end
    return t
end

function R.parseMemoryLine(line)
    line = tostring(line or ""):gsub("\r$", "")
    if line == "" or line:sub(1, 1) == "#" then return nil end
    local f = {}
    for p in (line .. "\t"):gmatch("([^\t]*)\t") do f[#f + 1] = p end
    if #f ~= 6 and #f ~= 8 then return nil end
    local x, y, z = tonumber(f[2]), tonumber(f[3]), tonumber(f[4])
    if f[1] == "" or not (x and y and z) then return nil end
    local m = { cls = f[1], x = x, y = y, z = z, res = splitNames(f[5]), fuel = splitNames(f[6]) }
    if #f == 8 and f[7] ~= "" then
        m.rec = f[7]
        m.qty = tonumber(f[8])
    end
    return m
end

function R.formatMemoryLine(m)
    local s = string.format("%s\t%.1f\t%.1f\t%.1f\t%s\t%s", m.cls, m.x, m.y, m.z,
        table.concat(m.res or {}, ";"), table.concat(m.fuel or {}, ";"))
    if m.rec and m.rec ~= "" then
        s = s .. "\t" .. m.rec .. "\t" .. tostring(int(m.qty))
    end
    return s
end

return R
